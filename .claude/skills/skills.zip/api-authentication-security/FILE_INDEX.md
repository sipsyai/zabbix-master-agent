# API Authentication & Security Skill - File Index

## Directory Structure

```
api-authentication-security/
├── SKILL.md                          (Main skill documentation)
├── README.md                         (Quick start guide)
├── SKILL_SUMMARY.md                  (Skill summary and overview)
├── FILE_INDEX.md                     (This file)
├── scripts/                          (Python automation scripts)
│   ├── zabbix_auth_manager.py       (809 lines)
│   ├── zabbix_token_manager.py      (655 lines)
│   ├── zabbix_rbac_manager.py       (695 lines)
│   ├── validate_security_config.py  (710 lines)
│   └── audit_security.py            (639 lines)
└── examples/                         (Configuration examples)
    ├── user_config.json
    ├── usergroup_config.yaml
    ├── role_config.json
    ├── token_config.yaml
    ├── ldap_config.json
    ├── saml_config.yaml
    ├── security_policies.yaml
    └── bulk_users.yaml
```

**Total**: 16 files, ~213KB, 3,508 lines of Python code

---

## File Descriptions

### 📘 Documentation Files

#### SKILL.md
**Purpose**: Complete skill documentation with progressive disclosure pattern
**Size**: ~50KB
**Sections**:
- Overview and quick start
- Core capabilities (authentication, users, RBAC, security)
- Detailed workflows (secure API access, user onboarding, LDAP integration, security audit, token rotation)
- Security best practices
- Troubleshooting guide
- API methods reference
- Credential management patterns
- Compliance considerations

**Key Features**:
- Progressive disclosure with reference to example files
- Quick start examples for immediate use
- Comprehensive workflow documentation
- Security-first approach
- Real-world use cases

#### README.md
**Purpose**: Quick start guide and reference
**Size**: ~15KB
**Sections**:
- Prerequisites and installation
- Quick start examples
- Common tasks
- Directory structure overview
- Scripts overview
- Best practices summary
- Troubleshooting guide
- Security hardening checklist

**Key Features**:
- Fast onboarding
- Copy-paste ready examples
- Essential information only
- Links to detailed documentation

#### SKILL_SUMMARY.md
**Purpose**: High-level skill overview and success metrics
**Size**: ~12KB
**Sections**:
- Skill overview
- File inventory
- Key features matrix
- Use cases covered
- Security best practices
- Compliance coverage
- Technical specifications
- Testing and deployment recommendations
- Maintenance tasks

**Key Features**:
- Executive summary
- Success metrics
- Deployment guidance
- Maintenance schedule

#### FILE_INDEX.md
**Purpose**: This file - complete file reference
**Contents**: Detailed description of every file in the skill

---

### 🐍 Python Scripts (5 scripts, 3,508 lines total)

#### 1. scripts/zabbix_auth_manager.py
**Lines**: 809
**Purpose**: Authentication and user account management

**Main Functions**:
- `login()` - Username/password authentication
- `logout()` - Session termination
- `test_auth()` - Authentication validation
- `create_user(config)` - Create new user account
- `update_user(username, updates)` - Modify user properties
- `delete_user(username)` - Remove user account
- `list_users(role_filter)` - List all users with filtering
- `get_user(username)` - Get detailed user information
- `add_to_group(username, group_name)` - Add user to user group
- `enable_2fa(username)` - Enable two-factor authentication
- `configure_ldap(config)` - Set up LDAP authentication
- `test_ldap(username, password)` - Test LDAP connection
- `set_auth_method(method)` - Change authentication method
- `disable_inactive_users(days)` - Cleanup inactive accounts

**CLI Commands**:
```bash
login                    # Test authentication
test-auth               # Validate credentials
create-user             # Create new user
update-user             # Update user properties
delete-user             # Delete user account
list-users              # List all users
get-user                # Get user details
add-to-group            # Add user to group
enable-2fa              # Enable 2FA
configure-ldap          # Configure LDAP
test-ldap               # Test LDAP auth
set-auth-method         # Change auth method
disable-inactive        # Disable inactive users
```

**Error Handling**: Comprehensive exception handling, user-friendly messages, debug mode

**Environment Variables**: `ZABBIX_URL`, `ZABBIX_USERNAME`, `ZABBIX_PASSWORD`, `ZABBIX_API_TOKEN`

---

#### 2. scripts/zabbix_token_manager.py
**Lines**: 655
**Purpose**: API token lifecycle management

**Main Functions**:
- `create_token(name, expires_in, description, username)` - Generate new API token
- `list_tokens(active_only, expiring_in)` - List tokens with filtering
- `get_token_info(name)` - Get detailed token information
- `revoke_token(name, token_id, reason)` - Revoke/delete token
- `revoke_expired_tokens()` - Cleanup expired tokens
- `test_token(token_value)` - Validate token
- `rotate_token(name, new_name, expires_in)` - Token rotation workflow

**CLI Commands**:
```bash
create                  # Create new API token
list                    # List all tokens
info                    # Get token details
revoke                  # Revoke specific token
revoke-expired          # Remove expired tokens
test                    # Test token validity
rotate                  # Rotate token
```

**Features**:
- Token expiration management (30d, 90d, 1y formats)
- Automated rotation workflow
- Expiration monitoring and alerts
- Secure token display (one-time only)

**Best Practices Implemented**:
- Default 90-day expiration
- Rotation reminders
- Secure storage recommendations
- Usage tracking

---

#### 3. scripts/zabbix_rbac_manager.py
**Lines**: 695
**Purpose**: Role-based access control and permission management

**Main Functions**:
- `list_roles()` - List all roles
- `show_role(name)` - Show detailed role information
- `create_role(config)` - Create custom role
- `update_role(name, updates)` - Modify role properties
- `delete_role(name)` - Remove custom role
- `assign_role(username, role_name)` - Assign role to user
- `show_user_permissions(username)` - Display user permissions
- `test_permission(username, operation)` - Test if user has permission
- `list_usergroups()` - List all user groups
- `create_usergroup(config)` - Create new user group
- `show_usergroup(name)` - Show group details

**CLI Commands**:
```bash
list-roles              # List all roles
show-role               # Show role details
create-role             # Create custom role
update-role             # Update role
delete-role             # Delete custom role
assign-role             # Assign role to user
show-permissions        # Show user permissions
test-permission         # Test permission
list-usergroups         # List user groups
show-usergroup          # Show group details
create-usergroup        # Create user group
```

**Permission Types Supported**:
- UI element access
- API method access
- Action permissions (dashboard editing, maintenance, etc.)
- Host group access
- Service access

**Features**:
- Built-in role management (Super admin, Admin, User, Guest)
- Custom role creation with granular permissions
- Permission testing and validation
- User group management
- Permission inheritance visualization

---

#### 4. scripts/validate_security_config.py
**Lines**: 710
**Purpose**: Security configuration validation against best practices

**Main Functions**:
- `validate_passwords()` - Check password policies
- `validate_ssl_tls()` - Validate SSL/TLS configuration
- `validate_authentication()` - Check auth settings
- `validate_sessions()` - Review session management
- `validate_access_control()` - Audit access controls
- `validate_api_tokens()` - Check token compliance
- `run_all_checks()` - Execute all validations
- `generate_report(output_file)` - Create validation report
- `print_summary()` - Display summary statistics

**CLI Commands**:
```bash
--check-all             # Run all security checks
--check-passwords       # Validate password policies
--check-ssl             # Check SSL/TLS config
--check-auth            # Validate authentication
--check-sessions        # Review session settings
--check-access          # Audit access control
--check-tokens          # Check token compliance
--report FILE           # Generate JSON report
```

**Validation Checks**:
- Password minimum length (12+ chars)
- Password complexity requirements
- SSL certificate validation and expiry
- TLS version (1.2+ required)
- Authentication method configuration
- Session timeout settings
- Auto-login settings
- Inactive user detection
- Token expiration compliance

**Output**:
- Color-coded results (✓ PASSED / ✗ FAILED)
- Severity levels (🔴 Critical, 🟠 High, 🟡 Medium, 🟢 Low)
- Detailed recommendations
- Summary statistics
- JSON report export

---

#### 5. scripts/audit_security.py
**Lines**: 639
**Purpose**: Comprehensive security auditing and compliance reporting

**Main Functions**:
- `audit_user_activity()` - Analyze user activity patterns
- `audit_permissions()` - Review access permissions
- `audit_tokens()` - Audit API token usage
- `audit_authentication_config()` - Check auth configuration
- `get_audit_logs(days)` - Retrieve audit logs
- `generate_compliance_report()` - Create compliance report
- `generate_report(output_file)` - Export audit results

**CLI Commands**:
```bash
--full                  # Run complete audit
--user-activity         # Audit user activity
--permission-review     # Review permissions
--token-audit           # Audit API tokens
--auth-config           # Audit auth settings
--audit-logs            # Retrieve audit logs
--compliance-report     # Generate compliance report
--days N                # Audit log period
--output FILE           # Export to JSON
--format json|pdf       # Report format
```

**Audit Areas**:
1. **User Activity**
   - Active vs inactive users
   - Failed login attempts
   - Never logged in accounts
   - Last access tracking

2. **Permissions**
   - Role distribution
   - Admin account count
   - User group analysis
   - Permission anomalies

3. **API Tokens**
   - Active token count
   - Expired tokens
   - Tokens expiring soon
   - Tokens without expiry

4. **Authentication**
   - Auth method (Internal/LDAP/SAML)
   - Password policies
   - Login attempt limits
   - 2FA status

5. **Audit Logs**
   - Security events
   - Configuration changes
   - Permission modifications
   - Failed authentications

6. **Compliance**
   - SOC2 requirements
   - ISO 27001 controls
   - GDPR compliance
   - PCI-DSS requirements
   - Compliance score calculation

**Output**:
- Comprehensive JSON report
- Summary statistics
- Compliance score (percentage)
- Actionable recommendations
- Event analysis by type and user

---

### 📋 Configuration Examples (8 files)

#### examples/user_config.json
**Purpose**: User account creation template
**Size**: ~0.7KB

**Contents**:
- Basic user information (username, name, surname)
- Password (temporary)
- User group assignment
- Role assignment (roleid)
- Auto-login and auto-logout settings
- Language and theme preferences
- Media/notification configuration

**Use Cases**:
- Single user creation
- Template for automation
- Reference for user structure

---

#### examples/usergroup_config.yaml
**Purpose**: User group configuration templates
**Size**: ~2.5KB

**Contents**:
- 4 complete user group examples:
  1. Operations Team (production access)
  2. Developers (development environment)
  3. Read-Only Viewers
  4. Security Team (LDAP authentication)
- Permission levels (deny, read-only, read-write)
- GUI access types
- Tag filters for granular access
- Debug mode settings

**Features**:
- Multiple real-world scenarios
- Permission reference guide
- Tag-based filtering examples
- Access type documentation

---

#### examples/role_config.json
**Purpose**: Custom role definition template
**Size**: ~1.2KB

**Contents**:
- Complete DevOps Engineer role example
- UI access permissions (monitoring, inventory, reports)
- Service access rules
- Action permissions (dashboards, maps, maintenance, scripts)
- API access configuration
- API method deny list

**Features**:
- Granular permission control
- UI element access
- API method restrictions
- Action-level permissions
- Real-world DevOps role

---

#### examples/token_config.yaml
**Purpose**: API token management examples and best practices
**Size**: ~4.5KB

**Contents**:
- 4 token examples (CI/CD, monitoring, integration, reporting)
- Token rotation schedule
- Best practices guide
- Naming conventions
- Storage methods (env vars, .env files, Kubernetes secrets, Vault, AWS)
- Expiration period reference
- Security guidelines

**Features**:
- Multiple use case examples
- Storage pattern examples
- Rotation workflows
- Security best practices

---

#### examples/ldap_config.json
**Purpose**: LDAP/Active Directory authentication setup
**Size**: ~1.8KB

**Contents**:
- LDAP server connection settings
- Search and bind configuration
- Group mapping to Zabbix roles
- Advanced settings (referrals, version, timeout)
- Test authentication setup
- Security notes and recommendations

**Features**:
- Complete LDAP configuration
- Group-to-role mapping
- Security best practices
- Test configuration included

---

#### examples/saml_config.yaml
**Purpose**: SAML SSO authentication configuration
**Size**: ~6.2KB

**Contents**:
- Basic SAML configuration
- Certificate management (IdP and SP)
- Attribute mapping (username, email, groups)
- Group-to-role mapping
- JIT (Just-In-Time) provisioning
- IdP-specific examples:
  - Okta
  - Azure AD
  - Google
- Security settings
- Troubleshooting guide
- Testing procedures
- Compliance considerations

**Features**:
- Complete SAML setup guide
- Multiple IdP examples
- Certificate templates
- Troubleshooting section
- Testing workflow

---

#### examples/security_policies.yaml
**Purpose**: Comprehensive security policy templates
**Size**: ~12KB

**Contents**:
- Password policy (length, complexity, expiration)
- Session management policy (timeouts, auto-login, concurrent sessions)
- Authentication policy (methods, login attempts, brute force protection)
- 2FA policy (enforcement by role, methods, backup codes)
- API access policy (authentication, tokens, rate limiting, IP restrictions)
- Access control policy (RBAC, provisioning, deprovisioning)
- Audit and compliance policy (logging, monitoring, frameworks)
- Data protection policy (encryption, SSL/TLS, sensitive data)
- Incident response policy (detection, response, escalation)
- User management policy (onboarding, offboarding, reviews)
- Third-party integration policy
- Compliance mappings (SOC2, ISO 27001, GDPR, PCI-DSS)
- Policy enforcement (automated checks, manual reviews)
- Training and awareness requirements

**Features**:
- Enterprise-ready policies
- Compliance framework mappings
- Detailed enforcement rules
- Real-world configurations
- Security by design

---

#### examples/bulk_users.yaml
**Purpose**: Bulk user operations and automation
**Size**: ~9KB

**Contents**:
- Bulk user creation (multiple users at once)
- Bulk user updates (modify multiple users)
- Bulk disable operations (inactive users)
- Bulk delete operations (contractors, temp users)
- Bulk group assignments
- Bulk role changes
- CSV import template and examples
- Department-based operations
- Scheduled bulk operations
- Bulk token management
- Error handling strategies
- Validation rules
- Reporting configuration
- Python script usage examples
- Best practices

**Features**:
- Multiple operation types
- CSV import support
- Department templates
- Automation schedules
- Error handling
- Comprehensive validation

---

## Usage Patterns

### Quick Start Pattern
1. Read README.md for quick orientation
2. Review SKILL.md for complete documentation
3. Start with user_config.json for basic operations
4. Use scripts with example configs

### Security Hardening Pattern
1. Review security_policies.yaml
2. Run validate_security_config.py --check-all
3. Implement recommended fixes
4. Run audit_security.py --full
5. Address compliance gaps

### SSO Integration Pattern
1. Choose IdP (LDAP or SAML)
2. Review ldap_config.json or saml_config.yaml
3. Use zabbix_auth_manager.py to configure
4. Test with test users
5. Enable authentication method
6. Monitor and validate

### Token Management Pattern
1. Review token_config.yaml for best practices
2. Create tokens with zabbix_token_manager.py
3. Set appropriate expiration (90 days recommended)
4. Store securely (secrets manager)
5. Monitor expiration with list --expiring-in
6. Rotate regularly

### User Lifecycle Pattern
1. Create user with zabbix_auth_manager.py
2. Assign role with zabbix_rbac_manager.py
3. Add to groups with add-to-group
4. Generate token if needed
5. Monitor activity with audit_security.py
6. Disable when inactive (disable-inactive)

---

## Script Dependencies

All scripts require:
- Python 3.7+
- requests library
- Standard library modules (json, sys, os, datetime, argparse)

Optional:
- pyyaml (for YAML config files)
- boto3 (for AWS Secrets Manager integration)
- hvac (for HashiCorp Vault integration)

---

## Environment Variables

All scripts support:
- `ZABBIX_URL` - Zabbix server URL (required)
- `ZABBIX_API_TOKEN` - API token for authentication (recommended)
- `ZABBIX_USERNAME` - Username for authentication (alternative)
- `ZABBIX_PASSWORD` - Password for authentication (alternative)

---

## Output Formats

### Console Output
- UTF-8 encoded
- Color-coded (✓, ✗, ⚠, ℹ)
- Progress indicators
- Summary statistics

### JSON Reports
- Structured data
- Timestamp included
- Complete audit trail
- Machine-readable

### Log Files
- Detailed operation logs
- Error tracking
- Success/failure records

---

## Security Considerations

All files follow security best practices:
- No hardcoded credentials
- Environment variable support
- Secrets manager integration patterns
- Secure communication (HTTPS/TLS)
- Input validation
- Error handling
- Audit logging

---

## Maintenance

### Files to Update Regularly
- security_policies.yaml (as policies evolve)
- saml_config.yaml (certificate rotation)
- ldap_config.json (server changes)

### Files that are Static
- Scripts (unless bugs found or features added)
- user_config.json (template)
- role_config.json (template)

---

## Version Information

**Created**: 2025-11-14
**Version**: 1.0
**Python Version**: 3.7+
**Zabbix Version**: 6.0+
**Status**: Production Ready

---

## Summary Statistics

- **Total Files**: 16
- **Total Size**: ~213KB
- **Python Code**: 3,508 lines
- **Documentation**: 3 files (~77KB)
- **Scripts**: 5 files (~135KB)
- **Examples**: 8 files (~38KB)
- **Average Script Size**: 701 lines
- **Comments/Documentation**: ~25% of code
- **Error Handlers**: Comprehensive in all scripts
- **Use Cases Covered**: 15+
- **Compliance Frameworks**: 4 (SOC2, ISO27001, GDPR, PCI-DSS)
- **Authentication Methods**: 5 (Internal, LDAP, SAML, HTTP, 2FA)

---

This file index provides complete reference to all files in the API Authentication & Security skill.
