# API Authentication & Security for Zabbix

Complete authentication and security management for Zabbix API including user management, RBAC, tokens, SSL/TLS, SSO integration, and security auditing.

## Quick Start

### Prerequisites

- Python 3.7+
- Zabbix 6.0+
- Required Python packages:
  ```bash
  pip install requests pyyaml
  ```

### Basic Authentication

```bash
# Set environment variables
export ZABBIX_URL="https://zabbix.example.com"
export ZABBIX_API_TOKEN="your-api-token-here"

# Test authentication
python scripts/zabbix_auth_manager.py test-auth

# Create API token
python scripts/zabbix_token_manager.py create \
  --name "automation-token" \
  --expires "90d" \
  --description "Token for automation"
```

## Key Features

### 1. Authentication Management
- Username/password authentication
- API token management
- Session management
- SSO integration (LDAP, SAML, HTTP auth)
- Two-factor authentication (2FA)

### 2. User Management
- Create, update, delete users
- Bulk user operations
- User lifecycle management
- Activity monitoring
- Inactive user cleanup

### 3. Role-Based Access Control (RBAC)
- Built-in and custom roles
- Granular permissions
- User group management
- Permission testing and validation

### 4. Security Features
- SSL/TLS configuration
- Password policies
- Session timeouts
- Login attempt monitoring
- Audit logging

### 5. API Token Management
- Token lifecycle management
- Expiration policies
- Token rotation
- Usage monitoring

### 6. Security Auditing
- User activity analysis
- Permission reviews
- Compliance reporting
- Security event tracking

## Common Tasks

### Create a Service Account

```bash
# Create user
python scripts/zabbix_auth_manager.py create-user \
  --config examples/user_config.json

# Generate token
python scripts/zabbix_token_manager.py create \
  --username "api-service" \
  --name "production-token" \
  --expires "90d"

# Assign role
python scripts/zabbix_rbac_manager.py assign-role \
  --username "api-service" \
  --role "User role"
```

### Configure LDAP Authentication

```bash
# Configure LDAP
python scripts/zabbix_auth_manager.py configure-ldap \
  --config examples/ldap_config.json

# Test LDAP connection
python scripts/zabbix_auth_manager.py test-ldap \
  --username "testuser"

# Enable LDAP authentication
python scripts/zabbix_auth_manager.py set-auth-method \
  --method ldap
```

### Security Audit

```bash
# Run full security audit
python scripts/audit_security.py --full \
  --output audit_report.json

# Validate security configuration
python scripts/validate_security_config.py --check-all

# Review user activity
python scripts/audit_security.py --user-activity
```

### Token Rotation

```bash
# List expiring tokens
python scripts/zabbix_token_manager.py list \
  --expiring-in "7d"

# Rotate token
python scripts/zabbix_token_manager.py rotate \
  --name "old-token" \
  --new-name "new-token"

# Revoke expired tokens
python scripts/zabbix_token_manager.py revoke-expired
```

## Directory Structure

```
api-authentication-security/
├── SKILL.md                          # Complete skill documentation
├── README.md                         # This file
├── scripts/
│   ├── zabbix_auth_manager.py       # User and auth management
│   ├── zabbix_token_manager.py      # Token lifecycle management
│   ├── zabbix_rbac_manager.py       # RBAC and permissions
│   ├── validate_security_config.py  # Security validation
│   └── audit_security.py            # Security auditing
└── examples/
    ├── user_config.json             # User creation examples
    ├── usergroup_config.yaml        # User group configs
    ├── role_config.json             # Custom role definitions
    ├── token_config.yaml            # Token management
    ├── ldap_config.json             # LDAP configuration
    ├── saml_config.yaml             # SAML SSO configuration
    ├── security_policies.yaml       # Security policies
    └── bulk_users.yaml              # Bulk operations
```

## Scripts Overview

### zabbix_auth_manager.py
Manages authentication and user accounts:
- Login/logout operations
- User CRUD operations
- User group assignment
- LDAP/SAML configuration
- 2FA management

### zabbix_token_manager.py
Manages API token lifecycle:
- Create tokens with expiration
- List and filter tokens
- Revoke tokens
- Token rotation
- Usage monitoring

### zabbix_rbac_manager.py
Manages roles and permissions:
- List and show roles
- Create custom roles
- Assign roles to users
- Test permissions
- User group management

### validate_security_config.py
Validates security configuration:
- Password policy checks
- SSL/TLS validation
- Authentication configuration
- Session management
- Access control review

### audit_security.py
Performs security audits:
- User activity analysis
- Permission reviews
- Token auditing
- Compliance reporting
- Audit log analysis

## Configuration Examples

All configuration examples are in the `examples/` directory:

- **user_config.json** - User account creation
- **usergroup_config.yaml** - User group setup
- **role_config.json** - Custom role definitions
- **token_config.yaml** - Token management
- **ldap_config.json** - LDAP authentication
- **saml_config.yaml** - SAML SSO setup
- **security_policies.yaml** - Security policy templates
- **bulk_users.yaml** - Bulk user operations

## Best Practices

### Authentication
- Use API tokens for automation (not username/password)
- Rotate tokens every 90 days
- Set expiration dates for all tokens
- Use separate tokens for different services
- Store tokens securely (secrets manager)

### Password Security
- Minimum 12 characters
- Require complexity (uppercase, lowercase, numbers, symbols)
- Enable password expiration (90-180 days)
- Prevent password reuse
- Implement account lockout after failed attempts

### Access Control
- Follow principle of least privilege
- Regular access reviews (quarterly)
- Remove inactive users (>90 days)
- Use role-based access control
- Limit admin account count

### Session Management
- Configure appropriate timeouts (15-30 minutes)
- Disable auto-login for admin accounts
- Monitor active sessions
- Force re-authentication for sensitive operations

### SSL/TLS
- Always use HTTPS
- Use valid SSL certificates
- Enable certificate validation
- Use TLS 1.2 or higher
- Monitor certificate expiration

### Monitoring & Auditing
- Enable audit logging
- Monitor failed login attempts
- Alert on permission changes
- Review audit logs regularly
- Implement SIEM integration

## Security Validation

Run security checks regularly:

```bash
# Check all security configurations
python scripts/validate_security_config.py --check-all

# Check specific areas
python scripts/validate_security_config.py --check-passwords
python scripts/validate_security_config.py --check-ssl
python scripts/validate_security_config.py --check-auth

# Generate security report
python scripts/validate_security_config.py \
  --check-all \
  --report security_report.json
```

## Troubleshooting

### Authentication Fails

```bash
# Test authentication
python scripts/zabbix_auth_manager.py test-auth

# Check user status
python scripts/zabbix_auth_manager.py get-user \
  --username "username"
```

### Token Not Working

```bash
# Verify token status
python scripts/zabbix_token_manager.py info \
  --name "token-name"

# Test token
python scripts/zabbix_token_manager.py test \
  --token-value "token-value"
```

### Permission Denied

```bash
# Check user permissions
python scripts/zabbix_rbac_manager.py show-permissions \
  --username "username"

# Test specific permission
python scripts/zabbix_rbac_manager.py test-permission \
  --username "username" \
  --operation "host.create"
```

### LDAP Issues

```bash
# Test LDAP connection
python scripts/zabbix_auth_manager.py test-ldap \
  --username "username" \
  --debug

# Validate LDAP configuration
python scripts/validate_security_config.py --check-auth
```

## Environment Variables

Set these environment variables for easier script usage:

```bash
export ZABBIX_URL="https://zabbix.example.com"
export ZABBIX_API_TOKEN="your-api-token"

# Alternative: username/password (not recommended for production)
export ZABBIX_USERNAME="Admin"
export ZABBIX_PASSWORD="zabbix"
```

## Credential Management

### Using .env File

```bash
# Create .env file
cat > .env << EOF
ZABBIX_URL=https://zabbix.example.com
ZABBIX_API_TOKEN=your-token-here
EOF

# Add to .gitignore
echo ".env" >> .gitignore

# Load in scripts
pip install python-dotenv
```

### Using Secrets Manager

```bash
# AWS Secrets Manager
aws secretsmanager create-secret \
  --name zabbix/api-token \
  --secret-string '{"token":"your-token"}'

# HashiCorp Vault
vault kv put secret/zabbix/api-token token=your-token

# Retrieve in scripts
export ZABBIX_API_TOKEN=$(aws secretsmanager get-secret-value \
  --secret-id zabbix/api-token \
  --query SecretString \
  --output text | jq -r .token)
```

## Compliance

This skill helps meet requirements for:

- **SOC2**: Access control, audit logging, encryption
- **ISO 27001**: User access management, system access control
- **GDPR**: Data protection, access controls, audit trails
- **PCI-DSS**: Access restrictions, authentication, monitoring

See `examples/security_policies.yaml` for detailed compliance mappings.

## Security Hardening Checklist

- [ ] Enable HTTPS with valid SSL certificate
- [ ] Set minimum password length to 12 characters
- [ ] Enable password complexity requirements
- [ ] Configure session timeouts (15-30 minutes)
- [ ] Disable auto-login for admin accounts
- [ ] Enable login attempt limits
- [ ] Use API tokens instead of username/password
- [ ] Set token expiration dates (90 days)
- [ ] Enable two-factor authentication
- [ ] Regular access reviews (quarterly)
- [ ] Remove inactive users (>90 days)
- [ ] Enable audit logging
- [ ] Monitor failed login attempts
- [ ] Configure LDAP/SAML for SSO
- [ ] Implement least privilege access
- [ ] Regular security audits

## Additional Resources

- Zabbix Documentation: https://www.zabbix.com/documentation
- Encryption: `/zabbix-docs-masters/zabbix-docs/17_Encryption/`
- API Documentation: https://www.zabbix.com/documentation/current/api

## Support

For detailed documentation, see `SKILL.md`.

For issues or questions:
1. Check the troubleshooting section
2. Review example configurations
3. Run security validation
4. Check Zabbix logs
