---
name: API Authentication & Security for Zabbix
description: Manages Zabbix API authentication, security configurations, user management, role-based access control (RBAC), API tokens, sessions, SSL/TLS encryption, and audit logging. Use when securing Zabbix API access, managing users and permissions, implementing SSO/LDAP integration, configuring authentication methods, rotating credentials, or ensuring compliance with security policies.
---

# API Authentication & Security for Zabbix

## Overview

This skill provides comprehensive management of Zabbix API authentication and security features including user management, RBAC, API tokens, SSL/TLS configuration, SSO integration, and security auditing.

## Quick Start

### Basic Authentication

```bash
# Authenticate with username/password
python scripts/zabbix_auth_manager.py login \
  --url "https://zabbix.example.com" \
  --username "Admin" \
  --password "zabbix"

# Create an API token
python scripts/zabbix_token_manager.py create \
  --name "automation-token" \
  --expires "30d" \
  --description "Token for CI/CD automation"

# List active tokens
python scripts/zabbix_token_manager.py list --active
```

### User Management

```bash
# Create a new user
python scripts/zabbix_auth_manager.py create-user \
  --config examples/user_config.json

# Add user to group
python scripts/zabbix_auth_manager.py add-to-group \
  --username "john.doe" \
  --group "Developers"

# Update user permissions
python scripts/zabbix_rbac_manager.py assign-role \
  --username "john.doe" \
  --role "User role"
```

### Security Validation

```bash
# Run security audit
python scripts/audit_security.py --full

# Validate security configuration
python scripts/validate_security_config.py \
  --check-all \
  --report security_audit.json
```

## Core Capabilities

### 1. Authentication Methods

**Username/Password Authentication**
- Standard Zabbix authentication
- Session-based access
- Password policy enforcement
- Login attempt monitoring

**API Token Authentication** (Recommended)
- Token-based authentication for automation
- Configurable expiration periods
- Granular permissions per token
- Easy rotation and revocation

**SSO Integration**
- LDAP/Active Directory integration
- SAML 2.0 support
- HTTP authentication
- Multi-factor authentication (2FA)

### 2. User Management

Create, update, and manage user accounts:

```python
# See examples/user_config.json for complete configuration
{
  "username": "john.doe",
  "name": "John",
  "surname": "Doe",
  "passwd": "SecurePass123!",
  "usrgrps": [{"usrgrpid": "7"}],
  "roleid": "3",
  "autologin": "0",
  "autologout": "15m"
}
```

Operations:
- Create users with proper roles
- Update user properties and permissions
- Disable/enable user accounts
- Bulk user operations
- Password management and rotation

### 3. Role-Based Access Control (RBAC)

**User Roles:**
- Super admin role (full access)
- Admin role (administrative tasks)
- User role (monitoring and operations)
- Guest role (read-only access)
- Custom roles with granular permissions

**Permission Types:**
- UI access permissions
- API access permissions
- Host group permissions
- Template permissions
- Action permissions

See `reference/rbac-configuration.md` for detailed RBAC setup.

### 4. API Token Management

Token lifecycle management:
- Generate tokens with specific permissions
- Set expiration dates (recommended: 30-90 days)
- Monitor token usage
- Automatic expiration notifications
- Rotation automation

See `reference/token-management.md` for token best practices.

### 5. User Group Management

Organize users into groups for efficient permission management:
- Create user groups with shared permissions
- Assign host group access
- Configure GUI and API access rights
- Manage group membership
- Inherit permissions from multiple groups

### 6. SSL/TLS Configuration

Secure API communication:
- Enable HTTPS for API endpoints
- Certificate management
- Certificate validation
- PSK (Pre-Shared Key) encryption
- Certificate-based authentication

See `reference/ssl-tls-configuration.md` for encryption setup.

### 7. Frontend Authentication Methods

Configure authentication backends:
- **Internal**: Default Zabbix authentication
- **LDAP**: Enterprise directory integration
- **SAML**: Single sign-on with identity providers
- **HTTP**: Web server authentication

See `reference/sso-integration.md` for SSO configuration examples.

### 8. Two-Factor Authentication (2FA)

Enhanced security with TOTP-based 2FA:
- Enable 2FA globally or per-user
- TOTP (Time-based One-Time Password)
- Backup codes for recovery
- 2FA enforcement policies

### 9. Security Policies

Implement security hardening:
- Password complexity requirements
- Password expiration policies
- Session timeout configuration
- Login attempt limits
- IP allowlisting/blocklisting
- API rate limiting

### 10. Audit Logging

Track security events:
- User login/logout events
- Permission changes
- Configuration modifications
- Failed authentication attempts
- API access logs
- Security incidents

See `reference/audit-logging.md` for audit log analysis.

## Workflows

### Secure API Access Setup

1. **Create Service Account**
   ```bash
   python scripts/zabbix_auth_manager.py create-user \
     --username "api-service" \
     --role "User role" \
     --config examples/user_config.json
   ```

2. **Generate API Token**
   ```bash
   python scripts/zabbix_token_manager.py create \
     --username "api-service" \
     --name "production-automation" \
     --expires "90d"
   ```

3. **Validate Permissions**
   ```bash
   python scripts/zabbix_rbac_manager.py test-permissions \
     --username "api-service" \
     --operations "host.get,item.get,trigger.get"
   ```

4. **Store Token Securely**
   - Use environment variables
   - Store in secrets manager (Vault, AWS Secrets Manager)
   - Never commit tokens to version control

### User Onboarding

1. **Create User Account**
   ```bash
   python scripts/zabbix_auth_manager.py create-user \
     --config examples/user_config.json
   ```

2. **Assign to User Group**
   ```bash
   python scripts/zabbix_auth_manager.py add-to-group \
     --username "new.user" \
     --group "Operations Team"
   ```

3. **Configure Permissions**
   ```bash
   python scripts/zabbix_rbac_manager.py assign-role \
     --username "new.user" \
     --role "User role"
   ```

4. **Enable 2FA** (if required)
   ```bash
   python scripts/zabbix_auth_manager.py enable-2fa \
     --username "new.user"
   ```

5. **Send Welcome Email**
   ```bash
   python scripts/zabbix_auth_manager.py send-welcome \
     --username "new.user" \
     --email "new.user@example.com"
   ```

### LDAP Integration

1. **Configure LDAP Settings**
   ```bash
   python scripts/zabbix_auth_manager.py configure-ldap \
     --config examples/ldap_config.json
   ```

2. **Test LDAP Connection**
   ```bash
   python scripts/zabbix_auth_manager.py test-ldap \
     --username "testuser"
   ```

3. **Enable LDAP Authentication**
   ```bash
   python scripts/zabbix_auth_manager.py set-auth-method \
     --method "ldap"
   ```

4. **Map LDAP Groups to Zabbix Roles**
   ```bash
   python scripts/zabbix_rbac_manager.py map-ldap-groups \
     --config examples/ldap_group_mapping.json
   ```

See `reference/sso-integration.md` for complete LDAP/SAML setup.

### Security Audit Workflow

1. **Run Comprehensive Audit**
   ```bash
   python scripts/audit_security.py \
     --full \
     --output audit_report.json
   ```

2. **Review Findings**
   - Check for weak passwords
   - Identify inactive users
   - Review permission anomalies
   - Find expired tokens still in use

3. **Remediate Issues**
   ```bash
   # Disable inactive users
   python scripts/zabbix_auth_manager.py disable-inactive \
     --days 90

   # Revoke expired tokens
   python scripts/zabbix_token_manager.py revoke-expired

   # Enforce password policies
   python scripts/validate_security_config.py \
     --enforce-password-policy
   ```

4. **Generate Compliance Report**
   ```bash
   python scripts/audit_security.py \
     --compliance-report \
     --format pdf \
     --output compliance_report.pdf
   ```

### Token Rotation

1. **List Expiring Tokens**
   ```bash
   python scripts/zabbix_token_manager.py list \
     --expiring-in "7d"
   ```

2. **Generate New Token**
   ```bash
   python scripts/zabbix_token_manager.py create \
     --name "automation-token-v2" \
     --expires "90d" \
     --clone-from "automation-token-v1"
   ```

3. **Update Applications**
   - Update environment variables
   - Refresh secrets in vault
   - Deploy configuration changes

4. **Revoke Old Token**
   ```bash
   python scripts/zabbix_token_manager.py revoke \
     --name "automation-token-v1" \
     --reason "Token rotation"
   ```

5. **Verify New Token**
   ```bash
   python scripts/zabbix_token_manager.py test \
     --name "automation-token-v2"
   ```

## Security Best Practices

### Authentication
- Use API tokens instead of username/password for automation
- Rotate tokens regularly (every 90 days recommended)
- Set appropriate token expiration periods
- Use separate tokens for different services
- Implement least privilege access

### Password Policies
- Enforce minimum password length (12+ characters)
- Require complexity (uppercase, lowercase, numbers, symbols)
- Enable password expiration (90-180 days)
- Prevent password reuse (last 5 passwords)
- Implement account lockout after failed attempts

### Session Management
- Configure appropriate session timeouts (15-30 minutes)
- Disable auto-login for administrative accounts
- Force re-authentication for sensitive operations
- Monitor active sessions regularly

### SSL/TLS
- Always use HTTPS for API access
- Use valid SSL certificates (not self-signed in production)
- Enable certificate validation
- Use TLS 1.2 or higher
- Configure strong cipher suites

### Access Control
- Implement role-based access control (RBAC)
- Follow principle of least privilege
- Regularly audit user permissions
- Remove unused accounts promptly
- Use user groups for permission management

### Monitoring & Auditing
- Enable audit logging for all security events
- Monitor failed login attempts
- Alert on permission changes
- Review audit logs regularly
- Implement SIEM integration for security events

### Compliance
- Document access control policies
- Maintain user access records
- Implement approval workflows for privilege escalation
- Regular security assessments
- Compliance reporting (SOC2, ISO 27001, GDPR)

## Troubleshooting

### Authentication Issues

**Problem**: API authentication fails
```bash
# Verify credentials
python scripts/zabbix_auth_manager.py test-auth \
  --url "https://zabbix.example.com" \
  --username "Admin"

# Check user status
python scripts/zabbix_auth_manager.py get-user \
  --username "Admin"
```

**Problem**: Token not working
```bash
# Verify token is valid and not expired
python scripts/zabbix_token_manager.py info \
  --name "my-token"

# Test token authentication
python scripts/zabbix_token_manager.py test \
  --token "abc123..."
```

### Permission Issues

**Problem**: Insufficient permissions
```bash
# Check user permissions
python scripts/zabbix_rbac_manager.py show-permissions \
  --username "john.doe"

# Test specific operation
python scripts/zabbix_rbac_manager.py test-permission \
  --username "john.doe" \
  --operation "host.create"
```

### LDAP Issues

**Problem**: LDAP authentication not working
```bash
# Test LDAP connection
python scripts/zabbix_auth_manager.py test-ldap \
  --debug

# Verify LDAP configuration
python scripts/validate_security_config.py \
  --check-ldap
```

See `reference/troubleshooting.md` for additional troubleshooting steps.

## API Methods Reference

### User Management
- `user.create` - Create new user
- `user.update` - Update user properties
- `user.delete` - Delete user
- `user.get` - Retrieve user information

### User Group Management
- `usergroup.create` - Create user group
- `usergroup.update` - Update group settings
- `usergroup.get` - Get group information

### Role Management
- `role.create` - Create custom role
- `role.update` - Update role permissions
- `role.get` - Get role information

### Token Management
- `token.create` - Generate API token
- `token.delete` - Revoke token
- `token.get` - List tokens

### Authentication Configuration
- `authentication.get` - Get auth settings
- `authentication.update` - Update auth configuration

### Audit Logging
- `auditlog.get` - Retrieve audit logs

See `reference/api-methods.md` for complete API documentation.

## Examples

All configuration examples are in the `examples/` directory:

- `user_config.json` - User creation examples
- `usergroup_config.yaml` - User group configurations
- `role_config.json` - Custom role definitions
- `token_config.yaml` - API token management
- `ldap_config.json` - LDAP authentication setup
- `saml_config.yaml` - SAML SSO configuration
- `security_policies.yaml` - Security policy templates
- `bulk_users.yaml` - Bulk user operations

## Scripts

All automation scripts are in the `scripts/` directory:

- `zabbix_auth_manager.py` - Authentication and user management
- `zabbix_token_manager.py` - API token lifecycle management
- `zabbix_rbac_manager.py` - Role and permission management
- `validate_security_config.py` - Security configuration validation
- `audit_security.py` - Security auditing and compliance

## Additional Resources

- `reference/rbac-configuration.md` - Detailed RBAC setup guide
- `reference/token-management.md` - Token best practices
- `reference/ssl-tls-configuration.md` - Encryption setup
- `reference/sso-integration.md` - SSO/LDAP configuration
- `reference/audit-logging.md` - Audit log analysis
- `reference/api-methods.md` - Complete API reference
- `reference/troubleshooting.md` - Common issues and solutions
- `reference/compliance.md` - Compliance requirements (SOC2, GDPR, etc.)

## Credential Management

### Environment Variables
```bash
export ZABBIX_URL="https://zabbix.example.com"
export ZABBIX_API_TOKEN="your-token-here"
```

### Using Secrets Manager
```python
# AWS Secrets Manager
import boto3
secret = boto3.client('secretsmanager').get_secret_value(
    SecretId='zabbix/api-token'
)

# HashiCorp Vault
import hvac
client = hvac.Client(url='https://vault.example.com')
secret = client.secrets.kv.v2.read_secret_version(
    path='zabbix/api-token'
)
```

### Configuration Files
```bash
# Use .env files (never commit to git)
echo "ZABBIX_API_TOKEN=your-token" > .env
echo ".env" >> .gitignore
```

## Compliance Considerations

### SOC2
- Implement least privilege access
- Enable audit logging
- Regular access reviews
- Automated provisioning/deprovisioning
- Multi-factor authentication

### GDPR
- Document data access
- Implement access controls
- Audit log retention
- Right to access reports
- Data protection by design

### ISO 27001
- Access control policy
- User access management
- Password management
- Privilege management
- Review of user access rights

See `reference/compliance.md` for detailed compliance mappings.

## Support

For issues or questions:
1. Check `reference/troubleshooting.md`
2. Review Zabbix documentation at `/zabbix-docs-masters/zabbix-docs/17_Encryption/`
3. Run security validation: `python scripts/validate_security_config.py`
4. Generate diagnostic report: `python scripts/audit_security.py --diagnostic`
