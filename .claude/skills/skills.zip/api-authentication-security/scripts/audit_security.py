#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Security Auditor

Performs comprehensive security audits including user activity analysis,
permission reviews, compliance checking, and security event monitoring.
Generates detailed audit reports for compliance and security reviews.

Usage:
    python audit_security.py --full
    python audit_security.py --user-activity
    python audit_security.py --permission-review
    python audit_security.py --compliance-report --format pdf
    python audit_security.py --audit-logs --days 30
    python audit_security.py --output audit_report.json

Environment Variables:
    ZABBIX_URL: Zabbix server URL
    ZABBIX_API_TOKEN: API token for authentication
"""

import argparse
import json
import sys
import os
import requests
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from urllib.parse import urljoin
from collections import defaultdict

# Constants
DEFAULT_TIMEOUT = 30
INACTIVE_USER_DAYS = 90
TOKEN_EXPIRY_WARNING_DAYS = 30


class SecurityAuditor:
    """Perform security audits"""

    def __init__(self, url: str, token: str, verify_ssl: bool = True):
        """
        Initialize security auditor

        Args:
            url: Zabbix server URL
            token: API token
            verify_ssl: Verify SSL certificates
        """
        self.url = url.rstrip('/')
        self.api_url = urljoin(self.url, '/api_jsonrpc.php')
        self.token = token
        self.verify_ssl = verify_ssl
        self.request_id = 0
        self.audit_results = {}

        if not verify_ssl:
            requests.packages.urllib3.disable_warnings()

    def _make_request(self, method: str, params: Any = None) -> Dict:
        """Make JSON-RPC request"""
        self.request_id += 1

        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params or {},
            "auth": self.token,
            "id": self.request_id
        }

        response = requests.post(
            self.api_url,
            json=payload,
            verify=self.verify_ssl,
            timeout=DEFAULT_TIMEOUT
        )
        response.raise_for_status()

        result = response.json()
        if "error" in result:
            raise Exception(f"API Error: {result['error']}")

        return result.get("result")

    def audit_user_activity(self) -> Dict:
        """Audit user activity and login patterns"""
        print("Auditing user activity...")

        users = self._make_request(
            "user.get",
            {
                "output": ["userid", "username", "name", "surname", "attempt_clock",
                          "attempt_failed", "attempt_ip", "rows_per_page"],
                "selectRole": ["name", "type"],
                "selectUsrgrps": ["name"]
            }
        )

        now = datetime.now()
        cutoff = now - timedelta(days=INACTIVE_USER_DAYS)

        active_users = []
        inactive_users = []
        failed_login_users = []
        never_logged_in = []

        for user in users:
            last_access = int(user.get("attempt_clock", 0))
            failed_attempts = int(user.get("attempt_failed", 0))

            user_info = {
                "username": user["username"],
                "name": f"{user['name']} {user['surname']}",
                "role": user.get("role", {}).get("name", "N/A"),
                "groups": [g["name"] for g in user.get("usrgrps", [])],
                "last_access": datetime.fromtimestamp(last_access).isoformat() if last_access > 0 else "Never",
                "failed_attempts": failed_attempts,
                "last_ip": user.get("attempt_ip", "N/A")
            }

            if last_access == 0:
                never_logged_in.append(user_info)
            elif datetime.fromtimestamp(last_access) < cutoff:
                days_inactive = (now - datetime.fromtimestamp(last_access)).days
                user_info["days_inactive"] = days_inactive
                inactive_users.append(user_info)
            else:
                active_users.append(user_info)

            if failed_attempts >= 3:
                failed_login_users.append(user_info)

        result = {
            "summary": {
                "total_users": len(users),
                "active_users": len(active_users),
                "inactive_users": len(inactive_users),
                "never_logged_in": len(never_logged_in),
                "users_with_failed_logins": len(failed_login_users)
            },
            "active_users": active_users,
            "inactive_users": inactive_users,
            "never_logged_in": never_logged_in,
            "failed_login_users": failed_login_users
        }

        print(f"  Total users: {len(users)}")
        print(f"  Active users: {len(active_users)}")
        print(f"  Inactive users (>{INACTIVE_USER_DAYS} days): {len(inactive_users)}")
        print(f"  Never logged in: {len(never_logged_in)}")
        print(f"  Users with failed logins: {len(failed_login_users)}")

        self.audit_results["user_activity"] = result
        return result

    def audit_permissions(self) -> Dict:
        """Audit user permissions and access levels"""
        print("\nAuditing permissions...")

        users = self._make_request(
            "user.get",
            {
                "output": ["username"],
                "selectRole": ["name", "type"],
                "selectUsrgrps": ["name", "gui_access", "users_status"]
            }
        )

        usergroups = self._make_request(
            "usergroup.get",
            {
                "output": ["name", "users_status", "gui_access"],
                "selectRights": "extend",
                "selectUsers": ["username"]
            }
        )

        # Analyze roles
        role_distribution = defaultdict(int)
        admin_users = []
        super_admin_users = []

        for user in users:
            role = user.get("role", {})
            role_name = role.get("name", "Unknown")
            role_type = role.get("type", "0")

            role_distribution[role_name] += 1

            if role_type == "3":  # Super admin
                super_admin_users.append(user["username"])
            elif role_type == "2":  # Admin
                admin_users.append(user["username"])

        # Analyze user groups
        groups_summary = []
        for group in usergroups:
            group_info = {
                "name": group["name"],
                "members": len(group.get("users", [])),
                "gui_access": self._format_gui_access(group["gui_access"]),
                "status": "Enabled" if group["users_status"] == "0" else "Disabled",
                "permissions": len(group.get("rights", []))
            }
            groups_summary.append(group_info)

        result = {
            "summary": {
                "total_users": len(users),
                "super_admins": len(super_admin_users),
                "admins": len(admin_users),
                "total_groups": len(usergroups)
            },
            "role_distribution": dict(role_distribution),
            "super_admin_users": super_admin_users,
            "admin_users": admin_users,
            "user_groups": groups_summary
        }

        print(f"  Total users: {len(users)}")
        print(f"  Super admins: {len(super_admin_users)}")
        print(f"  Admins: {len(admin_users)}")
        print(f"  User groups: {len(usergroups)}")

        self.audit_results["permissions"] = result
        return result

    def audit_tokens(self) -> Dict:
        """Audit API tokens"""
        print("\nAuditing API tokens...")

        tokens = self._make_request(
            "token.get",
            {
                "output": "extend",
                "selectUser": ["username"]
            }
        )

        now = int(datetime.now().timestamp())
        warning_threshold = now + (TOKEN_EXPIRY_WARNING_DAYS * 86400)

        active_tokens = []
        expired_tokens = []
        expiring_soon = []
        no_expiry = []

        for token in tokens:
            expires_at = int(token.get("expires_at", 0))

            token_info = {
                "name": token["name"],
                "user": token.get("user", {}).get("username", "N/A"),
                "created": datetime.fromtimestamp(int(token["created_at"])).isoformat() if token.get("created_at") else "N/A",
                "expires": datetime.fromtimestamp(expires_at).isoformat() if expires_at > 0 else "Never",
                "description": token.get("description", "")
            }

            if expires_at == 0:
                no_expiry.append(token_info)
            elif expires_at < now:
                days_expired = (now - expires_at) / 86400
                token_info["days_expired"] = int(days_expired)
                expired_tokens.append(token_info)
            elif expires_at < warning_threshold:
                days_until_expiry = (expires_at - now) / 86400
                token_info["days_until_expiry"] = int(days_until_expiry)
                expiring_soon.append(token_info)
            else:
                active_tokens.append(token_info)

        result = {
            "summary": {
                "total_tokens": len(tokens),
                "active_tokens": len(active_tokens),
                "expired_tokens": len(expired_tokens),
                "expiring_soon": len(expiring_soon),
                "no_expiry": len(no_expiry)
            },
            "active_tokens": active_tokens,
            "expired_tokens": expired_tokens,
            "expiring_soon": expiring_soon,
            "no_expiry_tokens": no_expiry
        }

        print(f"  Total tokens: {len(tokens)}")
        print(f"  Active tokens: {len(active_tokens)}")
        print(f"  Expired tokens: {len(expired_tokens)}")
        print(f"  Expiring soon (<{TOKEN_EXPIRY_WARNING_DAYS} days): {len(expiring_soon)}")
        print(f"  No expiry: {len(no_expiry)}")

        self.audit_results["tokens"] = result
        return result

    def audit_authentication_config(self) -> Dict:
        """Audit authentication configuration"""
        print("\nAuditing authentication configuration...")

        auth_config = self._make_request("authentication.get")

        auth_methods = {
            "0": "Internal",
            "1": "LDAP",
            "2": "SAML",
            "4": "HTTP"
        }

        result = {
            "authentication_method": auth_methods.get(str(auth_config.get("authentication_type")), "Unknown"),
            "password_min_length": int(auth_config.get("passwd_min_length", 8)),
            "password_complexity_enabled": int(auth_config.get("passwd_check_rules", 0)) > 0,
            "login_attempts_limit": int(auth_config.get("login_attempts", 5)),
            "login_block_duration": int(auth_config.get("login_block", 30)),
            "saml_enabled": auth_config.get("saml_idp_entityid") is not None,
            "ldap_configured": auth_config.get("ldap_configured") == "1"
        }

        print(f"  Authentication: {result['authentication_method']}")
        print(f"  Password min length: {result['password_min_length']}")
        print(f"  Password complexity: {'Enabled' if result['password_complexity_enabled'] else 'Disabled'}")
        print(f"  Login attempts limit: {result['login_attempts_limit']}")

        self.audit_results["authentication"] = result
        return result

    def get_audit_logs(self, days: int = 30) -> Dict:
        """Get audit logs for specified period"""
        print(f"\nRetrieving audit logs (last {days} days)...")

        time_from = int((datetime.now() - timedelta(days=days)).timestamp())

        try:
            audit_logs = self._make_request(
                "auditlog.get",
                {
                    "output": "extend",
                    "time_from": time_from,
                    "sortfield": "clock",
                    "sortorder": "DESC",
                    "limit": 1000
                }
            )

            # Analyze logs
            by_action = defaultdict(int)
            by_resource = defaultdict(int)
            by_user = defaultdict(int)

            for log in audit_logs:
                action = log.get("action", "unknown")
                resource = log.get("resourcetype", "unknown")
                userid = log.get("userid", "unknown")

                by_action[action] += 1
                by_resource[resource] += 1
                by_user[userid] += 1

            result = {
                "summary": {
                    "total_events": len(audit_logs),
                    "time_range_days": days,
                    "unique_users": len(by_user)
                },
                "by_action": dict(by_action),
                "by_resource": dict(by_resource),
                "recent_events": audit_logs[:20]  # Last 20 events
            }

            print(f"  Total events: {len(audit_logs)}")
            print(f"  Unique users: {len(by_user)}")
            print(f"  Most common actions:")
            for action, count in sorted(by_action.items(), key=lambda x: x[1], reverse=True)[:5]:
                print(f"    - {action}: {count}")

            self.audit_results["audit_logs"] = result
            return result

        except Exception as e:
            print(f"  [WARN] Could not retrieve audit logs: {str(e)}")
            return {"error": str(e)}

    def generate_compliance_report(self) -> Dict:
        """Generate compliance report"""
        print("\nGenerating compliance report...")

        # Check various compliance requirements
        compliance_checks = {
            "password_policy": self._check_password_policy(),
            "access_control": self._check_access_control(),
            "audit_logging": self._check_audit_logging(),
            "token_management": self._check_token_management(),
            "user_management": self._check_user_management()
        }

        # Calculate compliance score
        total_checks = sum(len(checks) for checks in compliance_checks.values())
        passed_checks = sum(
            sum(1 for check in checks.values() if check["compliant"])
            for checks in compliance_checks.values()
        )

        compliance_score = (passed_checks / total_checks * 100) if total_checks > 0 else 0

        result = {
            "timestamp": datetime.now().isoformat(),
            "compliance_score": round(compliance_score, 2),
            "total_checks": total_checks,
            "passed_checks": passed_checks,
            "failed_checks": total_checks - passed_checks,
            "checks": compliance_checks
        }

        print(f"  Compliance Score: {compliance_score:.1f}%")
        print(f"  Passed Checks: {passed_checks}/{total_checks}")

        self.audit_results["compliance"] = result
        return result

    def _check_password_policy(self) -> Dict:
        """Check password policy compliance"""
        auth_config = self._make_request("authentication.get")

        return {
            "min_length_12_chars": {
                "compliant": int(auth_config.get("passwd_min_length", 0)) >= 12,
                "current_value": auth_config.get("passwd_min_length"),
                "requirement": "Minimum 12 characters"
            },
            "complexity_enabled": {
                "compliant": int(auth_config.get("passwd_check_rules", 0)) > 0,
                "current_value": auth_config.get("passwd_check_rules"),
                "requirement": "Password complexity rules enabled"
            },
            "login_attempts_limited": {
                "compliant": int(auth_config.get("login_attempts", 0)) > 0,
                "current_value": auth_config.get("login_attempts"),
                "requirement": "Login attempts should be limited"
            }
        }

    def _check_access_control(self) -> Dict:
        """Check access control compliance"""
        users = self._make_request(
            "user.get",
            {"output": ["userid"], "selectRole": ["type"]}
        )

        admin_count = sum(1 for u in users if u.get("role", {}).get("type") in ["2", "3"])

        return {
            "limited_admin_access": {
                "compliant": admin_count <= 5,
                "current_value": admin_count,
                "requirement": "Limit number of admin users (recommended: ≤5)"
            },
            "rbac_implemented": {
                "compliant": len(users) > 0,
                "current_value": "Yes",
                "requirement": "Role-based access control implemented"
            }
        }

    def _check_audit_logging(self) -> Dict:
        """Check audit logging compliance"""
        try:
            logs = self._make_request(
                "auditlog.get",
                {"limit": 1}
            )
            audit_enabled = len(logs) >= 0
        except:
            audit_enabled = False

        return {
            "audit_logging_enabled": {
                "compliant": audit_enabled,
                "current_value": "Enabled" if audit_enabled else "Disabled",
                "requirement": "Audit logging must be enabled"
            }
        }

    def _check_token_management(self) -> Dict:
        """Check token management compliance"""
        tokens = self._make_request(
            "token.get",
            {"output": ["expires_at"]}
        )

        no_expiry_count = sum(1 for t in tokens if int(t.get("expires_at", 0)) == 0)

        return {
            "tokens_have_expiry": {
                "compliant": no_expiry_count == 0,
                "current_value": f"{no_expiry_count} tokens without expiry",
                "requirement": "All tokens should have expiration dates"
            }
        }

    def _check_user_management(self) -> Dict:
        """Check user management compliance"""
        users = self._make_request(
            "user.get",
            {"output": ["attempt_clock"]}
        )

        now = datetime.now()
        cutoff = now - timedelta(days=90)
        inactive_count = sum(
            1 for u in users
            if int(u.get("attempt_clock", 0)) > 0 and
            datetime.fromtimestamp(int(u["attempt_clock"])) < cutoff
        )

        return {
            "inactive_users_removed": {
                "compliant": inactive_count == 0,
                "current_value": f"{inactive_count} inactive users",
                "requirement": "Remove users inactive for >90 days"
            }
        }

    def _format_gui_access(self, access: str) -> str:
        """Format GUI access value"""
        access_types = {
            "0": "Default",
            "1": "Internal",
            "2": "LDAP",
            "3": "Disabled"
        }
        return access_types.get(str(access), "Unknown")

    def generate_report(self, output_file: Optional[str] = None) -> Dict:
        """Generate comprehensive audit report"""
        report = {
            "audit_timestamp": datetime.now().isoformat(),
            "zabbix_url": self.url,
            "results": self.audit_results
        }

        if output_file:
            with open(output_file, 'w') as f:
                json.dump(report, f, indent=2)
            print(f"\n[OK] Audit report saved to: {output_file}")

        return report


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Zabbix Security Auditor",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument("--url", help="Zabbix server URL")
    parser.add_argument("--token", help="API token")
    parser.add_argument("--no-verify-ssl", action="store_true", help="Disable SSL verification")

    parser.add_argument("--full", action="store_true", help="Run full security audit")
    parser.add_argument("--user-activity", action="store_true", help="Audit user activity")
    parser.add_argument("--permission-review", action="store_true", help="Review permissions")
    parser.add_argument("--token-audit", action="store_true", help="Audit API tokens")
    parser.add_argument("--auth-config", action="store_true", help="Audit authentication config")
    parser.add_argument("--audit-logs", action="store_true", help="Retrieve audit logs")
    parser.add_argument("--compliance-report", action="store_true", help="Generate compliance report")

    parser.add_argument("--days", type=int, default=30, help="Days for audit logs (default: 30)")
    parser.add_argument("--output", help="Output report file (JSON)")
    parser.add_argument("--format", choices=["json", "pdf"], default="json", help="Report format")

    args = parser.parse_args()

    # Get connection parameters
    url = args.url or os.environ.get("ZABBIX_URL")
    token = args.token or os.environ.get("ZABBIX_API_TOKEN")

    if not url or not token:
        print("[ERROR] Error: Zabbix URL and API token required")
        return 1

    try:
        auditor = SecurityAuditor(
            url=url,
            token=token,
            verify_ssl=not args.no_verify_ssl
        )

        print("=" * 60)
        print("Zabbix Security Audit")
        print("=" * 60)

        # Run audits
        if args.full or not any([
            args.user_activity, args.permission_review, args.token_audit,
            args.auth_config, args.audit_logs, args.compliance_report
        ]):
            auditor.audit_user_activity()
            auditor.audit_permissions()
            auditor.audit_tokens()
            auditor.audit_authentication_config()
            auditor.get_audit_logs(args.days)
            auditor.generate_compliance_report()
        else:
            if args.user_activity:
                auditor.audit_user_activity()
            if args.permission_review:
                auditor.audit_permissions()
            if args.token_audit:
                auditor.audit_tokens()
            if args.auth_config:
                auditor.audit_authentication_config()
            if args.audit_logs:
                auditor.get_audit_logs(args.days)
            if args.compliance_report:
                auditor.generate_compliance_report()

        # Generate report
        if args.output:
            auditor.generate_report(args.output)

        if args.format == "pdf":
            print("\n[WARN] PDF generation requires additional libraries. Report saved as JSON.")

        print("\n" + "=" * 60)
        print("Audit Complete")
        print("=" * 60)

        return 0

    except Exception as e:
        print(f"\n[ERROR] Error: {str(e)}")
        if "--debug" in sys.argv:
            raise
        return 1


if __name__ == "__main__":
    sys.exit(main())
