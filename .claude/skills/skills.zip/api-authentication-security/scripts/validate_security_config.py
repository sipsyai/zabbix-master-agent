#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Security Configuration Validator

Validates Zabbix security configuration against best practices including
password policies, session settings, SSL/TLS configuration, authentication
methods, and access controls.

Usage:
    python validate_security_config.py --check-all
    python validate_security_config.py --check-passwords
    python validate_security_config.py --check-ssl
    python validate_security_config.py --check-auth
    python validate_security_config.py --check-sessions
    python validate_security_config.py --report security_report.json
    python validate_security_config.py --enforce-password-policy

Environment Variables:
    ZABBIX_URL: Zabbix server URL
    ZABBIX_API_TOKEN: API token for authentication
"""

import argparse
import json
import sys
import os
import requests
import ssl
import socket
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from urllib.parse import urljoin, urlparse
from collections import defaultdict

# Constants
DEFAULT_TIMEOUT = 30
MIN_PASSWORD_LENGTH = 12
PASSWORD_EXPIRY_DAYS = 90
SESSION_TIMEOUT_MINUTES = 30
INACTIVE_USER_DAYS = 90


class ValidationResult:
    """Result of a security validation check"""

    def __init__(self, check_name: str):
        self.check_name = check_name
        self.passed = True
        self.issues = []
        self.warnings = []
        self.recommendations = []

    def add_issue(self, message: str, severity: str = "high"):
        """Add a security issue"""
        self.passed = False
        self.issues.append({"message": message, "severity": severity})

    def add_warning(self, message: str):
        """Add a warning"""
        self.warnings.append(message)

    def add_recommendation(self, message: str):
        """Add a recommendation"""
        self.recommendations.append(message)

    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return {
            "check": self.check_name,
            "passed": self.passed,
            "issues": self.issues,
            "warnings": self.warnings,
            "recommendations": self.recommendations
        }


class SecurityValidator:
    """Validate Zabbix security configuration"""

    def __init__(self, url: str, token: str, verify_ssl: bool = True):
        """
        Initialize security validator

        Args:
            url: Zabbix server URL
            token: API token
            verify_ssl: Verify SSL certificates
        """
        self.url = url.rstrip('/')
        self.api_url = urljoin(self.url, '/api_jsonrpc.php')
        self.token = token
        self.verify_ssl = verify_ssl
        self.request_id = 0
        self.results = []

        if not verify_ssl:
            requests.packages.urllib3.disable_warnings()

    def _make_request(self, method: str, params: Any = None) -> Dict:
        """Make JSON-RPC request"""
        self.request_id += 1

        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params or {},
            "auth": self.token,
            "id": self.request_id
        }

        response = requests.post(
            self.api_url,
            json=payload,
            verify=self.verify_ssl,
            timeout=DEFAULT_TIMEOUT
        )
        response.raise_for_status()

        result = response.json()
        if "error" in result:
            raise Exception(f"API Error: {result['error']}")

        return result.get("result")

    def validate_passwords(self) -> ValidationResult:
        """Validate password policies and user passwords"""
        result = ValidationResult("Password Security")

        print("Checking password security...")

        try:
            # Get authentication configuration
            auth_config = self._make_request("authentication.get")

            # Check password minimum length
            passwd_min_length = int(auth_config.get("passwd_min_length", 8))
            if passwd_min_length < MIN_PASSWORD_LENGTH:
                result.add_issue(
                    f"Password minimum length ({passwd_min_length}) is below recommended ({MIN_PASSWORD_LENGTH})",
                    "high"
                )
            else:
                result.add_recommendation(f"Password minimum length: {passwd_min_length} [OK]")

            # Check password complexity
            passwd_check_rules = int(auth_config.get("passwd_check_rules", 0))
            if passwd_check_rules == 0:
                result.add_issue(
                    "Password complexity requirements not enabled",
                    "high"
                )
            else:
                complexity_rules = []
                if passwd_check_rules & 1:
                    complexity_rules.append("uppercase")
                if passwd_check_rules & 2:
                    complexity_rules.append("lowercase")
                if passwd_check_rules & 4:
                    complexity_rules.append("digits")
                if passwd_check_rules & 8:
                    complexity_rules.append("special characters")

                if len(complexity_rules) < 3:
                    result.add_warning(
                        f"Password complexity has only {len(complexity_rules)} rules enabled. Recommended: at least 3"
                    )
                result.add_recommendation(f"Password complexity rules: {', '.join(complexity_rules)}")

            # Get users with weak passwords (users who never changed password)
            users = self._make_request(
                "user.get",
                {"output": ["username", "attempt_clock", "attempt_failed"]}
            )

            # Check for users with multiple failed login attempts
            for user in users:
                failed_attempts = int(user.get("attempt_failed", 0))
                if failed_attempts >= 5:
                    result.add_warning(
                        f"User '{user['username']}' has {failed_attempts} failed login attempts"
                    )

        except Exception as e:
            result.add_issue(f"Failed to validate passwords: {str(e)}", "medium")

        return result

    def validate_ssl_tls(self) -> ValidationResult:
        """Validate SSL/TLS configuration"""
        result = ValidationResult("SSL/TLS Configuration")

        print("Checking SSL/TLS configuration...")

        try:
            parsed_url = urlparse(self.url)

            # Check if HTTPS is used
            if parsed_url.scheme != "https":
                result.add_issue(
                    "Zabbix is not using HTTPS. All API communication is unencrypted.",
                    "critical"
                )
                return result

            result.add_recommendation("HTTPS is enabled [OK]")

            # Check SSL certificate
            hostname = parsed_url.hostname
            port = parsed_url.port or 443

            context = ssl.create_default_context()

            try:
                with socket.create_connection((hostname, port), timeout=10) as sock:
                    with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                        cert = ssock.getpeercert()

                        # Check certificate expiration
                        not_after = datetime.strptime(cert['notAfter'], '%b %d %H:%M:%S %Y %Z')
                        days_until_expiry = (not_after - datetime.now()).days

                        if days_until_expiry < 0:
                            result.add_issue(
                                f"SSL certificate has expired {abs(days_until_expiry)} days ago",
                                "critical"
                            )
                        elif days_until_expiry < 30:
                            result.add_warning(
                                f"SSL certificate expires in {days_until_expiry} days"
                            )
                        else:
                            result.add_recommendation(
                                f"SSL certificate valid for {days_until_expiry} days [OK]"
                            )

                        # Check TLS version
                        tls_version = ssock.version()
                        if tls_version in ["TLSv1", "TLSv1.1"]:
                            result.add_issue(
                                f"Outdated TLS version: {tls_version}. Use TLS 1.2 or higher",
                                "high"
                            )
                        else:
                            result.add_recommendation(f"TLS version: {tls_version} [OK]")

            except ssl.SSLError as e:
                result.add_issue(f"SSL certificate validation failed: {str(e)}", "high")
            except socket.error as e:
                result.add_warning(f"Could not check SSL certificate: {str(e)}")

        except Exception as e:
            result.add_issue(f"Failed to validate SSL/TLS: {str(e)}", "medium")

        return result

    def validate_authentication(self) -> ValidationResult:
        """Validate authentication configuration"""
        result = ValidationResult("Authentication Configuration")

        print("Checking authentication configuration...")

        try:
            auth_config = self._make_request("authentication.get")

            # Check authentication method
            auth_type = auth_config.get("authentication_type")
            auth_methods = {
                "0": "Internal",
                "1": "LDAP",
                "2": "SAML",
                "4": "HTTP"
            }

            auth_method = auth_methods.get(str(auth_type), "Unknown")
            result.add_recommendation(f"Authentication method: {auth_method}")

            # Check LDAP configuration if enabled
            if str(auth_type) == "1":
                ldap_configured = auth_config.get("ldap_configured")
                if ldap_configured != "1":
                    result.add_issue(
                        "LDAP authentication enabled but not properly configured",
                        "high"
                    )
                else:
                    result.add_recommendation("LDAP is properly configured [OK]")

                    # Check LDAP security
                    ldap_host = auth_config.get("ldap_host", "")
                    if not ldap_host.startswith("ldaps://"):
                        result.add_warning(
                            "LDAP is not using secure connection (ldaps://)"
                        )

            # Check SAML configuration if enabled
            if str(auth_type) == "2":
                saml_configured = auth_config.get("saml_idp_entityid")
                if not saml_configured:
                    result.add_issue(
                        "SAML authentication enabled but not properly configured",
                        "high"
                    )

            # Check login attempts
            login_attempts = int(auth_config.get("login_attempts", 5))
            login_block = int(auth_config.get("login_block", 30))

            if login_attempts == 0:
                result.add_warning("No limit on failed login attempts")
            else:
                result.add_recommendation(
                    f"Failed login attempts limit: {login_attempts} (blocked for {login_block}s) [OK]"
                )

        except Exception as e:
            result.add_issue(f"Failed to validate authentication: {str(e)}", "medium")

        return result

    def validate_sessions(self) -> ValidationResult:
        """Validate session configuration"""
        result = ValidationResult("Session Configuration")

        print("Checking session configuration...")

        try:
            # Get users with session settings
            users = self._make_request(
                "user.get",
                {"output": ["username", "autologin", "autologout", "roleid"]}
            )

            autologin_users = []
            long_timeout_users = []

            for user in users:
                # Check auto-login (should be disabled for admin users)
                if user.get("autologin") == "1":
                    autologin_users.append(user["username"])

                # Check auto-logout timeout
                autologout = user.get("autologout", "0")
                if autologout == "0":
                    long_timeout_users.append((user["username"], "Never"))
                else:
                    timeout_seconds = int(autologout)
                    timeout_minutes = timeout_seconds / 60
                    if timeout_minutes > SESSION_TIMEOUT_MINUTES:
                        long_timeout_users.append(
                            (user["username"], f"{timeout_minutes:.0f}m")
                        )

            if autologin_users:
                result.add_warning(
                    f"Auto-login enabled for {len(autologin_users)} user(s): {', '.join(autologin_users)}"
                )

            if long_timeout_users:
                result.add_warning(
                    f"Long session timeouts detected for {len(long_timeout_users)} user(s)"
                )
                for username, timeout in long_timeout_users[:5]:  # Show first 5
                    result.add_warning(f"  - {username}: {timeout}")

            if not autologin_users and not long_timeout_users:
                result.add_recommendation("Session configuration follows best practices [OK]")

        except Exception as e:
            result.add_issue(f"Failed to validate sessions: {str(e)}", "medium")

        return result

    def validate_access_control(self) -> ValidationResult:
        """Validate access control and permissions"""
        result = ValidationResult("Access Control")

        print("Checking access control...")

        try:
            # Get users with roles
            users = self._make_request(
                "user.get",
                {
                    "output": ["username", "attempt_clock", "roleid"],
                    "selectRole": ["name", "type"]
                }
            )

            # Check for inactive users
            now = datetime.now()
            cutoff = now - timedelta(days=INACTIVE_USER_DAYS)
            cutoff_timestamp = int(cutoff.timestamp())

            inactive_users = []
            admin_users = []

            for user in users:
                # Check last access
                last_access = int(user.get("attempt_clock", 0))
                if last_access > 0 and last_access < cutoff_timestamp:
                    days_inactive = (now - datetime.fromtimestamp(last_access)).days
                    inactive_users.append((user["username"], days_inactive))

                # Count admin users
                if user.get("role", {}).get("type") in ["2", "3"]:  # Admin or Super admin
                    admin_users.append(user["username"])

            if inactive_users:
                result.add_warning(
                    f"Found {len(inactive_users)} inactive user(s) (>{INACTIVE_USER_DAYS} days)"
                )
                for username, days in inactive_users[:5]:  # Show first 5
                    result.add_warning(f"  - {username}: {days} days inactive")

            # Check admin user count
            if len(admin_users) > 5:
                result.add_warning(
                    f"Large number of admin users: {len(admin_users)}. Review admin access regularly."
                )

            # Get user groups
            usergroups = self._make_request(
                "usergroup.get",
                {
                    "output": ["name", "users_status", "gui_access"],
                    "selectRights": "extend"
                }
            )

            # Check for groups with full access
            full_access_groups = []
            for group in usergroups:
                if group.get("rights"):
                    for right in group["rights"]:
                        if right.get("permission") == "3":  # Read-write
                            full_access_groups.append(group["name"])
                            break

            if full_access_groups:
                result.add_recommendation(
                    f"Groups with write access: {len(full_access_groups)}"
                )

        except Exception as e:
            result.add_issue(f"Failed to validate access control: {str(e)}", "medium")

        return result

    def validate_api_tokens(self) -> ValidationResult:
        """Validate API token configuration"""
        result = ValidationResult("API Tokens")

        print("Checking API tokens...")

        try:
            tokens = self._make_request(
                "token.get",
                {"output": "extend"}
            )

            now = int(datetime.now().timestamp())
            expired_tokens = []
            long_lived_tokens = []
            no_expiry_tokens = []

            for token in tokens:
                expires_at = int(token.get("expires_at", 0))

                if expires_at == 0:
                    no_expiry_tokens.append(token["name"])
                elif expires_at < now:
                    expired_tokens.append(token["name"])
                else:
                    days_until_expiry = (expires_at - now) / 86400
                    if days_until_expiry > 365:
                        long_lived_tokens.append((token["name"], int(days_until_expiry)))

            if expired_tokens:
                result.add_warning(
                    f"Found {len(expired_tokens)} expired token(s). Run revoke-expired to clean up."
                )

            if no_expiry_tokens:
                result.add_issue(
                    f"Found {len(no_expiry_tokens)} token(s) with no expiration",
                    "medium"
                )
                result.add_recommendation(
                    "Set expiration dates for all tokens (recommended: 90 days)"
                )

            if long_lived_tokens:
                result.add_warning(
                    f"Found {len(long_lived_tokens)} long-lived token(s) (>1 year)"
                )

            if not expired_tokens and not no_expiry_tokens and not long_lived_tokens:
                result.add_recommendation("Token configuration follows best practices [OK]")

        except Exception as e:
            result.add_issue(f"Failed to validate API tokens: {str(e)}", "medium")

        return result

    def run_all_checks(self) -> List[ValidationResult]:
        """Run all security validation checks"""
        print("=" * 60)
        print("Zabbix Security Configuration Validation")
        print("=" * 60)

        checks = [
            self.validate_passwords,
            self.validate_ssl_tls,
            self.validate_authentication,
            self.validate_sessions,
            self.validate_access_control,
            self.validate_api_tokens
        ]

        results = []
        for check in checks:
            print()
            result = check()
            results.append(result)
            self._print_result(result)

        self.results = results
        return results

    def _print_result(self, result: ValidationResult):
        """Print validation result"""
        status = "[OK] PASSED" if result.passed else "[ERROR] FAILED"
        print(f"\n{result.check_name}: {status}")

        if result.issues:
            print(f"\n  Issues ({len(result.issues)}):")
            for issue in result.issues:
                severity_marker = {
                    "critical": "🔴",
                    "high": "🟠",
                    "medium": "🟡",
                    "low": "🟢"
                }.get(issue["severity"], "⚪")
                print(f"    {severity_marker} [{issue['severity'].upper()}] {issue['message']}")

        if result.warnings:
            print(f"\n  Warnings ({len(result.warnings)}):")
            for warning in result.warnings:
                print(f"    [WARN] {warning}")

        if result.recommendations:
            print(f"\n  Recommendations:")
            for rec in result.recommendations:
                print(f"    ℹ {rec}")

    def generate_report(self, output_file: Optional[str] = None) -> Dict:
        """Generate security validation report"""
        report = {
            "timestamp": datetime.now().isoformat(),
            "zabbix_url": self.url,
            "summary": {
                "total_checks": len(self.results),
                "passed": sum(1 for r in self.results if r.passed),
                "failed": sum(1 for r in self.results if not r.passed),
                "total_issues": sum(len(r.issues) for r in self.results),
                "critical_issues": sum(
                    len([i for i in r.issues if i["severity"] == "critical"])
                    for r in self.results
                ),
                "high_issues": sum(
                    len([i for i in r.issues if i["severity"] == "high"])
                    for r in self.results
                )
            },
            "results": [r.to_dict() for r in self.results]
        }

        if output_file:
            with open(output_file, 'w') as f:
                json.dump(report, f, indent=2)
            print(f"\n[OK] Report saved to: {output_file}")

        return report

    def print_summary(self):
        """Print validation summary"""
        print("\n" + "=" * 60)
        print("Validation Summary")
        print("=" * 60)

        total_checks = len(self.results)
        passed = sum(1 for r in self.results if r.passed)
        failed = total_checks - passed

        print(f"\nTotal Checks: {total_checks}")
        print(f"Passed: {passed} [OK]")
        print(f"Failed: {failed} [ERROR]")

        total_issues = sum(len(r.issues) for r in self.results)
        if total_issues > 0:
            print(f"\nTotal Issues: {total_issues}")

            by_severity = defaultdict(int)
            for result in self.results:
                for issue in result.issues:
                    by_severity[issue["severity"]] += 1

            for severity in ["critical", "high", "medium", "low"]:
                count = by_severity[severity]
                if count > 0:
                    print(f"  {severity.capitalize()}: {count}")

        print("\n" + "=" * 60)


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Zabbix Security Configuration Validator",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument("--url", help="Zabbix server URL")
    parser.add_argument("--token", help="API token")
    parser.add_argument("--no-verify-ssl", action="store_true", help="Disable SSL verification")

    parser.add_argument("--check-all", action="store_true", help="Run all security checks")
    parser.add_argument("--check-passwords", action="store_true", help="Check password security")
    parser.add_argument("--check-ssl", action="store_true", help="Check SSL/TLS configuration")
    parser.add_argument("--check-auth", action="store_true", help="Check authentication config")
    parser.add_argument("--check-sessions", action="store_true", help="Check session configuration")
    parser.add_argument("--check-access", action="store_true", help="Check access control")
    parser.add_argument("--check-tokens", action="store_true", help="Check API tokens")

    parser.add_argument("--report", help="Output report file (JSON)")

    args = parser.parse_args()

    # Get connection parameters
    url = args.url or os.environ.get("ZABBIX_URL")
    token = args.token or os.environ.get("ZABBIX_API_TOKEN")

    if not url or not token:
        print("[ERROR] Error: Zabbix URL and API token required")
        return 1

    try:
        validator = SecurityValidator(
            url=url,
            token=token,
            verify_ssl=not args.no_verify_ssl
        )

        # Run checks
        if args.check_all or not any([
            args.check_passwords, args.check_ssl, args.check_auth,
            args.check_sessions, args.check_access, args.check_tokens
        ]):
            validator.run_all_checks()
        else:
            if args.check_passwords:
                result = validator.validate_passwords()
                validator.results.append(result)
                validator._print_result(result)

            if args.check_ssl:
                result = validator.validate_ssl_tls()
                validator.results.append(result)
                validator._print_result(result)

            if args.check_auth:
                result = validator.validate_authentication()
                validator.results.append(result)
                validator._print_result(result)

            if args.check_sessions:
                result = validator.validate_sessions()
                validator.results.append(result)
                validator._print_result(result)

            if args.check_access:
                result = validator.validate_access_control()
                validator.results.append(result)
                validator._print_result(result)

            if args.check_tokens:
                result = validator.validate_api_tokens()
                validator.results.append(result)
                validator._print_result(result)

        # Print summary
        validator.print_summary()

        # Generate report
        if args.report:
            validator.generate_report(args.report)

        # Return exit code based on results
        total_issues = sum(len(r.issues) for r in validator.results)
        return 1 if total_issues > 0 else 0

    except Exception as e:
        print(f"\n[ERROR] Error: {str(e)}")
        if "--debug" in sys.argv:
            raise
        return 1


if __name__ == "__main__":
    sys.exit(main())
