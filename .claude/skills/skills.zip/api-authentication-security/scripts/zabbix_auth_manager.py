#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Authentication Manager

Manages Zabbix API authentication, user accounts, and authentication methods.
Supports username/password authentication, session management, user CRUD operations,
and authentication method configuration (internal, LDAP, SAML, HTTP).

Usage:
    python zabbix_auth_manager.py login --url URL --username USER --password PASS
    python zabbix_auth_manager.py create-user --config user_config.json
    python zabbix_auth_manager.py update-user --username USER --config updates.json
    python zabbix_auth_manager.py delete-user --username USER
    python zabbix_auth_manager.py list-users --role "User role"
    python zabbix_auth_manager.py add-to-group --username USER --group GROUP
    python zabbix_auth_manager.py enable-2fa --username USER
    python zabbix_auth_manager.py configure-ldap --config ldap_config.json
    python zabbix_auth_manager.py test-ldap --username USER
    python zabbix_auth_manager.py set-auth-method --method ldap

Environment Variables:
    ZABBIX_URL: Zabbix server URL
    ZABBIX_USERNAME: Admin username (for initial auth)
    ZABBIX_PASSWORD: Admin password (for initial auth)
    ZABBIX_API_TOKEN: API token (preferred over username/password)
"""

import argparse
import json
import sys
import os
import requests
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from urllib.parse import urljoin

# Constants
DEFAULT_TIMEOUT = 30
MAX_RETRIES = 3
API_VERSION = "6.0"


class ZabbixAuthError(Exception):
    """Custom exception for authentication errors"""
    pass


class ZabbixAuthManager:
    """Manage Zabbix authentication and user accounts"""

    def __init__(self, url: str, token: Optional[str] = None,
                 username: Optional[str] = None, password: Optional[str] = None,
                 verify_ssl: bool = True):
        """
        Initialize Zabbix authentication manager

        Args:
            url: Zabbix server URL
            token: API token (preferred)
            username: Username for authentication
            password: Password for authentication
            verify_ssl: Verify SSL certificates
        """
        self.url = url.rstrip('/')
        self.api_url = urljoin(self.url, '/api_jsonrpc.php')
        self.token = token
        self.username = username
        self.password = password
        self.verify_ssl = verify_ssl
        self.session_token = None
        self.request_id = 0

        if not verify_ssl:
            requests.packages.urllib3.disable_warnings()

    def _make_request(self, method: str, params: Any = None, auth_required: bool = True) -> Dict:
        """
        Make JSON-RPC request to Zabbix API

        Args:
            method: API method to call
            params: Method parameters
            auth_required: Whether authentication is required

        Returns:
            API response result

        Raises:
            ZabbixAuthError: On authentication or API errors
        """
        self.request_id += 1

        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params or {},
            "id": self.request_id
        }

        # Add authentication
        if auth_required:
            if self.token:
                payload["auth"] = self.token
            elif self.session_token:
                payload["auth"] = self.session_token
            elif method != "user.login":
                raise ZabbixAuthError("No authentication token available")

        try:
            response = requests.post(
                self.api_url,
                json=payload,
                verify=self.verify_ssl,
                timeout=DEFAULT_TIMEOUT
            )
            response.raise_for_status()

            result = response.json()

            if "error" in result:
                error = result["error"]
                raise ZabbixAuthError(
                    f"API Error: {error.get('data', error.get('message', 'Unknown error'))}"
                )

            return result.get("result")

        except requests.exceptions.RequestException as e:
            raise ZabbixAuthError(f"Request failed: {str(e)}")

    def login(self) -> str:
        """
        Authenticate with username/password and get session token

        Returns:
            Session authentication token

        Raises:
            ZabbixAuthError: On authentication failure
        """
        if not self.username or not self.password:
            raise ZabbixAuthError("Username and password required for login")

        try:
            token = self._make_request(
                "user.login",
                {
                    "username": self.username,
                    "password": self.password
                },
                auth_required=False
            )

            self.session_token = token
            print(f"[OK] Successfully authenticated as {self.username}")
            return token

        except ZabbixAuthError as e:
            raise ZabbixAuthError(f"Login failed: {str(e)}")

    def logout(self) -> bool:
        """
        Logout and invalidate session token

        Returns:
            True if logout successful
        """
        try:
            result = self._make_request("user.logout")
            print("[OK] Successfully logged out")
            self.session_token = None
            return result
        except ZabbixAuthError as e:
            print(f"[WARN] Logout warning: {str(e)}")
            return False

    def test_auth(self) -> Dict:
        """
        Test authentication and get current user info

        Returns:
            Current user information
        """
        try:
            user_info = self._make_request(
                "user.get",
                {
                    "output": ["userid", "username", "name", "surname", "roleid"],
                    "getAccess": True
                }
            )

            if user_info:
                print(f"[OK] Authentication successful")
                print(f"  User: {user_info[0]['username']}")
                print(f"  Name: {user_info[0]['name']} {user_info[0]['surname']}")
                print(f"  Role ID: {user_info[0]['roleid']}")
                return user_info[0]
            else:
                raise ZabbixAuthError("No user information returned")

        except ZabbixAuthError as e:
            print(f"[ERROR] Authentication test failed: {str(e)}")
            raise

    def create_user(self, config: Dict) -> str:
        """
        Create a new user

        Args:
            config: User configuration dictionary

        Returns:
            Created user ID
        """
        required_fields = ["username", "passwd", "usrgrps", "roleid"]
        for field in required_fields:
            if field not in config:
                raise ValueError(f"Missing required field: {field}")

        try:
            result = self._make_request("user.create", config)
            user_id = result["userids"][0]

            print(f"[OK] User created successfully")
            print(f"  Username: {config['username']}")
            print(f"  User ID: {user_id}")
            print(f"  Role ID: {config['roleid']}")

            return user_id

        except ZabbixAuthError as e:
            raise ZabbixAuthError(f"Failed to create user: {str(e)}")

    def update_user(self, username: str, updates: Dict) -> bool:
        """
        Update existing user

        Args:
            username: Username to update
            updates: Dictionary of fields to update

        Returns:
            True if update successful
        """
        # Get user ID
        users = self._make_request(
            "user.get",
            {
                "filter": {"username": username},
                "output": ["userid"]
            }
        )

        if not users:
            raise ZabbixAuthError(f"User not found: {username}")

        user_id = users[0]["userid"]
        updates["userid"] = user_id

        try:
            self._make_request("user.update", updates)
            print(f"[OK] User updated successfully: {username}")
            return True

        except ZabbixAuthError as e:
            raise ZabbixAuthError(f"Failed to update user: {str(e)}")

    def delete_user(self, username: str) -> bool:
        """
        Delete user by username

        Args:
            username: Username to delete

        Returns:
            True if deletion successful
        """
        # Get user ID
        users = self._make_request(
            "user.get",
            {
                "filter": {"username": username},
                "output": ["userid"]
            }
        )

        if not users:
            raise ZabbixAuthError(f"User not found: {username}")

        user_id = users[0]["userid"]

        try:
            self._make_request("user.delete", [user_id])
            print(f"[OK] User deleted successfully: {username}")
            return True

        except ZabbixAuthError as e:
            raise ZabbixAuthError(f"Failed to delete user: {str(e)}")

    def list_users(self, role_filter: Optional[str] = None) -> List[Dict]:
        """
        List all users with optional role filter

        Args:
            role_filter: Filter by role name

        Returns:
            List of user dictionaries
        """
        params = {
            "output": ["userid", "username", "name", "surname", "roleid", "autologin", "autologout"],
            "selectUsrgrps": ["usrgrpid", "name"],
            "selectRole": ["name"]
        }

        users = self._make_request("user.get", params)

        if role_filter:
            users = [u for u in users if u["role"]["name"] == role_filter]

        print(f"[OK] Found {len(users)} user(s)")
        for user in users:
            print(f"\n  Username: {user['username']}")
            print(f"  Name: {user['name']} {user['surname']}")
            print(f"  Role: {user['role']['name']}")
            print(f"  Groups: {', '.join([g['name'] for g in user['usrgrps']])}")

        return users

    def get_user(self, username: str) -> Dict:
        """
        Get detailed user information

        Args:
            username: Username to retrieve

        Returns:
            User information dictionary
        """
        users = self._make_request(
            "user.get",
            {
                "filter": {"username": username},
                "output": "extend",
                "selectUsrgrps": "extend",
                "selectRole": "extend",
                "selectMedias": "extend"
            }
        )

        if not users:
            raise ZabbixAuthError(f"User not found: {username}")

        user = users[0]

        print(f"[OK] User information:")
        print(f"  Username: {user['username']}")
        print(f"  Name: {user['name']} {user['surname']}")
        print(f"  User ID: {user['userid']}")
        print(f"  Role: {user['role']['name']}")
        print(f"  Auto-login: {'Enabled' if user['autologin'] == '1' else 'Disabled'}")
        print(f"  Auto-logout: {user['autologout']}s")
        print(f"  Groups: {', '.join([g['name'] for g in user['usrgrps']])}")

        return user

    def add_to_group(self, username: str, group_name: str) -> bool:
        """
        Add user to a user group

        Args:
            username: Username to add
            group_name: User group name

        Returns:
            True if successful
        """
        # Get user ID
        users = self._make_request(
            "user.get",
            {
                "filter": {"username": username},
                "output": ["userid"],
                "selectUsrgrps": ["usrgrpid"]
            }
        )

        if not users:
            raise ZabbixAuthError(f"User not found: {username}")

        user = users[0]

        # Get group ID
        groups = self._make_request(
            "usergroup.get",
            {
                "filter": {"name": group_name},
                "output": ["usrgrpid"]
            }
        )

        if not groups:
            raise ZabbixAuthError(f"User group not found: {group_name}")

        group_id = groups[0]["usrgrpid"]

        # Get current groups
        current_groups = [g["usrgrpid"] for g in user["usrgrps"]]

        # Add new group if not already in it
        if group_id in current_groups:
            print(f"[OK] User {username} already in group {group_name}")
            return True

        current_groups.append(group_id)

        # Update user with new groups
        try:
            self._make_request(
                "user.update",
                {
                    "userid": user["userid"],
                    "usrgrps": [{"usrgrpid": gid} for gid in current_groups]
                }
            )
            print(f"[OK] Added user {username} to group {group_name}")
            return True

        except ZabbixAuthError as e:
            raise ZabbixAuthError(f"Failed to add user to group: {str(e)}")

    def enable_2fa(self, username: str) -> bool:
        """
        Enable two-factor authentication for user

        Args:
            username: Username to enable 2FA for

        Returns:
            True if successful
        """
        # Get user ID
        users = self._make_request(
            "user.get",
            {
                "filter": {"username": username},
                "output": ["userid"]
            }
        )

        if not users:
            raise ZabbixAuthError(f"User not found: {username}")

        user_id = users[0]["userid"]

        # Note: 2FA configuration in Zabbix requires additional steps
        # This is a simplified version
        print(f"[WARN] Two-factor authentication configuration:")
        print(f"  User {username} should configure 2FA in Zabbix UI:")
        print(f"  1. Login to Zabbix")
        print(f"  2. Go to User settings -> Two-factor authentication")
        print(f"  3. Scan QR code with authenticator app")
        print(f"  4. Enter verification code")

        return True

    def configure_ldap(self, config: Dict) -> bool:
        """
        Configure LDAP authentication

        Args:
            config: LDAP configuration dictionary

        Returns:
            True if configuration successful
        """
        auth_config = {
            "authentication_type": 1,  # LDAP
            "ldap_host": config.get("host"),
            "ldap_port": config.get("port", 389),
            "ldap_base_dn": config.get("base_dn"),
            "ldap_search_attribute": config.get("search_attribute", "uid"),
            "ldap_bind_dn": config.get("bind_dn", ""),
            "ldap_bind_password": config.get("bind_password", ""),
            "ldap_configured": 1
        }

        try:
            self._make_request("authentication.update", auth_config)
            print(f"[OK] LDAP authentication configured")
            print(f"  Host: {config.get('host')}")
            print(f"  Port: {config.get('port', 389)}")
            print(f"  Base DN: {config.get('base_dn')}")
            return True

        except ZabbixAuthError as e:
            raise ZabbixAuthError(f"Failed to configure LDAP: {str(e)}")

    def test_ldap(self, username: str, password: Optional[str] = None, debug: bool = False) -> bool:
        """
        Test LDAP authentication

        Args:
            username: LDAP username to test
            password: User password (prompted if not provided)
            debug: Enable debug output

        Returns:
            True if LDAP authentication successful
        """
        if not password:
            from getpass import getpass
            password = getpass(f"Enter password for {username}: ")

        try:
            # Get authentication configuration
            auth_config = self._make_request("authentication.get")

            if auth_config.get("authentication_type") != "1":
                print("[WARN] LDAP authentication is not enabled")
                return False

            if debug:
                print(f"LDAP Configuration:")
                print(f"  Host: {auth_config.get('ldap_host')}")
                print(f"  Port: {auth_config.get('ldap_port')}")
                print(f"  Base DN: {auth_config.get('ldap_base_dn')}")

            # Test login
            token = self._make_request(
                "user.login",
                {
                    "username": username,
                    "password": password
                },
                auth_required=False
            )

            print(f"[OK] LDAP authentication successful for {username}")

            # Logout test session
            self.session_token = token
            self.logout()

            return True

        except ZabbixAuthError as e:
            print(f"[ERROR] LDAP authentication failed: {str(e)}")
            return False

    def set_auth_method(self, method: str) -> bool:
        """
        Set authentication method

        Args:
            method: Authentication method (internal, ldap, saml, http)

        Returns:
            True if successful
        """
        method_map = {
            "internal": 0,
            "ldap": 1,
            "saml": 2,
            "http": 4
        }

        if method.lower() not in method_map:
            raise ValueError(f"Invalid auth method. Choose from: {', '.join(method_map.keys())}")

        try:
            self._make_request(
                "authentication.update",
                {"authentication_type": method_map[method.lower()]}
            )
            print(f"[OK] Authentication method set to: {method}")
            return True

        except ZabbixAuthError as e:
            raise ZabbixAuthError(f"Failed to set auth method: {str(e)}")

    def disable_inactive_users(self, days: int = 90) -> int:
        """
        Disable users inactive for specified days

        Args:
            days: Number of days of inactivity

        Returns:
            Number of users disabled
        """
        # Get all users with last access time
        users = self._make_request(
            "user.get",
            {
                "output": ["userid", "username", "attempt_clock"],
                "filter": {"users_status": 0}  # Active users only
            }
        )

        cutoff_timestamp = int((datetime.now() - timedelta(days=days)).timestamp())
        inactive_users = []

        for user in users:
            last_access = int(user.get("attempt_clock", 0))
            if last_access > 0 and last_access < cutoff_timestamp:
                inactive_users.append(user)

        print(f"Found {len(inactive_users)} inactive user(s) (>{days} days)")

        disabled_count = 0
        for user in inactive_users:
            try:
                self._make_request(
                    "user.update",
                    {
                        "userid": user["userid"],
                        "users_status": 1  # Disabled
                    }
                )
                print(f"  [OK] Disabled user: {user['username']}")
                disabled_count += 1
            except ZabbixAuthError as e:
                print(f"  [ERROR] Failed to disable {user['username']}: {str(e)}")

        return disabled_count


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Zabbix Authentication Manager",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument("--url", help="Zabbix server URL (or set ZABBIX_URL env var)")
    parser.add_argument("--username", help="Admin username (or set ZABBIX_USERNAME env var)")
    parser.add_argument("--password", help="Admin password (or set ZABBIX_PASSWORD env var)")
    parser.add_argument("--token", help="API token (or set ZABBIX_API_TOKEN env var)")
    parser.add_argument("--no-verify-ssl", action="store_true", help="Disable SSL verification")

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Login command
    subparsers.add_parser("login", help="Test authentication")

    # Test auth command
    subparsers.add_parser("test-auth", help="Test authentication and show user info")

    # Create user command
    create_parser = subparsers.add_parser("create-user", help="Create new user")
    create_parser.add_argument("--config", required=True, help="User configuration JSON file")

    # Update user command
    update_parser = subparsers.add_parser("update-user", help="Update existing user")
    update_parser.add_argument("--username", required=True, help="Username to update")
    update_parser.add_argument("--config", required=True, help="Updates JSON file")

    # Delete user command
    delete_parser = subparsers.add_parser("delete-user", help="Delete user")
    delete_parser.add_argument("--username", required=True, help="Username to delete")

    # List users command
    list_parser = subparsers.add_parser("list-users", help="List all users")
    list_parser.add_argument("--role", help="Filter by role name")

    # Get user command
    get_parser = subparsers.add_parser("get-user", help="Get user information")
    get_parser.add_argument("--username", required=True, help="Username to retrieve")

    # Add to group command
    group_parser = subparsers.add_parser("add-to-group", help="Add user to group")
    group_parser.add_argument("--username", required=True, help="Username")
    group_parser.add_argument("--group", required=True, help="User group name")

    # Enable 2FA command
    twofa_parser = subparsers.add_parser("enable-2fa", help="Enable 2FA for user")
    twofa_parser.add_argument("--username", required=True, help="Username")

    # Configure LDAP command
    ldap_config_parser = subparsers.add_parser("configure-ldap", help="Configure LDAP authentication")
    ldap_config_parser.add_argument("--config", required=True, help="LDAP configuration JSON file")

    # Test LDAP command
    ldap_test_parser = subparsers.add_parser("test-ldap", help="Test LDAP authentication")
    ldap_test_parser.add_argument("--username", required=True, help="LDAP username")
    ldap_test_parser.add_argument("--password", help="User password (prompted if not provided)")
    ldap_test_parser.add_argument("--debug", action="store_true", help="Enable debug output")

    # Set auth method command
    auth_method_parser = subparsers.add_parser("set-auth-method", help="Set authentication method")
    auth_method_parser.add_argument("--method", required=True,
                                   choices=["internal", "ldap", "saml", "http"],
                                   help="Authentication method")

    # Disable inactive users command
    inactive_parser = subparsers.add_parser("disable-inactive", help="Disable inactive users")
    inactive_parser.add_argument("--days", type=int, default=90, help="Days of inactivity (default: 90)")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    # Get connection parameters
    url = args.url or os.environ.get("ZABBIX_URL")
    username = args.username or os.environ.get("ZABBIX_USERNAME")
    password = args.password or os.environ.get("ZABBIX_PASSWORD")
    token = args.token or os.environ.get("ZABBIX_API_TOKEN")

    if not url:
        print("[ERROR] Error: Zabbix URL required (--url or ZABBIX_URL env var)")
        return 1

    if not token and not (username and password):
        print("[ERROR] Error: Authentication required (--token/--username/--password or env vars)")
        return 1

    try:
        # Initialize manager
        manager = ZabbixAuthManager(
            url=url,
            token=token,
            username=username,
            password=password,
            verify_ssl=not args.no_verify_ssl
        )

        # Login if using username/password
        if not token and username and password:
            manager.login()

        # Execute command
        if args.command == "login":
            manager.login()

        elif args.command == "test-auth":
            manager.test_auth()

        elif args.command == "create-user":
            with open(args.config, 'r') as f:
                config = json.load(f)
            manager.create_user(config)

        elif args.command == "update-user":
            with open(args.config, 'r') as f:
                updates = json.load(f)
            manager.update_user(args.username, updates)

        elif args.command == "delete-user":
            manager.delete_user(args.username)

        elif args.command == "list-users":
            manager.list_users(args.role)

        elif args.command == "get-user":
            manager.get_user(args.username)

        elif args.command == "add-to-group":
            manager.add_to_group(args.username, args.group)

        elif args.command == "enable-2fa":
            manager.enable_2fa(args.username)

        elif args.command == "configure-ldap":
            with open(args.config, 'r') as f:
                config = json.load(f)
            manager.configure_ldap(config)

        elif args.command == "test-ldap":
            manager.test_ldap(args.username, args.password, args.debug)

        elif args.command == "set-auth-method":
            manager.set_auth_method(args.method)

        elif args.command == "disable-inactive":
            count = manager.disable_inactive_users(args.days)
            print(f"\n[OK] Disabled {count} inactive user(s)")

        # Logout if using session token
        if manager.session_token:
            manager.logout()

        return 0

    except ZabbixAuthError as e:
        print(f"\n[ERROR] Error: {str(e)}")
        return 1
    except FileNotFoundError as e:
        print(f"\n[ERROR] File not found: {str(e)}")
        return 1
    except json.JSONDecodeError as e:
        print(f"\n[ERROR] Invalid JSON: {str(e)}")
        return 1
    except KeyboardInterrupt:
        print("\n\n[WARN] Operation cancelled")
        return 130
    except Exception as e:
        print(f"\n[ERROR] Unexpected error: {str(e)}")
        if "--debug" in sys.argv:
            raise
        return 1


if __name__ == "__main__":
    sys.exit(main())
