#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix RBAC Manager

Manages role-based access control including roles, permissions, user groups,
and permission assignments. Supports both built-in and custom roles with
granular permission management.

Usage:
    python zabbix_rbac_manager.py list-roles
    python zabbix_rbac_manager.py show-role --name "User role"
    python zabbix_rbac_manager.py create-role --config role_config.json
    python zabbix_rbac_manager.py assign-role --username USER --role ROLE
    python zabbix_rbac_manager.py show-permissions --username USER
    python zabbix_rbac_manager.py test-permission --username USER --operation host.get
    python zabbix_rbac_manager.py create-usergroup --config group_config.json
    python zabbix_rbac_manager.py list-usergroups

Environment Variables:
    ZABBIX_URL: Zabbix server URL
    ZABBIX_API_TOKEN: API token for authentication
"""

import argparse
import json
import sys
import os
import requests
from typing import Dict, List, Optional, Any
from urllib.parse import urljoin

# Constants
DEFAULT_TIMEOUT = 30

# Built-in role types
ROLE_TYPES = {
    "1": "User role",
    "2": "Admin role",
    "3": "Super admin role"
}

# Permission types
PERMISSION_TYPES = {
    "ui": "UI elements access",
    "api": "API methods access",
    "actions": "Actions access"
}


class ZabbixRBACError(Exception):
    """Custom exception for RBAC errors"""
    pass


class ZabbixRBACManager:
    """Manage Zabbix RBAC"""

    def __init__(self, url: str, token: str, verify_ssl: bool = True):
        """
        Initialize RBAC manager

        Args:
            url: Zabbix server URL
            token: API token for authentication
            verify_ssl: Verify SSL certificates
        """
        self.url = url.rstrip('/')
        self.api_url = urljoin(self.url, '/api_jsonrpc.php')
        self.token = token
        self.verify_ssl = verify_ssl
        self.request_id = 0

        if not verify_ssl:
            requests.packages.urllib3.disable_warnings()

    def _make_request(self, method: str, params: Any = None) -> Dict:
        """Make JSON-RPC request to Zabbix API"""
        self.request_id += 1

        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params or {},
            "auth": self.token,
            "id": self.request_id
        }

        try:
            response = requests.post(
                self.api_url,
                json=payload,
                verify=self.verify_ssl,
                timeout=DEFAULT_TIMEOUT
            )
            response.raise_for_status()

            result = response.json()

            if "error" in result:
                error = result["error"]
                raise ZabbixRBACError(
                    f"API Error: {error.get('data', error.get('message', 'Unknown error'))}"
                )

            return result.get("result")

        except requests.exceptions.RequestException as e:
            raise ZabbixRBACError(f"Request failed: {str(e)}")

    def list_roles(self) -> List[Dict]:
        """
        List all roles

        Returns:
            List of role dictionaries
        """
        roles = self._make_request(
            "role.get",
            {"output": "extend"}
        )

        print(f"[OK] Found {len(roles)} role(s)")

        for role in roles:
            print(f"\n  Name: {role['name']}")
            print(f"  Role ID: {role['roleid']}")
            print(f"  Type: {ROLE_TYPES.get(role['type'], 'Custom')}")
            print(f"  Readonly: {'Yes' if role.get('readonly') == '1' else 'No'}")

        return roles

    def show_role(self, name: str) -> Dict:
        """
        Show detailed role information

        Args:
            name: Role name

        Returns:
            Role information
        """
        roles = self._make_request(
            "role.get",
            {
                "filter": {"name": name},
                "output": "extend",
                "selectRules": "extend"
            }
        )

        if not roles:
            raise ZabbixRBACError(f"Role not found: {name}")

        role = roles[0]

        print(f"[OK] Role: {role['name']}")
        print(f"  Role ID: {role['roleid']}")
        print(f"  Type: {ROLE_TYPES.get(role['type'], 'Custom')}")
        print(f"  Readonly: {'Yes' if role.get('readonly') == '1' else 'No'}")

        # Show rules/permissions
        if role.get("rules"):
            print(f"\n  Permissions:")
            self._print_role_rules(role["rules"])

        return role

    def create_role(self, config: Dict) -> str:
        """
        Create a custom role

        Args:
            config: Role configuration

        Returns:
            Created role ID
        """
        required_fields = ["name", "type"]
        for field in required_fields:
            if field not in config:
                raise ValueError(f"Missing required field: {field}")

        try:
            result = self._make_request("role.create", config)
            role_id = result["roleids"][0]

            print(f"[OK] Role created successfully")
            print(f"  Name: {config['name']}")
            print(f"  Role ID: {role_id}")

            return role_id

        except ZabbixRBACError as e:
            raise ZabbixRBACError(f"Failed to create role: {str(e)}")

    def update_role(self, name: str, updates: Dict) -> bool:
        """
        Update existing role

        Args:
            name: Role name
            updates: Dictionary of fields to update

        Returns:
            True if update successful
        """
        # Get role ID
        roles = self._make_request(
            "role.get",
            {"filter": {"name": name}, "output": ["roleid"]}
        )

        if not roles:
            raise ZabbixRBACError(f"Role not found: {name}")

        role_id = roles[0]["roleid"]
        updates["roleid"] = role_id

        try:
            self._make_request("role.update", updates)
            print(f"[OK] Role updated successfully: {name}")
            return True

        except ZabbixRBACError as e:
            raise ZabbixRBACError(f"Failed to update role: {str(e)}")

    def delete_role(self, name: str) -> bool:
        """
        Delete custom role

        Args:
            name: Role name

        Returns:
            True if deletion successful
        """
        # Get role ID
        roles = self._make_request(
            "role.get",
            {"filter": {"name": name}, "output": ["roleid", "readonly"]}
        )

        if not roles:
            raise ZabbixRBACError(f"Role not found: {name}")

        role = roles[0]

        if role.get("readonly") == "1":
            raise ZabbixRBACError(f"Cannot delete built-in role: {name}")

        try:
            self._make_request("role.delete", [role["roleid"]])
            print(f"[OK] Role deleted successfully: {name}")
            return True

        except ZabbixRBACError as e:
            raise ZabbixRBACError(f"Failed to delete role: {str(e)}")

    def assign_role(self, username: str, role_name: str) -> bool:
        """
        Assign role to user

        Args:
            username: Username
            role_name: Role name

        Returns:
            True if assignment successful
        """
        # Get user ID
        users = self._make_request(
            "user.get",
            {"filter": {"username": username}, "output": ["userid"]}
        )

        if not users:
            raise ZabbixRBACError(f"User not found: {username}")

        user_id = users[0]["userid"]

        # Get role ID
        roles = self._make_request(
            "role.get",
            {"filter": {"name": role_name}, "output": ["roleid"]}
        )

        if not roles:
            raise ZabbixRBACError(f"Role not found: {role_name}")

        role_id = roles[0]["roleid"]

        try:
            self._make_request(
                "user.update",
                {"userid": user_id, "roleid": role_id}
            )
            print(f"[OK] Role assigned successfully")
            print(f"  User: {username}")
            print(f"  Role: {role_name}")
            return True

        except ZabbixRBACError as e:
            raise ZabbixRBACError(f"Failed to assign role: {str(e)}")

    def show_user_permissions(self, username: str) -> Dict:
        """
        Show user permissions

        Args:
            username: Username

        Returns:
            User permissions information
        """
        users = self._make_request(
            "user.get",
            {
                "filter": {"username": username},
                "output": "extend",
                "selectRole": "extend",
                "selectUsrgrps": ["name", "gui_access", "users_status"]
            }
        )

        if not users:
            raise ZabbixRBACError(f"User not found: {username}")

        user = users[0]

        print(f"[OK] Permissions for user: {username}")
        print(f"\n  Role: {user['role']['name']}")
        print(f"  Type: {ROLE_TYPES.get(user['role']['type'], 'Custom')}")

        print(f"\n  User Groups:")
        for group in user["usrgrps"]:
            print(f"    - {group['name']}")
            print(f"      GUI Access: {self._format_gui_access(group['gui_access'])}")
            print(f"      Status: {self._format_user_status(group['users_status'])}")

        if user['role'].get('rules'):
            print(f"\n  Role Permissions:")
            self._print_role_rules(user['role']['rules'])

        return user

    def test_permission(self, username: str, operation: str) -> bool:
        """
        Test if user has permission for operation

        Args:
            username: Username
            operation: API method to test (e.g., "host.get", "host.create")

        Returns:
            True if user has permission
        """
        # Get user info with role
        users = self._make_request(
            "user.get",
            {
                "filter": {"username": username},
                "selectRole": "extend"
            }
        )

        if not users:
            raise ZabbixRBACError(f"User not found: {username}")

        user = users[0]
        role = user["role"]

        print(f"Testing permission for user: {username}")
        print(f"  Role: {role['name']}")
        print(f"  Operation: {operation}")

        # Check API access rules
        if role.get("rules", {}).get("api.access") == "1":
            # Check specific API methods
            api_mode = role.get("rules", {}).get("api.mode", "0")

            if api_mode == "0":  # Deny list
                denied = role.get("rules", {}).get("api", [])
                if operation in denied:
                    print(f"  Result: [ERROR] DENIED (in deny list)")
                    return False
                else:
                    print(f"  Result: [OK] ALLOWED (not in deny list)")
                    return True
            else:  # Allow list
                allowed = role.get("rules", {}).get("api", [])
                if operation in allowed:
                    print(f"  Result: [OK] ALLOWED (in allow list)")
                    return True
                else:
                    print(f"  Result: [ERROR] DENIED (not in allow list)")
                    return False
        else:
            print(f"  Result: [ERROR] DENIED (API access disabled)")
            return False

    def list_usergroups(self) -> List[Dict]:
        """
        List all user groups

        Returns:
            List of user group dictionaries
        """
        groups = self._make_request(
            "usergroup.get",
            {
                "output": "extend",
                "selectRights": "extend",
                "selectUsers": ["username"]
            }
        )

        print(f"[OK] Found {len(groups)} user group(s)")

        for group in groups:
            print(f"\n  Name: {group['name']}")
            print(f"  Group ID: {group['usrgrpid']}")
            print(f"  GUI Access: {self._format_gui_access(group['gui_access'])}")
            print(f"  Users Status: {self._format_user_status(group['users_status'])}")
            print(f"  Members: {len(group.get('users', []))}")

            if group.get("rights"):
                print(f"  Host Group Rights: {len(group['rights'])}")

        return groups

    def create_usergroup(self, config: Dict) -> str:
        """
        Create user group

        Args:
            config: User group configuration

        Returns:
            Created group ID
        """
        required_fields = ["name"]
        for field in required_fields:
            if field not in config:
                raise ValueError(f"Missing required field: {field}")

        try:
            result = self._make_request("usergroup.create", config)
            group_id = result["usrgrpids"][0]

            print(f"[OK] User group created successfully")
            print(f"  Name: {config['name']}")
            print(f"  Group ID: {group_id}")

            return group_id

        except ZabbixRBACError as e:
            raise ZabbixRBACError(f"Failed to create user group: {str(e)}")

    def show_usergroup(self, name: str) -> Dict:
        """
        Show detailed user group information

        Args:
            name: User group name

        Returns:
            User group information
        """
        groups = self._make_request(
            "usergroup.get",
            {
                "filter": {"name": name},
                "output": "extend",
                "selectRights": "extend",
                "selectUsers": ["username"],
                "selectTagFilters": "extend"
            }
        )

        if not groups:
            raise ZabbixRBACError(f"User group not found: {name}")

        group = groups[0]

        print(f"[OK] User Group: {group['name']}")
        print(f"  Group ID: {group['usrgrpid']}")
        print(f"  GUI Access: {self._format_gui_access(group['gui_access'])}")
        print(f"  Users Status: {self._format_user_status(group['users_status'])}")

        print(f"\n  Members ({len(group.get('users', []))}):")
        for user in group.get("users", []):
            print(f"    - {user['username']}")

        if group.get("rights"):
            print(f"\n  Host Group Permissions ({len(group['rights'])}):")
            for right in group["rights"]:
                permission = self._format_permission(right["permission"])
                print(f"    - Host Group ID {right['id']}: {permission}")

        return group

    def _print_role_rules(self, rules: Dict):
        """Print formatted role rules"""
        # UI access
        if "ui" in rules:
            print(f"    UI Elements:")
            ui_elements = rules["ui"]
            for element in ui_elements:
                print(f"      - {element}")

        # API access
        if "api.access" in rules:
            api_access = "Enabled" if rules["api.access"] == "1" else "Disabled"
            print(f"    API Access: {api_access}")

            if rules["api.access"] == "1" and "api" in rules:
                api_mode = "Deny list" if rules.get("api.mode") == "0" else "Allow list"
                print(f"    API Mode: {api_mode}")
                print(f"    API Methods:")
                for method in rules["api"]:
                    print(f"      - {method}")

        # Actions
        if "actions" in rules:
            print(f"    Actions:")
            for action in rules["actions"]:
                print(f"      - {action}")

    def _format_gui_access(self, access: str) -> str:
        """Format GUI access value"""
        access_types = {
            "0": "Default (System)",
            "1": "Internal",
            "2": "LDAP",
            "3": "Disabled"
        }
        return access_types.get(access, "Unknown")

    def _format_user_status(self, status: str) -> str:
        """Format user status value"""
        return "Enabled" if status == "0" else "Disabled"

    def _format_permission(self, permission: str) -> str:
        """Format permission value"""
        permissions = {
            "0": "Deny",
            "2": "Read-only",
            "3": "Read-write"
        }
        return permissions.get(permission, "Unknown")


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Zabbix RBAC Manager",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument("--url", help="Zabbix server URL")
    parser.add_argument("--token", help="API token")
    parser.add_argument("--no-verify-ssl", action="store_true", help="Disable SSL verification")

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # List roles
    subparsers.add_parser("list-roles", help="List all roles")

    # Show role
    show_role_parser = subparsers.add_parser("show-role", help="Show role details")
    show_role_parser.add_argument("--name", required=True, help="Role name")

    # Create role
    create_role_parser = subparsers.add_parser("create-role", help="Create custom role")
    create_role_parser.add_argument("--config", required=True, help="Role configuration JSON file")

    # Update role
    update_role_parser = subparsers.add_parser("update-role", help="Update role")
    update_role_parser.add_argument("--name", required=True, help="Role name")
    update_role_parser.add_argument("--config", required=True, help="Updates JSON file")

    # Delete role
    delete_role_parser = subparsers.add_parser("delete-role", help="Delete custom role")
    delete_role_parser.add_argument("--name", required=True, help="Role name")

    # Assign role
    assign_parser = subparsers.add_parser("assign-role", help="Assign role to user")
    assign_parser.add_argument("--username", required=True, help="Username")
    assign_parser.add_argument("--role", required=True, help="Role name")

    # Show permissions
    perms_parser = subparsers.add_parser("show-permissions", help="Show user permissions")
    perms_parser.add_argument("--username", required=True, help="Username")

    # Test permission
    test_parser = subparsers.add_parser("test-permission", help="Test user permission")
    test_parser.add_argument("--username", required=True, help="Username")
    test_parser.add_argument("--operation", required=True, help="API operation to test")

    # List user groups
    subparsers.add_parser("list-usergroups", help="List all user groups")

    # Show user group
    show_group_parser = subparsers.add_parser("show-usergroup", help="Show user group details")
    show_group_parser.add_argument("--name", required=True, help="User group name")

    # Create user group
    create_group_parser = subparsers.add_parser("create-usergroup", help="Create user group")
    create_group_parser.add_argument("--config", required=True, help="User group config JSON file")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    # Get connection parameters
    url = args.url or os.environ.get("ZABBIX_URL")
    token = args.token or os.environ.get("ZABBIX_API_TOKEN")

    if not url or not token:
        print("[ERROR] Error: Zabbix URL and API token required")
        return 1

    try:
        # Initialize manager
        manager = ZabbixRBACManager(
            url=url,
            token=token,
            verify_ssl=not args.no_verify_ssl
        )

        # Execute command
        if args.command == "list-roles":
            manager.list_roles()

        elif args.command == "show-role":
            manager.show_role(args.name)

        elif args.command == "create-role":
            with open(args.config, 'r') as f:
                config = json.load(f)
            manager.create_role(config)

        elif args.command == "update-role":
            with open(args.config, 'r') as f:
                updates = json.load(f)
            manager.update_role(args.name, updates)

        elif args.command == "delete-role":
            manager.delete_role(args.name)

        elif args.command == "assign-role":
            manager.assign_role(args.username, args.role)

        elif args.command == "show-permissions":
            manager.show_user_permissions(args.username)

        elif args.command == "test-permission":
            manager.test_permission(args.username, args.operation)

        elif args.command == "list-usergroups":
            manager.list_usergroups()

        elif args.command == "show-usergroup":
            manager.show_usergroup(args.name)

        elif args.command == "create-usergroup":
            with open(args.config, 'r') as f:
                config = json.load(f)
            manager.create_usergroup(config)

        return 0

    except ZabbixRBACError as e:
        print(f"\n[ERROR] Error: {str(e)}")
        return 1
    except FileNotFoundError as e:
        print(f"\n[ERROR] File not found: {str(e)}")
        return 1
    except json.JSONDecodeError as e:
        print(f"\n[ERROR] Invalid JSON: {str(e)}")
        return 1
    except KeyboardInterrupt:
        print("\n\n[WARN] Operation cancelled")
        return 130
    except Exception as e:
        print(f"\n[ERROR] Unexpected error: {str(e)}")
        if "--debug" in sys.argv:
            raise
        return 1


if __name__ == "__main__":
    sys.exit(main())
