#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix API Token Manager

Manages API token lifecycle including creation, listing, revocation, and expiration monitoring.
Implements best practices for token management including rotation and expiration policies.

Usage:
    python zabbix_token_manager.py create --name TOKEN_NAME --expires 90d
    python zabbix_token_manager.py list --active
    python zabbix_token_manager.py list --expiring-in 7d
    python zabbix_token_manager.py info --name TOKEN_NAME
    python zabbix_token_manager.py revoke --name TOKEN_NAME
    python zabbix_token_manager.py revoke-expired
    python zabbix_token_manager.py test --token TOKEN_VALUE
    python zabbix_token_manager.py rotate --name TOKEN_NAME

Environment Variables:
    ZABBIX_URL: Zabbix server URL
    ZABBIX_API_TOKEN: API token for authentication
    ZABBIX_USERNAME: Username (if not using token)
    ZABBIX_PASSWORD: Password (if not using token)
"""

import argparse
import json
import sys
import os
import requests
import secrets
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from urllib.parse import urljoin

# Constants
DEFAULT_TIMEOUT = 30
TOKEN_LENGTH = 64
DEFAULT_EXPIRY_DAYS = 90


class ZabbixTokenError(Exception):
    """Custom exception for token management errors"""
    pass


class ZabbixTokenManager:
    """Manage Zabbix API tokens"""

    def __init__(self, url: str, token: Optional[str] = None,
                 username: Optional[str] = None, password: Optional[str] = None,
                 verify_ssl: bool = True):
        """
        Initialize token manager

        Args:
            url: Zabbix server URL
            token: API token for authentication
            username: Username for authentication
            password: Password for authentication
            verify_ssl: Verify SSL certificates
        """
        self.url = url.rstrip('/')
        self.api_url = urljoin(self.url, '/api_jsonrpc.php')
        self.token = token
        self.username = username
        self.password = password
        self.verify_ssl = verify_ssl
        self.session_token = None
        self.request_id = 0

        if not verify_ssl:
            requests.packages.urllib3.disable_warnings()

    def _make_request(self, method: str, params: Any = None, auth_required: bool = True) -> Dict:
        """Make JSON-RPC request to Zabbix API"""
        self.request_id += 1

        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params or {},
            "id": self.request_id
        }

        if auth_required:
            if self.token:
                payload["auth"] = self.token
            elif self.session_token:
                payload["auth"] = self.session_token
            elif method != "user.login":
                raise ZabbixTokenError("No authentication token available")

        try:
            response = requests.post(
                self.api_url,
                json=payload,
                verify=self.verify_ssl,
                timeout=DEFAULT_TIMEOUT
            )
            response.raise_for_status()

            result = response.json()

            if "error" in result:
                error = result["error"]
                raise ZabbixTokenError(
                    f"API Error: {error.get('data', error.get('message', 'Unknown error'))}"
                )

            return result.get("result")

        except requests.exceptions.RequestException as e:
            raise ZabbixTokenError(f"Request failed: {str(e)}")

    def login(self) -> str:
        """Authenticate with username/password"""
        if not self.username or not self.password:
            raise ZabbixTokenError("Username and password required")

        token = self._make_request(
            "user.login",
            {"username": self.username, "password": self.password},
            auth_required=False
        )

        self.session_token = token
        return token

    def create_token(self, name: str, expires_in: Optional[str] = None,
                    description: str = "", username: Optional[str] = None) -> Dict:
        """
        Create a new API token

        Args:
            name: Token name (must be unique)
            expires_in: Expiration period (e.g., "30d", "90d", "1y") or None for no expiration
            description: Token description
            username: Username to create token for (default: current user)

        Returns:
            Token information including token value
        """
        # Calculate expiration timestamp
        expires_at = None
        if expires_in:
            expires_at = self._parse_expiry(expires_in)

        # Get user ID if username provided
        userid = None
        if username:
            users = self._make_request(
                "user.get",
                {"filter": {"username": username}, "output": ["userid"]}
            )
            if not users:
                raise ZabbixTokenError(f"User not found: {username}")
            userid = users[0]["userid"]

        params = {
            "name": name,
            "description": description,
            "status": 0  # Enabled
        }

        if expires_at:
            params["expires_at"] = expires_at

        if userid:
            params["userid"] = userid

        try:
            result = self._make_request("token.create", params)
            token_id = result["tokenids"][0]

            # Get token details including the actual token value
            tokens = self._make_request(
                "token.get",
                {
                    "tokenids": [token_id],
                    "output": "extend"
                }
            )

            if not tokens:
                raise ZabbixTokenError("Failed to retrieve created token")

            token_info = tokens[0]

            print(f"[OK] API token created successfully")
            print(f"  Name: {name}")
            print(f"  Token ID: {token_id}")
            print(f"  Description: {description}")

            if expires_at:
                expiry_date = datetime.fromtimestamp(expires_at)
                print(f"  Expires: {expiry_date.strftime('%Y-%m-%d %H:%M:%S')}")
            else:
                print(f"  Expires: Never")

            print(f"\n[WARN] IMPORTANT: Save this token securely!")
            print(f"  Token will only be displayed once.")
            print(f"  Token value: {token_info.get('token', 'N/A')}")

            return token_info

        except ZabbixTokenError as e:
            raise ZabbixTokenError(f"Failed to create token: {str(e)}")

    def list_tokens(self, active_only: bool = False,
                   expiring_in: Optional[str] = None) -> List[Dict]:
        """
        List API tokens

        Args:
            active_only: Show only active (non-expired) tokens
            expiring_in: Show tokens expiring within period (e.g., "7d", "30d")

        Returns:
            List of token information
        """
        params = {
            "output": "extend",
            "selectUser": ["username"]
        }

        tokens = self._make_request("token.get", params)

        # Filter active tokens
        if active_only:
            now = int(datetime.now().timestamp())
            tokens = [
                t for t in tokens
                if int(t.get("expires_at", 0)) == 0 or int(t["expires_at"]) > now
            ]

        # Filter tokens expiring soon
        if expiring_in:
            expiry_threshold = self._parse_expiry(expiring_in)
            now = int(datetime.now().timestamp())
            tokens = [
                t for t in tokens
                if 0 < int(t.get("expires_at", 0)) <= expiry_threshold
            ]

        print(f"[OK] Found {len(tokens)} token(s)")

        for token in tokens:
            self._print_token_info(token)

        return tokens

    def get_token_info(self, name: str) -> Dict:
        """
        Get detailed information about a specific token

        Args:
            name: Token name

        Returns:
            Token information
        """
        tokens = self._make_request(
            "token.get",
            {
                "filter": {"name": name},
                "output": "extend",
                "selectUser": ["username"]
            }
        )

        if not tokens:
            raise ZabbixTokenError(f"Token not found: {name}")

        token = tokens[0]
        print(f"[OK] Token information:")
        self._print_token_info(token, detailed=True)

        return token

    def revoke_token(self, name: Optional[str] = None,
                    token_id: Optional[str] = None,
                    reason: str = "") -> bool:
        """
        Revoke (delete) an API token

        Args:
            name: Token name
            token_id: Token ID (if name not provided)
            reason: Reason for revocation (for logging)

        Returns:
            True if revocation successful
        """
        # Get token ID if name provided
        if name and not token_id:
            tokens = self._make_request(
                "token.get",
                {"filter": {"name": name}, "output": ["tokenid"]}
            )
            if not tokens:
                raise ZabbixTokenError(f"Token not found: {name}")
            token_id = tokens[0]["tokenid"]

        if not token_id:
            raise ZabbixTokenError("Either name or token_id required")

        try:
            self._make_request("token.delete", [token_id])
            print(f"[OK] Token revoked successfully")
            if name:
                print(f"  Name: {name}")
            print(f"  Token ID: {token_id}")
            if reason:
                print(f"  Reason: {reason}")

            return True

        except ZabbixTokenError as e:
            raise ZabbixTokenError(f"Failed to revoke token: {str(e)}")

    def revoke_expired_tokens(self) -> int:
        """
        Revoke all expired tokens

        Returns:
            Number of tokens revoked
        """
        now = int(datetime.now().timestamp())

        tokens = self._make_request(
            "token.get",
            {"output": ["tokenid", "name", "expires_at"]}
        )

        expired_tokens = [
            t for t in tokens
            if int(t.get("expires_at", 0)) > 0 and int(t["expires_at"]) < now
        ]

        print(f"Found {len(expired_tokens)} expired token(s)")

        revoked_count = 0
        for token in expired_tokens:
            try:
                self._make_request("token.delete", [token["tokenid"]])
                print(f"  [OK] Revoked: {token['name']}")
                revoked_count += 1
            except ZabbixTokenError as e:
                print(f"  [ERROR] Failed to revoke {token['name']}: {str(e)}")

        return revoked_count

    def test_token(self, token_value: str) -> bool:
        """
        Test if a token is valid

        Args:
            token_value: Token value to test

        Returns:
            True if token is valid
        """
        try:
            # Create temporary manager with test token
            test_manager = ZabbixTokenManager(
                url=self.url,
                token=token_value,
                verify_ssl=self.verify_ssl
            )

            # Try to get current user info
            user_info = test_manager._make_request(
                "user.get",
                {"output": ["userid", "username"]}
            )

            if user_info:
                print(f"[OK] Token is valid")
                print(f"  User: {user_info[0]['username']}")
                print(f"  User ID: {user_info[0]['userid']}")
                return True
            else:
                print(f"[ERROR] Token is invalid")
                return False

        except ZabbixTokenError as e:
            print(f"[ERROR] Token test failed: {str(e)}")
            return False

    def rotate_token(self, name: str, new_name: Optional[str] = None,
                    expires_in: Optional[str] = None) -> Dict:
        """
        Rotate token by creating new one and revoking old one

        Args:
            name: Current token name
            new_name: New token name (default: {name}-v2)
            expires_in: Expiration period for new token

        Returns:
            New token information
        """
        # Get old token info
        old_token = self.get_token_info(name)

        # Generate new name if not provided
        if not new_name:
            # Try to increment version number
            if "-v" in name:
                base_name, version = name.rsplit("-v", 1)
                try:
                    new_version = int(version) + 1
                    new_name = f"{base_name}-v{new_version}"
                except ValueError:
                    new_name = f"{name}-v2"
            else:
                new_name = f"{name}-v2"

        print(f"Rotating token: {name} -> {new_name}")

        # Create new token
        new_token = self.create_token(
            name=new_name,
            expires_in=expires_in or "90d",
            description=f"Rotated from {name}: {old_token.get('description', '')}",
            username=old_token.get("user", {}).get("username")
        )

        print(f"\n[WARN] Update your applications with the new token before revoking the old one!")
        print(f"  Old token: {name}")
        print(f"  New token: {new_name}")

        # Ask for confirmation before revoking old token
        response = input("\nRevoke old token now? (yes/no): ")
        if response.lower() in ["yes", "y"]:
            self.revoke_token(name=name, reason="Token rotation")
        else:
            print(f"[WARN] Old token not revoked. Remember to revoke it manually after updating applications.")

        return new_token

    def _parse_expiry(self, expiry_str: str) -> int:
        """
        Parse expiry string to Unix timestamp

        Args:
            expiry_str: Expiry string (e.g., "30d", "90d", "1y")

        Returns:
            Unix timestamp
        """
        if not expiry_str:
            return 0

        unit = expiry_str[-1].lower()
        try:
            value = int(expiry_str[:-1])
        except ValueError:
            raise ZabbixTokenError(f"Invalid expiry format: {expiry_str}")

        now = datetime.now()

        if unit == 'd':
            expiry = now + timedelta(days=value)
        elif unit == 'w':
            expiry = now + timedelta(weeks=value)
        elif unit == 'm':
            expiry = now + timedelta(days=value * 30)
        elif unit == 'y':
            expiry = now + timedelta(days=value * 365)
        else:
            raise ZabbixTokenError(f"Invalid expiry unit: {unit}. Use d/w/m/y")

        return int(expiry.timestamp())

    def _print_token_info(self, token: Dict, detailed: bool = False):
        """Print formatted token information"""
        print(f"\n  Name: {token['name']}")
        print(f"  Token ID: {token['tokenid']}")
        print(f"  User: {token.get('user', {}).get('username', 'N/A')}")

        # Check if expired
        expires_at = int(token.get("expires_at", 0))
        if expires_at == 0:
            print(f"  Expires: Never")
            status = "Active"
        else:
            expiry_date = datetime.fromtimestamp(expires_at)
            print(f"  Expires: {expiry_date.strftime('%Y-%m-%d %H:%M:%S')}")

            now = datetime.now()
            if expiry_date < now:
                status = "Expired"
                days_ago = (now - expiry_date).days
                print(f"  Status: {status} ({days_ago} days ago)")
            else:
                status = "Active"
                days_left = (expiry_date - now).days
                print(f"  Status: {status} ({days_left} days remaining)")

        if detailed:
            created_at = int(token.get("created_at", 0))
            if created_at > 0:
                created_date = datetime.fromtimestamp(created_at)
                print(f"  Created: {created_date.strftime('%Y-%m-%d %H:%M:%S')}")

            if token.get("description"):
                print(f"  Description: {token['description']}")

            last_access = int(token.get("lastaccess", 0))
            if last_access > 0:
                last_access_date = datetime.fromtimestamp(last_access)
                print(f"  Last Access: {last_access_date.strftime('%Y-%m-%d %H:%M:%S')}")


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Zabbix API Token Manager",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument("--url", help="Zabbix server URL")
    parser.add_argument("--username", help="Admin username")
    parser.add_argument("--password", help="Admin password")
    parser.add_argument("--token", help="API token")
    parser.add_argument("--no-verify-ssl", action="store_true", help="Disable SSL verification")

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Create token command
    create_parser = subparsers.add_parser("create", help="Create new API token")
    create_parser.add_argument("--name", required=True, help="Token name")
    create_parser.add_argument("--expires", help="Expiration period (e.g., 30d, 90d, 1y)")
    create_parser.add_argument("--description", default="", help="Token description")
    create_parser.add_argument("--username", help="Username to create token for")

    # List tokens command
    list_parser = subparsers.add_parser("list", help="List API tokens")
    list_parser.add_argument("--active", action="store_true", help="Show only active tokens")
    list_parser.add_argument("--expiring-in", help="Show tokens expiring within period (e.g., 7d)")

    # Token info command
    info_parser = subparsers.add_parser("info", help="Get token information")
    info_parser.add_argument("--name", required=True, help="Token name")

    # Revoke token command
    revoke_parser = subparsers.add_parser("revoke", help="Revoke API token")
    revoke_parser.add_argument("--name", help="Token name")
    revoke_parser.add_argument("--token-id", help="Token ID")
    revoke_parser.add_argument("--reason", default="", help="Revocation reason")

    # Revoke expired command
    subparsers.add_parser("revoke-expired", help="Revoke all expired tokens")

    # Test token command
    test_parser = subparsers.add_parser("test", help="Test token validity")
    test_parser.add_argument("--token-value", required=True, help="Token value to test")

    # Rotate token command
    rotate_parser = subparsers.add_parser("rotate", help="Rotate token")
    rotate_parser.add_argument("--name", required=True, help="Current token name")
    rotate_parser.add_argument("--new-name", help="New token name")
    rotate_parser.add_argument("--expires", help="Expiration period for new token")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    # Get connection parameters
    url = args.url or os.environ.get("ZABBIX_URL")
    username = args.username or os.environ.get("ZABBIX_USERNAME")
    password = args.password or os.environ.get("ZABBIX_PASSWORD")
    token = args.token or os.environ.get("ZABBIX_API_TOKEN")

    if not url:
        print("[ERROR] Error: Zabbix URL required")
        return 1

    if not token and not (username and password):
        print("[ERROR] Error: Authentication required")
        return 1

    try:
        # Initialize manager
        manager = ZabbixTokenManager(
            url=url,
            token=token,
            username=username,
            password=password,
            verify_ssl=not args.no_verify_ssl
        )

        # Login if using username/password
        if not token and username and password:
            manager.login()

        # Execute command
        if args.command == "create":
            manager.create_token(
                name=args.name,
                expires_in=args.expires,
                description=args.description,
                username=args.username
            )

        elif args.command == "list":
            manager.list_tokens(
                active_only=args.active,
                expiring_in=args.expiring_in
            )

        elif args.command == "info":
            manager.get_token_info(args.name)

        elif args.command == "revoke":
            manager.revoke_token(
                name=args.name,
                token_id=args.token_id,
                reason=args.reason
            )

        elif args.command == "revoke-expired":
            count = manager.revoke_expired_tokens()
            print(f"\n[OK] Revoked {count} expired token(s)")

        elif args.command == "test":
            manager.test_token(args.token_value)

        elif args.command == "rotate":
            manager.rotate_token(
                name=args.name,
                new_name=args.new_name,
                expires_in=args.expires
            )

        return 0

    except ZabbixTokenError as e:
        print(f"\n[ERROR] Error: {str(e)}")
        return 1
    except KeyboardInterrupt:
        print("\n\n[WARN] Operation cancelled")
        return 130
    except Exception as e:
        print(f"\n[ERROR] Unexpected error: {str(e)}")
        if "--debug" in sys.argv:
            raise
        return 1


if __name__ == "__main__":
    sys.exit(main())
