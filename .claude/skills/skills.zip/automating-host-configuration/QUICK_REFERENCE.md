# Quick Reference - Zabbix Host Manager

## Command Syntax

```bash
python scripts/zabbix_host_manager.py COMMAND [OPTIONS]
```

## Environment Variables

```bash
export ZABBIX_API_URL="https://zabbix.example.com/api_jsonrpc.php"
export ZABBIX_API_TOKEN="your-api-token"
# OR
export ZABBIX_API_USER="username"
export ZABBIX_API_PASSWORD="password"
```

## Common Commands

### Create Host
```bash
python scripts/zabbix_host_manager.py create --config host_config.json
```

### Update Host
```bash
python scripts/zabbix_host_manager.py update --host-id 10084 --config updated_config.json
```

### Get Host Info
```bash
# By ID
python scripts/zabbix_host_manager.py get --host-id 10084

# By name
python scripts/zabbix_host_manager.py get --host-name server-01.example.com

# YAML output
python scripts/zabbix_host_manager.py get --host-id 10084 --output yaml

# Table output
python scripts/zabbix_host_manager.py get --host-id 10084 --output table
```

### Delete Host
```bash
# With confirmation
python scripts/zabbix_host_manager.py delete --host-id 10084

# Skip confirmation
python scripts/zabbix_host_manager.py delete --host-id 10084 --confirm
```

### Enable/Disable Host
```bash
# Enable
python scripts/zabbix_host_manager.py enable --host-id 10084

# Disable
python scripts/zabbix_host_manager.py disable --host-id 10084
```

### Bulk Operations
```bash
python scripts/zabbix_host_manager.py bulk-create --config bulk_hosts.yaml
```

### Host Groups
```bash
# Create group
python scripts/zabbix_host_manager.py create-group --name "My Servers"

# List all groups
python scripts/zabbix_host_manager.py get-groups

# Filter by name
python scripts/zabbix_host_manager.py get-groups --name "Linux servers"
```

## Validation Commands

### Validate Single Host
```bash
python scripts/validate_host_config.py host_config.json
```

### Validate Bulk Configuration
```bash
python scripts/validate_host_config.py bulk_hosts.yaml --bulk
```

### Strict Validation
```bash
python scripts/validate_host_config.py config.json --strict
```

### Quiet Mode
```bash
python scripts/validate_host_config.py config.json --quiet
```

## Minimal Configuration Template

```json
{
  "host": "server-name",
  "groups": [{"groupid": "2"}],
  "interfaces": [{
    "type": 1,
    "main": 1,
    "useip": 1,
    "ip": "192.168.1.10",
    "dns": "",
    "port": "10050"
  }]
}
```

## Interface Types

| Type | Name | Port |
|------|------|------|
| 1 | Zabbix Agent | 10050 |
| 2 | SNMP | 161 |
| 3 | IPMI | 623 |
| 4 | JMX | 12345 |

## Host Status Values

| Value | Status |
|-------|--------|
| 0 | Enabled |
| 1 | Disabled |

## Inventory Modes

| Value | Mode |
|-------|------|
| -1 | Disabled |
| 0 | Manual |
| 1 | Automatic |

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Error (validation, API, network, etc.) |

## Common Error Solutions

**Authentication failed**
- Check token/credentials
- Verify user is enabled
- Ensure API access is enabled

**Missing required field**
- Add required fields: host, groups, interfaces
- Check configuration syntax

**Interface rejected**
- Validate IP address format
- Check port is 1-65535
- Ensure interface type matches configuration

**Permission denied**
- Verify API user has required permissions
- Check host group access rights

**Template assignment fails**
- Verify template IDs exist
- Check template compatibility with groups

## Pro Tips

1. **Always validate first**: `validate_host_config.py` before `zabbix_host_manager.py`
2. **Use environment variables**: Keep credentials secure
3. **Test in dev**: Try commands in development environment first
4. **Check output**: Review JSON/YAML output for details
5. **Bulk operations**: Process multiple hosts efficiently
6. **Version control**: Track configuration changes
7. **Meaningful names**: Use descriptive host names
8. **Tag everything**: Use tags for automation and filtering
9. **Document macros**: Add descriptions to custom macros
10. **Monitor logs**: Check Zabbix audit logs for API activity

## One-Liner Examples

**Create from template:**
```bash
cat template.json | sed 's/HOSTNAME/server-01/g' | python scripts/zabbix_host_manager.py create --config /dev/stdin
```

**Get all disabled hosts:**
```bash
python scripts/zabbix_host_manager.py get | jq '.[] | select(.status=="1") | .host'
```

**Bulk disable hosts by pattern:**
```bash
for id in $(python scripts/zabbix_host_manager.py get | jq -r '.[] | select(.host | contains("dev")) | .hostid'); do
  python scripts/zabbix_host_manager.py disable --host-id $id
done
```

**Export host configurations:**
```bash
python scripts/zabbix_host_manager.py get --host-id 10084 --output yaml > backup.yaml
```

**Validate all configs in directory:**
```bash
for f in configs/*.json; do
  echo "Validating $f..."
  python scripts/validate_host_config.py "$f"
done
```

## Integration Examples

**Ansible:**
```yaml
- name: Create Zabbix host
  command: python scripts/zabbix_host_manager.py create --config {{ config_file }}
  environment:
    ZABBIX_API_URL: "{{ zabbix_url }}"
    ZABBIX_API_TOKEN: "{{ zabbix_token }}"
```

**Bash Script:**
```bash
#!/bin/bash
export ZABBIX_API_URL="https://zabbix.example.com/api_jsonrpc.php"
export ZABBIX_API_TOKEN="secret-token"

python scripts/validate_host_config.py "$1" || exit 1
python scripts/zabbix_host_manager.py create --config "$1"
```

**Python:**
```python
import subprocess
import os

os.environ['ZABBIX_API_URL'] = 'https://zabbix.example.com/api_jsonrpc.php'
os.environ['ZABBIX_API_TOKEN'] = 'token'

result = subprocess.run([
    'python', 'scripts/zabbix_host_manager.py',
    'create', '--config', 'host.json'
], capture_output=True)

if result.returncode == 0:
    print("Success!")
```

## Getting Help

```bash
# Main script help
python scripts/zabbix_host_manager.py --help

# Command-specific help
python scripts/zabbix_host_manager.py create --help
python scripts/zabbix_host_manager.py update --help

# Validation help
python scripts/validate_host_config.py --help
```
