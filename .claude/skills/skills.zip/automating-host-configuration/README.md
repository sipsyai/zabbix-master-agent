# Automating Host Configuration for Zabbix

Complete automation toolkit for managing Zabbix host lifecycle through the API.

## Quick Start

### Prerequisites

- Python 3.7 or higher
- Zabbix 6.0+ server with API access
- API token or user credentials with appropriate permissions

### Installation

1. Ensure Python dependencies are available (standard library only):
   ```bash
   python --version  # Verify Python 3.7+
   ```

2. Set up environment variables (recommended):
   ```bash
   export ZABBIX_API_URL="https://zabbix.example.com/api_jsonrpc.php"
   export ZABBIX_API_TOKEN="your-api-token-here"
   ```

### Basic Usage

#### Create a Single Host

```bash
python scripts/zabbix_host_manager.py create \
  --url https://zabbix.example.com/api_jsonrpc.php \
  --token YOUR_API_TOKEN \
  --config examples/host_config.json
```

Or using environment variables:

```bash
python scripts/zabbix_host_manager.py create --config examples/host_config.json
```

#### Update Host Configuration

```bash
python scripts/zabbix_host_manager.py update \
  --host-id 10084 \
  --config updated_config.json
```

#### Get Host Information

```bash
# By host ID
python scripts/zabbix_host_manager.py get --host-id 10084

# By host name
python scripts/zabbix_host_manager.py get --host-name web-server-01.example.com

# Output in different formats
python scripts/zabbix_host_manager.py get --host-id 10084 --output yaml
python scripts/zabbix_host_manager.py get --host-id 10084 --output table
```

#### Delete a Host

```bash
# With confirmation prompt
python scripts/zabbix_host_manager.py delete --host-id 10084

# Skip confirmation (use with caution)
python scripts/zabbix_host_manager.py delete --host-id 10084 --confirm
```

#### Enable/Disable Host Monitoring

```bash
# Enable host
python scripts/zabbix_host_manager.py enable --host-id 10084

# Disable host
python scripts/zabbix_host_manager.py disable --host-id 10084
```

#### Bulk Operations

```bash
python scripts/zabbix_host_manager.py bulk-create \
  --config examples/bulk_hosts.yaml
```

#### Host Group Management

```bash
# Create a host group
python scripts/zabbix_host_manager.py create-group --name "Web Servers"

# List host groups
python scripts/zabbix_host_manager.py get-groups

# Filter by name
python scripts/zabbix_host_manager.py get-groups --name "Linux servers"
```

## Configuration Validation

Always validate configurations before applying:

```bash
# Validate single host configuration
python scripts/validate_host_config.py examples/host_config.json

# Validate bulk configuration
python scripts/validate_host_config.py examples/bulk_hosts.yaml --bulk

# Strict mode (warnings as errors)
python scripts/validate_host_config.py config.json --strict

# Quiet mode (summary only)
python scripts/validate_host_config.py config.json --quiet
```

## Configuration File Format

### Minimal Configuration

```json
{
  "host": "server-01.example.com",
  "groups": [{"groupid": "2"}],
  "interfaces": [{
    "type": 1,
    "main": 1,
    "useip": 1,
    "ip": "192.168.1.10",
    "dns": "",
    "port": "10050"
  }]
}
```

### Complete Configuration

See `examples/host_config.json` for a comprehensive example including:
- Host metadata (name, description, status)
- Multiple interfaces (agent, SNMP, JMX, IPMI)
- Template assignments
- Complete inventory data
- Host macros
- Tags
- TLS/encryption settings

### Bulk Configuration

See `examples/bulk_hosts.yaml` for provisioning multiple hosts with varied configurations.

## Interface Types

| Type | Name | Default Port | Description |
|------|------|--------------|-------------|
| 1 | Zabbix Agent | 10050 | Zabbix agent monitoring |
| 2 | SNMP | 161 | SNMP v1/v2c/v3 monitoring |
| 3 | IPMI | 623 | IPMI hardware monitoring |
| 4 | JMX | 12345 | Java JMX monitoring |

## Host Status

| Value | Status | Description |
|-------|--------|-------------|
| 0 | Enabled | Host monitoring is active |
| 1 | Disabled | Host monitoring is disabled |

## Inventory Mode

| Value | Mode | Description |
|-------|------|-------------|
| -1 | Disabled | Inventory disabled |
| 0 | Manual | Manual inventory management |
| 1 | Automatic | Automatic inventory population |

## Common Workflows

### Onboarding New Server

1. **Prepare configuration file**:
   ```bash
   cp examples/host_config.json my-server.json
   # Edit my-server.json with server details
   ```

2. **Validate configuration**:
   ```bash
   python scripts/validate_host_config.py my-server.json
   ```

3. **Create host**:
   ```bash
   python scripts/zabbix_host_manager.py create --config my-server.json
   ```

4. **Verify creation**:
   ```bash
   python scripts/zabbix_host_manager.py get --host-name my-server.example.com
   ```

### Decommissioning Host

1. **Disable monitoring** (optional, allows keeping historical data):
   ```bash
   python scripts/zabbix_host_manager.py disable --host-id 10084
   ```

2. **Delete host**:
   ```bash
   python scripts/zabbix_host_manager.py delete --host-id 10084
   ```

### Infrastructure as Code Integration

1. **Define infrastructure in YAML**:
   ```yaml
   hosts:
     - host: web-01.example.com
       groups: [{"groupid": "2"}]
       interfaces: [...]
     - host: web-02.example.com
       groups: [{"groupid": "2"}]
       interfaces: [...]
   ```

2. **Version control**:
   ```bash
   git add infrastructure.yaml
   git commit -m "Add new web servers"
   ```

3. **Apply configuration**:
   ```bash
   python scripts/zabbix_host_manager.py bulk-create --config infrastructure.yaml
   ```

### Standardizing Configurations

1. **Create template configuration** for each server type
2. **Use bulk configuration** to apply consistently
3. **Validate** before applying
4. **Track changes** in version control

## API Permissions

The API user requires the following permissions:

- **Host groups**: Read, Write (if creating groups)
- **Hosts**: Read, Write, Delete (as needed)
- **Templates**: Read (for template assignment)
- **Host inventory**: Read, Write (if managing inventory)

Minimal role: **User** with read/write access to relevant host groups.

Recommended: Create dedicated API user with specific permissions.

## Authentication

### API Token (Recommended)

1. Generate token in Zabbix UI: Administration → Users → API tokens
2. Use token in commands or set environment variable:
   ```bash
   export ZABBIX_API_TOKEN="your-token-here"
   ```

### Username/Password

```bash
export ZABBIX_API_USER="api-user"
export ZABBIX_API_PASSWORD="secure-password"
```

Script will authenticate and obtain session token automatically.

## Error Handling

The scripts implement comprehensive error handling:

- **Authentication errors**: Clear messages about invalid credentials/tokens
- **Permission errors**: Indicates missing API permissions
- **Validation errors**: Detailed configuration errors before API calls
- **API errors**: Full error messages from Zabbix API
- **Network errors**: Automatic retry with exponential backoff
- **Duplicate detection**: Checks before creation

All errors include actionable guidance for resolution.

## Troubleshooting

### Issue: "Authentication failed - invalid token/credentials"

**Solution**:
- Verify API token is correct and not expired
- Check user account is enabled
- Ensure API access is enabled in Zabbix configuration

### Issue: "Missing required field: 'groups'"

**Solution**:
- Add at least one host group to configuration
- Verify group IDs exist in Zabbix

### Issue: "Interface configuration rejected"

**Solution**:
- Validate interface type matches port and protocol
- Ensure IP address or DNS name is valid
- Check port is in valid range (1-65535)

### Issue: "Template assignment fails"

**Solution**:
- Verify template IDs exist in Zabbix
- Check templates are compatible with host groups
- Ensure API user has access to templates

### Issue: "Bulk operation partially fails"

**Solution**:
- Review detailed error messages in output
- Validate failed configurations individually
- Re-run bulk operation with only failed items

### Issue: "Permission denied errors"

**Solution**:
- Check API user role has sufficient permissions
- Verify access to specific host groups
- Review host group permissions in user role

## Integration Examples

### Ansible Playbook

```yaml
- name: Provision Zabbix monitoring
  hosts: localhost
  tasks:
    - name: Create Zabbix host configuration
      template:
        src: host_config.json.j2
        dest: /tmp/{{ inventory_hostname }}.json

    - name: Create Zabbix host
      command: >
        python scripts/zabbix_host_manager.py create
        --config /tmp/{{ inventory_hostname }}.json
      environment:
        ZABBIX_API_URL: "{{ zabbix_api_url }}"
        ZABBIX_API_TOKEN: "{{ zabbix_api_token }}"
```

### Terraform

```hcl
resource "null_resource" "zabbix_host" {
  provisioner "local-exec" {
    command = "python scripts/zabbix_host_manager.py create --config ${var.host_config}"
    environment = {
      ZABBIX_API_URL   = var.zabbix_api_url
      ZABBIX_API_TOKEN = var.zabbix_api_token
    }
  }
}
```

### CI/CD Pipeline (GitLab)

```yaml
provision_monitoring:
  stage: deploy
  script:
    - python scripts/validate_host_config.py config.json
    - python scripts/zabbix_host_manager.py create --config config.json
  environment:
    name: production
  only:
    - main
```

### Webhook Endpoint (Flask)

```python
from flask import Flask, request, jsonify
import subprocess

app = Flask(__name__)

@app.route('/provision', methods=['POST'])
def provision_host():
    config = request.json

    # Save config to file
    with open('/tmp/host_config.json', 'w') as f:
        json.dump(config, f)

    # Call provisioning script
    result = subprocess.run(
        ['python', 'scripts/zabbix_host_manager.py', 'create',
         '--config', '/tmp/host_config.json'],
        capture_output=True
    )

    return jsonify({'status': 'created' if result.returncode == 0 else 'failed'})
```

## Best Practices

1. **Always validate before applying**: Use validation script to catch errors early
2. **Use environment variables**: Keep credentials out of command history
3. **Version control configurations**: Track changes to infrastructure as code
4. **Test in development first**: Validate in non-production environment
5. **Use meaningful names**: Follow consistent naming conventions
6. **Populate inventory**: Maintain comprehensive asset information
7. **Tag appropriately**: Use tags for categorization and automation
8. **Document macros**: Add descriptions to custom macros
9. **Review bulk operations**: Check results for partial failures
10. **Implement change management**: Use approval workflows for production changes

## Security Considerations

- **Token security**: Never commit tokens to version control
- **Least privilege**: Grant minimal required API permissions
- **Audit logging**: Enable and monitor Zabbix API audit logs
- **Network restrictions**: Limit API access by IP/network where possible
- **Token rotation**: Regularly rotate API tokens
- **Secure storage**: Use secrets management for credentials (Vault, etc.)
- **TLS encryption**: Always use HTTPS for API connections
- **Configuration validation**: Prevent misconfigurations that could impact monitoring

## Additional Resources

- **Zabbix Host Configuration**: [../../zabbix-docs-masters/zabbix-docs/07_Configuration/1_hosts.md](../../zabbix-docs-masters/zabbix-docs/07_Configuration/1_hosts.md)
- **Zabbix API Documentation**: Official Zabbix API reference
- **Skill Documentation**: See [SKILL.md](SKILL.md) for complete skill guide

## Support

For issues or questions:
1. Check troubleshooting section above
2. Review Zabbix logs for detailed error messages
3. Validate configurations with validation script
4. Consult Zabbix API documentation for API-specific issues

## License

This skill is part of the Zabbix Skills collection.
