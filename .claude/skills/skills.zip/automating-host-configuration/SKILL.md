---
name: Automating Host Configuration for Zabbix
description: Automate Zabbix host lifecycle management including creating, updating, deleting hosts, managing host groups, interfaces, and inventory through the Zabbix API. Use when provisioning new servers, decommissioning infrastructure, standardizing configurations, or performing bulk host operations.
degree_of_freedom: medium
---

# Automating Host Configuration for Zabbix

## Overview

This skill enables automated management of Zabbix hosts through the API. It supports the complete host lifecycle: creation, configuration updates, deletion, group management, interface configuration, and inventory updates.

## Quick Start

### Basic Host Creation

```python
# Use the zabbix_host_manager.py script
python scripts/zabbix_host_manager.py create \
  --url https://zabbix.example.com/api_jsonrpc.php \
  --token YOUR_API_TOKEN \
  --config examples/host_config.json
```

### Update Host Configuration

```python
python scripts/zabbix_host_manager.py update \
  --url https://zabbix.example.com/api_jsonrpc.php \
  --token YOUR_API_TOKEN \
  --host-id 10001 \
  --config updated_config.json
```

### Bulk Operations

```python
python scripts/zabbix_host_manager.py bulk-create \
  --url https://zabbix.example.com/api_jsonrpc.php \
  --token YOUR_API_TOKEN \
  --config examples/bulk_hosts.yaml
```

## Core Capabilities

### 1. Host Creation

Create hosts with full configuration including:
- Host name and visible name
- Host groups (required)
- Monitoring interfaces (agent, SNMP, JMX, IPMI)
- Templates
- Inventory data
- Macros
- Tags

**Example configuration:**

```json
{
  "host": "web-server-01",
  "name": "Web Server 01",
  "groups": [{"groupid": "2"}],
  "interfaces": [{
    "type": 1,
    "main": 1,
    "useip": 1,
    "ip": "192.168.1.10",
    "dns": "",
    "port": "10050"
  }],
  "templates": [{"templateid": "10001"}],
  "inventory_mode": 0,
  "inventory": {
    "type": "Web Server",
    "location": "DC1-Rack5"
  }
}
```

### 2. Host Updates

Update existing host properties:
- Status (enabled/disabled)
- Host groups
- Templates
- Interfaces
- Inventory
- Monitoring settings
- Macros and tags

### 3. Host Deletion

Remove hosts from monitoring with optional validation checks.

### 4. Host Group Management

- Create new host groups
- Assign hosts to groups
- Remove hosts from groups
- Query group memberships

### 5. Interface Configuration

Configure multiple interface types per host:
- **Agent (type 1)**: Zabbix agent on port 10050
- **SNMP (type 2)**: SNMP v1/v2c/v3
- **IPMI (type 3)**: IPMI monitoring
- **JMX (type 4)**: Java JMX monitoring

Each interface supports:
- IP or DNS resolution
- Custom ports
- Main interface designation
- Bulk configuration

### 6. Inventory Management

Update host inventory fields:
- Hardware information
- Location data
- Contact information
- Custom fields

### 7. Search and Filter

Query hosts by:
- Host name or ID
- Group membership
- Template assignment
- Status
- Tags
- Custom filters

## Workflows

### Onboarding New Server

1. Validate server accessibility
2. Create host entry with appropriate groups
3. Configure monitoring interface
4. Assign templates based on server role
5. Set inventory data
6. Verify host creation
7. Wait for initial data collection

### Decommissioning Host

1. Locate host by name/IP/ID
2. Disable monitoring
3. Export historical data (if needed)
4. Remove from host groups
5. Delete host configuration
6. Confirm deletion

### Bulk Configuration Update

1. Load host list from file
2. Validate configurations
3. Process each host sequentially
4. Collect success/failure results
5. Generate report
6. Handle errors with rollback option

### Infrastructure as Code Integration

1. Define hosts in YAML/JSON
2. Validate against schema
3. Compare with existing configuration
4. Apply only changed configurations
5. Track changes in version control

## API Methods Reference

See [Zabbix API Documentation](file://../../zabbix-docs-masters/zabbix-docs/07_Configuration/1_hosts.md) for complete details.

### Key Methods

- `host.create`: Create new host
- `host.update`: Update host properties
- `host.delete`: Remove host
- `host.get`: Query hosts
- `hostgroup.create`: Create host group
- `hostgroup.get`: Query host groups
- `hostinterface.create`: Add interface
- `hostinterface.update`: Modify interface

## Configuration Examples

### Complete Host Configuration

See `examples/host_config.json` for detailed configuration including all supported fields.

### Bulk Host Provisioning

See `examples/bulk_hosts.yaml` for provisioning multiple hosts with varied configurations.

## Error Handling

The scripts implement comprehensive error handling:

- **Authentication errors**: Verify API token/credentials
- **Permission errors**: Check user role permissions
- **Validation errors**: Configuration schema validation
- **API errors**: Detailed error messages from Zabbix
- **Network errors**: Retry logic with backoff
- **Duplicate detection**: Check before creation

## Validation

Use the validation script before applying configurations:

```bash
python scripts/validate_host_config.py examples/host_config.json
```

Validates:
- Required fields presence
- Field format correctness
- Group and template references
- Interface configuration
- IP address/DNS format
- Port ranges

## Best Practices

1. **Use host groups**: Always assign at least one host group
2. **Template inheritance**: Leverage templates for standardization
3. **Naming conventions**: Use consistent, descriptive host names
4. **Inventory data**: Populate inventory for asset management
5. **Interface types**: Configure only required interfaces
6. **Tags**: Use tags for categorization and filtering
7. **Macros**: Use host-level macros for customization
8. **Testing**: Validate in dev environment first
9. **Backups**: Export configurations before bulk changes
10. **Monitoring**: Verify data collection after creation

## Common Patterns

### Pattern 1: Auto-Discovery Integration

When integrating with auto-discovery:
1. Discovery rule identifies new hosts
2. Script creates host with discovered attributes
3. Apply templates based on detected OS/services
4. Set inventory from discovery data

### Pattern 2: CI/CD Pipeline

For automated deployments:
1. Deployment pipeline creates new instance
2. Trigger host creation webhook
3. Script creates Zabbix host
4. Configure monitoring based on deployment metadata
5. Verify monitoring active before completing deployment

### Pattern 3: Configuration Management

With Ansible/Terraform:
1. Define desired state in configuration files
2. Query current Zabbix state
3. Calculate differences
4. Apply changes to reconcile
5. Update configuration management state

## Troubleshooting

**Issue**: Host creation fails with "group not found"
- Solution: Verify group IDs exist using `hostgroup.get`

**Issue**: Interface configuration rejected
- Solution: Check interface type matches port and protocol

**Issue**: Template assignment fails
- Solution: Ensure templates are compatible with host groups

**Issue**: Bulk operation partially fails
- Solution: Check logs for specific host errors, retry failed items

**Issue**: Permission denied errors
- Solution: Verify API user has sufficient role permissions

## Security Considerations

1. **API Token Storage**: Use environment variables or secret management
2. **Least Privilege**: Grant minimal required API permissions
3. **Audit Logging**: Enable and monitor API access logs
4. **Network Security**: Restrict API access by IP/network
5. **Configuration Validation**: Validate before execution to prevent misconfigurations

## Integration Examples

### With Terraform

```hcl
resource "null_resource" "zabbix_host" {
  provisioner "local-exec" {
    command = "python scripts/zabbix_host_manager.py create --config ${var.host_config}"
  }
}
```

### With Ansible

```yaml
- name: Create Zabbix host
  command: >
    python scripts/zabbix_host_manager.py create
    --url {{ zabbix_url }}
    --token {{ zabbix_token }}
    --config {{ config_file }}
```

### With Webhook

```python
# Flask webhook endpoint
@app.route('/provision', methods=['POST'])
def provision_host():
    config = request.json
    result = create_zabbix_host(config)
    return jsonify(result)
```

## Additional Resources

- Zabbix Host Configuration: [file://../../zabbix-docs-masters/zabbix-docs/07_Configuration/1_hosts.md](file://../../zabbix-docs-masters/zabbix-docs/07_Configuration/1_hosts.md)
- API Documentation: Official Zabbix API docs
- Script Usage: See README.md for detailed script documentation
