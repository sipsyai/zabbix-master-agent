# Testing Guide - Zabbix Host Manager

This guide provides comprehensive testing procedures for the Zabbix Host Manager skill.

## Prerequisites

Before testing:
1. Access to a Zabbix test/development instance (DO NOT test on production initially)
2. API token or credentials with appropriate permissions
3. Python 3.7+ installed
4. PyYAML installed: `pip install PyYAML`

## Setup Test Environment

### 1. Set Environment Variables

```bash
export ZABBIX_API_URL="https://zabbix-dev.example.com/api_jsonrpc.php"
export ZABBIX_API_TOKEN="your-test-api-token"
```

### 2. Verify Connectivity

```bash
# Test API connectivity by listing host groups
python scripts/zabbix_host_manager.py get-groups
```

Expected: List of existing host groups without errors.

## Unit Tests

### Test 1: Configuration Validation

```bash
# Test valid configuration
python scripts/validate_host_config.py examples/host_config.json
# Expected: "Configuration is valid" message

# Test invalid configuration (create test file)
cat > /tmp/invalid_config.json <<EOF
{
  "host": "test-server",
  "interfaces": []
}
EOF

python scripts/validate_host_config.py /tmp/invalid_config.json
# Expected: Validation errors about missing groups and interfaces
```

### Test 2: Bulk Configuration Validation

```bash
# Test bulk validation
python scripts/validate_host_config.py examples/bulk_hosts.yaml --bulk
# Expected: Summary showing validation results for all hosts
```

### Test 3: Strict Validation Mode

```bash
# Create config with warnings
cat > /tmp/warning_config.json <<EOF
{
  "host": "test server with spaces",
  "groups": [{"groupid": "2"}],
  "interfaces": [{
    "type": 1,
    "main": 1,
    "useip": 1,
    "ip": "192.168.1.10",
    "dns": "",
    "port": "10050"
  }]
}
EOF

python scripts/validate_host_config.py /tmp/warning_config.json --strict
# Expected: Fail due to hostname with spaces (warning treated as error)
```

## Integration Tests

### Test 4: Host Group Operations

```bash
# Create test group
python scripts/zabbix_host_manager.py create-group --name "Test Automation Group"
# Expected: Success message with group ID

# List groups and verify
python scripts/zabbix_host_manager.py get-groups --name "Test Automation Group"
# Expected: JSON output with the created group
```

### Test 5: Single Host Creation

```bash
# Create minimal test configuration
cat > /tmp/test_host.json <<EOF
{
  "host": "test-server-001",
  "name": "Test Server 001",
  "groups": [{"groupid": "2"}],
  "interfaces": [{
    "type": 1,
    "main": 1,
    "useip": 1,
    "ip": "10.0.0.100",
    "dns": "",
    "port": "10050"
  }],
  "tags": [
    {"tag": "Test", "value": "Automation"}
  ]
}
EOF

# Validate first
python scripts/validate_host_config.py /tmp/test_host.json
# Expected: Valid

# Create host
python scripts/zabbix_host_manager.py create --config /tmp/test_host.json
# Expected: Success with host ID

# Verify creation
python scripts/zabbix_host_manager.py get --host-name test-server-001
# Expected: Host details in JSON format
```

### Test 6: Host Update

```bash
# Update the test host
cat > /tmp/test_host_update.json <<EOF
{
  "name": "Test Server 001 - Updated",
  "description": "Updated during testing",
  "tags": [
    {"tag": "Test", "value": "Automation"},
    {"tag": "Updated", "value": "Yes"}
  ]
}
EOF

# Get host ID from previous test
HOST_ID=$(python scripts/zabbix_host_manager.py get --host-name test-server-001 | jq -r '.[0].hostid')

# Update host
python scripts/zabbix_host_manager.py update --host-id $HOST_ID --config /tmp/test_host_update.json
# Expected: Success message

# Verify update
python scripts/zabbix_host_manager.py get --host-id $HOST_ID --output table
# Expected: Updated name and tags visible
```

### Test 7: Enable/Disable Host

```bash
# Get host ID
HOST_ID=$(python scripts/zabbix_host_manager.py get --host-name test-server-001 | jq -r '.[0].hostid')

# Disable host
python scripts/zabbix_host_manager.py disable --host-id $HOST_ID
# Expected: Success message

# Verify disabled status
python scripts/zabbix_host_manager.py get --host-id $HOST_ID | jq '.[0].status'
# Expected: "1" (disabled)

# Re-enable host
python scripts/zabbix_host_manager.py enable --host-id $HOST_ID
# Expected: Success message

# Verify enabled status
python scripts/zabbix_host_manager.py get --host-id $HOST_ID | jq '.[0].status'
# Expected: "0" (enabled)
```

### Test 8: Bulk Host Creation

```bash
# Create bulk test configuration
cat > /tmp/bulk_test.yaml <<EOF
hosts:
  - host: test-bulk-01
    groups: [{groupid: "2"}]
    interfaces:
      - {type: 1, main: 1, useip: 1, ip: "10.0.1.1", dns: "", port: "10050"}
    tags:
      - {tag: "Bulk Test", value: "1"}

  - host: test-bulk-02
    groups: [{groupid: "2"}]
    interfaces:
      - {type: 1, main: 1, useip: 1, ip: "10.0.1.2", dns: "", port: "10050"}
    tags:
      - {tag: "Bulk Test", value: "2"}

  - host: test-bulk-03
    groups: [{groupid: "2"}]
    interfaces:
      - {type: 1, main: 1, useip: 1, ip: "10.0.1.3", dns: "", port: "10050"}
    tags:
      - {tag: "Bulk Test", value: "3"}
EOF

# Validate bulk configuration
python scripts/validate_host_config.py /tmp/bulk_test.yaml --bulk
# Expected: All hosts valid

# Create hosts in bulk
python scripts/zabbix_host_manager.py bulk-create --config /tmp/bulk_test.yaml
# Expected: Summary showing 3 successful creations

# Verify all created
for i in 01 02 03; do
  python scripts/zabbix_host_manager.py get --host-name test-bulk-$i
done
# Expected: Details for all three hosts
```

### Test 9: Error Handling

```bash
# Test duplicate host creation
python scripts/zabbix_host_manager.py create --config /tmp/test_host.json
# Expected: Error about host already existing

# Test invalid host ID
python scripts/zabbix_host_manager.py get --host-id 999999999
# Expected: Empty result or not found error

# Test invalid group ID
cat > /tmp/invalid_group.json <<EOF
{
  "host": "test-invalid-group",
  "groups": [{"groupid": "999999"}],
  "interfaces": [{
    "type": 1, "main": 1, "useip": 1,
    "ip": "10.0.0.200", "dns": "", "port": "10050"
  }]
}
EOF

python scripts/zabbix_host_manager.py create --config /tmp/invalid_group.json
# Expected: API error about invalid group ID
```

### Test 10: Host Deletion

```bash
# Delete individual test hosts
for host in test-server-001 test-bulk-01 test-bulk-02 test-bulk-03; do
  HOST_ID=$(python scripts/zabbix_host_manager.py get --host-name $host | jq -r '.[0].hostid')
  if [ ! -z "$HOST_ID" ] && [ "$HOST_ID" != "null" ]; then
    python scripts/zabbix_host_manager.py delete --host-id $HOST_ID --confirm
    echo "Deleted $host (ID: $HOST_ID)"
  fi
done
# Expected: All test hosts deleted

# Verify deletion
python scripts/zabbix_host_manager.py get --host-name test-server-001
# Expected: Empty result
```

## Performance Tests

### Test 11: Bulk Creation Performance

```bash
# Create large bulk configuration (100 hosts)
python - <<EOF
import yaml

hosts = []
for i in range(1, 101):
    hosts.append({
        'host': f'perf-test-{i:03d}',
        'groups': [{'groupid': '2'}],
        'interfaces': [{
            'type': 1, 'main': 1, 'useip': 1,
            'ip': f'10.1.{i//256}.{i%256}',
            'dns': '', 'port': '10050'
        }],
        'tags': [{'tag': 'Performance Test', 'value': 'Batch 1'}]
    })

with open('/tmp/perf_test.yaml', 'w') as f:
    yaml.dump({'hosts': hosts}, f)

print("Created configuration for 100 hosts")
EOF

# Time the bulk creation
time python scripts/zabbix_host_manager.py bulk-create --config /tmp/perf_test.yaml
# Expected: Completion in reasonable time (depends on network/server)
# Note: Record time for baseline performance metrics

# Cleanup (delete all performance test hosts)
for i in {1..100}; do
  hostname=$(printf "perf-test-%03d" $i)
  HOST_ID=$(python scripts/zabbix_host_manager.py get --host-name $hostname 2>/dev/null | jq -r '.[0].hostid')
  if [ ! -z "$HOST_ID" ] && [ "$HOST_ID" != "null" ]; then
    python scripts/zabbix_host_manager.py delete --host-id $HOST_ID --confirm >/dev/null 2>&1
  fi
done
echo "Cleanup complete"
```

## Edge Cases and Boundary Tests

### Test 12: Maximum Field Lengths

```bash
# Test maximum hostname length (128 characters)
cat > /tmp/max_length.json <<EOF
{
  "host": "$(printf 'a%.0s' {1..128})",
  "groups": [{"groupid": "2"}],
  "interfaces": [{
    "type": 1, "main": 1, "useip": 1,
    "ip": "10.0.0.250", "dns": "", "port": "10050"
  }]
}
EOF

python scripts/validate_host_config.py /tmp/max_length.json
# Expected: Valid

# Test exceeding maximum length
cat > /tmp/exceed_length.json <<EOF
{
  "host": "$(printf 'a%.0s' {1..129})",
  "groups": [{"groupid": "2"}],
  "interfaces": [{
    "type": 1, "main": 1, "useip": 1,
    "ip": "10.0.0.251", "dns": "", "port": "10050"
  }]
}
EOF

python scripts/validate_host_config.py /tmp/exceed_length.json
# Expected: Validation error
```

### Test 13: Special Characters

```bash
# Test special characters in hostname
cat > /tmp/special_chars.json <<EOF
{
  "host": "test-server_01.example.com",
  "groups": [{"groupid": "2"}],
  "interfaces": [{
    "type": 1, "main": 1, "useip": 1,
    "ip": "10.0.0.252", "dns": "", "port": "10050"
  }]
}
EOF

python scripts/validate_host_config.py /tmp/special_chars.json
# Expected: Valid (dots, dashes, underscores allowed)
```

### Test 14: Multiple Interfaces

```bash
# Test host with all interface types
cat > /tmp/multi_interface.json <<EOF
{
  "host": "multi-interface-test",
  "groups": [{"groupid": "2"}],
  "interfaces": [
    {
      "type": 1, "main": 1, "useip": 1,
      "ip": "10.0.2.1", "dns": "", "port": "10050"
    },
    {
      "type": 2, "main": 1, "useip": 1,
      "ip": "10.0.2.1", "dns": "", "port": "161",
      "details": {
        "version": 2,
        "community": "public",
        "bulk": 1
      }
    },
    {
      "type": 4, "main": 1, "useip": 1,
      "ip": "10.0.2.1", "dns": "", "port": "12345"
    }
  ]
}
EOF

python scripts/validate_host_config.py /tmp/multi_interface.json
# Expected: Valid

python scripts/zabbix_host_manager.py create --config /tmp/multi_interface.json
# Expected: Success with all interfaces configured

# Verify and cleanup
HOST_ID=$(python scripts/zabbix_host_manager.py get --host-name multi-interface-test | jq -r '.[0].hostid')
python scripts/zabbix_host_manager.py get --host-id $HOST_ID | jq '.[0].interfaces | length'
# Expected: 3 interfaces

python scripts/zabbix_host_manager.py delete --host-id $HOST_ID --confirm
```

## Test Results Template

Document your test results using this template:

```
Test Date: YYYY-MM-DD
Tester: Name
Zabbix Version: X.X.X
Python Version: X.X.X

| Test # | Test Name | Status | Notes |
|--------|-----------|--------|-------|
| 1 | Configuration Validation | PASS/FAIL | |
| 2 | Bulk Validation | PASS/FAIL | |
| 3 | Strict Mode | PASS/FAIL | |
| 4 | Host Group Operations | PASS/FAIL | |
| 5 | Single Host Creation | PASS/FAIL | |
| 6 | Host Update | PASS/FAIL | |
| 7 | Enable/Disable | PASS/FAIL | |
| 8 | Bulk Creation | PASS/FAIL | |
| 9 | Error Handling | PASS/FAIL | |
| 10 | Host Deletion | PASS/FAIL | |
| 11 | Performance (100 hosts) | PASS/FAIL | Time: X seconds |
| 12 | Maximum Lengths | PASS/FAIL | |
| 13 | Special Characters | PASS/FAIL | |
| 14 | Multiple Interfaces | PASS/FAIL | |

Overall Status: PASS/FAIL
Issues Found: [List any issues]
```

## Cleanup After Testing

```bash
# Remove all test hosts (if any remain)
for pattern in "test-" "perf-test-" "multi-interface-"; do
  python scripts/zabbix_host_manager.py get | \
    jq -r ".[] | select(.host | startswith(\"$pattern\")) | .hostid" | \
    while read host_id; do
      python scripts/zabbix_host_manager.py delete --host-id $host_id --confirm
    done
done

# Remove test files
rm -f /tmp/test_host.json /tmp/test_host_update.json /tmp/bulk_test.yaml
rm -f /tmp/invalid_config.json /tmp/warning_config.json /tmp/invalid_group.json
rm -f /tmp/perf_test.yaml /tmp/max_length.json /tmp/exceed_length.json
rm -f /tmp/special_chars.json /tmp/multi_interface.json

echo "Cleanup complete"
```

## Continuous Integration

Example CI configuration for automated testing:

```yaml
# .gitlab-ci.yml
test_zabbix_host_manager:
  stage: test
  script:
    - pip install PyYAML
    - python scripts/validate_host_config.py examples/host_config.json
    - python scripts/validate_host_config.py examples/bulk_hosts.yaml --bulk
    # Add more tests as needed
  only:
    - merge_requests
    - main
```

## Troubleshooting Test Failures

**Issue: Connection refused**
- Verify ZABBIX_API_URL is correct and accessible
- Check firewall rules allow API access

**Issue: Authentication failed**
- Verify API token is valid and not expired
- Check user account has required permissions

**Issue: Tests pass but hosts not visible in UI**
- Check user role has visibility to host groups used
- Verify hosts are in expected host groups

**Issue: Performance tests timeout**
- Adjust bulk size for slower environments
- Check Zabbix server resources (CPU, memory)

**Issue: Validation passes but creation fails**
- Check template IDs exist in your Zabbix instance
- Verify group IDs match your environment
- Ensure referenced objects are accessible
