#!/usr/bin/env python3
"""
Zabbix Host Configuration Validator

Validates host configuration files before applying to Zabbix.
Checks required fields, format correctness, and logical consistency.

Usage:
    python validate_host_config.py config.json
    python validate_host_config.py bulk_config.yaml --bulk
"""

import argparse
import json
import sys
import re
import yaml
from typing import Dict, List, Any, Tuple


import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
class ValidationError(Exception):
    """Custom exception for validation errors"""
    pass


class HostConfigValidator:
    """Validate Zabbix host configurations"""

    # Valid interface types
    INTERFACE_TYPES = {
        1: 'Agent',
        2: 'SNMP',
        3: 'IPMI',
        4: 'JMX'
    }

    # Valid host statuses
    HOST_STATUSES = {0: 'Enabled', 1: 'Disabled'}

    # Valid inventory modes
    INVENTORY_MODES = {
        -1: 'Disabled',
        0: 'Manual',
        1: 'Automatic'
    }

    # Valid SNMP versions
    SNMP_VERSIONS = {
        1: 'SNMPv1',
        2: 'SNMPv2c',
        3: 'SNMPv3'
    }

    def __init__(self, strict: bool = False):
        """
        Initialize validator

        Args:
            strict: Enable strict validation (fail on warnings)
        """
        self.strict = strict
        self.errors = []
        self.warnings = []

    def validate(self, config: Dict) -> Tuple[bool, List[str], List[str]]:
        """
        Validate host configuration

        Args:
            config: Host configuration dictionary

        Returns:
            Tuple of (is_valid, errors, warnings)
        """
        self.errors = []
        self.warnings = []

        try:
            self._validate_required_fields(config)
            self._validate_host_name(config)
            self._validate_groups(config)
            self._validate_interfaces(config)
            self._validate_templates(config)
            self._validate_inventory(config)
            self._validate_macros(config)
            self._validate_tags(config)
            self._validate_status(config)

        except ValidationError as e:
            self.errors.append(str(e))

        # In strict mode, warnings are treated as errors
        if self.strict and self.warnings:
            self.errors.extend(self.warnings)
            self.warnings = []

        return (len(self.errors) == 0, self.errors, self.warnings)

    def _validate_required_fields(self, config: Dict) -> None:
        """Validate required fields are present"""
        required_fields = ['host', 'groups', 'interfaces']

        for field in required_fields:
            if field not in config:
                raise ValidationError(f"Missing required field: '{field}'")

            if not config[field]:
                raise ValidationError(f"Required field '{field}' is empty")

    def _validate_host_name(self, config: Dict) -> None:
        """Validate host name format"""
        hostname = config.get('host', '')

        # Check length (1-128 characters)
        if len(hostname) < 1 or len(hostname) > 128:
            self.errors.append("Host name must be 1-128 characters")

        # Check for valid characters (alphanumeric, spaces, dots, dashes, underscores)
        if not re.match(r'^[a-zA-Z0-9\s._-]+$', hostname):
            self.errors.append(
                "Host name contains invalid characters. "
                "Allowed: alphanumeric, space, dot, dash, underscore"
            )

        # Warning for spaces (not recommended)
        if ' ' in hostname:
            self.warnings.append("Host name contains spaces (not recommended)")

        # Check visible name if present
        if 'name' in config:
            visible_name = config['name']
            if len(visible_name) > 128:
                self.errors.append("Visible name must be max 128 characters")

    def _validate_groups(self, config: Dict) -> None:
        """Validate host groups"""
        groups = config.get('groups', [])

        if not isinstance(groups, list):
            self.errors.append("'groups' must be a list")
            return

        if len(groups) == 0:
            self.errors.append("At least one host group is required")

        for i, group in enumerate(groups):
            if not isinstance(group, dict):
                self.errors.append(f"Group {i} must be a dictionary")
                continue

            if 'groupid' not in group:
                self.errors.append(f"Group {i} missing 'groupid'")

            # Validate groupid format (should be numeric string)
            group_id = str(group.get('groupid', ''))
            if not group_id.isdigit():
                self.errors.append(f"Group {i} 'groupid' must be numeric")

    def _validate_interfaces(self, config: Dict) -> None:
        """Validate host interfaces"""
        interfaces = config.get('interfaces', [])

        if not isinstance(interfaces, list):
            self.errors.append("'interfaces' must be a list")
            return

        if len(interfaces) == 0:
            self.errors.append("At least one interface is required")
            return

        main_interface_per_type = {}

        for i, interface in enumerate(interfaces):
            if not isinstance(interface, dict):
                self.errors.append(f"Interface {i} must be a dictionary")
                continue

            # Required fields
            required = ['type', 'main', 'useip', 'port']
            for field in required:
                if field not in interface:
                    self.errors.append(f"Interface {i} missing required field '{field}'")

            # Validate interface type
            iface_type = interface.get('type')
            if iface_type not in self.INTERFACE_TYPES:
                self.errors.append(
                    f"Interface {i} has invalid type {iface_type}. "
                    f"Valid types: {list(self.INTERFACE_TYPES.keys())}"
                )

            # Validate main interface flag
            main = interface.get('main')
            if main not in [0, 1]:
                self.errors.append(f"Interface {i} 'main' must be 0 or 1")

            # Track main interfaces per type
            if main == 1:
                if iface_type in main_interface_per_type:
                    self.errors.append(
                        f"Multiple main interfaces for type {iface_type}. "
                        f"Only one main interface allowed per type."
                    )
                else:
                    main_interface_per_type[iface_type] = i

            # Validate useip flag
            useip = interface.get('useip')
            if useip not in [0, 1]:
                self.errors.append(f"Interface {i} 'useip' must be 0 or 1")

            # Validate IP or DNS
            if useip == 1:
                ip = interface.get('ip', '')
                if not ip:
                    self.errors.append(f"Interface {i} missing 'ip' (useip=1)")
                elif not self._is_valid_ip(ip):
                    self.errors.append(f"Interface {i} has invalid IP address: {ip}")
            else:
                dns = interface.get('dns', '')
                if not dns:
                    self.errors.append(f"Interface {i} missing 'dns' (useip=0)")
                elif not self._is_valid_hostname(dns):
                    self.warnings.append(f"Interface {i} DNS may be invalid: {dns}")

            # Validate port
            port = str(interface.get('port', ''))
            if not port.isdigit():
                self.errors.append(f"Interface {i} port must be numeric")
            else:
                port_num = int(port)
                if port_num < 1 or port_num > 65535:
                    self.errors.append(f"Interface {i} port must be 1-65535")

                # Check common ports
                if iface_type == 1 and port_num != 10050:
                    self.warnings.append(
                        f"Interface {i} (Agent) using non-standard port {port_num} "
                        f"(default: 10050)"
                    )
                elif iface_type == 2 and port_num != 161:
                    self.warnings.append(
                        f"Interface {i} (SNMP) using non-standard port {port_num} "
                        f"(default: 161)"
                    )
                elif iface_type == 4 and port_num != 12345:
                    self.warnings.append(
                        f"Interface {i} (JMX) using non-standard port {port_num} "
                        f"(default: 12345)"
                    )

            # SNMP-specific validation
            if iface_type == 2:
                self._validate_snmp_interface(interface, i)

    def _validate_snmp_interface(self, interface: Dict, index: int) -> None:
        """Validate SNMP-specific interface parameters"""
        details = interface.get('details', {})

        if not isinstance(details, dict):
            self.errors.append(f"Interface {index} SNMP 'details' must be a dictionary")
            return

        # Validate SNMP version
        version = details.get('version')
        if version and version not in self.SNMP_VERSIONS:
            self.errors.append(
                f"Interface {index} invalid SNMP version {version}. "
                f"Valid: {list(self.SNMP_VERSIONS.keys())}"
            )

        # SNMPv1/v2c require community
        if version in [1, 2] and not details.get('community'):
            self.warnings.append(f"Interface {index} SNMPv{version} missing community string")

        # SNMPv3 requires security parameters
        if version == 3:
            if not details.get('securityname'):
                self.warnings.append(f"Interface {index} SNMPv3 missing securityname")
            if 'securitylevel' not in details:
                self.warnings.append(f"Interface {index} SNMPv3 missing securitylevel")

    def _validate_templates(self, config: Dict) -> None:
        """Validate template assignments"""
        templates = config.get('templates', [])

        if not isinstance(templates, list):
            self.errors.append("'templates' must be a list")
            return

        for i, template in enumerate(templates):
            if not isinstance(template, dict):
                self.errors.append(f"Template {i} must be a dictionary")
                continue

            if 'templateid' not in template:
                self.errors.append(f"Template {i} missing 'templateid'")

            template_id = str(template.get('templateid', ''))
            if not template_id.isdigit():
                self.errors.append(f"Template {i} 'templateid' must be numeric")

    def _validate_inventory(self, config: Dict) -> None:
        """Validate inventory configuration"""
        if 'inventory_mode' in config:
            mode = config['inventory_mode']
            if mode not in self.INVENTORY_MODES:
                self.errors.append(
                    f"Invalid inventory_mode {mode}. "
                    f"Valid: {list(self.INVENTORY_MODES.keys())}"
                )

            # If inventory is provided, mode should not be -1
            if 'inventory' in config and mode == -1:
                self.warnings.append(
                    "Inventory data provided but inventory_mode is -1 (disabled)"
                )

        if 'inventory' in config:
            inventory = config['inventory']
            if not isinstance(inventory, dict):
                self.errors.append("'inventory' must be a dictionary")

    def _validate_macros(self, config: Dict) -> None:
        """Validate host macros"""
        macros = config.get('macros', [])

        if not isinstance(macros, list):
            self.errors.append("'macros' must be a list")
            return

        for i, macro in enumerate(macros):
            if not isinstance(macro, dict):
                self.errors.append(f"Macro {i} must be a dictionary")
                continue

            if 'macro' not in macro:
                self.errors.append(f"Macro {i} missing 'macro' field")
            else:
                macro_name = macro['macro']
                # Macros should start with {$ and end with }
                if not (macro_name.startswith('{$') and macro_name.endswith('}')):
                    self.errors.append(
                        f"Macro {i} invalid format. Must be: {{$MACRO_NAME}}"
                    )

            if 'value' not in macro:
                self.warnings.append(f"Macro {i} missing 'value' field")

    def _validate_tags(self, config: Dict) -> None:
        """Validate host tags"""
        tags = config.get('tags', [])

        if not isinstance(tags, list):
            self.errors.append("'tags' must be a list")
            return

        for i, tag in enumerate(tags):
            if not isinstance(tag, dict):
                self.errors.append(f"Tag {i} must be a dictionary")
                continue

            if 'tag' not in tag:
                self.errors.append(f"Tag {i} missing 'tag' field")

            # Value is optional but should be string if present
            if 'value' in tag and not isinstance(tag['value'], str):
                self.warnings.append(f"Tag {i} value should be a string")

    def _validate_status(self, config: Dict) -> None:
        """Validate host status"""
        if 'status' in config:
            status = config['status']
            if status not in self.HOST_STATUSES:
                self.errors.append(
                    f"Invalid status {status}. Valid: {list(self.HOST_STATUSES.keys())}"
                )

    def _is_valid_ip(self, ip: str) -> bool:
        """Check if string is a valid IPv4 address"""
        pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
        if not re.match(pattern, ip):
            return False

        # Check each octet is 0-255
        octets = ip.split('.')
        return all(0 <= int(octet) <= 255 for octet in octets)

    def _is_valid_hostname(self, hostname: str) -> bool:
        """Check if string is a valid hostname/FQDN"""
        if len(hostname) > 255:
            return False

        # Basic hostname validation
        pattern = r'^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$'
        return bool(re.match(pattern, hostname))


def load_config_file(file_path: str) -> Any:
    """Load configuration from JSON or YAML file"""
    try:
        with open(file_path, 'r') as f:
            if file_path.endswith('.yaml') or file_path.endswith('.yml'):
                return yaml.safe_load(f)
            else:
                return json.load(f)
    except FileNotFoundError:
        print(f"[ERROR] File not found: {file_path}", file=sys.stderr)
        sys.exit(1)
    except (json.JSONDecodeError, yaml.YAMLError) as e:
        print(f"[ERROR] Invalid configuration file: {e}", file=sys.stderr)
        sys.exit(1)


def print_validation_results(hostname: str, is_valid: bool,
                            errors: List[str], warnings: List[str]) -> None:
    """Print validation results in a formatted way"""
    print(f"\n{'='*60}")
    print(f"Validation Results: {hostname}")
    print(f"{'='*60}")

    if is_valid and not warnings:
        print("[OK] Configuration is valid")
    elif is_valid and warnings:
        print("[WARN] Configuration is valid with warnings")
    else:
        print("[ERROR] Configuration is invalid")

    if errors:
        print(f"\nErrors ({len(errors)}):")
        for i, error in enumerate(errors, 1):
            print(f"  {i}. [ERROR] {error}")

    if warnings:
        print(f"\nWarnings ({len(warnings)}):")
        for i, warning in enumerate(warnings, 1):
            print(f"  {i}. [WARN] {warning}")

    print()


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='Validate Zabbix host configuration files',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Validate single host configuration
  python validate_host_config.py host_config.json

  # Validate bulk configuration
  python validate_host_config.py bulk_hosts.yaml --bulk

  # Strict validation (warnings treated as errors)
  python validate_host_config.py config.json --strict

  # Quiet mode (only show summary)
  python validate_host_config.py config.json --quiet
        """
    )

    parser.add_argument('config_file', help='Configuration file to validate')
    parser.add_argument('--bulk', action='store_true',
                       help='Validate bulk configuration (multiple hosts)')
    parser.add_argument('--strict', action='store_true',
                       help='Treat warnings as errors')
    parser.add_argument('--quiet', action='store_true',
                       help='Only show summary (no detailed errors)')

    args = parser.parse_args()

    # Load configuration
    config = load_config_file(args.config_file)

    # Initialize validator
    validator = HostConfigValidator(strict=args.strict)

    # Determine if bulk or single host
    if args.bulk:
        # Handle bulk configuration
        if isinstance(config, dict) and 'hosts' in config:
            hosts = config['hosts']
        elif isinstance(config, list):
            hosts = config
        else:
            print("[ERROR] Invalid bulk configuration format", file=sys.stderr)
            sys.exit(1)

        total_hosts = len(hosts)
        valid_count = 0
        invalid_count = 0

        print(f"Validating {total_hosts} host configurations...\n")

        for i, host_config in enumerate(hosts, 1):
            hostname = host_config.get('host', f'Host {i}')
            is_valid, errors, warnings = validator.validate(host_config)

            if is_valid:
                valid_count += 1
                if not args.quiet:
                    print(f"[{i}/{total_hosts}] [OK] {hostname}")
            else:
                invalid_count += 1
                if not args.quiet:
                    print(f"[{i}/{total_hosts}] [ERROR] {hostname}")

            # Print detailed results if not quiet
            if not args.quiet and (errors or warnings):
                print_validation_results(hostname, is_valid, errors, warnings)

        # Print summary
        print(f"\n{'='*60}")
        print("Validation Summary")
        print(f"{'='*60}")
        print(f"Total hosts: {total_hosts}")
        print(f"[OK] Valid: {valid_count}")
        print(f"[ERROR] Invalid: {invalid_count}")
        print()

        sys.exit(0 if invalid_count == 0 else 1)

    else:
        # Single host validation
        hostname = config.get('host', 'Unknown')
        is_valid, errors, warnings = validator.validate(config)

        if not args.quiet:
            print_validation_results(hostname, is_valid, errors, warnings)
        else:
            if is_valid:
                print(f"[OK] {hostname} is valid")
            else:
                print(f"[ERROR] {hostname} is invalid ({len(errors)} errors)")

        sys.exit(0 if is_valid else 1)


if __name__ == '__main__':
    main()
