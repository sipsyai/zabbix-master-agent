#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Host Manager - Automate host lifecycle management

This script provides comprehensive host management capabilities including:
- Creating hosts with full configuration
- Updating host properties
- Deleting hosts
- Managing host groups
- Configuring interfaces
- Bulk operations

Usage:
    python zabbix_host_manager.py create --url URL --token TOKEN --config CONFIG_FILE
    python zabbix_host_manager.py update --url URL --token TOKEN --host-id ID --config CONFIG_FILE
    python zabbix_host_manager.py delete --url URL --token TOKEN --host-id ID
    python zabbix_host_manager.py get --url URL --token TOKEN --host-name NAME
    python zabbix_host_manager.py bulk-create --url URL --token TOKEN --config BULK_CONFIG

Environment Variables:
    ZABBIX_API_URL: Zabbix API endpoint URL
    ZABBIX_API_TOKEN: API authentication token
    ZABBIX_API_USER: Username (alternative to token)
    ZABBIX_API_PASSWORD: Password (alternative to token)
"""

import argparse
import json
import sys
import os
import time
import yaml
from typing import Dict, List, Optional, Any, Tuple
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError


class ZabbixAPIError(Exception):
    """Custom exception for Zabbix API errors"""
    pass


class ZabbixHostManager:
    """Manage Zabbix hosts via API"""

    def __init__(self, url: str, token: Optional[str] = None,
                 user: Optional[str] = None, password: Optional[str] = None):
        """
        Initialize Zabbix API client

        Args:
            url: Zabbix API endpoint URL
            token: API token for authentication
            user: Username (if not using token)
            password: Password (if not using token)
        """
        self.url = url
        self.token = token
        self.user = user
        self.password = password
        self.request_id = 0

        # Authenticate if using user/password
        if not token and user and password:
            self._authenticate()

    def _authenticate(self) -> None:
        """Authenticate with username/password to get token"""
        try:
            result = self._call_api('user.login', {
                'username': self.user,
                'password': self.password
            }, use_auth=False)
            self.token = result
            print(f"[OK] Authenticated successfully as {self.user}")
        except Exception as e:
            raise ZabbixAPIError(f"Authentication failed: {e}")

    def _call_api(self, method: str, params: Dict, use_auth: bool = True) -> Any:
        """
        Make API call to Zabbix

        Args:
            method: API method name
            params: Method parameters
            use_auth: Whether to include authentication

        Returns:
            API response result

        Raises:
            ZabbixAPIError: On API errors
        """
        self.request_id += 1

        payload = {
            'jsonrpc': '2.0',
            'method': method,
            'params': params,
            'id': self.request_id
        }

        # Add authentication
        if use_auth and self.token:
            payload['auth'] = self.token

        # Prepare request
        headers = {'Content-Type': 'application/json-rpc'}
        data = json.dumps(payload).encode('utf-8')
        request = Request(self.url, data=data, headers=headers)

        # Make request with retry logic
        max_retries = 3
        retry_delay = 2

        for attempt in range(max_retries):
            try:
                with urlopen(request, timeout=30) as response:
                    result = json.loads(response.read().decode('utf-8'))

                    # Check for API errors
                    if 'error' in result:
                        error = result['error']
                        raise ZabbixAPIError(
                            f"API Error: {error.get('message', 'Unknown error')} "
                            f"(Code: {error.get('code', 'N/A')}, "
                            f"Data: {error.get('data', 'N/A')})"
                        )

                    return result.get('result')

            except HTTPError as e:
                if e.code == 401:
                    raise ZabbixAPIError("Authentication failed - invalid token/credentials")
                elif e.code >= 500 and attempt < max_retries - 1:
                    print(f"[WARN] Server error, retrying in {retry_delay}s... (attempt {attempt + 1}/{max_retries})")
                    time.sleep(retry_delay)
                    retry_delay *= 2
                else:
                    raise ZabbixAPIError(f"HTTP Error {e.code}: {e.reason}")

            except URLError as e:
                if attempt < max_retries - 1:
                    print(f"[WARN] Network error, retrying in {retry_delay}s... (attempt {attempt + 1}/{max_retries})")
                    time.sleep(retry_delay)
                    retry_delay *= 2
                else:
                    raise ZabbixAPIError(f"Network error: {e.reason}")

            except Exception as e:
                raise ZabbixAPIError(f"Unexpected error: {e}")

        raise ZabbixAPIError("Max retries exceeded")

    def create_host(self, config: Dict) -> Dict:
        """
        Create a new host

        Args:
            config: Host configuration dictionary

        Returns:
            Created host information
        """
        try:
            # Validate required fields
            if 'host' not in config:
                raise ValueError("Missing required field: 'host' (hostname)")
            if 'groups' not in config or not config['groups']:
                raise ValueError("Missing required field: 'groups' (at least one group required)")
            if 'interfaces' not in config or not config['interfaces']:
                raise ValueError("Missing required field: 'interfaces' (at least one interface required)")

            print(f"Creating host: {config['host']}...")
            result = self._call_api('host.create', config)

            host_id = result['hostids'][0]
            print(f"[OK] Host created successfully (ID: {host_id})")

            return {
                'hostid': host_id,
                'host': config['host'],
                'status': 'created'
            }

        except ZabbixAPIError as e:
            print(f"[ERROR] Failed to create host: {e}", file=sys.stderr)
            raise
        except ValueError as e:
            print(f"[ERROR] Invalid configuration: {e}", file=sys.stderr)
            raise

    def update_host(self, host_id: str, config: Dict) -> Dict:
        """
        Update existing host

        Args:
            host_id: Host ID to update
            config: Updated configuration

        Returns:
            Update result
        """
        try:
            config['hostid'] = host_id
            print(f"Updating host ID: {host_id}...")
            result = self._call_api('host.update', config)

            print(f"[OK] Host updated successfully")
            return {
                'hostid': host_id,
                'status': 'updated'
            }

        except ZabbixAPIError as e:
            print(f"[ERROR] Failed to update host: {e}", file=sys.stderr)
            raise

    def delete_host(self, host_id: str, confirm: bool = False) -> Dict:
        """
        Delete a host

        Args:
            host_id: Host ID to delete
            confirm: Confirmation flag

        Returns:
            Deletion result
        """
        try:
            # Get host info first
            host_info = self.get_host(host_id)
            if not host_info:
                raise ValueError(f"Host {host_id} not found")

            hostname = host_info[0].get('host', 'Unknown')

            if not confirm:
                print(f"[WARN] Warning: About to delete host '{hostname}' (ID: {host_id})")
                response = input("Type 'yes' to confirm: ")
                if response.lower() != 'yes':
                    print("[ERROR] Deletion cancelled")
                    return {'status': 'cancelled'}

            print(f"Deleting host: {hostname} (ID: {host_id})...")
            result = self._call_api('host.delete', [host_id])

            print(f"[OK] Host deleted successfully")
            return {
                'hostid': host_id,
                'host': hostname,
                'status': 'deleted'
            }

        except ZabbixAPIError as e:
            print(f"[ERROR] Failed to delete host: {e}", file=sys.stderr)
            raise

    def get_host(self, host_id: Optional[str] = None,
                 host_name: Optional[str] = None,
                 filters: Optional[Dict] = None) -> List[Dict]:
        """
        Get host information

        Args:
            host_id: Host ID to retrieve
            host_name: Host name to search
            filters: Additional filters

        Returns:
            List of matching hosts
        """
        try:
            params = {
                'output': 'extend',
                'selectGroups': 'extend',
                'selectInterfaces': 'extend',
                'selectTemplates': ['templateid', 'name'],
                'selectInventory': 'extend',
                'selectTags': 'extend',
                'selectMacros': 'extend'
            }

            if host_id:
                params['hostids'] = host_id
            elif host_name:
                params['filter'] = {'host': host_name}
            elif filters:
                params['filter'] = filters

            result = self._call_api('host.get', params)
            return result

        except ZabbixAPIError as e:
            print(f"[ERROR] Failed to get host: {e}", file=sys.stderr)
            raise

    def enable_host(self, host_id: str) -> Dict:
        """Enable host monitoring"""
        return self.update_host(host_id, {'status': 0})

    def disable_host(self, host_id: str) -> Dict:
        """Disable host monitoring"""
        return self.update_host(host_id, {'status': 1})

    def create_host_group(self, group_name: str) -> Dict:
        """
        Create a new host group

        Args:
            group_name: Name of the group

        Returns:
            Created group information
        """
        try:
            print(f"Creating host group: {group_name}...")
            result = self._call_api('hostgroup.create', {'name': group_name})

            group_id = result['groupids'][0]
            print(f"[OK] Host group created successfully (ID: {group_id})")

            return {
                'groupid': group_id,
                'name': group_name,
                'status': 'created'
            }

        except ZabbixAPIError as e:
            print(f"[ERROR] Failed to create host group: {e}", file=sys.stderr)
            raise

    def get_host_groups(self, group_name: Optional[str] = None) -> List[Dict]:
        """Get host groups"""
        try:
            params = {'output': 'extend'}
            if group_name:
                params['filter'] = {'name': group_name}

            result = self._call_api('hostgroup.get', params)
            return result

        except ZabbixAPIError as e:
            print(f"[ERROR] Failed to get host groups: {e}", file=sys.stderr)
            raise

    def bulk_create_hosts(self, configs: List[Dict]) -> Dict:
        """
        Create multiple hosts

        Args:
            configs: List of host configurations

        Returns:
            Summary of created hosts
        """
        results = {
            'successful': [],
            'failed': []
        }

        total = len(configs)
        print(f"Starting bulk creation of {total} hosts...\n")

        for i, config in enumerate(configs, 1):
            hostname = config.get('host', 'Unknown')
            print(f"[{i}/{total}] Processing host: {hostname}")

            try:
                result = self.create_host(config)
                results['successful'].append(result)

            except Exception as e:
                results['failed'].append({
                    'host': hostname,
                    'error': str(e)
                })

            print()  # Blank line between hosts

        # Print summary
        print("=" * 60)
        print("Bulk Creation Summary")
        print("=" * 60)
        print(f"Total hosts: {total}")
        print(f"[OK] Successful: {len(results['successful'])}")
        print(f"[ERROR] Failed: {len(results['failed'])}")

        if results['failed']:
            print("\nFailed hosts:")
            for item in results['failed']:
                print(f"  - {item['host']}: {item['error']}")

        return results


def load_config_file(file_path: str) -> Any:
    """
    Load configuration from JSON or YAML file

    Args:
        file_path: Path to configuration file

    Returns:
        Parsed configuration
    """
    try:
        with open(file_path, 'r') as f:
            if file_path.endswith('.yaml') or file_path.endswith('.yml'):
                return yaml.safe_load(f)
            else:
                return json.load(f)
    except FileNotFoundError:
        print(f"[ERROR] Configuration file not found: {file_path}", file=sys.stderr)
        sys.exit(1)
    except (json.JSONDecodeError, yaml.YAMLError) as e:
        print(f"[ERROR] Invalid configuration file: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='Zabbix Host Manager - Automate host lifecycle management',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    # Global options
    parser.add_argument('--url', help='Zabbix API URL (or set ZABBIX_API_URL)')
    parser.add_argument('--token', help='API token (or set ZABBIX_API_TOKEN)')
    parser.add_argument('--user', help='Username (or set ZABBIX_API_USER)')
    parser.add_argument('--password', help='Password (or set ZABBIX_API_PASSWORD)')

    # Subcommands
    subparsers = parser.add_subparsers(dest='command', help='Command to execute')

    # Create command
    create_parser = subparsers.add_parser('create', help='Create a new host')
    create_parser.add_argument('--config', required=True, help='Host configuration file (JSON/YAML)')

    # Update command
    update_parser = subparsers.add_parser('update', help='Update existing host')
    update_parser.add_argument('--host-id', required=True, help='Host ID to update')
    update_parser.add_argument('--config', required=True, help='Updated configuration file (JSON/YAML)')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a host')
    delete_parser.add_argument('--host-id', required=True, help='Host ID to delete')
    delete_parser.add_argument('--confirm', action='store_true', help='Skip confirmation prompt')

    # Get command
    get_parser = subparsers.add_parser('get', help='Get host information')
    get_parser.add_argument('--host-id', help='Host ID')
    get_parser.add_argument('--host-name', help='Host name')
    get_parser.add_argument('--output', choices=['json', 'yaml', 'table'], default='json',
                           help='Output format')

    # Enable/Disable commands
    enable_parser = subparsers.add_parser('enable', help='Enable host monitoring')
    enable_parser.add_argument('--host-id', required=True, help='Host ID')

    disable_parser = subparsers.add_parser('disable', help='Disable host monitoring')
    disable_parser.add_argument('--host-id', required=True, help='Host ID')

    # Bulk create command
    bulk_parser = subparsers.add_parser('bulk-create', help='Create multiple hosts')
    bulk_parser.add_argument('--config', required=True, help='Bulk configuration file (JSON/YAML)')

    # Create group command
    group_parser = subparsers.add_parser('create-group', help='Create host group')
    group_parser.add_argument('--name', required=True, help='Group name')

    # Get groups command
    groups_parser = subparsers.add_parser('get-groups', help='Get host groups')
    groups_parser.add_argument('--name', help='Filter by group name')

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    # Get credentials from args or environment
    url = args.url or os.environ.get('ZABBIX_API_URL')
    token = args.token or os.environ.get('ZABBIX_API_TOKEN')
    user = args.user or os.environ.get('ZABBIX_API_USER')
    password = args.password or os.environ.get('ZABBIX_API_PASSWORD')

    if not url:
        print("[ERROR] Error: Zabbix API URL required (--url or ZABBIX_API_URL)", file=sys.stderr)
        sys.exit(1)

    if not token and not (user and password):
        print("[ERROR] Error: Authentication required (--token or --user/--password)", file=sys.stderr)
        sys.exit(1)

    try:
        # Initialize manager
        manager = ZabbixHostManager(url, token, user, password)

        # Execute command
        if args.command == 'create':
            config = load_config_file(args.config)
            result = manager.create_host(config)
            print(f"\nResult: {json.dumps(result, indent=2)}")

        elif args.command == 'update':
            config = load_config_file(args.config)
            result = manager.update_host(args.host_id, config)
            print(f"\nResult: {json.dumps(result, indent=2)}")

        elif args.command == 'delete':
            result = manager.delete_host(args.host_id, args.confirm)
            print(f"\nResult: {json.dumps(result, indent=2)}")

        elif args.command == 'get':
            hosts = manager.get_host(args.host_id, args.host_name)

            if args.output == 'json':
                print(json.dumps(hosts, indent=2))
            elif args.output == 'yaml':
                print(yaml.dump(hosts, default_flow_style=False))
            else:  # table
                if hosts:
                    print(f"Found {len(hosts)} host(s):\n")
                    for host in hosts:
                        print(f"ID: {host['hostid']}")
                        print(f"Name: {host['host']}")
                        print(f"Status: {'Enabled' if host['status'] == '0' else 'Disabled'}")
                        print(f"Groups: {', '.join(g['name'] for g in host['groups'])}")
                        print(f"Interfaces: {len(host['interfaces'])}")
                        print("-" * 40)
                else:
                    print("No hosts found")

        elif args.command == 'enable':
            result = manager.enable_host(args.host_id)
            print(f"\n[OK] Host enabled: {json.dumps(result, indent=2)}")

        elif args.command == 'disable':
            result = manager.disable_host(args.host_id)
            print(f"\n[OK] Host disabled: {json.dumps(result, indent=2)}")

        elif args.command == 'bulk-create':
            config = load_config_file(args.config)
            if isinstance(config, dict) and 'hosts' in config:
                configs = config['hosts']
            elif isinstance(config, list):
                configs = config
            else:
                raise ValueError("Invalid bulk configuration format")

            result = manager.bulk_create_hosts(configs)

            # Exit with error code if any failed
            if result['failed']:
                sys.exit(1)

        elif args.command == 'create-group':
            result = manager.create_host_group(args.name)
            print(f"\nResult: {json.dumps(result, indent=2)}")

        elif args.command == 'get-groups':
            groups = manager.get_host_groups(args.name)
            print(json.dumps(groups, indent=2))

    except ZabbixAPIError as e:
        print(f"\n[ERROR] API Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"\n[ERROR] Unexpected error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
