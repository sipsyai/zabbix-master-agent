# Configuring Triggers & Alerts in Zabbix

Comprehensive Agent Skill for automating Zabbix trigger and alert configuration through the Zabbix API.

## Overview

This skill enables automated management of Zabbix triggers and alerts, including:
- Creating triggers with complex expressions
- Configuring alert actions and escalations
- Setting up notification channels (email, SMS, webhooks)
- Bulk operations for infrastructure-wide deployment
- Configuration validation before deployment

## Quick Start

### Prerequisites

1. Python 3.7 or higher
2. Required Python packages:
   ```bash
   pip install requests pyyaml
   ```

3. Zabbix API access credentials
4. Network access to Zabbix server

### Basic Usage

#### Create a Simple Trigger

```bash
python scripts/zabbix_trigger_manager.py \
  --url https://zabbix.example.com/api_jsonrpc.php \
  --username admin \
  --password password \
  create \
  --name "High CPU load on {HOST.NAME}" \
  --expression "avg(/Production Server/system.cpu.load,5m)>5" \
  --severity average
```

#### Create Alert Action

```bash
python scripts/zabbix_action_manager.py \
  --url https://zabbix.example.com/api_jsonrpc.php \
  --username admin \
  --password password \
  create \
  --config examples/alert_actions.yaml
```

#### Validate Configuration

```bash
python scripts/validate_trigger_config.py \
  --config examples/bulk_triggers.yaml
```

#### Bulk Deployment

```bash
python scripts/zabbix_trigger_manager.py \
  --url https://zabbix.example.com/api_jsonrpc.php \
  --username admin \
  --password password \
  bulk-create \
  --config examples/bulk_triggers.yaml
```

## Directory Structure

```
configuring-triggers-alerts/
├── SKILL.md                          # Main skill documentation
├── README.md                         # This file
├── scripts/
│   ├── zabbix_trigger_manager.py    # Trigger management script
│   ├── zabbix_action_manager.py     # Action management script
│   └── validate_trigger_config.py   # Configuration validator
└── examples/
    ├── basic_triggers.json          # Simple trigger examples
    ├── advanced_triggers.json       # Complex expression examples
    ├── alert_actions.yaml           # Alert action configurations
    ├── escalation_examples.yaml     # Escalation patterns
    ├── media_types.json             # Notification channel configs
    └── bulk_triggers.yaml           # Bulk deployment template
```

## Script Documentation

### zabbix_trigger_manager.py

Manages trigger lifecycle operations.

**Commands:**
- `create` - Create a new trigger
- `update` - Update existing trigger
- `delete` - Delete a trigger
- `list` - List triggers with filters
- `enable` - Enable a trigger
- `disable` - Disable a trigger
- `bulk-create` - Create multiple triggers
- `test` - Test expression syntax

**Example:**
```bash
python scripts/zabbix_trigger_manager.py \
  --url https://zabbix.example.com/api_jsonrpc.php \
  --username admin \
  --password password \
  list \
  --host "Production Server" \
  --severity high \
  --enabled-only
```

### zabbix_action_manager.py

Manages alert actions and escalations.

**Commands:**
- `create` - Create alert action
- `update` - Update existing action
- `delete` - Delete action
- `list` - List actions
- `create-media` - Create media type
- `test-media` - Test media delivery
- `create-escalation` - Create escalation action

**Example:**
```bash
python scripts/zabbix_action_manager.py \
  --url https://zabbix.example.com/api_jsonrpc.php \
  --username admin \
  --password password \
  create-escalation \
  --config examples/escalation_examples.yaml
```

### validate_trigger_config.py

Validates configurations before deployment.

**Features:**
- Expression syntax validation
- Severity level validation
- Circular dependency detection
- Tag format validation
- Escalation timing checks

**Example:**
```bash
python scripts/validate_trigger_config.py \
  --config examples/bulk_triggers.yaml \
  --type trigger
```

## Configuration Examples

### Basic Trigger (JSON)

```json
{
  "triggers": [
    {
      "name": "High CPU load on {HOST.NAME}",
      "expression": "avg(/Production Server/system.cpu.load,5m)>5",
      "severity": "average",
      "description": "CPU load exceeded threshold",
      "recovery_expression": "avg(/Production Server/system.cpu.load,5m)<3",
      "tags": [
        {"name": "component", "value": "cpu"}
      ],
      "enabled": true
    }
  ]
}
```

### Alert Action (YAML)

```yaml
actions:
  - name: "Critical Alert - Immediate Notification"
    enabled: true
    esc_period: "0"
    conditions:
      - conditiontype: 4  # Trigger severity
        operator: 5       # >=
        value: "4"        # High severity
    operations:
      - operationtype: 0  # Send message
        esc_step_from: 1
        esc_step_to: 1
        opmessage:
          default_msg: 0
          subject: "CRITICAL: {EVENT.NAME}"
          message: "Problem detected on {HOST.NAME}"
        opmessage_usr:
          - userid: "1"
```

## Trigger Expression Reference

### Common Functions

- `avg(item,period)` - Average value over period
- `last(item)` - Last (most recent) value
- `min(item,period)` - Minimum value
- `max(item,period)` - Maximum value
- `sum(item,period)` - Sum of values
- `count(item,period)` - Count of values
- `change(item)` - Difference between last and previous value
- `nodata(item,period)` - Check if no data received

### Operators

- `>`, `<`, `=`, `>=`, `<=`, `<>` - Comparison
- `and`, `or`, `not` - Logical operators

### Time Suffixes

- `s` - seconds
- `m` - minutes
- `h` - hours
- `d` - days
- `w` - weeks

### Example Expressions

**Simple threshold:**
```
last(/host/item.key)>100
```

**Time-based average:**
```
avg(/host/cpu.load,5m)>5
```

**Multi-condition:**
```
avg(/host/cpu.load,5m)>5 and max(/host/memory.util,5m)>90
```

**No data detection:**
```
nodata(/host/agent.ping,10m)=1
```

**Time-based condition:**
```
avg(/host/item,5m)>threshold and time()>093000 and time()<180000
```

## Severity Levels

| Level | Value | Use Case |
|-------|-------|----------|
| Not classified | 0 | Informational only |
| Information | 1 | FYI messages |
| Warning | 2 | Potential issues |
| Average | 3 | Significant problems |
| High | 4 | Important issues |
| Disaster | 5 | Critical failures |

## Best Practices

### Trigger Design

1. **Use appropriate evaluation periods**
   - 5m for most metrics
   - 10-15m for trend detection
   - 1m for critical services

2. **Implement hysteresis**
   ```
   Problem: avg(/host/temp,5m)>80
   Recovery: avg(/host/temp,5m)<75
   ```

3. **Use meaningful names with macros**
   - Good: "High CPU load on {HOST.NAME}"
   - Bad: "CPU trigger 1"

4. **Add operational data**
   ```
   "Current value: {ITEM.LASTVALUE1}%"
   ```

5. **Tag triggers for correlation**
   ```yaml
   tags:
     - name: "component"
       value: "database"
     - name: "criticality"
       value: "high"
   ```

### Alert Configuration

1. **Set up escalation chains**
   - Step 1: On-call engineer (immediate)
   - Step 2: Team lead (10 minutes)
   - Step 3: Management (30 minutes)

2. **Use severity-based routing**
   - Disaster → SMS + Email
   - High → Email
   - Average → Email (business hours)

3. **Configure recovery notifications**
   - Always notify on recovery
   - Include duration in message

4. **Test notification delivery**
   ```bash
   python scripts/zabbix_action_manager.py test-media \
     --id 1 --recipient user@example.com
   ```

### Performance

1. **Avoid very short evaluation periods**
   - Don't use <1m unless necessary
   - Use trend functions for long-term analysis

2. **Minimize trigger recalculations**
   - Combine related conditions
   - Use trigger dependencies

3. **Use appropriate time windows**
   - Business hours vs. 24/7 monitoring
   - Maintenance window awareness

## Troubleshooting

### Common Issues

**Authentication Failed**
```
Solution: Verify API URL, username, and password
Check: User has API access permissions
```

**Invalid Expression**
```
Solution: Use validate_trigger_config.py
Check: Item references use correct format /host/item.key
```

**Trigger Not Firing**
```
Check: Item is receiving data
Check: Expression evaluation logic
Check: Trigger is enabled
```

**No Notifications Received**
```
Check: Action conditions match trigger
Check: Media type configured correctly
Check: User has media configured
Test: Use test-media command
```

### Validation Errors

Run validation before deployment:
```bash
python scripts/validate_trigger_config.py \
  --config your_config.yaml \
  --strict
```

Common validation errors:
- Unbalanced parentheses
- Invalid item reference format
- Unknown trigger functions
- Invalid severity levels
- Circular dependencies

## Integration Examples

### CI/CD Pipeline

```yaml
# .gitlab-ci.yml
deploy_triggers:
  stage: deploy
  script:
    - python scripts/validate_trigger_config.py --config triggers.yaml
    - python scripts/zabbix_trigger_manager.py
        --url $ZABBIX_URL
        --username $ZABBIX_USER
        --password $ZABBIX_PASS
        bulk-create --config triggers.yaml
  only:
    - main
```

### Infrastructure as Code

Store trigger configurations in version control:
```
monitoring/
├── triggers/
│   ├── production/
│   │   ├── web_servers.yaml
│   │   ├── db_servers.yaml
│   │   └── cache_servers.yaml
│   └── staging/
│       └── all_servers.yaml
└── actions/
    ├── production_alerts.yaml
    └── staging_alerts.yaml
```

## Security Considerations

1. **Protect credentials**
   - Use environment variables
   - Never commit passwords to git
   - Use Zabbix API tokens when available

2. **Validate input**
   - Always validate before deployment
   - Use dry-run mode for testing

3. **Audit trail**
   - Log all API operations
   - Track configuration changes
   - Review trigger modifications

4. **Principle of least privilege**
   - Use dedicated API user
   - Grant minimum required permissions
   - Separate read/write access

## Support and Documentation

- **Main Skill Documentation**: See SKILL.md
- **Zabbix Documentation**: zabbix-docs-masters/zabbix-docs/07_Configuration/
- **API Reference**: https://www.zabbix.com/documentation/current/en/manual/api
- **Expression Syntax**: https://www.zabbix.com/documentation/current/en/manual/config/triggers/expression

## License

This Agent Skill is part of the Zabbix Skills collection.

## Version

Version: 1.0.0
Last Updated: 2025-11-14
