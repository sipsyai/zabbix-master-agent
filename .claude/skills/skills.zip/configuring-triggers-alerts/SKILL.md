---
name: Configuring Triggers & Alerts in Zabbix
description: Automates Zabbix trigger and alert configuration including creating complex trigger expressions, managing severity levels, setting up alert escalations, configuring notifications, and handling problem acknowledgments through the Zabbix API. Use when implementing problem detection rules, setting up notification workflows, creating escalation chains, configuring correlation rules, standardizing alerting configurations, or implementing infrastructure-as-code for monitoring alerts.
version: 1.0.0
author: Zabbix Skills Team
tags: [zabbix, triggers, alerts, notifications, escalation, monitoring]
---

# Configuring Triggers & Alerts in Zabbix

Automate comprehensive trigger and alert management in Zabbix, from basic threshold monitoring to complex event correlation and multi-tier escalation workflows.

## Quick Start

### Basic Trigger Creation
```python
# Create a simple CPU load trigger
python scripts/zabbix_trigger_manager.py create \
  --host "Production Server" \
  --name "High CPU load on {HOST.NAME}" \
  --expression "avg(/Production Server/system.cpu.load,5m)>5" \
  --severity "Average"
```

### Alert Action Setup
```python
# Configure email notifications for critical problems
python scripts/zabbix_action_manager.py create \
  --name "Critical Alerts" \
  --config examples/alert_actions.yaml
```

### Bulk Operations
```yaml
# Deploy standardized triggers across infrastructure
python scripts/zabbix_trigger_manager.py bulk-create \
  --config examples/bulk_triggers.yaml
```

## Core Capabilities

### Trigger Management
- Create triggers with complex expressions
- Update trigger properties (severity, descriptions, dependencies)
- Delete triggers with safety checks
- Enable/disable triggers
- Test trigger expressions before deployment
- Bulk trigger operations
- Configure trigger tags and event correlation

### Expression Support
All trigger functions: avg, last, min, max, sum, count, percentile, change, diff, nodata, time-based functions

Operators: and, or, not, <, >, =, <=, >=, <>

Time-based conditions: evaluation periods, time shifts, hysteresis

### Alert Configuration
- Configure action conditions and operations
- Set up escalation rules with multiple steps
- Configure media types (Email, SMS, Webhook, Script)
- Create custom message templates
- Configure user and user group targeting
- Set up time periods and schedules
- Recovery and update operations

### Severity Levels
- Not classified
- Information
- Warning
- Average
- High
- Disaster

## When to Use This Skill

Invoke this skill when you need to:
- Set up new monitoring alerts
- Configure problem detection rules
- Implement alert notification workflows
- Create escalation chains
- Standardize trigger configurations across hosts
- Configure event correlation rules
- Implement infrastructure-as-code for alerting
- Test and validate trigger expressions
- Configure maintenance windows
- Set up user notification preferences

## Trigger Expression Patterns

### Simple Threshold
```
last(/host/item.key)>threshold
```

### Time-Based Average
```
avg(/host/item.key,5m)>threshold
```

### Change Detection
```
change(/host/item.key)<>0
```

### Hysteresis (Dual Threshold)
Problem: `avg(/host/temp,5m)>80`
Recovery: `avg(/host/temp,5m)<75`

### No Data Detection
```
nodata(/host/item.key,10m)=1
```

### Complex Multi-Condition
```
avg(/host/cpu.load,5m)>5 and max(/host/memory.used,5m)>90
```

### Time-Based Conditions
```
avg(/host/item.key,5m)>threshold and time()>000000 and time()<060000
```

## Alert Escalation Workflow

```
Step 1 (0-10m): Send email to on-call engineer
Step 2 (10-30m): Send SMS to team lead + email
Step 3 (30m+): Send SMS to manager + create ticket
Recovery: Send recovery notification to all
```

## API Operations Used

### Triggers
- `trigger.create` - Create new triggers
- `trigger.update` - Update trigger properties
- `trigger.delete` - Delete triggers
- `trigger.get` - Retrieve trigger information

### Actions
- `action.create` - Create alert actions
- `action.update` - Update action configurations
- `action.get` - Retrieve action details

### Media Types
- `mediatype.create` - Create notification channels
- `mediatype.update` - Update media configurations
- `mediatype.test` - Test media type delivery

### Users
- `user.update` - Configure user notification settings
- `usergroup.get` - Retrieve user group permissions

## Validation and Safety

Before applying trigger configurations:
1. Validate expression syntax
2. Check host/item existence
3. Verify user/group permissions
4. Test notification delivery
5. Validate escalation timing
6. Check for circular dependencies

Use validation script:
```bash
python scripts/validate_trigger_config.py --config examples/bulk_triggers.yaml
```

## Progressive Disclosure

For detailed implementation guidance:
- **Trigger Expressions**: See examples/advanced_triggers.json
- **Escalation Rules**: See examples/escalation_examples.yaml
- **Media Types**: See examples/media_types.json
- **Bulk Operations**: See examples/bulk_triggers.yaml
- **Script Documentation**: See scripts/README.md

## Configuration Files

All configuration files support both JSON and YAML formats.

### Trigger Configuration Structure
```yaml
triggers:
  - name: "Trigger name with {HOST.NAME}"
    expression: "avg(/host/item,5m)>threshold"
    severity: "Average"
    description: "Problem description"
    recovery_expression: "avg(/host/item,5m)<threshold"
    tags:
      - name: "component"
        value: "cpu"
    dependencies: []
    enabled: true
```

### Action Configuration Structure
```yaml
actions:
  - name: "Action name"
    conditions:
      - type: "trigger_severity"
        operator: ">="
        value: "Average"
    operations:
      - step: 1
        from: "0s"
        to: "0s"
        type: "send_message"
        media_type: "Email"
        users: ["Admin"]
        message_template: "custom"
```

## Best Practices

### Expression Design
- Use appropriate evaluation periods (5m for most metrics)
- Implement hysteresis to prevent flapping
- Test expressions before production deployment
- Use meaningful trigger names with macros
- Add operational data for context

### Alert Configuration
- Set up escalation chains (don't rely on single notification)
- Use severity levels appropriately
- Configure recovery notifications
- Test notification delivery
- Implement time-based routing for off-hours

### Performance
- Avoid very short evaluation periods
- Use trend functions for long-term analysis
- Minimize trigger recalculation frequency
- Use trigger dependencies to reduce noise

### Organization
- Use consistent naming conventions
- Tag triggers for filtering and correlation
- Document trigger logic in descriptions
- Group related triggers with dependencies
- Use templates for standardization

## Error Handling

Scripts include comprehensive error handling for:
- Invalid expression syntax
- Non-existent hosts/items
- Permission errors
- API connection failures
- Invalid severity levels
- Circular dependencies
- Media delivery failures

All errors include actionable remediation steps.

## Examples Library

- `examples/basic_triggers.json` - Simple threshold triggers
- `examples/advanced_triggers.json` - Complex multi-condition triggers
- `examples/alert_actions.yaml` - Standard notification actions
- `examples/escalation_examples.yaml` - Multi-tier escalation rules
- `examples/media_types.json` - Email, SMS, webhook configurations
- `examples/bulk_triggers.yaml` - Infrastructure-wide trigger deployment

## Reference Documentation

For comprehensive Zabbix trigger and action documentation, reference:
- Trigger configuration: zabbix-docs-masters/zabbix-docs/07_Configuration/3_triggers.md
- Action configuration: zabbix-docs-masters/zabbix-docs/07_Configuration/2_action.md
- Trigger expressions: Zabbix documentation on expression syntax
- Trigger functions: Zabbix appendix on available functions

## Common Use Cases

### High CPU Load Alert
Create trigger for sustained high CPU usage with escalation

### Disk Space Monitoring
Threshold-based disk space alerts with recovery notification

### Service Availability
Monitor service status with immediate critical alerts

### Performance Degradation
Detect gradual performance decline with trend analysis

### Custom Metric Monitoring
Application-specific metrics with custom thresholds

### Infrastructure-as-Code
Version-controlled trigger and alert configurations

## Getting Started

1. Review examples in `examples/` directory
2. Configure Zabbix API credentials
3. Validate configurations with validation script
4. Test on non-production environment
5. Deploy to production infrastructure
6. Monitor alert delivery and adjust thresholds

For quick reference, see README.md in the skill directory.
