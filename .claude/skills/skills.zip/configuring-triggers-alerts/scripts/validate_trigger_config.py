#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Trigger Configuration Validator

Validates trigger and action configurations before deployment:
- Expression syntax validation
- Host and item existence checks
- User and group permission validation
- Escalation timing verification
- Circular dependency detection
- Severity level validation

Author: Zabbix Skills Team
Version: 1.0.0
"""

import sys
import json
import yaml
import argparse
import re
from typing import Dict, List, Tuple, Optional, Set
from dataclasses import dataclass
from enum import Enum


class ValidationLevel(Enum):
    """Validation severity levels"""
    ERROR = "ERROR"
    WARNING = "WARNING"
    INFO = "INFO"


@dataclass
class ValidationResult:
    """Result of a validation check"""
    level: ValidationLevel
    message: str
    field: str = ""
    suggestion: str = ""


class TriggerValidator:
    """Validates trigger configurations"""

    # Supported trigger functions
    TRIGGER_FUNCTIONS = {
        'avg', 'last', 'min', 'max', 'sum', 'count', 'change', 'diff',
        'percentile', 'timeleft', 'forecast', 'nodata', 'date', 'time',
        'dayofweek', 'dayofmonth', 'now', 'fuzzytime', 'logeventid',
        'logseverity', 'logsource', 'strlen', 'band', 'abs', 'baselinedev',
        'baselinewma', 'bucket_percentile', 'bucket_rate_foreach',
        'find', 'trendavg', 'trendcount', 'trendmax', 'trendmin', 'trendsum'
    }

    # Valid operators
    OPERATORS = {'<', '>', '=', '<=', '>=', '<>', 'and', 'or', 'not'}

    # Valid severity levels
    SEVERITY_LEVELS = {
        'not classified': 0,
        'information': 1,
        'warning': 2,
        'average': 3,
        'high': 4,
        'disaster': 5
    }

    def __init__(self):
        """Initialize validator"""
        self.results: List[ValidationResult] = []

    def add_result(self, level: ValidationLevel, message: str,
                   field: str = "", suggestion: str = ""):
        """Add a validation result"""
        self.results.append(ValidationResult(level, message, field, suggestion))

    def validate_expression_syntax(self, expression: str, trigger_name: str = "") -> bool:
        """
        Validate trigger expression syntax

        Args:
            expression: Trigger expression
            trigger_name: Optional trigger name for error messages

        Returns:
            True if valid, False otherwise
        """
        context = f" in trigger '{trigger_name}'" if trigger_name else ""
        is_valid = True

        if not expression:
            self.add_result(
                ValidationLevel.ERROR,
                f"Expression is empty{context}",
                "expression",
                "Provide a valid trigger expression"
            )
            return False

        # Check balanced parentheses
        if expression.count('(') != expression.count(')'):
            self.add_result(
                ValidationLevel.ERROR,
                f"Unbalanced parentheses{context}",
                "expression",
                "Ensure all parentheses are properly paired"
            )
            is_valid = False

        # Check for at least one function
        has_function = any(f'/{func}(' in expression or expression.startswith(f'{func}(')
                          for func in self.TRIGGER_FUNCTIONS)

        if not has_function:
            # More lenient check - just look for function names
            has_function = any(func in expression for func in self.TRIGGER_FUNCTIONS)

        if not has_function:
            self.add_result(
                ValidationLevel.ERROR,
                f"No valid trigger function found{context}",
                "expression",
                f"Use one of: {', '.join(sorted(list(self.TRIGGER_FUNCTIONS)[:10]))}..."
            )
            is_valid = False

        # Check item reference format: /host/item.key
        item_pattern = r'/[^/]+/[^/,)>\s]+'
        if not re.search(item_pattern, expression):
            self.add_result(
                ValidationLevel.ERROR,
                f"Invalid item reference format{context}",
                "expression",
                "Use format: /hostname/item.key"
            )
            is_valid = False

        # Check for invalid characters
        invalid_chars = ['#', '$', '@', '^', '~', '`']
        for char in invalid_chars:
            if char in expression and char not in ['$']:  # $ allowed in macros
                self.add_result(
                    ValidationLevel.WARNING,
                    f"Potentially invalid character '{char}' found{context}",
                    "expression",
                    "Remove or escape special characters"
                )

        # Check for common mistakes
        if ' = ' in expression and not ' == ' in expression:
            self.add_result(
                ValidationLevel.WARNING,
                f"Single '=' found, use '=' for comparison (not '=='){context}",
                "expression",
                "Zabbix uses '=' for equality comparison"
            )

        # Check evaluation period format
        time_periods = re.findall(r'(\d+[smhdw])', expression)
        for period in time_periods:
            if not re.match(r'^\d+[smhdw]$', period):
                self.add_result(
                    ValidationLevel.WARNING,
                    f"Invalid time period format: {period}{context}",
                    "expression",
                    "Use format: 5m, 1h, 1d, etc."
                )

        return is_valid

    def validate_severity(self, severity: str, trigger_name: str = "") -> bool:
        """
        Validate trigger severity

        Args:
            severity: Severity level
            trigger_name: Optional trigger name

        Returns:
            True if valid
        """
        context = f" in trigger '{trigger_name}'" if trigger_name else ""

        if not severity:
            self.add_result(
                ValidationLevel.ERROR,
                f"Severity not specified{context}",
                "severity",
                "Provide a severity level"
            )
            return False

        if severity.lower() not in self.SEVERITY_LEVELS:
            valid_levels = ', '.join(self.SEVERITY_LEVELS.keys())
            self.add_result(
                ValidationLevel.ERROR,
                f"Invalid severity: {severity}{context}",
                "severity",
                f"Use one of: {valid_levels}"
            )
            return False

        return True

    def validate_trigger_name(self, name: str) -> bool:
        """
        Validate trigger name

        Args:
            name: Trigger name

        Returns:
            True if valid
        """
        if not name:
            self.add_result(
                ValidationLevel.ERROR,
                "Trigger name is empty",
                "name",
                "Provide a descriptive trigger name"
            )
            return False

        # Check if name is too generic
        generic_names = ['test', 'trigger', 'alert', 'problem', 'issue']
        if name.lower() in generic_names:
            self.add_result(
                ValidationLevel.WARNING,
                f"Trigger name is too generic: {name}",
                "name",
                "Use descriptive names like 'High CPU load on {HOST.NAME}'"
            )

        # Check for recommended macros
        if '{HOST.NAME}' not in name and '{HOST.HOST}' not in name:
            self.add_result(
                ValidationLevel.INFO,
                f"Consider adding {{HOST.NAME}} macro to trigger name",
                "name",
                "Helps identify which host triggered the alert"
            )

        # Check name length
        if len(name) > 255:
            self.add_result(
                ValidationLevel.ERROR,
                "Trigger name exceeds 255 characters",
                "name",
                "Shorten the trigger name"
            )
            return False

        return True

    def validate_tags(self, tags: List[Dict], trigger_name: str = "") -> bool:
        """
        Validate trigger tags

        Args:
            tags: List of tag dictionaries
            trigger_name: Optional trigger name

        Returns:
            True if valid
        """
        if not tags:
            return True

        context = f" in trigger '{trigger_name}'" if trigger_name else ""
        is_valid = True

        for i, tag in enumerate(tags):
            if not isinstance(tag, dict):
                self.add_result(
                    ValidationLevel.ERROR,
                    f"Tag {i+1} is not a dictionary{context}",
                    "tags",
                    "Use format: {name: 'key', value: 'value'}"
                )
                is_valid = False
                continue

            if 'name' not in tag:
                self.add_result(
                    ValidationLevel.ERROR,
                    f"Tag {i+1} missing 'name' field{context}",
                    "tags",
                    "Add 'name' field to tag"
                )
                is_valid = False

            if 'value' not in tag:
                self.add_result(
                    ValidationLevel.WARNING,
                    f"Tag {i+1} missing 'value' field{context}",
                    "tags",
                    "Consider adding value for better correlation"
                )

            # Check tag name length
            if 'name' in tag and len(tag['name']) > 255:
                self.add_result(
                    ValidationLevel.ERROR,
                    f"Tag name exceeds 255 characters{context}",
                    "tags",
                    "Shorten tag name"
                )
                is_valid = False

        return is_valid

    def check_circular_dependencies(self, triggers: List[Dict],
                                   dependency_map: Dict[str, List[str]]) -> bool:
        """
        Check for circular dependencies in triggers

        Args:
            triggers: List of trigger configurations
            dependency_map: Map of trigger name to dependency names

        Returns:
            True if no circular dependencies found
        """
        def has_cycle(trigger_name: str, visited: Set[str], rec_stack: Set[str]) -> bool:
            visited.add(trigger_name)
            rec_stack.add(trigger_name)

            if trigger_name in dependency_map:
                for dependency in dependency_map[trigger_name]:
                    if dependency not in visited:
                        if has_cycle(dependency, visited, rec_stack):
                            return True
                    elif dependency in rec_stack:
                        return True

            rec_stack.remove(trigger_name)
            return False

        visited = set()
        has_circular = False

        for trigger in triggers:
            trigger_name = trigger.get('name', '')
            if trigger_name not in visited:
                if has_cycle(trigger_name, visited, set()):
                    self.add_result(
                        ValidationLevel.ERROR,
                        f"Circular dependency detected involving: {trigger_name}",
                        "dependencies",
                        "Remove circular dependencies from trigger chain"
                    )
                    has_circular = True

        return not has_circular

    def validate_recovery_expression(self, problem_expr: str, recovery_expr: str,
                                    trigger_name: str = "") -> bool:
        """
        Validate recovery expression compatibility

        Args:
            problem_expr: Problem expression
            recovery_expr: Recovery expression
            trigger_name: Optional trigger name

        Returns:
            True if valid
        """
        if not recovery_expr:
            return True  # Recovery expression is optional

        context = f" in trigger '{trigger_name}'" if trigger_name else ""

        # Validate recovery expression syntax
        if not self.validate_expression_syntax(recovery_expr, trigger_name):
            return False

        # Check for hysteresis pattern
        if '>' in problem_expr and '<' not in recovery_expr:
            self.add_result(
                ValidationLevel.WARNING,
                f"Hysteresis not detected{context}",
                "recovery_expression",
                "Consider using a lower threshold in recovery expression"
            )

        if '<' in problem_expr and '>' not in recovery_expr:
            self.add_result(
                ValidationLevel.WARNING,
                f"Hysteresis not detected{context}",
                "recovery_expression",
                "Consider using a higher threshold in recovery expression"
            )

        return True


class ActionValidator:
    """Validates action configurations"""

    def __init__(self):
        """Initialize validator"""
        self.results: List[ValidationResult] = []

    def add_result(self, level: ValidationLevel, message: str,
                   field: str = "", suggestion: str = ""):
        """Add a validation result"""
        self.results.append(ValidationResult(level, message, field, suggestion))

    def validate_escalation_timing(self, operations: List[Dict],
                                   action_name: str = "") -> bool:
        """
        Validate escalation step timing

        Args:
            operations: List of operations
            action_name: Optional action name

        Returns:
            True if valid
        """
        context = f" in action '{action_name}'" if action_name else ""
        is_valid = True

        if not operations:
            self.add_result(
                ValidationLevel.WARNING,
                f"No operations defined{context}",
                "operations",
                "Add at least one notification operation"
            )
            return False

        # Check escalation step sequence
        steps = []
        for op in operations:
            step_from = op.get('esc_step_from', 1)
            step_to = op.get('esc_step_to', 1)
            steps.append((step_from, step_to))

        steps.sort()

        # Verify continuous sequence
        for i in range(len(steps) - 1):
            if steps[i][1] + 1 != steps[i+1][0]:
                self.add_result(
                    ValidationLevel.WARNING,
                    f"Gap in escalation steps: {steps[i][1]} to {steps[i+1][0]}{context}",
                    "operations",
                    "Ensure escalation steps are continuous"
                )

        return is_valid

    def validate_message_template(self, template: Dict, context: str = "") -> bool:
        """
        Validate message template

        Args:
            template: Message template dict
            context: Context string for errors

        Returns:
            True if valid
        """
        is_valid = True

        if 'subject' not in template and 'message' not in template:
            self.add_result(
                ValidationLevel.WARNING,
                f"Empty message template{context}",
                "message_template",
                "Provide subject and/or message body"
            )
            return False

        # Check for recommended macros
        recommended_macros = ['{EVENT.NAME}', '{TRIGGER.NAME}', '{HOST.NAME}']
        message_text = template.get('subject', '') + template.get('message', '')

        has_macro = any(macro in message_text for macro in recommended_macros)
        if not has_macro:
            self.add_result(
                ValidationLevel.INFO,
                f"Consider using macros in message template{context}",
                "message_template",
                f"Recommended: {', '.join(recommended_macros)}"
            )

        return is_valid


def load_config_file(file_path: str) -> Dict:
    """Load configuration from JSON or YAML file"""
    try:
        with open(file_path, 'r') as f:
            if file_path.endswith('.json'):
                return json.load(f)
            elif file_path.endswith(('.yaml', '.yml')):
                return yaml.safe_load(f)
            else:
                raise ValueError("Unsupported file format. Use .json, .yaml, or .yml")
    except FileNotFoundError:
        print(f"[ERROR] Configuration file not found: {file_path}")
        sys.exit(1)
    except (json.JSONDecodeError, yaml.YAMLError) as e:
        print(f"[ERROR] Failed to parse configuration file: {e}")
        sys.exit(1)


def print_results(results: List[ValidationResult], show_info: bool = True):
    """Print validation results"""
    if not results:
        print("\n[OK] All validations passed!")
        return

    errors = [r for r in results if r.level == ValidationLevel.ERROR]
    warnings = [r for r in results if r.level == ValidationLevel.WARNING]
    info = [r for r in results if r.level == ValidationLevel.INFO]

    if errors:
        print(f"\n[ERROR] ERRORS ({len(errors)}):")
        for i, result in enumerate(errors, 1):
            print(f"\n  {i}. {result.message}")
            if result.field:
                print(f"     Field: {result.field}")
            if result.suggestion:
                print(f"     Suggestion: {result.suggestion}")

    if warnings:
        print(f"\n[WARN] WARNINGS ({len(warnings)}):")
        for i, result in enumerate(warnings, 1):
            print(f"\n  {i}. {result.message}")
            if result.field:
                print(f"     Field: {result.field}")
            if result.suggestion:
                print(f"     Suggestion: {result.suggestion}")

    if show_info and info:
        print(f"\nℹ INFO ({len(info)}):")
        for i, result in enumerate(info, 1):
            print(f"\n  {i}. {result.message}")
            if result.suggestion:
                print(f"     Suggestion: {result.suggestion}")

    # Summary
    print("\n" + "=" * 60)
    print(f"VALIDATION SUMMARY:")
    print(f"  Errors: {len(errors)}")
    print(f"  Warnings: {len(warnings)}")
    print(f"  Info: {len(info)}")
    print("=" * 60)


def validate_trigger_config(config: Dict, show_info: bool = True) -> bool:
    """
    Validate trigger configuration

    Args:
        config: Configuration dictionary
        show_info: Show info-level messages

    Returns:
        True if validation passed (no errors)
    """
    validator = TriggerValidator()
    triggers = config.get('triggers', [])

    if not triggers:
        print("[ERROR] No triggers found in configuration")
        return False

    print(f"Validating {len(triggers)} trigger(s)...")

    # Build dependency map
    dependency_map = {}
    for trigger in triggers:
        name = trigger.get('name', '')
        deps = trigger.get('dependencies', [])
        if deps:
            dependency_map[name] = deps

    # Validate each trigger
    for i, trigger in enumerate(triggers, 1):
        print(f"  [{i}/{len(triggers)}] {trigger.get('name', 'Unnamed trigger')}")

        # Validate name
        validator.validate_trigger_name(trigger.get('name', ''))

        # Validate expression
        validator.validate_expression_syntax(
            trigger.get('expression', ''),
            trigger.get('name', '')
        )

        # Validate severity
        validator.validate_severity(
            trigger.get('severity', ''),
            trigger.get('name', '')
        )

        # Validate tags
        if 'tags' in trigger:
            validator.validate_tags(trigger['tags'], trigger.get('name', ''))

        # Validate recovery expression
        if 'recovery_expression' in trigger:
            validator.validate_recovery_expression(
                trigger.get('expression', ''),
                trigger['recovery_expression'],
                trigger.get('name', '')
            )

    # Check for circular dependencies
    if dependency_map:
        validator.check_circular_dependencies(triggers, dependency_map)

    # Print results
    print_results(validator.results, show_info)

    # Return True if no errors
    errors = [r for r in validator.results if r.level == ValidationLevel.ERROR]
    return len(errors) == 0


def validate_action_config(config: Dict, show_info: bool = True) -> bool:
    """
    Validate action configuration

    Args:
        config: Configuration dictionary
        show_info: Show info-level messages

    Returns:
        True if validation passed (no errors)
    """
    validator = ActionValidator()
    actions = config.get('actions', [])

    if not actions:
        print("[ERROR] No actions found in configuration")
        return False

    print(f"Validating {len(actions)} action(s)...")

    for i, action in enumerate(actions, 1):
        print(f"  [{i}/{len(actions)}] {action.get('name', 'Unnamed action')}")

        # Validate operations
        operations = action.get('operations', [])
        validator.validate_escalation_timing(operations, action.get('name', ''))

        # Validate message templates
        for op in operations:
            if 'message_template' in op:
                validator.validate_message_template(
                    op['message_template'],
                    f" in action '{action.get('name', '')}'"
                )

    # Print results
    print_results(validator.results, show_info)

    # Return True if no errors
    errors = [r for r in validator.results if r.level == ValidationLevel.ERROR]
    return len(errors) == 0


def main():
    """Main execution function"""
    parser = argparse.ArgumentParser(
        description="Validate Zabbix trigger and action configurations"
    )

    parser.add_argument("--config", required=True, help="Path to configuration file")
    parser.add_argument("--type", choices=["trigger", "action", "auto"],
                       default="auto", help="Configuration type (auto-detect by default)")
    parser.add_argument("--no-info", action="store_true",
                       help="Hide informational messages")
    parser.add_argument("--strict", action="store_true",
                       help="Treat warnings as errors")

    args = parser.parse_args()

    # Load configuration
    config = load_config_file(args.config)

    # Determine configuration type
    config_type = args.type
    if config_type == "auto":
        if 'triggers' in config:
            config_type = "trigger"
        elif 'actions' in config:
            config_type = "action"
        else:
            print("[ERROR] Unable to determine configuration type")
            print("   Specify --type trigger or --type action")
            return 1

    # Validate configuration
    print(f"\nValidating {config_type} configuration: {args.config}\n")

    if config_type == "trigger":
        is_valid = validate_trigger_config(config, not args.no_info)
    else:
        is_valid = validate_action_config(config, not args.no_info)

    # Return appropriate exit code
    if not is_valid:
        return 1

    if args.strict:
        # Check for any warnings
        # This would require refactoring to return validator object
        print("\nNote: Run without --strict to allow warnings")

    return 0


if __name__ == "__main__":
    sys.exit(main())
