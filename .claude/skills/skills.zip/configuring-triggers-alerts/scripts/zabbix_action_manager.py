#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Action Manager

Manage Zabbix actions, escalations, and notifications including:
- Creating alert actions
- Configuring escalation rules
- Setting up media types
- Managing user notifications
- Testing notification delivery

Author: Zabbix Skills Team
Version: 1.0.0
"""

import sys
import json
import yaml
import argparse
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from enum import Enum

try:
    import requests
except ImportError:
    print("ERROR: Required package 'requests' not found.")
    print("Install with: pip install requests")
    sys.exit(1)


class ActionType(Enum):
    """Action types"""
    TRIGGER_ACTION = 0
    DISCOVERY_ACTION = 1
    AUTOREGISTRATION_ACTION = 2
    INTERNAL_ACTION = 3
    SERVICE_ACTION = 4


class OperationType(Enum):
    """Operation types"""
    SEND_MESSAGE = 0
    REMOTE_COMMAND = 1
    ADD_HOST = 2
    REMOVE_HOST = 3
    ADD_TO_HOST_GROUP = 4
    REMOVE_FROM_HOST_GROUP = 5
    LINK_TO_TEMPLATE = 6
    UNLINK_FROM_TEMPLATE = 7
    ENABLE_HOST = 8
    DISABLE_HOST = 9
    SET_HOST_INVENTORY_MODE = 10


class ConditionType(Enum):
    """Condition types for trigger actions"""
    HOST_GROUP = 0
    HOST = 1
    TRIGGER = 2
    TRIGGER_NAME = 3
    TRIGGER_SEVERITY = 4
    TRIGGER_VALUE = 5
    TIME_PERIOD = 6
    HOST_IP = 7
    DISCOVERED_SERVICE_TYPE = 8
    DISCOVERED_SERVICE_PORT = 9
    DISCOVERY_STATUS = 10
    UPTIME_DOWNTIME = 11
    RECEIVED_VALUE = 12
    HOST_NAME = 13
    EVENT_ACKNOWLEDGED = 16
    APPLICATION = 17
    MAINTENANCE_STATUS = 21
    EVENT_TAG = 26
    EVENT_TAG_VALUE = 27


@dataclass
class ActionConfig:
    """Configuration for an action"""
    name: str
    conditions: List[Dict[str, Any]]
    operations: List[Dict[str, Any]]
    recovery_operations: List[Dict[str, Any]] = None
    update_operations: List[Dict[str, Any]] = None
    enabled: bool = True
    esc_period: str = "1h"
    pause_suppressed: bool = True


class ZabbixActionManager:
    """Manages Zabbix actions and notifications via API"""

    def __init__(self, url: str, username: str, password: str):
        """
        Initialize Zabbix API connection

        Args:
            url: Zabbix API URL
            username: Zabbix username
            password: Zabbix password
        """
        self.url = url
        self.username = username
        self.password = password
        self.auth_token = None
        self.request_id = 1

    def authenticate(self) -> bool:
        """Authenticate with Zabbix API"""
        payload = {
            "jsonrpc": "2.0",
            "method": "user.login",
            "params": {
                "username": self.username,
                "password": self.password
            },
            "id": self.request_id,
        }

        try:
            response = requests.post(self.url, json=payload, timeout=30)
            response.raise_for_status()
            result = response.json()

            if "result" in result:
                self.auth_token = result["result"]
                self.request_id += 1
                print("[OK] Successfully authenticated with Zabbix API")
                return True
            elif "error" in result:
                print(f"[ERROR] Authentication failed: {result['error']['data']}")
                return False

        except requests.exceptions.RequestException as e:
            print(f"[ERROR] Connection error: {e}")
            return False

        return False

    def _api_call(self, method: str, params: Dict = None) -> Optional[Dict]:
        """Make an API call to Zabbix"""
        if not self.auth_token:
            print("[ERROR] Not authenticated. Call authenticate() first.")
            return None

        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params or {},
            "auth": self.auth_token,
            "id": self.request_id,
        }

        try:
            response = requests.post(self.url, json=payload, timeout=30)
            response.raise_for_status()
            result = response.json()
            self.request_id += 1

            if "result" in result:
                return result["result"]
            elif "error" in result:
                error_msg = result["error"].get("data", result["error"].get("message", "Unknown error"))
                print(f"[ERROR] API Error: {error_msg}")
                return None

        except requests.exceptions.RequestException as e:
            print(f"[ERROR] API request failed: {e}")
            return None

        return None

    def get_user_id(self, username: str) -> Optional[str]:
        """Get user ID by username"""
        params = {
            "output": ["userid"],
            "filter": {"username": [username]}
        }

        result = self._api_call("user.get", params)
        if result and len(result) > 0:
            return result[0]["userid"]

        print(f"[ERROR] User not found: {username}")
        return None

    def get_usergroup_id(self, group_name: str) -> Optional[str]:
        """Get user group ID by name"""
        params = {
            "output": ["usrgrpid"],
            "filter": {"name": [group_name]}
        }

        result = self._api_call("usergroup.get", params)
        if result and len(result) > 0:
            return result[0]["usrgrpid"]

        print(f"[ERROR] User group not found: {group_name}")
        return None

    def get_mediatype_id(self, name: str) -> Optional[str]:
        """Get media type ID by name"""
        params = {
            "output": ["mediatypeid"],
            "filter": {"name": [name]}
        }

        result = self._api_call("mediatype.get", params)
        if result and len(result) > 0:
            return result[0]["mediatypeid"]

        print(f"[ERROR] Media type not found: {name}")
        return None

    def create_action(self, config: ActionConfig) -> Optional[str]:
        """
        Create a new action

        Args:
            config: Action configuration

        Returns:
            Action ID or None on failure
        """
        print(f"Creating action: {config.name}")

        # Build action parameters
        params = {
            "name": config.name,
            "eventsource": ActionType.TRIGGER_ACTION.value,
            "status": 0 if config.enabled else 1,
            "esc_period": config.esc_period,
            "pause_suppressed": 1 if config.pause_suppressed else 0,
            "filter": {
                "evaltype": 0,  # And/Or
                "conditions": config.conditions
            },
            "operations": config.operations
        }

        # Add recovery operations if provided
        if config.recovery_operations:
            params["recovery_operations"] = config.recovery_operations

        # Add update operations if provided
        if config.update_operations:
            params["update_operations"] = config.update_operations

        result = self._api_call("action.create", params)

        if result and "actionids" in result:
            action_id = result["actionids"][0]
            print(f"[OK] Action created successfully (ID: {action_id})")
            return action_id

        return None

    def update_action(self, action_id: str, config: ActionConfig) -> bool:
        """
        Update an existing action

        Args:
            action_id: ID of action to update
            config: New action configuration

        Returns:
            True if successful, False otherwise
        """
        print(f"Updating action ID: {action_id}")

        params = {
            "actionid": action_id,
            "name": config.name,
            "status": 0 if config.enabled else 1,
            "esc_period": config.esc_period,
            "filter": {
                "evaltype": 0,
                "conditions": config.conditions
            },
            "operations": config.operations
        }

        if config.recovery_operations:
            params["recovery_operations"] = config.recovery_operations

        if config.update_operations:
            params["update_operations"] = config.update_operations

        result = self._api_call("action.update", params)

        if result:
            print(f"[OK] Action updated successfully")
            return True

        return False

    def delete_action(self, action_id: str, force: bool = False) -> bool:
        """
        Delete an action

        Args:
            action_id: ID of action to delete
            force: Skip safety checks if True

        Returns:
            True if successful, False otherwise
        """
        if not force:
            action = self.get_action(action_id)
            if not action:
                print(f"[ERROR] Action {action_id} not found")
                return False

            print(f"[WARN] WARNING: About to delete action: {action.get('name', 'Unknown')}")
            confirm = input("Type 'DELETE' to confirm: ")
            if confirm != "DELETE":
                print("[ERROR] Deletion cancelled")
                return False

        print(f"Deleting action ID: {action_id}")
        result = self._api_call("action.delete", [action_id])

        if result:
            print(f"[OK] Action deleted successfully")
            return True

        return False

    def get_action(self, action_id: str) -> Optional[Dict]:
        """Get action details"""
        params = {
            "output": "extend",
            "actionids": action_id,
            "selectOperations": "extend",
            "selectRecoveryOperations": "extend",
            "selectUpdateOperations": "extend",
            "selectFilter": "extend"
        }

        result = self._api_call("action.get", params)

        if result and len(result) > 0:
            return result[0]

        return None

    def list_actions(self, enabled_only: bool = False) -> List[Dict]:
        """
        List all actions

        Args:
            enabled_only: Show only enabled actions

        Returns:
            List of actions
        """
        params = {
            "output": ["actionid", "name", "status", "eventsource"],
            "selectOperations": "extend"
        }

        if enabled_only:
            params["filter"] = {"status": 0}

        result = self._api_call("action.get", params)
        return result or []

    def create_mediatype(self, name: str, media_type: str, **kwargs) -> Optional[str]:
        """
        Create a new media type

        Args:
            name: Media type name
            media_type: Type (email, sms, webhook, script, etc.)
            **kwargs: Additional parameters

        Returns:
            Media type ID or None on failure
        """
        print(f"Creating media type: {name}")

        # Media type codes
        type_map = {
            "email": 0,
            "script": 1,
            "sms": 2,
            "webhook": 4
        }

        params = {
            "name": name,
            "type": type_map.get(media_type, 0),
            "status": 0  # Enabled
        }

        # Add type-specific parameters
        if media_type == "email":
            params.update({
                "smtp_server": kwargs.get("smtp_server", "localhost"),
                "smtp_port": kwargs.get("smtp_port", 25),
                "smtp_email": kwargs.get("smtp_email", "zabbix@example.com"),
                "smtp_helo": kwargs.get("smtp_helo", "zabbix.example.com")
            })

        elif media_type == "webhook":
            params.update({
                "script": kwargs.get("script", ""),
                "parameters": kwargs.get("parameters", [])
            })

        elif media_type == "script":
            params.update({
                "exec_path": kwargs.get("exec_path", "")
            })

        result = self._api_call("mediatype.create", params)

        if result and "mediatypeids" in result:
            mediatype_id = result["mediatypeids"][0]
            print(f"[OK] Media type created successfully (ID: {mediatype_id})")
            return mediatype_id

        return None

    def test_mediatype(self, mediatype_id: str, recipient: str) -> bool:
        """
        Test media type delivery

        Args:
            mediatype_id: Media type ID
            recipient: Test recipient

        Returns:
            True if test successful
        """
        print(f"Testing media type ID: {mediatype_id}")

        params = {
            "mediatypeid": mediatype_id,
            "sendto": recipient,
            "subject": "Zabbix Test Message",
            "message": "This is a test message from Zabbix"
        }

        result = self._api_call("mediatype.test", params)

        if result:
            print(f"[OK] Test message sent successfully")
            return True

        return False

    def create_escalation_action(self, name: str, severity_threshold: int,
                                 escalation_steps: List[Dict]) -> Optional[str]:
        """
        Create an action with escalation steps

        Args:
            name: Action name
            severity_threshold: Minimum severity (0-5)
            escalation_steps: List of escalation step configurations

        Returns:
            Action ID or None on failure
        """
        print(f"Creating escalation action: {name}")

        # Build condition for severity threshold
        conditions = [{
            "conditiontype": ConditionType.TRIGGER_SEVERITY.value,
            "operator": 5,  # >=
            "value": str(severity_threshold)
        }]

        # Build operations from escalation steps
        operations = []
        for step in escalation_steps:
            operation = {
                "operationtype": OperationType.SEND_MESSAGE.value,
                "esc_period": step.get("duration", "0"),
                "esc_step_from": step.get("step", 1),
                "esc_step_to": step.get("step", 1),
                "evaltype": 0
            }

            # Add message configuration
            if "message_template" in step:
                operation["opmessage"] = {
                    "default_msg": 0,
                    "subject": step["message_template"].get("subject", "Problem: {EVENT.NAME}"),
                    "message": step["message_template"].get("body", "{TRIGGER.STATUS}: {TRIGGER.NAME}")
                }

            # Add recipients
            if "users" in step:
                operation["opmessage_usr"] = [
                    {"userid": self.get_user_id(user)} for user in step["users"]
                ]

            if "user_groups" in step:
                operation["opmessage_grp"] = [
                    {"usrgrpid": self.get_usergroup_id(group)} for group in step["user_groups"]
                ]

            operations.append(operation)

        config = ActionConfig(
            name=name,
            conditions=conditions,
            operations=operations,
            enabled=True
        )

        return self.create_action(config)

    def build_operation(self, step: int, duration: str, users: List[str] = None,
                       user_groups: List[str] = None, media_type: str = None,
                       message_subject: str = None, message_body: str = None) -> Dict:
        """
        Build an operation configuration

        Args:
            step: Escalation step number
            duration: Step duration (e.g., "10m", "1h")
            users: List of usernames
            user_groups: List of user group names
            media_type: Media type name
            message_subject: Message subject
            message_body: Message body

        Returns:
            Operation configuration dict
        """
        operation = {
            "operationtype": OperationType.SEND_MESSAGE.value,
            "esc_period": duration,
            "esc_step_from": step,
            "esc_step_to": step,
            "evaltype": 0
        }

        # Configure message
        operation["opmessage"] = {
            "default_msg": 1 if not message_subject else 0,
            "mediatypeid": self.get_mediatype_id(media_type) if media_type else "0"
        }

        if message_subject:
            operation["opmessage"]["subject"] = message_subject

        if message_body:
            operation["opmessage"]["message"] = message_body

        # Add recipients
        if users:
            operation["opmessage_usr"] = [
                {"userid": self.get_user_id(user)} for user in users if self.get_user_id(user)
            ]

        if user_groups:
            operation["opmessage_grp"] = [
                {"usrgrpid": self.get_usergroup_id(group)} for group in user_groups if self.get_usergroup_id(group)
            ]

        return operation


def load_config_file(file_path: str) -> Dict:
    """Load configuration from JSON or YAML file"""
    with open(file_path, 'r') as f:
        if file_path.endswith('.json'):
            return json.load(f)
        elif file_path.endswith(('.yaml', '.yml')):
            return yaml.safe_load(f)
        else:
            raise ValueError("Unsupported file format. Use .json, .yaml, or .yml")


def main():
    """Main execution function"""
    parser = argparse.ArgumentParser(
        description="Zabbix Action Manager - Manage actions, escalations, and notifications"
    )

    parser.add_argument("--url", required=True, help="Zabbix API URL")
    parser.add_argument("--username", required=True, help="Zabbix username")
    parser.add_argument("--password", required=True, help="Zabbix password")

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Create action
    create_parser = subparsers.add_parser("create", help="Create a new action")
    create_parser.add_argument("--config", required=True, help="Path to action config file")

    # Update action
    update_parser = subparsers.add_parser("update", help="Update an action")
    update_parser.add_argument("--id", required=True, help="Action ID")
    update_parser.add_argument("--config", required=True, help="Path to action config file")

    # Delete action
    delete_parser = subparsers.add_parser("delete", help="Delete an action")
    delete_parser.add_argument("--id", required=True, help="Action ID")
    delete_parser.add_argument("--force", action="store_true", help="Skip confirmation")

    # List actions
    list_parser = subparsers.add_parser("list", help="List actions")
    list_parser.add_argument("--enabled-only", action="store_true", help="Show only enabled actions")

    # Create media type
    media_parser = subparsers.add_parser("create-media", help="Create a media type")
    media_parser.add_argument("--name", required=True, help="Media type name")
    media_parser.add_argument("--type", required=True, choices=["email", "sms", "webhook", "script"],
                             help="Media type")
    media_parser.add_argument("--smtp-server", help="SMTP server (for email)")
    media_parser.add_argument("--smtp-email", help="From email address")

    # Test media type
    test_parser = subparsers.add_parser("test-media", help="Test media type delivery")
    test_parser.add_argument("--id", required=True, help="Media type ID")
    test_parser.add_argument("--recipient", required=True, help="Test recipient")

    # Create escalation
    esc_parser = subparsers.add_parser("create-escalation", help="Create escalation action")
    esc_parser.add_argument("--config", required=True, help="Path to escalation config file")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    # Initialize manager and authenticate
    manager = ZabbixActionManager(args.url, args.username, args.password)
    if not manager.authenticate():
        return 1

    # Execute command
    if args.command == "create":
        config_data = load_config_file(args.config)
        config = ActionConfig(
            name=config_data["name"],
            conditions=config_data["conditions"],
            operations=config_data["operations"],
            recovery_operations=config_data.get("recovery_operations"),
            update_operations=config_data.get("update_operations"),
            enabled=config_data.get("enabled", True),
            esc_period=config_data.get("esc_period", "1h")
        )
        manager.create_action(config)

    elif args.command == "update":
        config_data = load_config_file(args.config)
        config = ActionConfig(
            name=config_data["name"],
            conditions=config_data["conditions"],
            operations=config_data["operations"],
            recovery_operations=config_data.get("recovery_operations"),
            enabled=config_data.get("enabled", True)
        )
        manager.update_action(args.id, config)

    elif args.command == "delete":
        manager.delete_action(args.id, args.force)

    elif args.command == "list":
        actions = manager.list_actions(args.enabled_only)
        print(f"\nFound {len(actions)} action(s):")
        for action in actions:
            print(f"\nID: {action['actionid']}")
            print(f"  Name: {action['name']}")
            print(f"  Status: {'Enabled' if action['status'] == '0' else 'Disabled'}")
            print(f"  Operations: {len(action.get('operations', []))}")

    elif args.command == "create-media":
        kwargs = {}
        if args.smtp_server:
            kwargs["smtp_server"] = args.smtp_server
        if args.smtp_email:
            kwargs["smtp_email"] = args.smtp_email

        manager.create_mediatype(args.name, args.type, **kwargs)

    elif args.command == "test-media":
        manager.test_mediatype(args.id, args.recipient)

    elif args.command == "create-escalation":
        config_data = load_config_file(args.config)
        manager.create_escalation_action(
            config_data["name"],
            config_data.get("severity_threshold", 3),
            config_data.get("escalation_steps", [])
        )

    return 0


if __name__ == "__main__":
    sys.exit(main())
