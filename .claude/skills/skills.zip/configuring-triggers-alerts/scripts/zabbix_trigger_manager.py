#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Trigger Manager

Comprehensive trigger management script for Zabbix API operations including:
- Creating triggers with complex expressions
- Updating trigger properties
- Deleting triggers with safety checks
- Bulk operations
- Expression validation
- Dependency management

Author: Zabbix Skills Team
Version: 1.0.0
"""

import sys
import json
import yaml
import argparse
import re
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from enum import Enum

try:
    import requests
    from requests.auth import HTTPBasicAuth
except ImportError:
    print("ERROR: Required package 'requests' not found.")
    print("Install with: pip install requests")
    sys.exit(1)


class Severity(Enum):
    """Trigger severity levels"""
    NOT_CLASSIFIED = 0
    INFORMATION = 1
    WARNING = 2
    AVERAGE = 3
    HIGH = 4
    DISASTER = 5


class TriggerStatus(Enum):
    """Trigger enable/disable status"""
    ENABLED = 0
    DISABLED = 1


@dataclass
class TriggerConfig:
    """Configuration for a trigger"""
    name: str
    expression: str
    severity: str
    description: str = ""
    recovery_expression: str = ""
    priority: int = 3
    tags: List[Dict[str, str]] = None
    dependencies: List[str] = None
    enabled: bool = True
    manual_close: bool = True
    event_name: str = ""
    operational_data: str = ""
    comments: str = ""


class ZabbixTriggerManager:
    """Manages Zabbix triggers via API"""

    # Supported trigger functions for validation
    TRIGGER_FUNCTIONS = [
        'avg', 'last', 'min', 'max', 'sum', 'count', 'change', 'diff',
        'percentile', 'timeleft', 'forecast', 'nodata', 'date', 'time',
        'dayofweek', 'dayofmonth', 'now', 'fuzzytime', 'logeventid',
        'logseverity', 'logsource', 'strlen', 'band', 'abs', 'baselinedev',
        'baselinewma', 'bucket_percentile', 'bucket_rate_foreach',
        'find', 'trendavg', 'trendcount', 'trendmax', 'trendmin', 'trendsum'
    ]

    def __init__(self, url: str, username: str, password: str):
        """
        Initialize Zabbix API connection

        Args:
            url: Zabbix API URL (e.g., https://zabbix.example.com/api_jsonrpc.php)
            username: Zabbix username
            password: Zabbix password
        """
        self.url = url
        self.username = username
        self.password = password
        self.auth_token = None
        self.request_id = 1

    def authenticate(self) -> bool:
        """
        Authenticate with Zabbix API

        Returns:
            True if authentication successful, False otherwise
        """
        payload = {
            "jsonrpc": "2.0",
            "method": "user.login",
            "params": {
                "username": self.username,
                "password": self.password
            },
            "id": self.request_id,
        }

        try:
            response = requests.post(self.url, json=payload, timeout=30)
            response.raise_for_status()
            result = response.json()

            if "result" in result:
                self.auth_token = result["result"]
                self.request_id += 1
                print("[OK] Successfully authenticated with Zabbix API")
                return True
            elif "error" in result:
                print(f"[ERROR] Authentication failed: {result['error']['data']}")
                return False

        except requests.exceptions.RequestException as e:
            print(f"[ERROR] Connection error: {e}")
            return False

        return False

    def _api_call(self, method: str, params: Dict = None) -> Optional[Dict]:
        """
        Make an API call to Zabbix

        Args:
            method: API method name
            params: Method parameters

        Returns:
            API response result or None on error
        """
        if not self.auth_token:
            print("[ERROR] Not authenticated. Call authenticate() first.")
            return None

        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params or {},
            "auth": self.auth_token,
            "id": self.request_id,
        }

        try:
            response = requests.post(self.url, json=payload, timeout=30)
            response.raise_for_status()
            result = response.json()
            self.request_id += 1

            if "result" in result:
                return result["result"]
            elif "error" in result:
                error_msg = result["error"].get("data", result["error"].get("message", "Unknown error"))
                print(f"[ERROR] API Error: {error_msg}")
                return None

        except requests.exceptions.RequestException as e:
            print(f"[ERROR] API request failed: {e}")
            return None

        return None

    def validate_expression(self, expression: str) -> Tuple[bool, str]:
        """
        Validate trigger expression syntax

        Args:
            expression: Trigger expression to validate

        Returns:
            Tuple of (is_valid, error_message)
        """
        if not expression:
            return False, "Expression cannot be empty"

        # Check for balanced parentheses
        if expression.count('(') != expression.count(')'):
            return False, "Unbalanced parentheses in expression"

        # Check for at least one function call
        has_function = any(func in expression for func in self.TRIGGER_FUNCTIONS)
        if not has_function:
            return False, f"Expression must contain at least one trigger function. Supported: {', '.join(self.TRIGGER_FUNCTIONS[:10])}..."

        # Check for valid item reference format: /host/item.key
        item_pattern = r'/[^/]+/[^/,)>\s]+'
        if not re.search(item_pattern, expression):
            return False, "Expression must contain valid item reference format: /host/item.key"

        # Check for valid operators
        invalid_chars = ['#', '$', '@', '^', '~', '`']
        for char in invalid_chars:
            if char in expression:
                return False, f"Invalid character '{char}' in expression"

        return True, "Expression syntax valid"

    def get_severity_value(self, severity: str) -> int:
        """
        Convert severity name to numeric value

        Args:
            severity: Severity name (e.g., "Average", "High")

        Returns:
            Numeric severity value
        """
        severity_map = {
            "not classified": 0,
            "information": 1,
            "warning": 2,
            "average": 3,
            "high": 4,
            "disaster": 5
        }
        return severity_map.get(severity.lower(), 3)

    def get_host_id(self, host_name: str) -> Optional[str]:
        """
        Get host ID by hostname

        Args:
            host_name: Name of the host

        Returns:
            Host ID or None if not found
        """
        params = {
            "output": ["hostid"],
            "filter": {"host": [host_name]}
        }

        result = self._api_call("host.get", params)
        if result and len(result) > 0:
            return result[0]["hostid"]

        print(f"[ERROR] Host not found: {host_name}")
        return None

    def get_item_id(self, host_name: str, item_key: str) -> Optional[str]:
        """
        Get item ID by hostname and item key

        Args:
            host_name: Name of the host
            item_key: Item key

        Returns:
            Item ID or None if not found
        """
        host_id = self.get_host_id(host_name)
        if not host_id:
            return None

        params = {
            "output": ["itemid"],
            "hostids": host_id,
            "filter": {"key_": [item_key]}
        }

        result = self._api_call("item.get", params)
        if result and len(result) > 0:
            return result[0]["itemid"]

        print(f"[ERROR] Item not found: {item_key} on host {host_name}")
        return None

    def create_trigger(self, config: TriggerConfig) -> Optional[str]:
        """
        Create a new trigger

        Args:
            config: Trigger configuration

        Returns:
            Trigger ID or None on failure
        """
        # Validate expression
        is_valid, error_msg = self.validate_expression(config.expression)
        if not is_valid:
            print(f"[ERROR] Invalid expression: {error_msg}")
            return None

        print(f"Creating trigger: {config.name}")

        # Build trigger parameters
        params = {
            "description": config.name,
            "expression": config.expression,
            "priority": self.get_severity_value(config.severity),
            "comments": config.description or config.comments,
            "status": TriggerStatus.ENABLED.value if config.enabled else TriggerStatus.DISABLED.value,
            "manual_close": 1 if config.manual_close else 0
        }

        # Add optional parameters
        if config.recovery_expression:
            params["recovery_mode"] = 1  # Recovery expression mode
            params["recovery_expression"] = config.recovery_expression

        if config.event_name:
            params["event_name"] = config.event_name

        if config.operational_data:
            params["opdata"] = config.operational_data

        if config.tags:
            params["tags"] = config.tags

        if config.dependencies:
            params["dependencies"] = [{"triggerid": dep_id} for dep_id in config.dependencies]

        result = self._api_call("trigger.create", params)

        if result and "triggerids" in result:
            trigger_id = result["triggerids"][0]
            print(f"[OK] Trigger created successfully (ID: {trigger_id})")
            return trigger_id

        return None

    def update_trigger(self, trigger_id: str, config: TriggerConfig) -> bool:
        """
        Update an existing trigger

        Args:
            trigger_id: ID of trigger to update
            config: New trigger configuration

        Returns:
            True if successful, False otherwise
        """
        print(f"Updating trigger ID: {trigger_id}")

        # Build update parameters
        params = {
            "triggerid": trigger_id,
            "description": config.name,
            "expression": config.expression,
            "priority": self.get_severity_value(config.severity),
            "comments": config.description or config.comments,
            "status": TriggerStatus.ENABLED.value if config.enabled else TriggerStatus.DISABLED.value
        }

        # Add optional parameters
        if config.recovery_expression:
            params["recovery_mode"] = 1
            params["recovery_expression"] = config.recovery_expression

        if config.tags:
            params["tags"] = config.tags

        result = self._api_call("trigger.update", params)

        if result:
            print(f"[OK] Trigger updated successfully")
            return True

        return False

    def delete_trigger(self, trigger_id: str, force: bool = False) -> bool:
        """
        Delete a trigger

        Args:
            trigger_id: ID of trigger to delete
            force: Skip safety checks if True

        Returns:
            True if successful, False otherwise
        """
        if not force:
            # Safety check: get trigger details
            trigger = self.get_trigger(trigger_id)
            if not trigger:
                print(f"[ERROR] Trigger {trigger_id} not found")
                return False

            print(f"[WARN] WARNING: About to delete trigger: {trigger.get('description', 'Unknown')}")
            confirm = input("Type 'DELETE' to confirm: ")
            if confirm != "DELETE":
                print("[ERROR] Deletion cancelled")
                return False

        print(f"Deleting trigger ID: {trigger_id}")
        result = self._api_call("trigger.delete", [trigger_id])

        if result:
            print(f"[OK] Trigger deleted successfully")
            return True

        return False

    def get_trigger(self, trigger_id: str) -> Optional[Dict]:
        """
        Get trigger details

        Args:
            trigger_id: Trigger ID

        Returns:
            Trigger details or None if not found
        """
        params = {
            "output": "extend",
            "triggerids": trigger_id,
            "selectTags": "extend",
            "selectDependencies": "extend"
        }

        result = self._api_call("trigger.get", params)

        if result and len(result) > 0:
            return result[0]

        return None

    def list_triggers(self, host_name: Optional[str] = None,
                     severity: Optional[str] = None,
                     enabled_only: bool = False) -> List[Dict]:
        """
        List triggers with optional filtering

        Args:
            host_name: Filter by hostname
            severity: Filter by severity
            enabled_only: Show only enabled triggers

        Returns:
            List of triggers
        """
        params = {
            "output": ["triggerid", "description", "expression", "priority", "status"],
            "selectHosts": ["host"],
            "selectTags": "extend"
        }

        if host_name:
            host_id = self.get_host_id(host_name)
            if host_id:
                params["hostids"] = host_id

        if severity:
            params["filter"] = {"priority": self.get_severity_value(severity)}

        if enabled_only:
            params["filter"] = params.get("filter", {})
            params["filter"]["status"] = TriggerStatus.ENABLED.value

        result = self._api_call("trigger.get", params)
        return result or []

    def enable_trigger(self, trigger_id: str) -> bool:
        """Enable a trigger"""
        return self.update_trigger_status(trigger_id, True)

    def disable_trigger(self, trigger_id: str) -> bool:
        """Disable a trigger"""
        return self.update_trigger_status(trigger_id, False)

    def update_trigger_status(self, trigger_id: str, enabled: bool) -> bool:
        """
        Update trigger enabled/disabled status

        Args:
            trigger_id: Trigger ID
            enabled: True to enable, False to disable

        Returns:
            True if successful
        """
        status = TriggerStatus.ENABLED.value if enabled else TriggerStatus.DISABLED.value
        params = {
            "triggerid": trigger_id,
            "status": status
        }

        result = self._api_call("trigger.update", params)

        if result:
            status_text = "enabled" if enabled else "disabled"
            print(f"[OK] Trigger {status_text} successfully")
            return True

        return False

    def bulk_create_triggers(self, configs: List[TriggerConfig]) -> Dict[str, List]:
        """
        Create multiple triggers

        Args:
            configs: List of trigger configurations

        Returns:
            Dict with 'successful' and 'failed' lists
        """
        results = {"successful": [], "failed": []}

        for i, config in enumerate(configs, 1):
            print(f"\n[{i}/{len(configs)}] Processing: {config.name}")
            trigger_id = self.create_trigger(config)

            if trigger_id:
                results["successful"].append({
                    "name": config.name,
                    "id": trigger_id
                })
            else:
                results["failed"].append({
                    "name": config.name,
                    "error": "Creation failed"
                })

        print(f"\n[OK] Successfully created: {len(results['successful'])}")
        print(f"[ERROR] Failed: {len(results['failed'])}")

        return results

    def test_expression(self, expression: str, host_name: str, test_value: Any) -> Optional[bool]:
        """
        Test a trigger expression with a sample value

        Args:
            expression: Trigger expression
            host_name: Host name
            test_value: Value to test with

        Returns:
            True if expression would fire, False if not, None on error
        """
        is_valid, error_msg = self.validate_expression(expression)
        if not is_valid:
            print(f"[ERROR] Invalid expression: {error_msg}")
            return None

        print(f"Testing expression: {expression}")
        print(f"Test value: {test_value}")

        # Note: Zabbix doesn't have a direct expression test API
        # This provides syntax validation only
        print("[OK] Expression syntax is valid")
        print("ℹ Deploy to test environment for functional testing")

        return None


def load_config_file(file_path: str) -> Dict:
    """Load configuration from JSON or YAML file"""
    with open(file_path, 'r') as f:
        if file_path.endswith('.json'):
            return json.load(f)
        elif file_path.endswith(('.yaml', '.yml')):
            return yaml.safe_load(f)
        else:
            raise ValueError("Unsupported file format. Use .json, .yaml, or .yml")


def main():
    """Main execution function"""
    parser = argparse.ArgumentParser(
        description="Zabbix Trigger Manager - Comprehensive trigger management via API"
    )

    parser.add_argument("--url", required=True, help="Zabbix API URL")
    parser.add_argument("--username", required=True, help="Zabbix username")
    parser.add_argument("--password", required=True, help="Zabbix password")

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Create trigger
    create_parser = subparsers.add_parser("create", help="Create a new trigger")
    create_parser.add_argument("--name", required=True, help="Trigger name")
    create_parser.add_argument("--expression", required=True, help="Trigger expression")
    create_parser.add_argument("--severity", required=True,
                              choices=["not classified", "information", "warning", "average", "high", "disaster"],
                              help="Trigger severity")
    create_parser.add_argument("--description", default="", help="Trigger description")
    create_parser.add_argument("--recovery-expression", default="", help="Recovery expression")
    create_parser.add_argument("--disabled", action="store_true", help="Create trigger disabled")

    # Update trigger
    update_parser = subparsers.add_parser("update", help="Update a trigger")
    update_parser.add_argument("--id", required=True, help="Trigger ID")
    update_parser.add_argument("--name", help="New trigger name")
    update_parser.add_argument("--expression", help="New trigger expression")
    update_parser.add_argument("--severity",
                              choices=["not classified", "information", "warning", "average", "high", "disaster"],
                              help="New trigger severity")

    # Delete trigger
    delete_parser = subparsers.add_parser("delete", help="Delete a trigger")
    delete_parser.add_argument("--id", required=True, help="Trigger ID")
    delete_parser.add_argument("--force", action="store_true", help="Skip confirmation")

    # List triggers
    list_parser = subparsers.add_parser("list", help="List triggers")
    list_parser.add_argument("--host", help="Filter by hostname")
    list_parser.add_argument("--severity", help="Filter by severity")
    list_parser.add_argument("--enabled-only", action="store_true", help="Show only enabled triggers")

    # Enable/disable trigger
    enable_parser = subparsers.add_parser("enable", help="Enable a trigger")
    enable_parser.add_argument("--id", required=True, help="Trigger ID")

    disable_parser = subparsers.add_parser("disable", help="Disable a trigger")
    disable_parser.add_argument("--id", required=True, help="Trigger ID")

    # Bulk create
    bulk_parser = subparsers.add_parser("bulk-create", help="Create multiple triggers from config file")
    bulk_parser.add_argument("--config", required=True, help="Path to config file (JSON or YAML)")

    # Test expression
    test_parser = subparsers.add_parser("test", help="Test trigger expression")
    test_parser.add_argument("--expression", required=True, help="Trigger expression")
    test_parser.add_argument("--host", required=True, help="Host name")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    # Initialize manager and authenticate
    manager = ZabbixTriggerManager(args.url, args.username, args.password)
    if not manager.authenticate():
        return 1

    # Execute command
    if args.command == "create":
        config = TriggerConfig(
            name=args.name,
            expression=args.expression,
            severity=args.severity,
            description=args.description,
            recovery_expression=args.recovery_expression,
            enabled=not args.disabled
        )
        manager.create_trigger(config)

    elif args.command == "update":
        trigger = manager.get_trigger(args.id)
        if not trigger:
            return 1

        config = TriggerConfig(
            name=args.name or trigger["description"],
            expression=args.expression or trigger["expression"],
            severity=args.severity or str(trigger["priority"]),
            description=trigger.get("comments", "")
        )
        manager.update_trigger(args.id, config)

    elif args.command == "delete":
        manager.delete_trigger(args.id, args.force)

    elif args.command == "list":
        triggers = manager.list_triggers(args.host, args.severity, args.enabled_only)
        print(f"\nFound {len(triggers)} trigger(s):")
        for trigger in triggers:
            host = trigger["hosts"][0]["host"] if trigger.get("hosts") else "Unknown"
            print(f"\nID: {trigger['triggerid']}")
            print(f"  Name: {trigger['description']}")
            print(f"  Host: {host}")
            print(f"  Severity: {trigger['priority']}")
            print(f"  Status: {'Enabled' if trigger['status'] == '0' else 'Disabled'}")

    elif args.command == "enable":
        manager.enable_trigger(args.id)

    elif args.command == "disable":
        manager.disable_trigger(args.id)

    elif args.command == "bulk-create":
        config_data = load_config_file(args.config)
        configs = []

        for trigger_data in config_data.get("triggers", []):
            config = TriggerConfig(
                name=trigger_data["name"],
                expression=trigger_data["expression"],
                severity=trigger_data.get("severity", "average"),
                description=trigger_data.get("description", ""),
                recovery_expression=trigger_data.get("recovery_expression", ""),
                tags=trigger_data.get("tags", []),
                enabled=trigger_data.get("enabled", True)
            )
            configs.append(config)

        manager.bulk_create_triggers(configs)

    elif args.command == "test":
        manager.test_expression(args.expression, args.host, None)

    return 0


if __name__ == "__main__":
    sys.exit(main())
