# Dashboards & Visualizations in Zabbix

Complete toolkit for creating and managing Zabbix dashboards with 30+ widget types, templates, and automation scripts.

## Quick Start

### 1. Set Up Environment

```bash
# Install dependencies
pip install pyzabbix pyyaml

# Set environment variables
export ZABBIX_URL="https://zabbix.example.com"
export ZABBIX_TOKEN="your-api-token"
```

### 2. Create Your First Dashboard

```bash
# Create a basic dashboard
python scripts/zabbix_dashboard_manager.py \
  --url $ZABBIX_URL \
  --token $ZABBIX_TOKEN \
  create \
  --name "My Dashboard" \
  --owner "Admin"
```

### 3. Add Widgets

```bash
# Add problems widget
python scripts/zabbix_widget_builder.py \
  --url $ZABBIX_URL \
  --token $ZABBIX_TOKEN \
  add \
  --dashboard-id 10 \
  --widget-type problems \
  --name "Active Problems" \
  --position '{"x":0,"y":0,"width":36,"height":8}'
```

### 4. Deploy from Template

```bash
# Deploy executive dashboard
python scripts/dashboard_template_creator.py \
  --url $ZABBIX_URL \
  --token $ZABBIX_TOKEN \
  deploy \
  --template templates/executive_dashboard.json \
  --dashboard-name "Executive Dashboard"
```

## What's Included

### Scripts (7 production-ready tools)

- **zabbix_dashboard_manager.py** - Create, update, delete, clone, share dashboards
- **zabbix_widget_builder.py** - Add and configure widgets with validation
- **dashboard_template_creator.py** - Deploy from templates with variable substitution
- **graph_visualizer.py** - Create graph widgets with styling
- **map_builder.py** - Build network topology maps
- **dashboard_exporter.py** - Export/import for backup and migration
- **validate_dashboard_config.py** - Validate configurations before deployment

### Templates (6 ready-to-deploy)

- **executive_dashboard.json** - High-level KPIs for leadership
- **infrastructure_dashboard.yaml** - Server and network health
- **application_dashboard.json** - Application performance monitoring
- **noc_dashboard.yaml** - 24/7 NOC monitoring display
- **sla_dashboard.json** - Service level agreement reporting
- **security_dashboard.yaml** - Security events and compliance

### Examples (Complete configurations)

- **widget_configs.json** - All 30+ widget types with field documentation
- **graph_examples.yaml** - Graph styles (line, stacked, bar, pie, gauge)
- **kiosk_dashboard.yaml** - Kiosk mode best practices and layouts

## Common Tasks

### Create Executive Dashboard

```bash
# 1. Create dashboard with 2 pages
python scripts/zabbix_dashboard_manager.py \
  --url $ZABBIX_URL --token $ZABBIX_TOKEN \
  create \
  --name "Executive Dashboard" \
  --owner "Admin" \
  --pages 2 \
  --auto-slideshow

# 2. Add KPI widgets
python scripts/zabbix_widget_builder.py \
  --url $ZABBIX_URL --token $ZABBIX_TOKEN \
  add \
  --dashboard-id 10 \
  --widget-type item \
  --name "Total Hosts" \
  --position '{"x":0,"y":0,"width":12,"height":4}' \
  --config '{"itemid":"12345","show_description":true}'

# 3. Add problems by severity
python scripts/zabbix_widget_builder.py \
  --url $ZABBIX_URL --token $ZABBIX_TOKEN \
  add \
  --dashboard-id 10 \
  --widget-type problemsbysv \
  --name "Problems by Severity" \
  --position '{"x":12,"y":0,"width":24,"height":8}'

# 4. Share with executives
python scripts/zabbix_dashboard_manager.py \
  --url $ZABBIX_URL --token $ZABBIX_TOKEN \
  share \
  --dashboard-id 10 \
  --type public
```

### Create NOC Display

```bash
# Deploy NOC template
python scripts/dashboard_template_creator.py \
  --url $ZABBIX_URL --token $ZABBIX_TOKEN \
  deploy \
  --template templates/noc_dashboard.yaml \
  --dashboard-name "NOC Display"

# Access in kiosk mode
# https://zabbix.example.com/zabbix.php?action=dashboard.view&dashboardid=10&kiosk=1&slideshow=1
```

### Create Infrastructure Dashboard

```bash
# Deploy with host group variable
python scripts/dashboard_template_creator.py \
  --url $ZABBIX_URL --token $ZABBIX_TOKEN \
  deploy \
  --template templates/infrastructure_dashboard.yaml \
  --dashboard-name "Linux Infrastructure" \
  --variables '{"linux_servers_group":"Linux servers"}'
```

### Create Custom Graphs

```bash
# Multi-series graph
python scripts/graph_visualizer.py \
  --url $ZABBIX_URL --token $ZABBIX_TOKEN \
  create \
  --dashboard-id 10 \
  --name "Network Traffic" \
  --items "Traffic In:Router1:net.if.in[eth0],Traffic Out:Router1:net.if.out[eth0]" \
  --graph-type stacked \
  --position '{"x":0,"y":8,"width":36,"height":8}'
```

### Backup and Restore

```bash
# Export dashboard
python scripts/dashboard_exporter.py \
  --url $ZABBIX_URL --token $ZABBIX_TOKEN \
  export \
  --dashboard-id 10 \
  --output backups/dashboard_backup.json

# Import to different Zabbix
python scripts/dashboard_exporter.py \
  --url $ZABBIX_URL2 --token $ZABBIX_TOKEN2 \
  import \
  --input backups/dashboard_backup.json \
  --dashboard-name "Restored Dashboard"
```

### Validate Configuration

```bash
# Validate before deployment
python scripts/validate_dashboard_config.py \
  --config templates/my_dashboard.json \
  --strict
```

## Widget Types Reference

### Monitoring & Problems
- **problems** - Active problems with filtering
- **problemsbysv** - Problems by severity
- **problemhosts** - Hosts with problems
- **trigover** - Trigger overview grid

### Data Visualization
- **graph** - Modern SVG graphs
- **graphclassic** - Classic graphs
- **gauge** - Single value gauge
- **piechart** - Pie chart
- **honeycomb** - Hexagonal display

### Maps
- **map** - Network topology
- **geomap** - Geographic distribution
- **navtree** - Map navigation tree

### Information
- **item** - Single item value
- **itemcard** - Item details
- **itemhistory** - Value history
- **hostcard** - Host details
- **hostavail** - Host availability

### Top Lists
- **tophosts** - Top hosts by metric
- **topitems** - Top items by value
- **toptriggers** - Most frequent triggers

### Reports & System
- **slareport** - SLA reporting
- **systeminfo** - System information
- **actionlog** - Action execution log
- **web** - Web monitoring

### Navigation
- **hostnavigator** - Browse hosts
- **itemnavigator** - Browse items
- **favgraphs** - Favorite graphs
- **favmaps** - Favorite maps

### Utilities
- **clock** - Time display
- **url** - External content
- **discovery** - Discovery status

## Dashboard Grid System

- **Width**: 72 columns (minimum 1200px)
- **Height**: 64 rows (70px per row)
- **Position**: x (0-71), y (0-63)
- **Size**: width (1-72), height (1-64)

### Common Widget Sizes

```
Small KPI: 12x4
Medium widget: 24x8
Large graph: 36x8
Full width: 72x12
Map: 36x16
```

## Best Practices

### Dashboard Design
- Group related widgets logically
- Use consistent color scheme
- Limit to 20-30 widgets per page
- Test on target display hardware
- Plan for different screen sizes

### Performance
- Optimize refresh intervals
- Filter data appropriately
- Avoid excessive widgets
- Monitor API load
- Test with production data

### Kiosk Mode
- Hide widget headers
- Use high contrast colors
- Large fonts readable from distance
- Auto-rotate pages (30-60s)
- Test extended operation

### Security
- Use appropriate permissions
- Create read-only kiosk users
- Share dashboards carefully
- Audit dashboard access
- Regular permission reviews

## Troubleshooting

### Widget Not Showing Data
```bash
# Check permissions
# Verify host/item access
# Review filter criteria
# Check time period settings
```

### Layout Issues
```bash
# Validate positions don't overlap
python scripts/validate_dashboard_config.py --config dashboard.json

# Check grid bounds (x: 0-71, y: 0-63)
# Test on target resolution
```

### Performance Problems
```bash
# Reduce widget count
# Increase refresh intervals
# Optimize filters
# Check network latency
```

## Advanced Usage

### Template Variables

Create reusable templates with variables:

```json
{
  "host_references": {
    "web_server": "Web-Server-01"
  },
  "item_references": {
    "cpu_item": "Web-Server-01:system.cpu.load"
  }
}
```

Deploy with different values:

```bash
python scripts/dashboard_template_creator.py deploy \
  --template template.json \
  --variables '{"web_server":"Web-Server-02"}'
```

### Dynamic Widget Linking

Link widgets for drill-down:

```yaml
# Host navigator broadcasts host selection
- type: "hostnavigator"
  name: "Select Host"

# Graph widget listens for host
- type: "graph"
  fields:
    - type: "1"
      name: "reference"
      value: "DASHBOARD"  # Listen to dashboard host selector
```

### Multi-Tenant Dashboards

Create separate dashboards per tenant:

```bash
# Create tenant dashboard
python scripts/zabbix_dashboard_manager.py create \
  --name "Tenant A Dashboard" \
  --owner "tenant_a_admin" \
  --private

# Share with tenant group only
python scripts/zabbix_dashboard_manager.py share \
  --dashboard-id 10 \
  --type private \
  --user-groups '[{"name":"Tenant_A_Users","permission":"read"}]'
```

## API Reference

All scripts use the Zabbix API. Key methods:

```python
# Dashboard operations
dashboard.create(params)
dashboard.update(params)
dashboard.delete([ids])
dashboard.get(params)

# Widget configuration in dashboard pages
{
  "pages": [{
    "widgets": [{
      "type": "problems",
      "x": 0, "y": 0,
      "width": 36, "height": 8,
      "fields": [...]
    }]
  }]
}
```

## Support

- **Documentation**: See SKILL.md for complete reference
- **Examples**: Check examples/ directory for patterns
- **Templates**: Use templates/ for quick deployment
- **Zabbix Docs**: zabbix-docs-masters/zabbix-docs/18_Web_Interface/

## License

Part of the Zabbix Skills collection for automation and orchestration.
