---
name: dashboards-visualizations
description: Automates Zabbix dashboard creation and management including designing custom dashboards, configuring 30+ widget types (graphs, maps, problem displays, gauges, geomaps), creating data visualizations, managing dashboard templates, implementing role-based dashboard views, and exporting/importing dashboard configurations through the Zabbix API. Use when building executive dashboards, NOC/SOC monitoring displays, infrastructure overviews, SLA reports, kiosk displays, or any custom visualization needs in Zabbix.
version: 1.0.0
skills_category: zabbix-monitoring
tags:
  - zabbix
  - dashboards
  - visualizations
  - widgets
  - graphs
  - maps
  - monitoring
  - kiosk-mode
  - sla-reports
---

# Dashboards & Visualizations in Zabbix

Automate the creation and management of Zabbix dashboards with comprehensive widget configuration, visualization design, and template-based deployment.

## Quick Start

### Create a Basic Dashboard

```python
# Use the dashboard manager script
python scripts/zabbix_dashboard_manager.py create \
  --name "Infrastructure Overview" \
  --owner "Admin"
```

### Add Widgets to Dashboard

```python
# Use the widget builder
python scripts/zabbix_widget_builder.py add \
  --dashboard-id 10 \
  --widget-type "problems" \
  --name "Active Problems" \
  --position '{"x": 0, "y": 0, "width": 12, "height": 5}'
```

### Deploy from Template

```python
# Use template creator
python scripts/dashboard_template_creator.py deploy \
  --template templates/executive_dashboard.json \
  --dashboard-name "Executive Dashboard"
```

## Core Capabilities

### Dashboard Management
- Create multi-page dashboards with custom layouts
- Configure slideshow rotation and timing
- Set dashboard permissions (public/private)
- Share dashboards with user groups
- Clone and export dashboards
- Manage dashboard templates

### Widget Types (30+ Supported)

**Monitoring & Problems:**
- Problems - Display active problems with filtering
- Problems by severity - Severity-based problem view
- Problem hosts - Hosts with active problems
- Trigger overview - Grid of trigger states

**Data Visualization:**
- Graph - Modern SVG graphs with drill-down
- Graph (classic) - Traditional graph visualization
- Graph prototype - Graphs from LLD prototypes
- Pie chart - Proportional data display
- Gauge - Single value with thresholds
- Honeycomb - Hexagonal host/item display

**Maps & Navigation:**
- Map - Network topology visualization
- Geomap - Geographic host distribution
- Map navigation tree - Hierarchical map navigation
- Host navigator - Browse host hierarchy
- Item navigator - Browse item hierarchy

**Information Display:**
- Item value - Display single item values
- Item card - Detailed item information
- Item history - Item value history table
- Host card - Detailed host information
- Host availability - Agent/SNMP/IPMI status
- Top hosts - Ranked host metrics
- Top items - Ranked item values
- Top triggers - Most frequent triggers

**Reports & System:**
- SLA report - Service level reporting
- System information - Zabbix system status
- Action log - Recent action execution
- Discovery status - Network discovery status
- Web monitoring - Web scenario status
- Clock - Time display with timezone support

**Favorites & Utilities:**
- Favorite graphs - Quick access to graphs
- Favorite maps - Quick access to maps
- URL - Embed external content

### Visualization Features

**Graph Types:**
- Line charts (normal, stacked, gradient)
- Area charts (filled, stacked)
- Bar charts
- Pie charts with percentage/value labels
- Gauge displays with color thresholds
- Single value displays with units

**Map Features:**
- Network topology with auto-layout
- Custom element icons and shapes
- Link status indicators
- Geographic coordinates (Geomap)
- Heat map overlays
- Drill-down to host details

**Layout & Design:**
- 72-column grid system (minimum 1200px)
- Up to 64 rows (70px each)
- Drag-and-drop positioning
- Auto-fit and responsive sizing
- Widget header show/hide
- Custom refresh intervals

### Dynamic Data Sharing

**Widget Communication:**
- Host selection broadcasting
- Time period synchronization
- Item filtering cascades
- Host group propagation
- Map element selection

**Dashboard Variables:**
- Dynamic host selection at dashboard level
- Global time period selector
- Tag-based filtering
- Template variable substitution

### Use Cases

Refer to examples/ for complete implementations:
- [Executive Dashboard](examples/executive_dashboard_walkthrough.md) - High-level KPIs for leadership
- [NOC Display](examples/noc_dashboard.yaml) - 24/7 monitoring display
- [Infrastructure Overview](examples/infrastructure_overview.md) - Server/network health
- [Application Performance](examples/application_dashboard.json) - APM metrics
- [Security Dashboard](examples/security_dashboard.yaml) - Security events and compliance
- [SLA Reports](examples/sla_dashboard.json) - Service level reporting
- [Kiosk Mode](examples/kiosk_dashboard.yaml) - Full-screen displays

## Scripts

All scripts include comprehensive error handling and validation:

- **zabbix_dashboard_manager.py** - CRUD operations for dashboards
- **zabbix_widget_builder.py** - Widget configuration and placement
- **dashboard_template_creator.py** - Template-based dashboard generation
- **graph_visualizer.py** - Graph creation and styling
- **map_builder.py** - Network map creation and layout
- **dashboard_exporter.py** - Export/import dashboard configurations
- **validate_dashboard_config.py** - Validate dashboard JSON/YAML

## API Methods

### Dashboard Operations
```python
# Create dashboard
dashboard.create({
    "name": "My Dashboard",
    "owner": {"userid": "1"},
    "pages": [...]
})

# Update dashboard
dashboard.update({
    "dashboardid": "10",
    "name": "Updated Dashboard"
})

# Get dashboards
dashboard.get({
    "output": "extend",
    "selectPages": "extend",
    "selectUsers": "extend",
    "selectUserGroups": "extend"
})

# Delete dashboard
dashboard.delete(["10", "11"])
```

### Widget Configuration

Each widget type has specific parameters. Reference [Widget Configuration Guide](examples/widget_configs.json) for complete specifications.

**Common Widget Structure:**
```json
{
  "type": "problems",
  "name": "Active Problems",
  "x": 0,
  "y": 0,
  "width": 12,
  "height": 5,
  "view_mode": 0,
  "fields": [
    {
      "type": "INTEGER",
      "name": "show_tags",
      "value": 3
    }
  ]
}
```

### Positioning System

Dashboard uses a grid layout:
- Width: 72 columns (minimum 1200px total)
- Height: 64 rows maximum (70px per row)
- Position: x (0-71), y (0-63)
- Size: width (1-72), height (1-64)

## Workflow Example

### Building an Executive Dashboard

1. **Create Dashboard Structure**
```python
python scripts/zabbix_dashboard_manager.py create \
  --name "Executive Dashboard" \
  --pages 3 \
  --auto-slideshow
```

2. **Add KPI Widgets**
```python
python scripts/zabbix_widget_builder.py add \
  --dashboard-id 10 \
  --widget-type "item_value" \
  --name "Total Servers" \
  --item "Number of hosts" \
  --position '{"x": 0, "y": 0, "width": 12, "height": 3}'
```

3. **Add Problem Overview**
```python
python scripts/zabbix_widget_builder.py add \
  --dashboard-id 10 \
  --widget-type "problems_severity" \
  --name "Problems by Severity" \
  --position '{"x": 12, "y": 0, "width": 24, "height": 5}'
```

4. **Add Graphs**
```python
python scripts/graph_visualizer.py create \
  --dashboard-id 10 \
  --name "Network Traffic" \
  --items "net.if.in[eth0],net.if.out[eth0]" \
  --graph-type "stacked" \
  --position '{"x": 0, "y": 5, "width": 36, "height": 8}'
```

5. **Configure Permissions**
```python
python scripts/zabbix_dashboard_manager.py share \
  --dashboard-id 10 \
  --type "public" \
  --user-groups "Executives:read"
```

6. **Export Template**
```python
python scripts/dashboard_exporter.py export \
  --dashboard-id 10 \
  --output templates/executive_dashboard.json
```

## Best Practices

### Dashboard Design
- **Group related widgets** - Logical organization improves usability
- **Use consistent colors** - Match severity colors (red=critical, yellow=warning)
- **Optimize refresh rates** - Balance freshness vs. performance
- **Limit page count** - 3-5 pages maximum for slideshow
- **Test permissions** - Verify visibility for target users
- **Plan for screen sizes** - Test on actual display hardware

### Widget Configuration
- **Show headers selectively** - Hide headers on dense dashboards
- **Use dynamic parameters** - Link widgets for drill-down capability
- **Configure time periods** - Match widget refresh to data frequency
- **Add appropriate filters** - Host groups, tags, severity
- **Optimize data queries** - Limit items/hosts in complex widgets

### Performance
- **Avoid excessive widgets** - Limit to 20-30 widgets per page
- **Use appropriate refresh rates** - Not all data needs 1-minute refresh
- **Filter data appropriately** - Don't fetch unnecessary hosts/items
- **Test with production data** - Ensure queries perform at scale
- **Monitor API load** - Dashboard refreshes create API calls

### Kiosk Mode
- **Full-screen optimization** - Design for actual display resolution
- **Auto-rotate pages** - Set appropriate timing (30-60 seconds)
- **High contrast** - Ensure visibility from distance
- **Large fonts** - Readable from 10+ feet
- **Minimal interaction** - Kiosk should be view-only
- **Auto-refresh reliability** - Test extended operation

## Troubleshooting

### Widget Not Displaying Data
- Verify host/item permissions for dashboard owner
- Check filter criteria (host groups, tags)
- Confirm data exists for selected time period
- Review API permissions for dashboard user

### Layout Issues
- Ensure widget positions don't overlap
- Verify coordinates within grid bounds (x: 0-71, y: 0-63)
- Check total dashboard width (min 1200px)
- Test on target display resolution

### Performance Problems
- Reduce widget count per page
- Increase refresh intervals
- Optimize host/item filters
- Check database query performance
- Review Zabbix server load

### Permission Errors
- Verify dashboard sharing configuration
- Check user group permissions
- Confirm host access for user
- Review dashboard ownership

## Templates

Production-ready templates in templates/:
- **executive_dashboard.json** - C-level overview with KPIs
- **infrastructure_dashboard.yaml** - Server and network health
- **application_dashboard.json** - Application performance monitoring
- **noc_dashboard.yaml** - Network operations center display
- **sla_dashboard.json** - Service level agreement reporting
- **security_dashboard.yaml** - Security monitoring and events

## Examples

Complete examples in examples/:
- **widget_configs.json** - Configuration for all 30+ widget types
- **graph_examples.yaml** - Graph styles and configurations
- **map_examples.json** - Network map layouts
- **kiosk_dashboard.yaml** - Kiosk mode best practices
- **mobile_dashboard.json** - Mobile-optimized layouts
- **drill_down_dashboard.yaml** - Interactive drill-down patterns

## Reference Documentation

Complete Zabbix documentation:
- Dashboard fundamentals: zabbix-docs-masters/zabbix-docs/18_Web_Interface/1_dashboards.md
- Widget reference: zabbix-docs-masters/zabbix-docs/18_Web_Interface/1_widgets.md
- Individual widget docs: zabbix-docs-masters/zabbix-docs/18_Web_Interface/[widget_name].md
- API reference: https://www.zabbix.com/documentation/current/en/manual/api

## Common Patterns

### Multi-Tenant Dashboards
Share different dashboards with different user groups, each seeing only their hosts:
```python
# Create tenant-specific dashboard
python scripts/zabbix_dashboard_manager.py create \
  --name "Tenant A - Infrastructure" \
  --owner "tenant_a_admin"

# Share with tenant user group
python scripts/zabbix_dashboard_manager.py share \
  --dashboard-id 10 \
  --type "private" \
  --user-groups "Tenant_A_Users:read"
```

### Drill-Down Dashboards
Link widgets for progressive detail exploration:
```yaml
# Top-level: Problems by severity widget
# Click severity -> filters Problem hosts widget
# Click host -> opens Host card widget
# See examples/drill_down_dashboard.yaml
```

### Time Period Sync
Synchronize multiple graph widgets to same time period:
```python
# Set dashboard time period selector
python scripts/zabbix_widget_builder.py add \
  --widget-type "graph" \
  --time-period "dashboard"  # Links to dashboard time selector
```

### Template Variables
Use dashboard-level host selection:
```python
# Configure widget with dashboard host variable
python scripts/zabbix_widget_builder.py add \
  --widget-type "graph" \
  --override-host "dashboard"  # Links to dashboard host selector
```
