#!/usr/bin/env python3
"""
Dashboard Exporter

Export and import dashboard configurations for backup and migration.

Usage:
    python dashboard_exporter.py export --dashboard-id 10 --output backup.json
    python dashboard_exporter.py import --input backup.json --dashboard-name "Imported Dashboard"
"""

import argparse
import json
import sys
from pathlib import Path
from pyzabbix import ZabbixAPI


import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
class DashboardExporter:
    """Export/import dashboards"""

    def __init__(self, url: str, token: str):
        self.zapi = ZabbixAPI(url)
        self.zapi.login(api_token=token)

    def export_dashboard(self, dashboard_id: str, output_path: str) -> None:
        """Export dashboard to JSON"""

        dashboards = self.zapi.dashboard.get(
            dashboardids=dashboard_id,
            output="extend",
            selectPages="extend"
        )

        if not dashboards:
            raise ValueError(f"Dashboard {dashboard_id} not found")

        Path(output_path).write_text(json.dumps(dashboards[0], indent=2))
        print(f"[OK] Dashboard exported to {output_path}")

    def import_dashboard(self, input_path: str, dashboard_name: str, owner: str = "Admin") -> None:
        """Import dashboard from JSON"""

        data = json.loads(Path(input_path).read_text())

        users = self.zapi.user.get(filter={"username": owner}, output=["userid"])
        if not users:
            raise ValueError(f"User {owner} not found")

        data["name"] = dashboard_name
        data["userid"] = users[0]["userid"]

        # Remove ID fields
        data.pop("dashboardid", None)
        for page in data.get("pages", []):
            page.pop("dashboard_pageid", None)

        result = self.zapi.dashboard.create(data)
        print(f"[OK] Dashboard imported (ID: {result['dashboardids'][0]})")


def main():
    parser = argparse.ArgumentParser(description="Dashboard Exporter")
    parser.add_argument("--url", required=True)
    parser.add_argument("--token", required=True)

    subparsers = parser.add_subparsers(dest="command")

    export_parser = subparsers.add_parser("export")
    export_parser.add_argument("--dashboard-id", required=True)
    export_parser.add_argument("--output", required=True)

    import_parser = subparsers.add_parser("import")
    import_parser.add_argument("--input", required=True)
    import_parser.add_argument("--dashboard-name", required=True)
    import_parser.add_argument("--owner", default="Admin")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    try:
        exporter = DashboardExporter(args.url, args.token)

        if args.command == "export":
            exporter.export_dashboard(args.dashboard_id, args.output)
        elif args.command == "import":
            exporter.import_dashboard(args.input, args.dashboard_name, args.owner)

        return 0

    except Exception as e:
        print(f"[ERROR] Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
