#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Dashboard Template Creator

Deploy dashboards from templates with variable substitution and validation.
Supports JSON and YAML template formats.

Usage:
    # Deploy from template
    python dashboard_template_creator.py deploy \
        --template templates/executive_dashboard.json \
        --dashboard-name "Executive Dashboard"

    # Deploy with variable substitution
    python dashboard_template_creator.py deploy \
        --template templates/infrastructure_dashboard.yaml \
        --dashboard-name "Infra Dashboard" \
        --variables '{"host_group":"Linux servers"}'

    # Create template from existing dashboard
    python dashboard_template_creator.py create \
        --dashboard-id 10 \
        --output templates/my_template.json

    # Validate template
    python dashboard_template_creator.py validate \
        --template templates/executive_dashboard.json
"""

import argparse
import json
import sys
import yaml
from pathlib import Path
from typing import Dict, List, Optional, Any
from pyzabbix import ZabbixAPI, ZabbixAPIException


class DashboardTemplateCreator:
    """Create and deploy dashboard templates"""

    def __init__(self, url: str, token: str):
        """
        Initialize template creator.

        Args:
            url: Zabbix server URL
            token: API authentication token
        """
        self.zapi = ZabbixAPI(url)
        self.zapi.login(api_token=token)

    def _load_template(self, template_path: str) -> Dict[str, Any]:
        """
        Load template from file.

        Args:
            template_path: Path to template file (JSON or YAML)

        Returns:
            Template dictionary

        Raises:
            ValueError: If file not found or invalid format
        """
        path = Path(template_path)

        if not path.exists():
            raise ValueError(f"Template file not found: {template_path}")

        content = path.read_text(encoding='utf-8')

        # Try JSON first
        if path.suffix.lower() in ['.json', '.js']:
            try:
                return json.loads(content)
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid JSON template: {e}")

        # Try YAML
        elif path.suffix.lower() in ['.yaml', '.yml']:
            try:
                return yaml.safe_load(content)
            except yaml.YAMLError as e:
                raise ValueError(f"Invalid YAML template: {e}")

        else:
            raise ValueError(f"Unsupported template format: {path.suffix}")

    def _substitute_variables(
        self,
        template: Dict[str, Any],
        variables: Dict[str, str]
    ) -> Dict[str, Any]:
        """
        Substitute variables in template.

        Args:
            template: Template dictionary
            variables: Variable substitutions

        Returns:
            Template with substituted variables
        """
        template_str = json.dumps(template)

        # Replace variables in format ${variable_name}
        for key, value in variables.items():
            placeholder = f"${{{key}}}"
            template_str = template_str.replace(placeholder, value)

        return json.loads(template_str)

    def _resolve_references(self, template: Dict[str, Any]) -> Dict[str, Any]:
        """
        Resolve host/item/map references in template.

        Args:
            template: Template dictionary

        Returns:
            Template with resolved IDs

        Raises:
            ValueError: If reference cannot be resolved
        """
        # Resolve host references
        if "host_references" in template:
            host_map = {}
            for ref_name, host_name in template["host_references"].items():
                hosts = self.zapi.host.get(
                    filter={"host": host_name},
                    output=["hostid"]
                )
                if hosts:
                    host_map[f"${{{ref_name}}}"] = hosts[0]["hostid"]
                else:
                    print(f"Warning: Host '{host_name}' not found for reference '{ref_name}'")

            # Replace in template
            template_str = json.dumps(template)
            for ref, hostid in host_map.items():
                template_str = template_str.replace(ref, str(hostid))
            template = json.loads(template_str)

        # Resolve item references
        if "item_references" in template:
            item_map = {}
            for ref_name, item_key in template["item_references"].items():
                # Parse "host:key" format
                if ":" in item_key:
                    host_name, key = item_key.split(":", 1)
                    items = self.zapi.item.get(
                        filter={"key_": key},
                        host=host_name,
                        output=["itemid"]
                    )
                    if items:
                        item_map[f"${{{ref_name}}}"] = items[0]["itemid"]
                    else:
                        print(f"Warning: Item '{item_key}' not found for reference '{ref_name}'")

            template_str = json.dumps(template)
            for ref, itemid in item_map.items():
                template_str = template_str.replace(ref, str(itemid))
            template = json.loads(template_str)

        # Resolve map references
        if "map_references" in template:
            map_map = {}
            for ref_name, map_name in template["map_references"].items():
                maps = self.zapi.map.get(
                    filter={"name": map_name},
                    output=["sysmapid"]
                )
                if maps:
                    map_map[f"${{{ref_name}}}"] = maps[0]["sysmapid"]
                else:
                    print(f"Warning: Map '{map_name}' not found for reference '{ref_name}'")

            template_str = json.dumps(template)
            for ref, mapid in map_map.items():
                template_str = template_str.replace(ref, str(mapid))
            template = json.loads(template_str)

        return template

    def deploy_template(
        self,
        template_path: str,
        dashboard_name: str,
        owner_username: str = "Admin",
        variables: Optional[Dict[str, str]] = None,
        resolve_references: bool = True
    ) -> Dict[str, Any]:
        """
        Deploy dashboard from template.

        Args:
            template_path: Path to template file
            dashboard_name: Name for deployed dashboard
            owner_username: Dashboard owner username
            variables: Variable substitutions
            resolve_references: Resolve host/item/map references

        Returns:
            Dict with deployed dashboard details

        Raises:
            ValueError: If template invalid or deployment fails
            ZabbixAPIException: If API call fails
        """
        # Load template
        template = self._load_template(template_path)

        # Validate template structure
        if "dashboard" not in template:
            raise ValueError("Template missing 'dashboard' section")

        dashboard_template = template["dashboard"]

        # Substitute variables
        if variables:
            dashboard_template = self._substitute_variables(dashboard_template, variables)

        # Resolve references
        if resolve_references:
            dashboard_template = self._resolve_references(template)

        # Get owner user ID
        users = self.zapi.user.get(
            filter={"username": owner_username},
            output=["userid"]
        )

        if not users:
            raise ValueError(f"User '{owner_username}' not found")

        owner_userid = users[0]["userid"]

        # Prepare dashboard for creation
        dashboard_params = {
            "name": dashboard_name,
            "userid": owner_userid,
            "private": dashboard_template.get("private", "0"),
            "display_period": dashboard_template.get("display_period", 30),
            "auto_start": dashboard_template.get("auto_start", "0"),
            "pages": dashboard_template.get("pages", [])
        }

        # Create dashboard
        result = self.zapi.dashboard.create(dashboard_params)
        dashboard_id = result["dashboardids"][0]

        print(f"[OK] Dashboard deployed successfully from template")
        print(f"  Template: {template_path}")
        print(f"  Dashboard ID: {dashboard_id}")
        print(f"  Name: {dashboard_name}")
        print(f"  Pages: {len(dashboard_params['pages'])}")

        # Count widgets
        total_widgets = sum(len(page.get("widgets", [])) for page in dashboard_params["pages"])
        print(f"  Total widgets: {total_widgets}")

        return {
            "dashboardid": dashboard_id,
            "name": dashboard_name,
            "template": template_path,
            "pages": len(dashboard_params["pages"]),
            "widgets": total_widgets
        }

    def create_template(
        self,
        dashboard_id: str,
        output_path: str,
        include_references: bool = True
    ) -> Dict[str, Any]:
        """
        Create template from existing dashboard.

        Args:
            dashboard_id: Dashboard ID to export
            output_path: Output file path
            include_references: Include host/item/map references

        Returns:
            Dict with template creation result

        Raises:
            ValueError: If dashboard not found
            ZabbixAPIException: If API call fails
        """
        # Get dashboard
        dashboards = self.zapi.dashboard.get(
            dashboardids=dashboard_id,
            output="extend",
            selectPages="extend"
        )

        if not dashboards:
            raise ValueError(f"Dashboard ID {dashboard_id} not found")

        dashboard = dashboards[0]

        # Build template structure
        template = {
            "template_version": "1.0",
            "description": f"Template created from dashboard: {dashboard['name']}",
            "dashboard": {
                "private": dashboard["private"],
                "display_period": dashboard.get("display_period", 30),
                "auto_start": dashboard.get("auto_start", "0"),
                "pages": dashboard["pages"]
            }
        }

        # Extract references if requested
        if include_references:
            host_refs = {}
            item_refs = {}
            map_refs = {}

            for page in dashboard["pages"]:
                for widget in page.get("widgets", []):
                    for field in widget.get("fields", []):
                        # Extract host references
                        if field["type"] == "2" and field["name"] == "hostid":
                            hostid = field["value"]
                            hosts = self.zapi.host.get(
                                hostids=hostid,
                                output=["host"]
                            )
                            if hosts:
                                ref_name = f"host_{hostid}"
                                host_refs[ref_name] = hosts[0]["host"]
                                field["value"] = f"${{{ref_name}}}"

                        # Extract item references
                        elif field["type"] == "4" and field["name"] == "itemid":
                            itemid = field["value"]
                            items = self.zapi.item.get(
                                itemids=itemid,
                                output=["key_"],
                                selectHosts=["host"]
                            )
                            if items:
                                item = items[0]
                                host_name = item["hosts"][0]["host"]
                                ref_name = f"item_{itemid}"
                                item_refs[ref_name] = f"{host_name}:{item['key_']}"
                                field["value"] = f"${{{ref_name}}}"

                        # Extract map references
                        elif field["type"] == "6" and field["name"] == "sysmapid":
                            mapid = field["value"]
                            maps = self.zapi.map.get(
                                sysmapids=mapid,
                                output=["name"]
                            )
                            if maps:
                                ref_name = f"map_{mapid}"
                                map_refs[ref_name] = maps[0]["name"]
                                field["value"] = f"${{{ref_name}}}"

            if host_refs:
                template["host_references"] = host_refs
            if item_refs:
                template["item_references"] = item_refs
            if map_refs:
                template["map_references"] = map_refs

        # Write template to file
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)

        if output.suffix.lower() in ['.json', '.js']:
            output.write_text(json.dumps(template, indent=2), encoding='utf-8')
        elif output.suffix.lower() in ['.yaml', '.yml']:
            output.write_text(yaml.dump(template, default_flow_style=False), encoding='utf-8')
        else:
            # Default to JSON
            output.write_text(json.dumps(template, indent=2), encoding='utf-8')

        print(f"[OK] Template created successfully")
        print(f"  Dashboard ID: {dashboard_id}")
        print(f"  Output: {output_path}")
        print(f"  Pages: {len(template['dashboard']['pages'])}")

        if include_references:
            print(f"  Host references: {len(host_refs)}")
            print(f"  Item references: {len(item_refs)}")
            print(f"  Map references: {len(map_refs)}")

        return {
            "dashboard_id": dashboard_id,
            "output_path": output_path,
            "pages": len(template["dashboard"]["pages"])
        }

    def validate_template(self, template_path: str) -> Dict[str, Any]:
        """
        Validate template structure.

        Args:
            template_path: Path to template file

        Returns:
            Dict with validation results
        """
        try:
            template = self._load_template(template_path)

            errors = []
            warnings = []

            # Check required fields
            if "dashboard" not in template:
                errors.append("Missing 'dashboard' section")
            else:
                dashboard = template["dashboard"]

                if "pages" not in dashboard:
                    errors.append("Missing 'pages' in dashboard")
                elif not isinstance(dashboard["pages"], list):
                    errors.append("'pages' must be a list")
                elif len(dashboard["pages"]) == 0:
                    warnings.append("No pages defined")

                # Validate pages
                for idx, page in enumerate(dashboard.get("pages", [])):
                    if "widgets" not in page:
                        warnings.append(f"Page {idx} has no widgets")
                    else:
                        for widx, widget in enumerate(page["widgets"]):
                            # Check required widget fields
                            if "type" not in widget:
                                errors.append(f"Page {idx}, Widget {widx}: Missing 'type'")
                            if "x" not in widget or "y" not in widget:
                                errors.append(f"Page {idx}, Widget {widx}: Missing position")
                            if "width" not in widget or "height" not in widget:
                                errors.append(f"Page {idx}, Widget {widx}: Missing size")

            # Check for unresolved variables
            template_str = json.dumps(template)
            import re
            unresolved = re.findall(r'\$\{(\w+)\}', template_str)
            if unresolved:
                warnings.append(f"Unresolved variables: {', '.join(set(unresolved))}")

            if errors:
                print(f"[ERROR] Template validation failed")
                print(f"  Template: {template_path}")
                print(f"\nErrors:")
                for error in errors:
                    print(f"  - {error}")

            if warnings:
                print(f"\nWarnings:")
                for warning in warnings:
                    print(f"  - {warning}")

            if not errors and not warnings:
                print(f"[OK] Template is valid")
                print(f"  Template: {template_path}")

                # Count elements
                pages = len(template.get("dashboard", {}).get("pages", []))
                widgets = sum(
                    len(page.get("widgets", []))
                    for page in template.get("dashboard", {}).get("pages", [])
                )
                print(f"  Pages: {pages}")
                print(f"  Widgets: {widgets}")

            return {
                "valid": len(errors) == 0,
                "errors": errors,
                "warnings": warnings,
                "template_path": template_path
            }

        except Exception as e:
            print(f"[ERROR] Template validation failed: {e}")
            return {
                "valid": False,
                "errors": [str(e)],
                "warnings": [],
                "template_path": template_path
            }


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Dashboard Template Creator",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument("--url", help="Zabbix server URL")
    parser.add_argument("--token", help="API token")

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Deploy command
    deploy_parser = subparsers.add_parser("deploy", help="Deploy dashboard from template")
    deploy_parser.add_argument("--template", required=True, help="Template file path")
    deploy_parser.add_argument("--dashboard-name", required=True, help="Dashboard name")
    deploy_parser.add_argument("--owner", default="Admin", help="Owner username")
    deploy_parser.add_argument("--variables", help="Variables JSON: {\"key\":\"value\"}")
    deploy_parser.add_argument("--no-resolve", action="store_true", help="Don't resolve references")

    # Create command
    create_parser = subparsers.add_parser("create", help="Create template from dashboard")
    create_parser.add_argument("--dashboard-id", required=True, help="Dashboard ID")
    create_parser.add_argument("--output", required=True, help="Output file path")
    create_parser.add_argument("--no-references", action="store_true", help="Don't include references")

    # Validate command
    validate_parser = subparsers.add_parser("validate", help="Validate template")
    validate_parser.add_argument("--template", required=True, help="Template file path")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    # Validate command doesn't need API credentials
    if args.command == "validate":
        creator = DashboardTemplateCreator("", "")
        creator.validate_template(args.template)
        return 0

    # Other commands need credentials
    if not args.url or not args.token:
        print("Error: --url and --token required for this command", file=sys.stderr)
        return 1

    try:
        creator = DashboardTemplateCreator(args.url, args.token)

        if args.command == "deploy":
            variables = json.loads(args.variables) if args.variables else None

            creator.deploy_template(
                template_path=args.template,
                dashboard_name=args.dashboard_name,
                owner_username=args.owner,
                variables=variables,
                resolve_references=not args.no_resolve
            )

        elif args.command == "create":
            creator.create_template(
                dashboard_id=args.dashboard_id,
                output_path=args.output,
                include_references=not args.no_references
            )

        return 0

    except Exception as e:
        print(f"[ERROR] Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
