#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Graph Visualizer

Create and configure graph widgets with custom styling, data series, and visualization options.

Usage:
    python graph_visualizer.py create --dashboard-id 10 --name "CPU Load" \
        --items "CPU load:system.cpu.load" --graph-type line

    python graph_visualizer.py create --dashboard-id 10 --name "Network Traffic" \
        --items "Traffic in:net.if.in[eth0],Traffic out:net.if.out[eth0]" \
        --graph-type stacked --position '{"x":0,"y":5,"width":36,"height":8}'
"""

import argparse
import json
import sys
from typing import Dict, List, Optional, Any
from pyzabbix import ZabbixAPI


class GraphVisualizer:
    """Create graph visualizations"""

    GRAPH_TYPES = ["line", "stacked", "area", "bar", "points"]
    COLORS = ["1A7C11", "F63100", "2774A4", "F7941D", "FC6EA3", "6C59DC"]

    def __init__(self, url: str, token: str):
        self.zapi = ZabbixAPI(url)
        self.zapi.login(api_token=token)

    def create_graph_widget(
        self,
        dashboard_id: str,
        name: str,
        items: List[Dict[str, str]],
        graph_type: str = "line",
        position: Optional[Dict[str, int]] = None,
        time_period: str = "1h"
    ) -> Dict[str, Any]:
        """
        Create graph widget.

        Args:
            dashboard_id: Dashboard ID
            name: Widget name
            items: List of dicts with 'name', 'host', 'key'
            graph_type: Graph type (line, stacked, area, bar, points)
            position: Position dict
            time_period: Time period (e.g., '1h', '24h', '7d')

        Returns:
            Dict with result
        """
        if graph_type not in self.GRAPH_TYPES:
            raise ValueError(f"Invalid graph type. Valid: {', '.join(self.GRAPH_TYPES)}")

        # Resolve items
        fields = []
        for idx, item_spec in enumerate(items):
            item_data = self.zapi.item.get(
                filter={"key_": item_spec["key"]},
                host=item_spec["host"],
                output=["itemid"]
            )

            if not item_data:
                print(f"Warning: Item not found: {item_spec['host']}:{item_spec['key']}")
                continue

            itemid = item_data[0]["itemid"]

            # Add item field
            fields.append({
                "type": "4",  # ITEM
                "name": f"itemid.{idx}",
                "value": itemid
            })

            # Add item options
            color = self.COLORS[idx % len(self.COLORS)]
            fields.append({
                "type": "1",  # STRING
                "name": f"ds.{idx}.color",
                "value": color
            })

            if item_spec.get("name"):
                fields.append({
                    "type": "1",
                    "name": f"ds.{idx}.legend",
                    "value": item_spec["name"]
                })

        # Graph type configuration
        draw_type = {"line": "0", "area": "1", "stacked": "2", "bar": "3", "points": "4"}
        if graph_type in draw_type:
            fields.append({
                "type": "0",
                "name": "source",
                "value": draw_type[graph_type]
            })

        # Time period
        fields.append({
            "type": "1",
            "name": "time_period.from",
            "value": f"now-{time_period}"
        })
        fields.append({
            "type": "1",
            "name": "time_period.to",
            "value": "now"
        })

        # Get dashboard
        dashboards = self.zapi.dashboard.get(
            dashboardids=dashboard_id,
            output="extend",
            selectPages="extend"
        )

        if not dashboards:
            raise ValueError(f"Dashboard ID {dashboard_id} not found")

        dashboard = dashboards[0]

        # Default position
        if not position:
            position = {"x": 0, "y": 0, "width": 24, "height": 8}

        # Create widget
        widget = {
            "type": "graph",
            "name": name,
            "x": position["x"],
            "y": position["y"],
            "width": position["width"],
            "height": position["height"],
            "view_mode": "0",
            "fields": fields
        }

        dashboard["pages"][0]["widgets"].append(widget)

        result = self.zapi.dashboard.update({
            "dashboardid": dashboard_id,
            "pages": dashboard["pages"]
        })

        print(f"[OK] Graph widget created")
        print(f"  Dashboard ID: {dashboard_id}")
        print(f"  Name: {name}")
        print(f"  Items: {len(items)}")
        print(f"  Type: {graph_type}")

        return result


def main():
    parser = argparse.ArgumentParser(description="Graph Visualizer")
    parser.add_argument("--url", required=True, help="Zabbix server URL")
    parser.add_argument("--token", required=True, help="API token")

    subparsers = parser.add_subparsers(dest="command")

    create_parser = subparsers.add_parser("create", help="Create graph widget")
    create_parser.add_argument("--dashboard-id", required=True, help="Dashboard ID")
    create_parser.add_argument("--name", required=True, help="Widget name")
    create_parser.add_argument("--items", required=True, help="Items: 'Name:host:key,Name:host:key'")
    create_parser.add_argument("--graph-type", default="line", choices=GraphVisualizer.GRAPH_TYPES)
    create_parser.add_argument("--position", help="Position JSON")
    create_parser.add_argument("--time-period", default="1h", help="Time period (e.g., 1h, 24h)")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    try:
        viz = GraphVisualizer(args.url, args.token)

        if args.command == "create":
            # Parse items
            items_list = []
            for item_str in args.items.split(","):
                parts = item_str.split(":")
                if len(parts) == 2:
                    items_list.append({"name": "", "host": parts[0], "key": parts[1]})
                elif len(parts) == 3:
                    items_list.append({"name": parts[0], "host": parts[1], "key": parts[2]})

            position = json.loads(args.position) if args.position else None

            viz.create_graph_widget(
                dashboard_id=args.dashboard_id,
                name=args.name,
                items=items_list,
                graph_type=args.graph_type,
                position=position,
                time_period=args.time_period
            )

        return 0

    except Exception as e:
        print(f"[ERROR] Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
