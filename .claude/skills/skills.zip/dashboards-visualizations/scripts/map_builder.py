#!/usr/bin/env python3
"""
Map Builder

Create network topology maps and add them to dashboards.

Usage:
    python map_builder.py create --name "Network Map" --hosts "Server1,Server2,Router1"
    python map_builder.py add-to-dashboard --map-id 5 --dashboard-id 10
"""

import argparse
import sys
from typing import List, Dict, Any
from pyzabbix import ZabbixAPI


import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
class MapBuilder:
    """Build network maps"""

    def __init__(self, url: str, token: str):
        self.zapi = ZabbixAPI(url)
        self.zapi.login(api_token=token)

    def create_map(self, name: str, hosts: List[str], width: int = 800, height: int = 600) -> Dict[str, Any]:
        """Create network map with hosts"""

        elements = []
        x_spacing = width // (len(hosts) + 1)

        for idx, hostname in enumerate(hosts):
            host_data = self.zapi.host.get(filter={"host": hostname}, output=["hostid"])

            if not host_data:
                print(f"Warning: Host '{hostname}' not found")
                continue

            elements.append({
                "selementid": str(idx + 1),
                "elementtype": "0",  # Host
                "elements": [{"hostid": host_data[0]["hostid"]}],
                "x": str(x_spacing * (idx + 1)),
                "y": str(height // 2),
                "iconid_off": "1",
                "label": hostname
            })

        result = self.zapi.map.create({
            "name": name,
            "width": width,
            "height": height,
            "selements": elements
        })

        mapid = result["sysmapids"][0]
        print(f"[OK] Map created: {name} (ID: {mapid})")
        return {"sysmapid": mapid, "name": name}

    def add_to_dashboard(self, map_id: str, dashboard_id: str, position: Dict = None) -> Dict[str, Any]:
        """Add map widget to dashboard"""

        dashboards = self.zapi.dashboard.get(dashboardids=dashboard_id, output="extend", selectPages="extend")

        if not dashboards:
            raise ValueError(f"Dashboard {dashboard_id} not found")

        if not position:
            position = {"x": 0, "y": 0, "width": 36, "height": 16}

        widget = {
            "type": "map",
            "name": "Network Map",
            "x": position["x"],
            "y": position["y"],
            "width": position["width"],
            "height": position["height"],
            "view_mode": "0",
            "fields": [{"type": "6", "name": "sysmapid", "value": map_id}]
        }

        dashboards[0]["pages"][0]["widgets"].append(widget)

        self.zapi.dashboard.update({
            "dashboardid": dashboard_id,
            "pages": dashboards[0]["pages"]
        })

        print(f"[OK] Map widget added to dashboard {dashboard_id}")
        return {"success": True}


def main():
    parser = argparse.ArgumentParser(description="Map Builder")
    parser.add_argument("--url", required=True)
    parser.add_argument("--token", required=True)

    subparsers = parser.add_subparsers(dest="command")

    create_parser = subparsers.add_parser("create")
    create_parser.add_argument("--name", required=True)
    create_parser.add_argument("--hosts", required=True, help="Comma-separated hostnames")

    add_parser = subparsers.add_parser("add-to-dashboard")
    add_parser.add_argument("--map-id", required=True)
    add_parser.add_argument("--dashboard-id", required=True)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    try:
        builder = MapBuilder(args.url, args.token)

        if args.command == "create":
            builder.create_map(args.name, args.hosts.split(","))
        elif args.command == "add-to-dashboard":
            builder.add_to_dashboard(args.map_id, args.dashboard_id)

        return 0

    except Exception as e:
        print(f"[ERROR] Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
