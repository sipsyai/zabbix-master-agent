#!/usr/bin/env python3
"""
Dashboard Configuration Validator

Validate dashboard JSON/YAML configurations before deployment.

Usage:
    python validate_dashboard_config.py --config dashboard.json
    python validate_dashboard_config.py --config dashboard.yaml --strict
"""

import argparse
import json
import sys
import yaml
from pathlib import Path
from typing import Dict, List, Any


import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
class DashboardValidator:
    """Validate dashboard configurations"""

    MAX_COLUMNS = 72
    MAX_ROWS = 64
    VALID_WIDGET_TYPES = [
        "actionlog", "clock", "dataover", "discovery", "favgraphs", "favmaps",
        "gauge", "geomap", "graph", "graphclassic", "graphprototype", "honeycomb",
        "hostavail", "hostcard", "hostnavigator", "itemcard", "itemhistory",
        "itemnavigator", "item", "map", "navtree", "piechart", "problemhosts",
        "problems", "problemsbysv", "slareport", "systeminfo", "tophosts",
        "topitems", "toptriggers", "trigover", "url", "web"
    ]

    def __init__(self, strict: bool = False):
        self.strict = strict
        self.errors = []
        self.warnings = []

    def validate(self, config_path: str) -> bool:
        """Validate dashboard configuration"""

        path = Path(config_path)
        if not path.exists():
            self.errors.append(f"File not found: {config_path}")
            return False

        # Load config
        try:
            content = path.read_text()
            if path.suffix.lower() in ['.json', '.js']:
                config = json.loads(content)
            elif path.suffix.lower() in ['.yaml', '.yml']:
                config = yaml.safe_load(content)
            else:
                self.errors.append(f"Unsupported format: {path.suffix}")
                return False
        except Exception as e:
            self.errors.append(f"Parse error: {e}")
            return False

        # Validate structure
        self._validate_structure(config)

        # Validate pages
        if "pages" in config:
            for idx, page in enumerate(config["pages"]):
                self._validate_page(idx, page)

        # Report results
        if self.errors:
            print("[ERROR] Validation failed\n")
            print("Errors:")
            for error in self.errors:
                print(f"  - {error}")

        if self.warnings:
            print("\nWarnings:")
            for warning in self.warnings:
                print(f"  - {warning}")

        if not self.errors and not self.warnings:
            print("[OK] Configuration is valid")

        return len(self.errors) == 0

    def _validate_structure(self, config: Dict[str, Any]) -> None:
        """Validate basic structure"""

        if "name" not in config:
            self.warnings.append("Missing dashboard name")

        if "pages" not in config:
            self.errors.append("Missing pages array")
        elif not isinstance(config["pages"], list):
            self.errors.append("Pages must be an array")
        elif len(config["pages"]) == 0:
            self.warnings.append("No pages defined")

    def _validate_page(self, page_idx: int, page: Dict[str, Any]) -> None:
        """Validate page configuration"""

        if "widgets" not in page:
            self.warnings.append(f"Page {page_idx}: No widgets defined")
            return

        if not isinstance(page["widgets"], list):
            self.errors.append(f"Page {page_idx}: Widgets must be an array")
            return

        # Check for overlapping widgets
        positions = []
        for widget_idx, widget in enumerate(page["widgets"]):
            self._validate_widget(page_idx, widget_idx, widget)

            # Track positions for overlap detection
            if all(k in widget for k in ["x", "y", "width", "height"]):
                positions.append({
                    "idx": widget_idx,
                    "x": widget["x"],
                    "y": widget["y"],
                    "width": widget["width"],
                    "height": widget["height"]
                })

        # Check overlaps
        for i, pos1 in enumerate(positions):
            for pos2 in positions[i+1:]:
                if self._check_overlap(pos1, pos2):
                    self.warnings.append(
                        f"Page {page_idx}: Widgets {pos1['idx']} and {pos2['idx']} overlap"
                    )

    def _validate_widget(self, page_idx: int, widget_idx: int, widget: Dict[str, Any]) -> None:
        """Validate widget configuration"""

        prefix = f"Page {page_idx}, Widget {widget_idx}"

        # Required fields
        if "type" not in widget:
            self.errors.append(f"{prefix}: Missing type")
        elif widget["type"] not in self.VALID_WIDGET_TYPES:
            self.errors.append(f"{prefix}: Invalid type '{widget['type']}'")

        if "name" not in widget and self.strict:
            self.warnings.append(f"{prefix}: Missing name")

        # Position validation
        for field in ["x", "y", "width", "height"]:
            if field not in widget:
                self.errors.append(f"{prefix}: Missing {field}")

        if "x" in widget and "width" in widget:
            if widget["x"] + widget["width"] > self.MAX_COLUMNS:
                self.errors.append(
                    f"{prefix}: Exceeds grid width "
                    f"(x:{widget['x']} + width:{widget['width']} > {self.MAX_COLUMNS})"
                )

        if "y" in widget and "height" in widget:
            if widget["y"] + widget["height"] > self.MAX_ROWS:
                self.errors.append(
                    f"{prefix}: Exceeds grid height "
                    f"(y:{widget['y']} + height:{widget['height']} > {self.MAX_ROWS})"
                )

        # Field validation
        if "fields" in widget and not isinstance(widget["fields"], list):
            self.errors.append(f"{prefix}: Fields must be an array")

    def _check_overlap(self, pos1: Dict, pos2: Dict) -> bool:
        """Check if two widget positions overlap"""

        return not (
            pos1["x"] + pos1["width"] <= pos2["x"] or
            pos2["x"] + pos2["width"] <= pos1["x"] or
            pos1["y"] + pos1["height"] <= pos2["y"] or
            pos2["y"] + pos2["height"] <= pos1["y"]
        )


def main():
    parser = argparse.ArgumentParser(description="Dashboard Configuration Validator")
    parser.add_argument("--config", required=True, help="Config file path")
    parser.add_argument("--strict", action="store_true", help="Enable strict validation")

    args = parser.parse_args()

    validator = DashboardValidator(strict=args.strict)
    valid = validator.validate(args.config)

    return 0 if valid else 1


if __name__ == "__main__":
    sys.exit(main())
