#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Dashboard Manager

Comprehensive dashboard CRUD operations including creation, updating, deletion,
sharing, cloning, and page management.

Usage:
    # Create dashboard
    python zabbix_dashboard_manager.py create --name "My Dashboard" --owner "Admin"

    # Update dashboard
    python zabbix_dashboard_manager.py update --dashboard-id 10 --name "Updated Name"

    # Delete dashboard
    python zabbix_dashboard_manager.py delete --dashboard-id 10

    # Clone dashboard
    python zabbix_dashboard_manager.py clone --dashboard-id 10 --new-name "Cloned Dashboard"

    # Share dashboard
    python zabbix_dashboard_manager.py share --dashboard-id 10 --type public

    # List dashboards
    python zabbix_dashboard_manager.py list

    # Add page to dashboard
    python zabbix_dashboard_manager.py add-page --dashboard-id 10 --page-name "Page 2"
"""

import argparse
import json
import sys
from typing import Dict, List, Optional, Any
from pyzabbix import ZabbixAPI, ZabbixAPIException


class ZabbixDashboardManager:
    """Manage Zabbix dashboards via API"""

    def __init__(self, url: str, token: str):
        """
        Initialize dashboard manager.

        Args:
            url: Zabbix server URL
            token: API authentication token
        """
        self.zapi = ZabbixAPI(url)
        self.zapi.login(api_token=token)

    def create_dashboard(
        self,
        name: str,
        owner_username: str,
        pages: int = 1,
        auto_slideshow: bool = False,
        display_period: int = 30,
        private: bool = False
    ) -> Dict[str, Any]:
        """
        Create a new dashboard.

        Args:
            name: Dashboard name
            owner_username: Username of dashboard owner
            pages: Number of pages to create (default: 1)
            auto_slideshow: Start slideshow automatically (default: False)
            display_period: Page display period in seconds (default: 30)
            private: Create as private dashboard (default: False)

        Returns:
            Dict with created dashboard details

        Raises:
            ValueError: If owner not found or parameters invalid
            ZabbixAPIException: If API call fails
        """
        # Get owner user ID
        users = self.zapi.user.get(
            filter={"username": owner_username},
            output=["userid"]
        )

        if not users:
            raise ValueError(f"User '{owner_username}' not found")

        owner_userid = users[0]["userid"]

        # Validate parameters
        if pages < 1 or pages > 10:
            raise ValueError("Pages must be between 1 and 10")

        if display_period < 10 or display_period > 300:
            raise ValueError("Display period must be between 10 and 300 seconds")

        # Create pages
        page_list = []
        for i in range(pages):
            page_list.append({
                "name": f"Page {i + 1}" if pages > 1 else "",
                "display_period": display_period,
                "widgets": []
            })

        # Create dashboard
        dashboard_params = {
            "name": name,
            "userid": owner_userid,
            "private": "1" if private else "0",
            "display_period": display_period,
            "auto_start": "1" if auto_slideshow else "0",
            "pages": page_list
        }

        result = self.zapi.dashboard.create(dashboard_params)

        dashboard_id = result["dashboardids"][0]

        print(f"[OK] Dashboard created successfully")
        print(f"  Dashboard ID: {dashboard_id}")
        print(f"  Name: {name}")
        print(f"  Owner: {owner_username}")
        print(f"  Pages: {pages}")
        print(f"  Type: {'Private' if private else 'Public'}")

        return {
            "dashboardid": dashboard_id,
            "name": name,
            "owner": owner_username,
            "pages": pages,
            "private": private
        }

    def update_dashboard(
        self,
        dashboard_id: str,
        name: Optional[str] = None,
        display_period: Optional[int] = None,
        auto_slideshow: Optional[bool] = None
    ) -> Dict[str, Any]:
        """
        Update dashboard properties.

        Args:
            dashboard_id: Dashboard ID to update
            name: New dashboard name (optional)
            display_period: New display period (optional)
            auto_slideshow: Enable/disable auto slideshow (optional)

        Returns:
            Dict with update result

        Raises:
            ValueError: If dashboard not found
            ZabbixAPIException: If API call fails
        """
        # Verify dashboard exists
        dashboards = self.zapi.dashboard.get(
            dashboardids=dashboard_id,
            output=["dashboardid", "name"]
        )

        if not dashboards:
            raise ValueError(f"Dashboard ID {dashboard_id} not found")

        # Build update parameters
        update_params = {"dashboardid": dashboard_id}

        if name:
            update_params["name"] = name

        if display_period is not None:
            if display_period < 10 or display_period > 300:
                raise ValueError("Display period must be between 10 and 300 seconds")
            update_params["display_period"] = display_period

        if auto_slideshow is not None:
            update_params["auto_start"] = "1" if auto_slideshow else "0"

        result = self.zapi.dashboard.update(update_params)

        print(f"[OK] Dashboard updated successfully")
        print(f"  Dashboard ID: {dashboard_id}")
        if name:
            print(f"  New name: {name}")

        return result

    def delete_dashboard(self, dashboard_id: str) -> Dict[str, Any]:
        """
        Delete a dashboard.

        Args:
            dashboard_id: Dashboard ID to delete

        Returns:
            Dict with deletion result

        Raises:
            ValueError: If dashboard not found
            ZabbixAPIException: If API call fails
        """
        # Verify dashboard exists
        dashboards = self.zapi.dashboard.get(
            dashboardids=dashboard_id,
            output=["dashboardid", "name"]
        )

        if not dashboards:
            raise ValueError(f"Dashboard ID {dashboard_id} not found")

        dashboard_name = dashboards[0]["name"]

        result = self.zapi.dashboard.delete([dashboard_id])

        print(f"[OK] Dashboard deleted successfully")
        print(f"  Dashboard ID: {dashboard_id}")
        print(f"  Name: {dashboard_name}")

        return result

    def clone_dashboard(
        self,
        dashboard_id: str,
        new_name: str,
        owner_username: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Clone an existing dashboard.

        Args:
            dashboard_id: Dashboard ID to clone
            new_name: Name for cloned dashboard
            owner_username: Owner for cloned dashboard (optional, uses original owner)

        Returns:
            Dict with cloned dashboard details

        Raises:
            ValueError: If dashboard not found
            ZabbixAPIException: If API call fails
        """
        # Get original dashboard
        dashboards = self.zapi.dashboard.get(
            dashboardids=dashboard_id,
            output="extend",
            selectPages="extend",
            selectUsers="extend",
            selectUserGroups="extend"
        )

        if not dashboards:
            raise ValueError(f"Dashboard ID {dashboard_id} not found")

        original = dashboards[0]

        # Prepare clone parameters
        clone_params = {
            "name": new_name,
            "userid": original["userid"],
            "private": original["private"],
            "display_period": original["display_period"],
            "auto_start": original["auto_start"],
            "pages": original["pages"]
        }

        # Change owner if specified
        if owner_username:
            users = self.zapi.user.get(
                filter={"username": owner_username},
                output=["userid"]
            )
            if users:
                clone_params["userid"] = users[0]["userid"]

        result = self.zapi.dashboard.create(clone_params)

        cloned_id = result["dashboardids"][0]

        print(f"[OK] Dashboard cloned successfully")
        print(f"  Original ID: {dashboard_id}")
        print(f"  New ID: {cloned_id}")
        print(f"  New name: {new_name}")
        print(f"  Pages cloned: {len(original['pages'])}")

        return {
            "dashboardid": cloned_id,
            "name": new_name,
            "original_id": dashboard_id
        }

    def share_dashboard(
        self,
        dashboard_id: str,
        dashboard_type: str,
        user_groups: Optional[List[Dict[str, str]]] = None,
        users: Optional[List[Dict[str, str]]] = None
    ) -> Dict[str, Any]:
        """
        Configure dashboard sharing.

        Args:
            dashboard_id: Dashboard ID to share
            dashboard_type: 'public' or 'private'
            user_groups: List of dicts with 'name' and 'permission' (read/read-write)
            users: List of dicts with 'username' and 'permission' (read/read-write)

        Returns:
            Dict with sharing configuration result

        Raises:
            ValueError: If parameters invalid
            ZabbixAPIException: If API call fails
        """
        if dashboard_type not in ["public", "private"]:
            raise ValueError("Dashboard type must be 'public' or 'private'")

        update_params = {
            "dashboardid": dashboard_id,
            "private": "1" if dashboard_type == "private" else "0"
        }

        # Handle user groups
        if user_groups:
            usergroups_list = []
            for ug in user_groups:
                groups = self.zapi.usergroup.get(
                    filter={"name": ug["name"]},
                    output=["usrgrpid"]
                )
                if groups:
                    permission = "2" if ug.get("permission") == "read" else "3"
                    usergroups_list.append({
                        "usrgrpid": groups[0]["usrgrpid"],
                        "permission": permission
                    })

            if usergroups_list:
                update_params["userGroups"] = usergroups_list

        # Handle users
        if users:
            users_list = []
            for u in users:
                user_data = self.zapi.user.get(
                    filter={"username": u["username"]},
                    output=["userid"]
                )
                if user_data:
                    permission = "2" if u.get("permission") == "read" else "3"
                    users_list.append({
                        "userid": user_data[0]["userid"],
                        "permission": permission
                    })

            if users_list:
                update_params["users"] = users_list

        result = self.zapi.dashboard.update(update_params)

        print(f"[OK] Dashboard sharing configured")
        print(f"  Dashboard ID: {dashboard_id}")
        print(f"  Type: {dashboard_type}")
        if user_groups:
            print(f"  User groups: {len(user_groups)}")
        if users:
            print(f"  Users: {len(users)}")

        return result

    def list_dashboards(self, owner_only: bool = False) -> List[Dict[str, Any]]:
        """
        List all dashboards.

        Args:
            owner_only: Show only dashboards owned by current user

        Returns:
            List of dashboard details
        """
        params = {
            "output": ["dashboardid", "name", "userid", "private"],
            "selectPages": "count"
        }

        dashboards = self.zapi.dashboard.get(**params)

        # Get current user if filtering
        current_userid = None
        if owner_only:
            current_user = self.zapi.user.get(output=["userid"])[0]
            current_userid = current_user["userid"]

        print(f"\n{'ID':<8} {'Name':<40} {'Pages':<8} {'Type':<10}")
        print("-" * 70)

        filtered = []
        for dash in dashboards:
            if owner_only and dash["userid"] != current_userid:
                continue

            dash_type = "Private" if dash["private"] == "1" else "Public"
            print(f"{dash['dashboardid']:<8} {dash['name']:<40} {dash['pages']:<8} {dash_type:<10}")
            filtered.append(dash)

        print(f"\nTotal: {len(filtered)} dashboards")

        return filtered

    def add_page(
        self,
        dashboard_id: str,
        page_name: str = "",
        display_period: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Add a page to existing dashboard.

        Args:
            dashboard_id: Dashboard ID
            page_name: Page name (optional)
            display_period: Page-specific display period (optional)

        Returns:
            Dict with update result

        Raises:
            ValueError: If dashboard not found
            ZabbixAPIException: If API call fails
        """
        # Get current dashboard
        dashboards = self.zapi.dashboard.get(
            dashboardids=dashboard_id,
            output="extend",
            selectPages="extend"
        )

        if not dashboards:
            raise ValueError(f"Dashboard ID {dashboard_id} not found")

        dashboard = dashboards[0]
        pages = dashboard["pages"]

        # Create new page
        new_page = {
            "name": page_name if page_name else f"Page {len(pages) + 1}",
            "widgets": []
        }

        if display_period:
            if display_period < 10 or display_period > 300:
                raise ValueError("Display period must be between 10 and 300 seconds")
            new_page["display_period"] = display_period

        pages.append(new_page)

        result = self.zapi.dashboard.update({
            "dashboardid": dashboard_id,
            "pages": pages
        })

        print(f"[OK] Page added successfully")
        print(f"  Dashboard ID: {dashboard_id}")
        print(f"  Page name: {new_page['name']}")
        print(f"  Total pages: {len(pages)}")

        return result


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Zabbix Dashboard Manager",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument("--url", required=True, help="Zabbix server URL")
    parser.add_argument("--token", required=True, help="API token")

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Create command
    create_parser = subparsers.add_parser("create", help="Create dashboard")
    create_parser.add_argument("--name", required=True, help="Dashboard name")
    create_parser.add_argument("--owner", required=True, help="Owner username")
    create_parser.add_argument("--pages", type=int, default=1, help="Number of pages")
    create_parser.add_argument("--auto-slideshow", action="store_true", help="Auto-start slideshow")
    create_parser.add_argument("--display-period", type=int, default=30, help="Display period (seconds)")
    create_parser.add_argument("--private", action="store_true", help="Create as private")

    # Update command
    update_parser = subparsers.add_parser("update", help="Update dashboard")
    update_parser.add_argument("--dashboard-id", required=True, help="Dashboard ID")
    update_parser.add_argument("--name", help="New name")
    update_parser.add_argument("--display-period", type=int, help="Display period")
    update_parser.add_argument("--auto-slideshow", type=bool, help="Auto-start slideshow")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete dashboard")
    delete_parser.add_argument("--dashboard-id", required=True, help="Dashboard ID")

    # Clone command
    clone_parser = subparsers.add_parser("clone", help="Clone dashboard")
    clone_parser.add_argument("--dashboard-id", required=True, help="Dashboard ID")
    clone_parser.add_argument("--new-name", required=True, help="New dashboard name")
    clone_parser.add_argument("--owner", help="New owner username")

    # Share command
    share_parser = subparsers.add_parser("share", help="Share dashboard")
    share_parser.add_argument("--dashboard-id", required=True, help="Dashboard ID")
    share_parser.add_argument("--type", required=True, choices=["public", "private"], help="Dashboard type")
    share_parser.add_argument("--user-groups", help="User groups JSON: [{'name':'group','permission':'read'}]")
    share_parser.add_argument("--users", help="Users JSON: [{'username':'user','permission':'read'}]")

    # List command
    list_parser = subparsers.add_parser("list", help="List dashboards")
    list_parser.add_argument("--owner-only", action="store_true", help="Show only owned dashboards")

    # Add page command
    addpage_parser = subparsers.add_parser("add-page", help="Add page to dashboard")
    addpage_parser.add_argument("--dashboard-id", required=True, help="Dashboard ID")
    addpage_parser.add_argument("--page-name", default="", help="Page name")
    addpage_parser.add_argument("--display-period", type=int, help="Display period")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    try:
        manager = ZabbixDashboardManager(args.url, args.token)

        if args.command == "create":
            manager.create_dashboard(
                name=args.name,
                owner_username=args.owner,
                pages=args.pages,
                auto_slideshow=args.auto_slideshow,
                display_period=args.display_period,
                private=args.private
            )

        elif args.command == "update":
            manager.update_dashboard(
                dashboard_id=args.dashboard_id,
                name=args.name,
                display_period=args.display_period,
                auto_slideshow=args.auto_slideshow
            )

        elif args.command == "delete":
            manager.delete_dashboard(args.dashboard_id)

        elif args.command == "clone":
            manager.clone_dashboard(
                dashboard_id=args.dashboard_id,
                new_name=args.new_name,
                owner_username=args.owner
            )

        elif args.command == "share":
            user_groups = json.loads(args.user_groups) if args.user_groups else None
            users = json.loads(args.users) if args.users else None

            manager.share_dashboard(
                dashboard_id=args.dashboard_id,
                dashboard_type=args.type,
                user_groups=user_groups,
                users=users
            )

        elif args.command == "list":
            manager.list_dashboards(owner_only=args.owner_only)

        elif args.command == "add-page":
            manager.add_page(
                dashboard_id=args.dashboard_id,
                page_name=args.page_name,
                display_period=args.display_period
            )

        return 0

    except Exception as e:
        print(f"[ERROR] Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
