#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Widget Builder

Configure and add widgets to dashboards with proper positioning, field configuration,
and validation for all 30+ widget types.

Usage:
    # Add problems widget
    python zabbix_widget_builder.py add --dashboard-id 10 --widget-type problems \
        --name "Active Problems" --position '{"x":0,"y":0,"width":12,"height":5}'

    # Add graph widget
    python zabbix_widget_builder.py add --dashboard-id 10 --widget-type graph \
        --name "CPU Load" --config '{"itemids":["12345","12346"]}'

    # Update widget
    python zabbix_widget_builder.py update --dashboard-id 10 --widget-index 0 \
        --name "Updated Name"

    # Delete widget
    python zabbix_widget_builder.py delete --dashboard-id 10 --widget-index 0

    # List widgets
    python zabbix_widget_builder.py list --dashboard-id 10
"""

import argparse
import json
import sys
from typing import Dict, List, Optional, Any
from pyzabbix import ZabbixAPI, ZabbixAPIException


# Widget type constants
WIDGET_TYPES = {
    "actionlog": "actionlog",
    "clock": "clock",
    "dataover": "dataover",
    "discovery": "discovery",
    "favgraphs": "favgraphs",
    "favmaps": "favmaps",
    "gauge": "gauge",
    "geomap": "geomap",
    "graph": "graph",
    "graphclassic": "graphclassic",
    "graphprototype": "graphprototype",
    "honeycomb": "honeycomb",
    "hostavail": "hostavail",
    "hostcard": "hostcard",
    "hostnavigator": "hostnavigator",
    "itemcard": "itemcard",
    "itemhistory": "itemhistory",
    "itemnavigator": "itemnavigator",
    "item": "item",
    "map": "map",
    "navtree": "navtree",
    "piechart": "piechart",
    "problemhosts": "problemhosts",
    "problems": "problems",
    "problemsbysv": "problemsbysv",
    "slareport": "slareport",
    "systeminfo": "systeminfo",
    "tophosts": "tophosts",
    "topitems": "topitems",
    "toptriggers": "toptriggers",
    "trigover": "trigover",
    "url": "url",
    "web": "web"
}


class ZabbixWidgetBuilder:
    """Build and manage dashboard widgets"""

    # Grid constants
    MAX_COLUMNS = 72
    MAX_ROWS = 64
    DEFAULT_WIDTH = 12
    DEFAULT_HEIGHT = 5

    def __init__(self, url: str, token: str):
        """
        Initialize widget builder.

        Args:
            url: Zabbix server URL
            token: API authentication token
        """
        self.zapi = ZabbixAPI(url)
        self.zapi.login(api_token=token)

    def _validate_position(self, x: int, y: int, width: int, height: int) -> None:
        """
        Validate widget position on grid.

        Args:
            x: X coordinate (0-71)
            y: Y coordinate (0-63)
            width: Widget width (1-72)
            height: Widget height (1-64)

        Raises:
            ValueError: If position invalid
        """
        if x < 0 or x >= self.MAX_COLUMNS:
            raise ValueError(f"X must be between 0 and {self.MAX_COLUMNS - 1}")

        if y < 0 or y >= self.MAX_ROWS:
            raise ValueError(f"Y must be between 0 and {self.MAX_ROWS - 1}")

        if width < 1 or width > self.MAX_COLUMNS:
            raise ValueError(f"Width must be between 1 and {self.MAX_COLUMNS}")

        if height < 1 or height > self.MAX_ROWS:
            raise ValueError(f"Height must be between 1 and {self.MAX_ROWS}")

        if x + width > self.MAX_COLUMNS:
            raise ValueError(f"Widget extends beyond grid width (x:{x} + width:{width} > {self.MAX_COLUMNS})")

        if y + height > self.MAX_ROWS:
            raise ValueError(f"Widget extends beyond grid height (y:{y} + height:{height} > {self.MAX_ROWS})")

    def _build_widget_fields(self, widget_type: str, config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Build widget field configuration based on type and config.

        Args:
            widget_type: Widget type identifier
            config: Widget-specific configuration

        Returns:
            List of widget field dictionaries
        """
        fields = []

        # Common fields for problem widgets
        if widget_type in ["problems", "problemhosts", "problemsbysv"]:
            if "show_tags" in config:
                fields.append({
                    "type": "0",  # INTEGER
                    "name": "show_tags",
                    "value": str(config["show_tags"])
                })

            if "hostids" in config:
                for hostid in config["hostids"]:
                    fields.append({
                        "type": "1",  # STRING
                        "name": "hostids",
                        "value": str(hostid)
                    })

            if "problem_name" in config:
                fields.append({
                    "type": "1",
                    "name": "problem",
                    "value": config["problem_name"]
                })

            if "severities" in config:
                for severity in config["severities"]:
                    fields.append({
                        "type": "0",
                        "name": "severities",
                        "value": str(severity)
                    })

        # Graph widgets
        elif widget_type in ["graph", "graphclassic"]:
            if "itemids" in config:
                for itemid in config["itemids"]:
                    fields.append({
                        "type": "4",  # ITEM
                        "name": "itemid",
                        "value": str(itemid)
                    })

            if "time_period" in config:
                fields.append({
                    "type": "1",
                    "name": "time_period.from",
                    "value": config["time_period"].get("from", "now-1h")
                })
                fields.append({
                    "type": "1",
                    "name": "time_period.to",
                    "value": config["time_period"].get("to", "now")
                })

        # Item value widgets
        elif widget_type == "item":
            if "itemid" in config:
                fields.append({
                    "type": "4",
                    "name": "itemid",
                    "value": str(config["itemid"])
                })

            if "show_description" in config:
                fields.append({
                    "type": "0",
                    "name": "show",
                    "value": "1" if config["show_description"] else "2"
                })

        # Map widget
        elif widget_type == "map":
            if "sysmapid" in config:
                fields.append({
                    "type": "6",  # MAP
                    "name": "sysmapid",
                    "value": str(config["sysmapid"])
                })

        # Gauge widget
        elif widget_type == "gauge":
            if "itemid" in config:
                fields.append({
                    "type": "4",
                    "name": "itemid",
                    "value": str(config["itemid"])
                })

            if "min" in config:
                fields.append({
                    "type": "1",
                    "name": "min",
                    "value": str(config["min"])
                })

            if "max" in config:
                fields.append({
                    "type": "1",
                    "name": "max",
                    "value": str(config["max"])
                })

        # Geomap widget
        elif widget_type == "geomap":
            if "hostids" in config:
                for hostid in config["hostids"]:
                    fields.append({
                        "type": "2",  # HOST
                        "name": "hostid",
                        "value": str(hostid)
                    })

        # Top hosts/items/triggers
        elif widget_type in ["tophosts", "topitems", "toptriggers"]:
            if "columns" in config:
                for idx, col in enumerate(config["columns"]):
                    fields.append({
                        "type": "1",
                        "name": f"columns.{idx}.name",
                        "value": col.get("name", "")
                    })
                    if "item" in col:
                        fields.append({
                            "type": "1",
                            "name": f"columns.{idx}.item",
                            "value": col["item"]
                        })

        # SLA report
        elif widget_type == "slareport":
            if "slaid" in config:
                fields.append({
                    "type": "1",
                    "name": "slaid",
                    "value": str(config["slaid"])
                })

        # URL widget
        elif widget_type == "url":
            if "url" in config:
                fields.append({
                    "type": "1",
                    "name": "url",
                    "value": config["url"]
                })

        # Clock widget
        elif widget_type == "clock":
            if "time_type" in config:
                fields.append({
                    "type": "0",
                    "name": "time_type",
                    "value": str(config["time_type"])
                })

        return fields

    def add_widget(
        self,
        dashboard_id: str,
        widget_type: str,
        name: str,
        page_index: int = 0,
        position: Optional[Dict[str, int]] = None,
        config: Optional[Dict[str, Any]] = None,
        show_header: bool = True,
        refresh_interval: int = 60
    ) -> Dict[str, Any]:
        """
        Add widget to dashboard.

        Args:
            dashboard_id: Dashboard ID
            widget_type: Widget type (see WIDGET_TYPES)
            name: Widget name
            page_index: Page index (0-based)
            position: Dict with x, y, width, height
            config: Widget-specific configuration
            show_header: Show widget header
            refresh_interval: Refresh interval in seconds

        Returns:
            Dict with result

        Raises:
            ValueError: If parameters invalid
            ZabbixAPIException: If API call fails
        """
        if widget_type not in WIDGET_TYPES:
            raise ValueError(f"Invalid widget type. Valid types: {', '.join(WIDGET_TYPES.keys())}")

        # Get dashboard
        dashboards = self.zapi.dashboard.get(
            dashboardids=dashboard_id,
            output="extend",
            selectPages="extend"
        )

        if not dashboards:
            raise ValueError(f"Dashboard ID {dashboard_id} not found")

        dashboard = dashboards[0]

        if page_index >= len(dashboard["pages"]):
            raise ValueError(f"Page index {page_index} out of range (max: {len(dashboard['pages']) - 1})")

        # Set default position if not provided
        if not position:
            position = {
                "x": 0,
                "y": 0,
                "width": self.DEFAULT_WIDTH,
                "height": self.DEFAULT_HEIGHT
            }

        # Validate position
        self._validate_position(
            position["x"],
            position["y"],
            position["width"],
            position["height"]
        )

        # Build widget fields
        fields = []
        if config:
            fields = self._build_widget_fields(WIDGET_TYPES[widget_type], config)

        # Create widget
        widget = {
            "type": WIDGET_TYPES[widget_type],
            "name": name,
            "x": position["x"],
            "y": position["y"],
            "width": position["width"],
            "height": position["height"],
            "view_mode": "0" if show_header else "1",
            "fields": fields
        }

        # Add widget to page
        dashboard["pages"][page_index]["widgets"].append(widget)

        # Update dashboard
        result = self.zapi.dashboard.update({
            "dashboardid": dashboard_id,
            "pages": dashboard["pages"]
        })

        print(f"[OK] Widget added successfully")
        print(f"  Dashboard ID: {dashboard_id}")
        print(f"  Widget type: {widget_type}")
        print(f"  Name: {name}")
        print(f"  Position: x={position['x']}, y={position['y']}, w={position['width']}, h={position['height']}")
        print(f"  Page: {page_index + 1}")

        return result

    def update_widget(
        self,
        dashboard_id: str,
        widget_index: int,
        page_index: int = 0,
        name: Optional[str] = None,
        position: Optional[Dict[str, int]] = None,
        config: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Update existing widget.

        Args:
            dashboard_id: Dashboard ID
            widget_index: Widget index on page (0-based)
            page_index: Page index (0-based)
            name: New widget name
            position: New position
            config: Updated configuration

        Returns:
            Dict with result

        Raises:
            ValueError: If parameters invalid
            ZabbixAPIException: If API call fails
        """
        # Get dashboard
        dashboards = self.zapi.dashboard.get(
            dashboardids=dashboard_id,
            output="extend",
            selectPages="extend"
        )

        if not dashboards:
            raise ValueError(f"Dashboard ID {dashboard_id} not found")

        dashboard = dashboards[0]

        if page_index >= len(dashboard["pages"]):
            raise ValueError(f"Page index {page_index} out of range")

        page = dashboard["pages"][page_index]

        if widget_index >= len(page["widgets"]):
            raise ValueError(f"Widget index {widget_index} out of range")

        widget = page["widgets"][widget_index]

        # Update properties
        if name:
            widget["name"] = name

        if position:
            self._validate_position(
                position.get("x", widget["x"]),
                position.get("y", widget["y"]),
                position.get("width", widget["width"]),
                position.get("height", widget["height"])
            )
            widget.update(position)

        if config:
            new_fields = self._build_widget_fields(widget["type"], config)
            widget["fields"] = new_fields

        # Update dashboard
        result = self.zapi.dashboard.update({
            "dashboardid": dashboard_id,
            "pages": dashboard["pages"]
        })

        print(f"[OK] Widget updated successfully")
        print(f"  Dashboard ID: {dashboard_id}")
        print(f"  Widget index: {widget_index}")
        print(f"  Page: {page_index + 1}")

        return result

    def delete_widget(
        self,
        dashboard_id: str,
        widget_index: int,
        page_index: int = 0
    ) -> Dict[str, Any]:
        """
        Delete widget from dashboard.

        Args:
            dashboard_id: Dashboard ID
            widget_index: Widget index on page (0-based)
            page_index: Page index (0-based)

        Returns:
            Dict with result

        Raises:
            ValueError: If parameters invalid
            ZabbixAPIException: If API call fails
        """
        # Get dashboard
        dashboards = self.zapi.dashboard.get(
            dashboardids=dashboard_id,
            output="extend",
            selectPages="extend"
        )

        if not dashboards:
            raise ValueError(f"Dashboard ID {dashboard_id} not found")

        dashboard = dashboards[0]

        if page_index >= len(dashboard["pages"]):
            raise ValueError(f"Page index {page_index} out of range")

        page = dashboard["pages"][page_index]

        if widget_index >= len(page["widgets"]):
            raise ValueError(f"Widget index {widget_index} out of range")

        widget_name = page["widgets"][widget_index]["name"]
        del page["widgets"][widget_index]

        # Update dashboard
        result = self.zapi.dashboard.update({
            "dashboardid": dashboard_id,
            "pages": dashboard["pages"]
        })

        print(f"[OK] Widget deleted successfully")
        print(f"  Dashboard ID: {dashboard_id}")
        print(f"  Widget: {widget_name}")
        print(f"  Page: {page_index + 1}")

        return result

    def list_widgets(self, dashboard_id: str, page_index: int = 0) -> List[Dict[str, Any]]:
        """
        List widgets on dashboard page.

        Args:
            dashboard_id: Dashboard ID
            page_index: Page index (0-based)

        Returns:
            List of widget details
        """
        # Get dashboard
        dashboards = self.zapi.dashboard.get(
            dashboardids=dashboard_id,
            output="extend",
            selectPages="extend"
        )

        if not dashboards:
            raise ValueError(f"Dashboard ID {dashboard_id} not found")

        dashboard = dashboards[0]

        if page_index >= len(dashboard["pages"]):
            raise ValueError(f"Page index {page_index} out of range")

        widgets = dashboard["pages"][page_index]["widgets"]

        print(f"\nDashboard: {dashboard['name']} (ID: {dashboard_id})")
        print(f"Page: {page_index + 1} / {len(dashboard['pages'])}\n")
        print(f"{'#':<4} {'Type':<20} {'Name':<30} {'Position':<25}")
        print("-" * 80)

        for idx, widget in enumerate(widgets):
            pos = f"x:{widget['x']} y:{widget['y']} w:{widget['width']} h:{widget['height']}"
            print(f"{idx:<4} {widget['type']:<20} {widget['name']:<30} {pos:<25}")

        print(f"\nTotal: {len(widgets)} widgets")

        return widgets


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Zabbix Widget Builder",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument("--url", required=True, help="Zabbix server URL")
    parser.add_argument("--token", required=True, help="API token")

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add widget")
    add_parser.add_argument("--dashboard-id", required=True, help="Dashboard ID")
    add_parser.add_argument("--widget-type", required=True, choices=list(WIDGET_TYPES.keys()), help="Widget type")
    add_parser.add_argument("--name", required=True, help="Widget name")
    add_parser.add_argument("--page-index", type=int, default=0, help="Page index (0-based)")
    add_parser.add_argument("--position", help="Position JSON: {x:0,y:0,width:12,height:5}")
    add_parser.add_argument("--config", help="Widget config JSON")
    add_parser.add_argument("--hide-header", action="store_true", help="Hide widget header")
    add_parser.add_argument("--refresh-interval", type=int, default=60, help="Refresh interval")

    # Update command
    update_parser = subparsers.add_parser("update", help="Update widget")
    update_parser.add_argument("--dashboard-id", required=True, help="Dashboard ID")
    update_parser.add_argument("--widget-index", type=int, required=True, help="Widget index")
    update_parser.add_argument("--page-index", type=int, default=0, help="Page index")
    update_parser.add_argument("--name", help="New name")
    update_parser.add_argument("--position", help="Position JSON")
    update_parser.add_argument("--config", help="Config JSON")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete widget")
    delete_parser.add_argument("--dashboard-id", required=True, help="Dashboard ID")
    delete_parser.add_argument("--widget-index", type=int, required=True, help="Widget index")
    delete_parser.add_argument("--page-index", type=int, default=0, help="Page index")

    # List command
    list_parser = subparsers.add_parser("list", help="List widgets")
    list_parser.add_argument("--dashboard-id", required=True, help="Dashboard ID")
    list_parser.add_argument("--page-index", type=int, default=0, help="Page index")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    try:
        builder = ZabbixWidgetBuilder(args.url, args.token)

        if args.command == "add":
            position = json.loads(args.position) if args.position else None
            config = json.loads(args.config) if args.config else None

            builder.add_widget(
                dashboard_id=args.dashboard_id,
                widget_type=args.widget_type,
                name=args.name,
                page_index=args.page_index,
                position=position,
                config=config,
                show_header=not args.hide_header,
                refresh_interval=args.refresh_interval
            )

        elif args.command == "update":
            position = json.loads(args.position) if args.position else None
            config = json.loads(args.config) if args.config else None

            builder.update_widget(
                dashboard_id=args.dashboard_id,
                widget_index=args.widget_index,
                page_index=args.page_index,
                name=args.name,
                position=position,
                config=config
            )

        elif args.command == "delete":
            builder.delete_widget(
                dashboard_id=args.dashboard_id,
                widget_index=args.widget_index,
                page_index=args.page_index
            )

        elif args.command == "list":
            builder.list_widgets(
                dashboard_id=args.dashboard_id,
                page_index=args.page_index
            )

        return 0

    except Exception as e:
        print(f"[ERROR] Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
