# Exporting/Importing Configurations in Zabbix

Complete toolkit for Zabbix configuration management including export, import, backup, migration, and version control workflows.

## Quick Start

### Installation

```bash
# Install dependencies
pip install pyzabbix pyyaml deepdiff

# Set environment variables
export ZABBIX_URL="https://zabbix.example.com"
export ZABBIX_TOKEN="your_api_token"
```

### Basic Operations

```bash
# Export a template
python scripts/zabbix_config_exporter.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --type templates \
    --ids 10571 \
    --format yaml \
    --output template.yaml

# Import configuration
python scripts/zabbix_config_importer.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --file template.yaml \
    --format yaml \
    --create-missing \
    --update-existing

# Full backup
python scripts/zabbix_config_backup.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --output-dir ./backups/$(date +%Y%m%d) \
    --format yaml \
    --include-all
```

## Scripts Overview

### Core Scripts

1. **zabbix_config_exporter.py** - Export configurations with dependency resolution
2. **zabbix_config_importer.py** - Import with validation and rule control
3. **zabbix_config_backup.py** - Automated backup with retention policies
4. **zabbix_config_migrate.py** - Environment migration with transformations
5. **zabbix_config_diff.py** - Compare configurations
6. **zabbix_config_merge.py** - Merge multiple configurations
7. **validate_config_import.py** - Pre-import validation
8. **format_converter.py** - Convert between XML/JSON/YAML
9. **git_workflow.py** - Git integration for version control

### Usage Examples

#### Export Templates with Dependencies
```bash
python scripts/zabbix_config_exporter.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --type templates \
    --name-pattern "Linux*" \
    --format yaml \
    --include-dependencies \
    --output linux_templates.yaml
```

#### Import with Validation
```bash
# Validate first
python scripts/validate_config_import.py \
    --file template.yaml \
    --format yaml \
    --check-dependencies

# Import if valid
python scripts/zabbix_config_importer.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --file template.yaml \
    --format yaml \
    --create-missing \
    --update-existing \
    --dry-run
```

#### Migrate Between Environments
```bash
python scripts/zabbix_config_migrate.py \
    --source-url https://zabbix-dev.example.com \
    --source-token $DEV_TOKEN \
    --target-url https://zabbix-prod.example.com \
    --target-token $PROD_TOKEN \
    --types templates hosts \
    --transform-config ./examples/migration_plan.yaml \
    --dry-run
```

#### Git Integration
```bash
# Export and commit
python scripts/git_workflow.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --repo ./zabbix-configs \
    --operation export-commit \
    --message "Daily backup" \
    --format yaml

# Import from branch
python scripts/git_workflow.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --repo ./zabbix-configs \
    --operation import-from-branch \
    --branch production \
    --format yaml
```

## Common Workflows

### 1. Daily Backup Automation

```bash
#!/bin/bash
# daily_backup.sh

BACKUP_DIR="/backups/zabbix/$(date +%Y%m%d)"

python scripts/zabbix_config_backup.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --output-dir $BACKUP_DIR \
    --format yaml \
    --include-all \
    --compress \
    --retention-days 30

# Upload to S3 (optional)
aws s3 sync $BACKUP_DIR s3://backups/zabbix/$(date +%Y%m%d)/
```

Add to crontab:
```
0 2 * * * /path/to/daily_backup.sh
```

### 2. Template Development and Distribution

```bash
# 1. Export template from development
python scripts/zabbix_config_exporter.py \
    --url https://zabbix-dev.example.com \
    --token $DEV_TOKEN \
    --type templates \
    --name "Custom App Template" \
    --format yaml \
    --include-dependencies \
    --add-metadata \
    --output custom_app_v1.yaml

# 2. Validate
python scripts/validate_config_import.py \
    --file custom_app_v1.yaml \
    --format yaml \
    --check-all

# 3. Import to staging
python scripts/zabbix_config_importer.py \
    --url https://zabbix-staging.example.com \
    --token $STAGING_TOKEN \
    --file custom_app_v1.yaml \
    --format yaml \
    --create-missing \
    --validate-only

# 4. Import to production (after testing)
python scripts/zabbix_config_importer.py \
    --url https://zabbix-prod.example.com \
    --token $PROD_TOKEN \
    --file custom_app_v1.yaml \
    --format yaml \
    --create-missing \
    --create-rollback ./rollback/
```

### 3. Infrastructure as Code with Git

```bash
# Initialize repository
mkdir zabbix-configs && cd zabbix-configs
git init

# Export all configurations
python scripts/git_workflow.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --repo . \
    --operation full-export \
    --format yaml \
    --organize-by-type

# Commit
git add .
git commit -m "Initial Zabbix configuration"
git remote add origin git@github.com:yourorg/zabbix-configs.git
git push -u origin main

# Daily updates
python scripts/git_workflow.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --repo . \
    --operation export-commit \
    --message "Daily update $(date +%Y-%m-%d)" \
    --format yaml
```

### 4. Multi-Environment Management

```bash
# Export from production
python scripts/zabbix_config_exporter.py \
    --url https://zabbix-prod.example.com \
    --token $PROD_TOKEN \
    --type templates \
    --output prod_templates.yaml

# Transform for staging
python scripts/format_converter.py \
    --input prod_templates.yaml \
    --input-format yaml \
    --output staging_templates.yaml \
    --output-format yaml

# Apply transformations
# (Edit transformation rules in examples/transformation_rules.json)

# Import to staging
python scripts/zabbix_config_importer.py \
    --url https://zabbix-staging.example.com \
    --token $STAGING_TOKEN \
    --file staging_templates.yaml \
    --create-missing \
    --update-existing
```

## Configuration Examples

All example configurations are in the `examples/` directory:

- `export_templates.yaml` - Template export configurations
- `export_hosts.json` - Host export patterns
- `full_backup.yaml` - Backup configurations
- `migration_plan.yaml` - Migration workflows
- `selective_import.json` - Import rule templates
- `git_workflow.yaml` - Git integration examples
- `transformation_rules.json` - Configuration transformations
- `merge_configs.yaml` - Merge strategies

## Best Practices

### Export Best Practices

1. **Always include dependencies** when exporting templates
2. **Use meaningful names** for export files (include version/date)
3. **Add metadata** for tracking (version, author, purpose)
4. **Use YAML format** for human readability and version control
5. **Export by tags** for organized exports

### Import Best Practices

1. **Always validate first** with `--validate-only`
2. **Use dry-run** to test imports without changes
3. **Create rollback points** before critical imports
4. **Never use deleteMissing** without careful review
5. **Test in non-production** first

### Backup Best Practices

1. **Schedule daily backups** with retention policy
2. **Verify backups** after creation
3. **Store backups offsite** (S3, NAS, etc.)
4. **Test restore procedures** regularly
5. **Use incremental backups** to save space

### Version Control Best Practices

1. **Commit configurations** to Git regularly
2. **Use meaningful commit messages**
3. **Tag releases** with version numbers
4. **Create branches** for different environments
5. **Review changes** before applying

## Troubleshooting

### Common Issues

#### Import Fails with Permission Error
```bash
# Check user permissions
# Ensure API token has sufficient rights
# Verify user role allows configuration import
```

#### Circular Dependency Detected
```bash
# Use dependency analysis
python scripts/zabbix_config_exporter.py \
    --analyze-dependencies \
    --output-graph dependencies.png
```

#### UUID Conflicts
```bash
# Validate configuration
python scripts/validate_config_import.py \
    --file config.yaml \
    --check-uuid-consistency
```

#### Import Partially Succeeds
```bash
# Check import results
# Use --create-rollback for safety
# Review error messages
```

## Security Considerations

1. **Protect API tokens** - Use environment variables, never commit
2. **Encrypt backups** - Use encryption for sensitive data
3. **Access control** - Limit who can import configurations
4. **Audit trail** - Track all configuration changes
5. **Credential handling** - Remove passwords before export

## Integration with CI/CD

### GitLab CI Example

```yaml
# .gitlab-ci.yml
stages:
  - validate
  - deploy

validate_config:
  stage: validate
  script:
    - python scripts/validate_config_import.py --file template.yaml
  only:
    - merge_requests

deploy_to_staging:
  stage: deploy
  script:
    - python scripts/zabbix_config_importer.py
        --url $STAGING_URL
        --token $STAGING_TOKEN
        --file template.yaml
        --create-missing
  only:
    - staging

deploy_to_production:
  stage: deploy
  script:
    - python scripts/zabbix_config_importer.py
        --url $PROD_URL
        --token $PROD_TOKEN
        --file template.yaml
        --create-missing
        --create-rollback ./rollback/
  only:
    - main
  when: manual
```

## Support

For issues and questions:
1. Check the examples in `examples/` directory
2. Run scripts with `--help` for usage information
3. Review Zabbix API documentation
4. Check SKILL.md for detailed documentation

## License

See main repository LICENSE file.

## Contributing

Contributions welcome! Please:
1. Test thoroughly before submitting
2. Update documentation
3. Follow existing code style
4. Add examples for new features
