---
name: Exporting/Importing Configurations in Zabbix
description: Automates Zabbix configuration export/import for backup, version control, environment migration, and Infrastructure as Code workflows. Supports all configuration objects (templates, hosts, items, triggers, discovery rules) with multiple formats (XML, JSON, YAML), dependency resolution, validation, and Git integration. Use when backing up configurations, migrating between environments, implementing IaC workflows, version controlling Zabbix objects, or distributing templates.
categories: ["configuration", "backup", "migration", "automation", "devops"]
tags: ["export", "import", "backup", "migration", "git", "iac", "templates", "configuration-as-code", "disaster-recovery", "version-control"]
version: "1.0.0"
zabbix_versions: ["7.0", "6.4", "6.0"]
---

# Exporting/Importing Configurations in Zabbix

## Quick Start

### Basic Export
```python
# Export a single template
python scripts/zabbix_config_exporter.py \
    --url https://zabbix.example.com \
    --token $ZABBIX_TOKEN \
    --type templates \
    --ids 10571 \
    --format yaml \
    --output template.yaml

# Export multiple templates with dependencies
python scripts/zabbix_config_exporter.py \
    --url https://zabbix.example.com \
    --token $ZABBIX_TOKEN \
    --type templates \
    --ids 10571,10572,10573 \
    --format json \
    --output templates.json \
    --include-dependencies
```

### Basic Import
```python
# Import configuration with validation
python scripts/zabbix_config_importer.py \
    --url https://zabbix.example.com \
    --token $ZABBIX_TOKEN \
    --file template.yaml \
    --format yaml \
    --validate-only

# Import with rules
python scripts/zabbix_config_importer.py \
    --url https://zabbix.example.com \
    --token $ZABBIX_TOKEN \
    --file template.yaml \
    --format yaml \
    --create-missing \
    --update-existing
```

### Full Backup
```python
# Backup entire Zabbix configuration
python scripts/zabbix_config_backup.py \
    --url https://zabbix.example.com \
    --token $ZABBIX_TOKEN \
    --output-dir ./backups/$(date +%Y%m%d) \
    --format yaml \
    --include-all

# Incremental backup (only changed objects)
python scripts/zabbix_config_backup.py \
    --url https://zabbix.example.com \
    --token $ZABBIX_TOKEN \
    --output-dir ./backups/$(date +%Y%m%d) \
    --format yaml \
    --incremental \
    --baseline ./backups/20250101
```

## Core Capabilities

### 1. Export Operations
Export Zabbix configurations in multiple formats with dependency resolution:

```python
# Export templates with all dependencies
python scripts/zabbix_config_exporter.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --type templates \
    --ids 10571,10572 \
    --format yaml \
    --include-dependencies \
    --output templates_export.yaml

# Export hosts with host groups
python scripts/zabbix_config_exporter.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --type hosts \
    --ids 10001,10002 \
    --format json \
    --include-groups \
    --output hosts_export.json

# Export by name pattern
python scripts/zabbix_config_exporter.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --type templates \
    --name-pattern "Linux*" \
    --format yaml \
    --output linux_templates.yaml
```

**Exportable Objects:**
- Templates (with items, triggers, graphs, discovery rules)
- Hosts and host groups
- Template groups
- Items and item prototypes
- Triggers and trigger prototypes
- Discovery rules (LLD)
- Graphs and template dashboards
- Maps and images
- Media types
- Web scenarios (HTTP tests)
- Value maps

### 2. Import Operations
Import configurations with comprehensive validation and rules:

```python
# Validate before import
python scripts/validate_config_import.py \
    --file template.yaml \
    --format yaml \
    --check-dependencies \
    --check-conflicts

# Import with selective rules
python scripts/zabbix_config_importer.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --file template.yaml \
    --format yaml \
    --create-missing \
    --update-existing \
    --skip-items deleteMissing \
    --dry-run

# Bulk import from directory
python scripts/zabbix_config_importer.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --directory ./templates/ \
    --format yaml \
    --create-missing \
    --update-existing \
    --parallel 4
```

**Import Rules:**
- `createMissing`: Create new objects not in database
- `updateExisting`: Update existing objects with new data
- `deleteMissing`: Delete objects not in import (use carefully)
- Per-object type rules (items, triggers, graphs, etc.)
- Template linkage control

### 3. Backup and Recovery
Automated backup workflows with versioning:

```python
# Full backup
python scripts/zabbix_config_backup.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --output-dir ./backups/full_$(date +%Y%m%d_%H%M%S) \
    --format yaml \
    --compress \
    --include-all

# Selective backup
python scripts/zabbix_config_backup.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --output-dir ./backups/templates \
    --format yaml \
    --types templates,template_groups \
    --exclude-pattern "Test*"

# Restore from backup
python scripts/zabbix_config_importer.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --directory ./backups/full_20250114 \
    --format yaml \
    --create-missing \
    --update-existing \
    --restore-mode
```

### 4. Environment Migration
Migrate configurations between Zabbix environments:

```python
# Migrate from dev to staging
python scripts/zabbix_config_migrate.py \
    --source-url https://zabbix-dev.example.com \
    --source-token $DEV_TOKEN \
    --target-url https://zabbix-staging.example.com \
    --target-token $STAGING_TOKEN \
    --types templates,hosts \
    --transform-config ./examples/migration_plan.yaml \
    --dry-run

# Migration with transformations
python scripts/zabbix_config_migrate.py \
    --source-url $SOURCE_URL \
    --source-token $SOURCE_TOKEN \
    --target-url $TARGET_URL \
    --target-token $TARGET_TOKEN \
    --config ./examples/migration_plan.yaml \
    --apply
```

### 5. Configuration Comparison
Compare configurations between environments or versions:

```python
# Compare two configurations
python scripts/zabbix_config_diff.py \
    --source template_v1.yaml \
    --target template_v2.yaml \
    --format yaml \
    --output diff_report.json \
    --show-changes

# Compare environments
python scripts/zabbix_config_diff.py \
    --source-url https://zabbix-dev.example.com \
    --source-token $DEV_TOKEN \
    --target-url https://zabbix-prod.example.com \
    --target-token $PROD_TOKEN \
    --types templates \
    --output env_diff.html
```

### 6. Configuration Merging
Merge configurations from multiple sources:

```python
# Merge templates
python scripts/zabbix_config_merge.py \
    --inputs template1.yaml template2.yaml template3.yaml \
    --output merged_template.yaml \
    --format yaml \
    --resolve-conflicts prefer-newer \
    --validate

# Merge with rules
python scripts/zabbix_config_merge.py \
    --config ./examples/merge_configs.yaml \
    --output merged_output.yaml \
    --format yaml
```

### 7. Format Conversion
Convert between XML, JSON, and YAML formats:

```python
# Convert XML to YAML
python scripts/format_converter.py \
    --input template.xml \
    --input-format xml \
    --output template.yaml \
    --output-format yaml \
    --pretty-print

# Convert JSON to XML
python scripts/format_converter.py \
    --input config.json \
    --input-format json \
    --output config.xml \
    --output-format xml \
    --validate
```

### 8. Git Integration
Version control workflows with Git:

```python
# Export and commit to Git
python scripts/git_workflow.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --repo ./zabbix-configs \
    --operation export-commit \
    --message "Daily backup $(date +%Y-%m-%d)" \
    --format yaml

# Import from Git branch
python scripts/git_workflow.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --repo ./zabbix-configs \
    --operation import-from-branch \
    --branch production \
    --format yaml \
    --create-missing \
    --update-existing

# Track configuration changes
python scripts/git_workflow.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --repo ./zabbix-configs \
    --operation track-changes \
    --since "7 days ago"
```

## Use Cases

### Use Case 1: Daily Backup Automation
```bash
# Cron job for daily backups
0 2 * * * python /opt/zabbix-scripts/zabbix_config_backup.py \
    --url https://zabbix.example.com \
    --token $ZABBIX_TOKEN \
    --output-dir /backups/zabbix/$(date +\%Y\%m\%d) \
    --format yaml \
    --compress \
    --include-all \
    --retention-days 30
```

### Use Case 2: Template Distribution
```bash
# Export template for distribution
python scripts/zabbix_config_exporter.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --type templates \
    --name "Custom Application Template" \
    --format yaml \
    --include-dependencies \
    --output custom_app_template.yaml \
    --add-metadata

# Import on target system
python scripts/zabbix_config_importer.py \
    --url $TARGET_URL \
    --token $TARGET_TOKEN \
    --file custom_app_template.yaml \
    --format yaml \
    --create-missing \
    --update-existing
```

### Use Case 3: Infrastructure as Code
```bash
# Structure: zabbix-configs/
#   templates/
#   hosts/
#   host_groups/
#   maps/

# Export all to Git repository
python scripts/git_workflow.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --repo ./zabbix-configs \
    --operation full-export \
    --format yaml \
    --organize-by-type

# Apply changes from repository
python scripts/git_workflow.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --repo ./zabbix-configs \
    --operation apply-changes \
    --since-commit HEAD~1 \
    --validate-first
```

### Use Case 4: Multi-Environment Management
```bash
# Export from production
python scripts/zabbix_config_exporter.py \
    --url https://zabbix-prod.example.com \
    --token $PROD_TOKEN \
    --type templates \
    --output prod_templates.yaml

# Transform for staging
python scripts/format_converter.py \
    --input prod_templates.yaml \
    --transform ./examples/transformation_rules.json \
    --output staging_templates.yaml

# Import to staging
python scripts/zabbix_config_importer.py \
    --url https://zabbix-staging.example.com \
    --token $STAGING_TOKEN \
    --file staging_templates.yaml \
    --create-missing \
    --update-existing
```

## Configuration Examples

See comprehensive examples in the `examples/` directory:
- `examples/export_templates.yaml` - Template export configurations
- `examples/export_hosts.json` - Host export patterns
- `examples/full_backup.yaml` - Full backup settings
- `examples/migration_plan.yaml` - Migration workflows
- `examples/selective_import.json` - Import rule patterns
- `examples/git_workflow.yaml` - Git integration
- `examples/transformation_rules.json` - Configuration transformations
- `examples/merge_configs.yaml` - Merge strategies

## Important Notes

### Dependency Resolution
- Scripts automatically resolve template dependencies
- Host group dependencies are tracked
- Value maps are included with templates
- Linked templates are optionally included

### Validation
- Pre-import validation checks for conflicts
- Circular dependency detection
- UUID consistency verification
- Permission validation

### Safety
- Always use `--dry-run` for testing
- Validate before import with `--validate-only`
- Use `--backup-before-import` for safety
- Never use `deleteMissing` without verification

### Performance
- Use `--parallel` for bulk operations
- Incremental backups save time and space
- Filter exports to reduce data size
- Use compression for large backups

### Version Compatibility
- Export/import between same major versions
- Format version is embedded in exports
- Scripts validate version compatibility
- Transformations may be needed for version migrations

## Common Workflows

### Workflow 1: Template Development Cycle
1. Export template from dev: `zabbix_config_exporter.py --type templates`
2. Commit to Git: `git add template.yaml && git commit`
3. Review changes: `git diff`
4. Import to staging: `zabbix_config_importer.py --validate-only`
5. Test in staging
6. Import to production: `zabbix_config_importer.py --create-missing`

### Workflow 2: Disaster Recovery
1. Regular backups: `zabbix_config_backup.py --include-all`
2. Store offsite: `rsync backups/ remote:/backups/`
3. On recovery: `zabbix_config_importer.py --directory ./backups/latest`
4. Validate: `zabbix_config_diff.py --compare-with-backup`
5. Test critical monitors

### Workflow 3: Configuration Standardization
1. Create standard template
2. Export: `zabbix_config_exporter.py --type templates`
3. Distribute to teams
4. Import on all Zabbix instances
5. Track compliance: `zabbix_config_diff.py --check-standard`

## Advanced Features

### Dependency Graph Analysis
```python
# Analyze dependencies
python scripts/zabbix_config_exporter.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --type templates \
    --ids 10571 \
    --analyze-dependencies \
    --output-graph dependencies.png
```

### Selective Export by Tags
```python
# Export templates by tag
python scripts/zabbix_config_exporter.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --type templates \
    --tags "environment:production,team:infrastructure" \
    --format yaml
```

### Configuration Validation
```python
# Validate configuration integrity
python scripts/validate_config_import.py \
    --file template.yaml \
    --format yaml \
    --check-all \
    --strict
```

### Rollback Support
```python
# Create rollback point before import
python scripts/zabbix_config_importer.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --file new_config.yaml \
    --create-rollback ./rollback/

# Rollback if needed
python scripts/zabbix_config_importer.py \
    --url $ZABBIX_URL \
    --token $ZABBIX_TOKEN \
    --rollback ./rollback/rollback_timestamp.yaml
```

## Error Handling

All scripts include comprehensive error handling:
- Connection errors with retry logic
- Permission errors with clear messages
- Validation errors with detailed reports
- Partial import recovery
- Rollback on critical failures

## Integration with CI/CD

```yaml
# GitLab CI example
export-zabbix-config:
  script:
    - python scripts/zabbix_config_exporter.py --config ci-config.yaml
    - git add configs/
    - git commit -m "Automated config export"
  schedule: daily

import-to-staging:
  script:
    - python scripts/zabbix_config_importer.py --validate-only
    - python scripts/zabbix_config_importer.py --apply
  only:
    - staging

import-to-production:
  script:
    - python scripts/zabbix_config_importer.py --validate-only
    - python scripts/zabbix_config_importer.py --apply --create-rollback
  only:
    - production
  when: manual
```

## Getting Help

Run any script with `--help` for detailed usage:
```bash
python scripts/zabbix_config_exporter.py --help
python scripts/zabbix_config_importer.py --help
python scripts/zabbix_config_backup.py --help
```

## See Also

- Zabbix API documentation: [configuration.export](https://www.zabbix.com/documentation/current/en/manual/api/reference/configuration/export)
- Zabbix API documentation: [configuration.import](https://www.zabbix.com/documentation/current/en/manual/api/reference/configuration/import)
- Infrastructure as Code best practices
- Git workflow strategies
- Disaster recovery planning
