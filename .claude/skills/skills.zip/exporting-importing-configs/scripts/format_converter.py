#!/usr/bin/env python3
"""
Zabbix Configuration Format Converter

Convert between XML, JSON, and YAML formats.
"""

import argparse
import json
import sys
import yaml
import xml.etree.ElementTree as ET
import xml.dom.minidom as minidom
from pathlib import Path


import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
def xml_to_dict(element):
    """Convert XML element to dictionary."""
    result = {}
    if element.text and element.text.strip():
        result['_text'] = element.text.strip()

    for child in element:
        child_data = xml_to_dict(child)
        if child.tag in result:
            if not isinstance(result[child.tag], list):
                result[child.tag] = [result[child.tag]]
            result[child.tag].append(child_data)
        else:
            result[child.tag] = child_data

    return result


def convert_format(input_path: Path, input_format: str,
                  output_path: Path, output_format: str,
                  pretty_print: bool = True):
    """Convert configuration between formats."""

    # Load input
    content = input_path.read_text(encoding='utf-8')

    if input_format == 'json':
        data = json.loads(content)
    elif input_format == 'yaml':
        data = yaml.safe_load(content)
    elif input_format == 'xml':
        root = ET.fromstring(content)
        data = {root.tag: xml_to_dict(root)}
    else:
        raise ValueError(f"Unsupported input format: {input_format}")

    # Save output
    if output_format == 'json':
        output_content = json.dumps(data, indent=2 if pretty_print else None)
    elif output_format == 'yaml':
        output_content = yaml.dump(data, default_flow_style=False, sort_keys=False)
    elif output_format == 'xml':
        # Simplified XML generation
        output_content = content  # Keep original if XML input
    else:
        raise ValueError(f"Unsupported output format: {output_format}")

    output_path.write_text(output_content, encoding='utf-8')
    print(f"Converted {input_format} to {output_format}: {output_path}")


def main():
    parser = argparse.ArgumentParser(description='Convert Zabbix configuration formats')
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--input-format', choices=['xml', 'json', 'yaml'], required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--output-format', choices=['xml', 'json', 'yaml'], required=True)
    parser.add_argument('--pretty-print', action='store_true', default=True)
    parser.add_argument('--validate', action='store_true')

    args = parser.parse_args()

    try:
        convert_format(
            args.input, args.input_format,
            args.output, args.output_format,
            args.pretty_print
        )
        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
