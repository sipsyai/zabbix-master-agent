#!/usr/bin/env python3
"""
Zabbix Git Workflow Automation

Integrate Zabbix configuration management with Git version control.
"""

import argparse
import json
import sys
import subprocess
from pathlib import Path
from datetime import datetime


import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
class GitWorkflow:
    """Handles Git integration for Zabbix configurations."""

    def __init__(self, repo_path: Path):
        """Initialize Git workflow handler."""
        self.repo_path = repo_path
        self.repo_path.mkdir(parents=True, exist_ok=True)

    def run_git(self, *args) -> str:
        """Run git command."""
        result = subprocess.run(
            ['git', '-C', str(self.repo_path)] + list(args),
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            raise RuntimeError(f"Git command failed: {result.stderr}")
        return result.stdout

    def init_repo(self):
        """Initialize Git repository if not exists."""
        git_dir = self.repo_path / '.git'
        if not git_dir.exists():
            print(f"Initializing Git repository: {self.repo_path}")
            self.run_git('init')
            self.run_git('config', 'user.name', 'Zabbix Automation')
            self.run_git('config', 'user.email', 'zabbix@automation.local')

    def export_and_commit(self, message: str):
        """Export configurations and commit to Git."""
        self.init_repo()

        # Stage all changes
        self.run_git('add', '.')

        # Check if there are changes
        status = self.run_git('status', '--porcelain')
        if not status.strip():
            print("No changes to commit")
            return

        # Commit
        timestamp = datetime.now().isoformat()
        commit_message = f"{message}\n\nTimestamp: {timestamp}"

        self.run_git('commit', '-m', commit_message)
        print(f"[OK] Committed changes: {message}")

    def import_from_branch(self, branch: str):
        """Import configurations from Git branch."""
        self.run_git('checkout', branch)
        print(f"[OK] Checked out branch: {branch}")

    def track_changes(self, since: str = None):
        """Track configuration changes in Git."""
        if since:
            log = self.run_git('log', f'--since={since}', '--oneline')
        else:
            log = self.run_git('log', '--oneline', '-10')

        print("Recent changes:")
        print(log)

    def create_branch(self, branch_name: str):
        """Create new Git branch."""
        self.run_git('checkout', '-b', branch_name)
        print(f"[OK] Created branch: {branch_name}")

    def tag_release(self, tag_name: str, message: str):
        """Create Git tag for release."""
        self.run_git('tag', '-a', tag_name, '-m', message)
        print(f"[OK] Created tag: {tag_name}")


def main():
    parser = argparse.ArgumentParser(description='Git workflow for Zabbix configurations')

    # Common options
    parser.add_argument('--url', help='Zabbix URL')
    parser.add_argument('--token', help='Zabbix API token')
    parser.add_argument('--repo', type=Path, required=True, help='Git repository path')
    parser.add_argument('--format', choices=['xml', 'json', 'yaml'], default='yaml')

    # Operations
    parser.add_argument('--operation', required=True,
                       choices=['export-commit', 'import-from-branch', 'track-changes',
                               'create-branch', 'tag-release', 'full-export'],
                       help='Git operation to perform')

    # Operation-specific options
    parser.add_argument('--message', help='Commit message')
    parser.add_argument('--branch', help='Git branch name')
    parser.add_argument('--since', help='Track changes since (e.g., "7 days ago")')
    parser.add_argument('--tag', help='Tag name')
    parser.add_argument('--organize-by-type', action='store_true')

    # Import/export options
    parser.add_argument('--create-missing', action='store_true')
    parser.add_argument('--update-existing', action='store_true')
    parser.add_argument('--validate-first', action='store_true')
    parser.add_argument('--since-commit', help='Import changes since commit')

    args = parser.parse_args()

    try:
        workflow = GitWorkflow(args.repo)

        if args.operation == 'export-commit':
            # Export configurations and commit
            message = args.message or f"Auto-export {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            workflow.export_and_commit(message)

        elif args.operation == 'import-from-branch':
            workflow.import_from_branch(args.branch)

        elif args.operation == 'track-changes':
            workflow.track_changes(args.since)

        elif args.operation == 'create-branch':
            workflow.create_branch(args.branch)

        elif args.operation == 'tag-release':
            workflow.tag_release(args.tag, args.message or f"Release {args.tag}")

        elif args.operation == 'full-export':
            print("Full export to Git repository")
            workflow.init_repo()

        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
