#!/usr/bin/env python3
"""
Zabbix Configuration Import Validator

Validate configurations before import to catch errors early.
"""

import argparse
import json
import sys
import yaml
from pathlib import Path
from typing import Dict, List


import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
class ConfigValidator:
    """Validates Zabbix configuration before import."""

    def __init__(self):
        self.errors = []
        self.warnings = []

    def validate_file(self, file_path: Path, format: str) -> Dict:
        """Validate configuration file."""
        self.errors = []
        self.warnings = []

        try:
            content = file_path.read_text(encoding='utf-8')

            # Format validation
            if format == 'json':
                data = json.loads(content)
            elif format == 'yaml':
                data = yaml.safe_load(content)
            elif format == 'xml':
                import xml.etree.ElementTree as ET
                ET.fromstring(content)
                data = None
            else:
                self.errors.append(f"Unsupported format: {format}")
                return self._get_results()

            # Structure validation
            if data:
                self._validate_structure(data)
                self._check_required_fields(data)
                self._check_uuid_consistency(data)

            return self._get_results()

        except json.JSONDecodeError as e:
            self.errors.append(f"Invalid JSON: {e}")
        except yaml.YAMLError as e:
            self.errors.append(f"Invalid YAML: {e}")
        except Exception as e:
            self.errors.append(f"Validation error: {e}")

        return self._get_results()

    def _validate_structure(self, data: Dict):
        """Validate configuration structure."""
        if not isinstance(data, dict):
            self.errors.append("Configuration must be a dictionary")
            return

        # Check for zabbix_export root
        if 'zabbix_export' not in data:
            self.warnings.append("No 'zabbix_export' root found")

    def _check_required_fields(self, data: Dict):
        """Check for required fields in configuration."""
        if 'zabbix_export' in data:
            export_data = data['zabbix_export']

            # Check version
            if 'version' not in export_data:
                self.warnings.append("Missing version field")

            # Check for at least one object type
            object_types = ['templates', 'hosts', 'host_groups', 'maps', 'images', 'mediaTypes']
            has_objects = any(obj_type in export_data for obj_type in object_types)

            if not has_objects:
                self.warnings.append("No exportable objects found in configuration")

    def _check_uuid_consistency(self, data: Dict):
        """Check UUID consistency in configuration."""
        if 'zabbix_export' not in data:
            return

        uuids = set()
        duplicates = []

        def collect_uuids(obj):
            if isinstance(obj, dict):
                if 'uuid' in obj:
                    uuid = obj['uuid']
                    if uuid in uuids:
                        duplicates.append(uuid)
                    uuids.add(uuid)
                for value in obj.values():
                    collect_uuids(value)
            elif isinstance(obj, list):
                for item in obj:
                    collect_uuids(item)

        collect_uuids(data['zabbix_export'])

        if duplicates:
            self.errors.append(f"Duplicate UUIDs found: {duplicates}")

    def _get_results(self) -> Dict:
        """Get validation results."""
        return {
            'valid': len(self.errors) == 0,
            'errors': self.errors,
            'warnings': self.warnings
        }


def main():
    parser = argparse.ArgumentParser(description='Validate Zabbix configuration before import')
    parser.add_argument('--file', type=Path, required=True)
    parser.add_argument('--format', choices=['xml', 'json', 'yaml'], default='yaml')
    parser.add_argument('--check-dependencies', action='store_true')
    parser.add_argument('--check-conflicts', action='store_true')
    parser.add_argument('--strict', action='store_true',
                       help='Treat warnings as errors')

    args = parser.parse_args()

    try:
        validator = ConfigValidator()
        results = validator.validate_file(args.file, args.format)

        # Print results
        if results['valid']:
            print(f"[OK] Configuration is valid: {args.file}")
        else:
            print(f"[ERROR] Configuration validation failed: {args.file}")

        if results['errors']:
            print("\nErrors:")
            for error in results['errors']:
                print(f"  [ERROR] {error}")

        if results['warnings']:
            print("\nWarnings:")
            for warning in results['warnings']:
                print(f"  [WARN] {warning}")

        # Exit code
        has_issues = bool(results['errors'])
        if args.strict:
            has_issues = has_issues or bool(results['warnings'])

        return 1 if has_issues else 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
