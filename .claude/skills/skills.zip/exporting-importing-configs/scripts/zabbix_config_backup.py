#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Configuration Backup

Automated backup of Zabbix configurations with versioning, compression,
and incremental backup support.

Usage:
    python zabbix_config_backup.py --url <zabbix_url> --token <token> \
        --output-dir ./backups --format yaml --include-all

Features:
    - Full and incremental backups
    - Multiple format support
    - Compression and retention policies
    - Backup verification
    - Restore capabilities
    - Scheduled backup support
"""

import argparse
import json
import sys
import yaml
import hashlib
import gzip
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Set
from datetime import datetime, timedelta

try:
    from pyzabbix import ZabbixAPI
except ImportError:
    print("Error: pyzabbix library not found. Install with: pip install pyzabbix")
    sys.exit(1)


# Constants
SUPPORTED_FORMATS = ['xml', 'json', 'yaml']
OBJECT_TYPES = [
    'templates', 'hosts', 'host_groups', 'template_groups',
    'maps', 'images', 'mediaTypes'
]


class ZabbixConfigBackup:
    """Handles Zabbix configuration backup operations."""

    def __init__(self, url: str, token: str, verify_ssl: bool = True):
        """
        Initialize Zabbix API connection.

        Args:
            url: Zabbix server URL
            token: API authentication token
            verify_ssl: Whether to verify SSL certificates
        """
        self.zapi = ZabbixAPI(url)
        self.zapi.session.verify = verify_ssl
        self.zapi.login(api_token=token)

    def get_all_objects(self, object_type: str) -> List[str]:
        """
        Get all object IDs of a specific type.

        Args:
            object_type: Type of object

        Returns:
            List of object IDs
        """
        method_map = {
            'templates': (self.zapi.template.get, 'templateid'),
            'hosts': (self.zapi.host.get, 'hostid'),
            'host_groups': (self.zapi.hostgroup.get, 'groupid'),
            'template_groups': (self.zapi.templategroup.get, 'groupid'),
            'maps': (self.zapi.map.get, 'sysmapid'),
            'images': (self.zapi.image.get, 'imageid'),
            'mediaTypes': (self.zapi.mediatype.get, 'mediatypeid')
        }

        if object_type not in method_map:
            raise ValueError(f"Unsupported object type: {object_type}")

        method, id_key = method_map[object_type]
        objects = method(output='extend')

        return [obj[id_key] for obj in objects]

    def export_objects(self, object_type: str, object_ids: List[str],
                      format: str) -> str:
        """
        Export objects using Zabbix API.

        Args:
            object_type: Type of objects
            object_ids: List of object IDs
            format: Output format

        Returns:
            Exported configuration
        """
        # Map type to API parameter
        api_params = {
            'templates': 'templates',
            'hosts': 'hosts',
            'host_groups': 'host_groups',
            'template_groups': 'template_groups',
            'maps': 'maps',
            'images': 'images',
            'mediaTypes': 'mediaTypes'
        }

        options = {api_params[object_type]: object_ids}

        # Export
        export_format = 'json' if format == 'yaml' else format
        result = self.zapi.configuration.export(
            format=export_format,
            prettyprint=True,
            options=options
        )

        # Convert to YAML if needed
        if format == 'yaml':
            data = json.loads(result)
            result = yaml.dump(data, default_flow_style=False, sort_keys=False)

        return result

    def full_backup(self, output_dir: Path, format: str,
                   types: Optional[List[str]] = None,
                   exclude_pattern: Optional[str] = None) -> Dict:
        """
        Perform full backup of all configurations.

        Args:
            output_dir: Output directory
            format: Output format
            types: Object types to backup (None = all)
            exclude_pattern: Pattern for objects to exclude

        Returns:
            Backup metadata
        """
        backup_types = types or OBJECT_TYPES
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

        output_dir.mkdir(parents=True, exist_ok=True)

        metadata = {
            'backup_type': 'full',
            'timestamp': timestamp,
            'format': format,
            'objects': {}
        }

        print(f"Starting full backup to {output_dir}")

        for obj_type in backup_types:
            print(f"Backing up {obj_type}...")

            try:
                # Get all objects
                object_ids = self.get_all_objects(obj_type)

                if not object_ids:
                    print(f"  No {obj_type} found")
                    continue

                # Export
                config = self.export_objects(obj_type, object_ids, format)

                # Save to file
                ext = 'yaml' if format == 'yaml' else format
                filename = f"{obj_type}.{ext}"
                filepath = output_dir / filename

                filepath.write_text(config, encoding='utf-8')

                # Calculate checksum
                checksum = hashlib.sha256(config.encode()).hexdigest()

                metadata['objects'][obj_type] = {
                    'count': len(object_ids),
                    'file': filename,
                    'checksum': checksum,
                    'size_bytes': len(config)
                }

                print(f"  [OK] Backed up {len(object_ids)} {obj_type} to {filename}")

            except Exception as e:
                print(f"  [ERROR] Error backing up {obj_type}: {e}")
                metadata['objects'][obj_type] = {
                    'error': str(e)
                }

        # Save metadata
        metadata_file = output_dir / 'backup_metadata.json'
        metadata_file.write_text(json.dumps(metadata, indent=2))

        print(f"\nBackup complete: {output_dir}")
        print(f"Metadata: {metadata_file}")

        return metadata

    def incremental_backup(self, output_dir: Path, baseline_dir: Path,
                          format: str) -> Dict:
        """
        Perform incremental backup (only changed objects).

        Args:
            output_dir: Output directory
            baseline_dir: Baseline backup directory
            format: Output format

        Returns:
            Backup metadata
        """
        # Load baseline metadata
        baseline_metadata_file = baseline_dir / 'backup_metadata.json'
        if not baseline_metadata_file.exists():
            raise ValueError(f"Baseline metadata not found: {baseline_metadata_file}")

        baseline_metadata = json.loads(baseline_metadata_file.read_text())

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_dir.mkdir(parents=True, exist_ok=True)

        metadata = {
            'backup_type': 'incremental',
            'timestamp': timestamp,
            'baseline': str(baseline_dir),
            'format': format,
            'objects': {},
            'changes': []
        }

        print(f"Starting incremental backup (baseline: {baseline_dir})")

        for obj_type in OBJECT_TYPES:
            if obj_type not in baseline_metadata.get('objects', {}):
                continue

            print(f"Checking {obj_type}...")

            try:
                # Get current objects
                object_ids = self.get_all_objects(obj_type)

                if not object_ids:
                    continue

                # Export current configuration
                current_config = self.export_objects(obj_type, object_ids, format)
                current_checksum = hashlib.sha256(current_config.encode()).hexdigest()

                # Compare with baseline
                baseline_checksum = baseline_metadata['objects'][obj_type].get('checksum')

                if current_checksum != baseline_checksum:
                    # Configuration changed, save it
                    ext = 'yaml' if format == 'yaml' else format
                    filename = f"{obj_type}.{ext}"
                    filepath = output_dir / filename

                    filepath.write_text(current_config, encoding='utf-8')

                    metadata['objects'][obj_type] = {
                        'count': len(object_ids),
                        'file': filename,
                        'checksum': current_checksum,
                        'size_bytes': len(current_config),
                        'changed': True
                    }

                    metadata['changes'].append(obj_type)

                    print(f"  [OK] Changed: Backed up {len(object_ids)} {obj_type}")
                else:
                    print(f"  = Unchanged: {obj_type}")
                    metadata['objects'][obj_type] = {
                        'changed': False,
                        'checksum': current_checksum
                    }

            except Exception as e:
                print(f"  [ERROR] Error checking {obj_type}: {e}")
                metadata['objects'][obj_type] = {
                    'error': str(e)
                }

        # Save metadata
        metadata_file = output_dir / 'backup_metadata.json'
        metadata_file.write_text(json.dumps(metadata, indent=2))

        print(f"\nIncremental backup complete: {output_dir}")
        print(f"Changed object types: {', '.join(metadata['changes']) or 'none'}")

        return metadata

    def compress_backup(self, backup_dir: Path) -> Path:
        """
        Compress backup directory.

        Args:
            backup_dir: Backup directory to compress

        Returns:
            Path to compressed file
        """
        print(f"Compressing backup: {backup_dir}")

        archive_path = backup_dir.parent / f"{backup_dir.name}.tar.gz"

        shutil.make_archive(
            str(backup_dir),
            'gztar',
            root_dir=backup_dir.parent,
            base_dir=backup_dir.name
        )

        print(f"Backup compressed: {archive_path}")
        return archive_path

    def cleanup_old_backups(self, backup_root: Path, retention_days: int):
        """
        Remove old backups based on retention policy.

        Args:
            backup_root: Root backup directory
            retention_days: Number of days to keep backups
        """
        cutoff_date = datetime.now() - timedelta(days=retention_days)

        print(f"Cleaning up backups older than {retention_days} days...")

        removed_count = 0

        for item in backup_root.iterdir():
            if item.is_dir():
                # Check if directory name matches timestamp pattern
                try:
                    dir_date = datetime.strptime(item.name, '%Y%m%d_%H%M%S')
                    if dir_date < cutoff_date:
                        shutil.rmtree(item)
                        removed_count += 1
                        print(f"  Removed: {item.name}")
                except ValueError:
                    # Not a timestamped backup directory
                    continue

        print(f"Cleanup complete: {removed_count} backups removed")

    def verify_backup(self, backup_dir: Path) -> bool:
        """
        Verify backup integrity.

        Args:
            backup_dir: Backup directory

        Returns:
            True if backup is valid
        """
        metadata_file = backup_dir / 'backup_metadata.json'

        if not metadata_file.exists():
            print(f"[ERROR] Metadata file not found: {metadata_file}")
            return False

        metadata = json.loads(metadata_file.read_text())

        print(f"Verifying backup: {backup_dir}")

        all_valid = True

        for obj_type, obj_data in metadata.get('objects', {}).items():
            if 'error' in obj_data:
                continue

            if not obj_data.get('changed', True):
                continue

            filename = obj_data.get('file')
            if not filename:
                continue

            filepath = backup_dir / filename

            if not filepath.exists():
                print(f"  [ERROR] Missing file: {filename}")
                all_valid = False
                continue

            # Verify checksum
            content = filepath.read_text(encoding='utf-8')
            checksum = hashlib.sha256(content.encode()).hexdigest()

            if checksum != obj_data.get('checksum'):
                print(f"  [ERROR] Checksum mismatch: {filename}")
                all_valid = False
            else:
                print(f"  [OK] Valid: {filename}")

        return all_valid


def main():
    parser = argparse.ArgumentParser(
        description='Backup Zabbix configurations with versioning and compression',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Full backup
  %(prog)s --url https://zabbix.example.com --token TOKEN --output-dir ./backups/full_20250114 --format yaml --include-all

  # Incremental backup
  %(prog)s --url https://zabbix.example.com --token TOKEN --output-dir ./backups/incr_20250114 --format yaml --incremental --baseline ./backups/full_20250101

  # Backup with compression and retention
  %(prog)s --url https://zabbix.example.com --token TOKEN --output-dir ./backups/full_20250114 --format yaml --include-all --compress --retention-days 30

  # Selective backup
  %(prog)s --url https://zabbix.example.com --token TOKEN --output-dir ./backups/templates --format yaml --types templates template_groups

  # Verify backup
  %(prog)s --verify ./backups/full_20250114
        """
    )

    # Connection parameters
    parser.add_argument('--url', help='Zabbix server URL')
    parser.add_argument('--token', help='API authentication token')
    parser.add_argument('--no-verify-ssl', action='store_true', help='Disable SSL verification')

    # Output
    parser.add_argument('--output-dir', type=Path, help='Output directory for backup')
    parser.add_argument('--format', choices=SUPPORTED_FORMATS, default='yaml',
                       help='Output format (default: yaml)')

    # Backup options
    parser.add_argument('--include-all', action='store_true',
                       help='Backup all object types')
    parser.add_argument('--types', nargs='+', choices=OBJECT_TYPES,
                       help='Specific object types to backup')
    parser.add_argument('--exclude-pattern', help='Exclude objects matching pattern')

    # Incremental backup
    parser.add_argument('--incremental', action='store_true',
                       help='Perform incremental backup')
    parser.add_argument('--baseline', type=Path,
                       help='Baseline backup directory for incremental')

    # Post-backup options
    parser.add_argument('--compress', action='store_true',
                       help='Compress backup after creation')
    parser.add_argument('--retention-days', type=int,
                       help='Remove backups older than N days')

    # Verification
    parser.add_argument('--verify', type=Path,
                       help='Verify existing backup')

    args = parser.parse_args()

    # Verify mode
    if args.verify:
        backup = ZabbixConfigBackup('', '')  # No connection needed
        valid = backup.verify_backup(args.verify)
        return 0 if valid else 1

    # Validate inputs
    if not args.url or not args.token:
        parser.error("--url and --token required for backup operations")

    if not args.output_dir:
        parser.error("--output-dir required")

    if not args.include_all and not args.types:
        parser.error("Must specify --include-all or --types")

    if args.incremental and not args.baseline:
        parser.error("--baseline required for incremental backup")

    try:
        # Initialize backup handler
        backup = ZabbixConfigBackup(
            args.url,
            args.token,
            verify_ssl=not args.no_verify_ssl
        )

        # Perform backup
        if args.incremental:
            metadata = backup.incremental_backup(
                args.output_dir,
                args.baseline,
                args.format
            )
        else:
            backup_types = args.types if args.types else None

            metadata = backup.full_backup(
                args.output_dir,
                args.format,
                backup_types,
                args.exclude_pattern
            )

        # Verify backup
        print("\nVerifying backup...")
        if backup.verify_backup(args.output_dir):
            print("[OK] Backup verification successful")
        else:
            print("[ERROR] Backup verification failed")
            return 1

        # Compress if requested
        if args.compress:
            backup.compress_backup(args.output_dir)

        # Cleanup old backups
        if args.retention_days:
            backup.cleanup_old_backups(
                args.output_dir.parent,
                args.retention_days
            )

        print("\n[OK] Backup complete")
        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
