#!/usr/bin/env python3
"""
Zabbix Configuration Diff Tool

Compare Zabbix configurations and generate diff reports.
"""

import argparse
import json
import sys
import yaml
from pathlib import Path
from typing import Dict, Any
from deepdiff import DeepDiff

import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
SUPPORTED_FORMATS = ['xml', 'json', 'yaml']


def load_config(file_path: Path, format: str) -> Dict:
    """Load configuration from file."""
    content = file_path.read_text(encoding='utf-8')

    if format == 'json':
        return json.loads(content)
    elif format == 'yaml':
        return yaml.safe_load(content)
    elif format == 'xml':
        import xml.etree.ElementTree as ET
        # Simple XML to dict conversion
        root = ET.fromstring(content)
        return {'xml_root': root.tag, 'content': content}
    return {}


def compare_configs(source: Dict, target: Dict) -> Dict:
    """Compare two configurations and return differences."""
    diff = DeepDiff(source, target, ignore_order=True, report_repetition=True)
    return diff.to_dict() if hasattr(diff, 'to_dict') else dict(diff)


def generate_report(diff: Dict, format: str = 'json') -> str:
    """Generate diff report in specified format."""
    if format == 'json':
        return json.dumps(diff, indent=2)
    elif format == 'yaml':
        return yaml.dump(diff, default_flow_style=False)
    elif format == 'text':
        report = []
        for key, value in diff.items():
            report.append(f"\n{key}:")
            report.append(f"  {value}")
        return '\n'.join(report)
    return str(diff)


def main():
    parser = argparse.ArgumentParser(description='Compare Zabbix configurations')
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--target', type=Path, required=True)
    parser.add_argument('--format', choices=SUPPORTED_FORMATS, default='yaml')
    parser.add_argument('--output', type=Path, help='Output file')
    parser.add_argument('--output-format', choices=['json', 'yaml', 'text', 'html'],
                       default='json')
    parser.add_argument('--show-changes', action='store_true')

    args = parser.parse_args()

    try:
        # Load configurations
        source_config = load_config(args.source, args.format)
        target_config = load_config(args.target, args.format)

        # Compare
        diff = compare_configs(source_config, target_config)

        # Generate report
        report = generate_report(diff, args.output_format)

        # Output
        if args.output:
            args.output.write_text(report)
            print(f"Diff report saved to: {args.output}")
        else:
            print(report)

        # Summary
        if args.show_changes:
            print(f"\nChanges detected: {bool(diff)}")
            if diff:
                print(f"Change types: {list(diff.keys())}")

        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
