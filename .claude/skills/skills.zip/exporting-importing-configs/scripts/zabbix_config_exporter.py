#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Configuration Exporter

Exports Zabbix configurations in multiple formats (XML, JSON, YAML) with
dependency resolution, filtering, and metadata support.

Usage:
    python zabbix_config_exporter.py --url <zabbix_url> --token <token> \
        --type templates --ids 10571,10572 --format yaml --output templates.yaml

Features:
    - Export templates, hosts, host groups, maps, media types, images
    - Multiple output formats: XML, JSON, YAML
    - Automatic dependency resolution
    - Name-based and tag-based filtering
    - Batch export support
    - Metadata inclusion
    - Pretty-print formatting
"""

import argparse
import json
import sys
import yaml
from pathlib import Path
from typing import Dict, List, Optional, Set, Any
from collections import defaultdict
from datetime import datetime

try:
    from pyzabbix import ZabbixAPI
except ImportError:
    print("Error: pyzabbix library not found. Install with: pip install pyzabbix")
    sys.exit(1)


# Constants
SUPPORTED_FORMATS = ['xml', 'json', 'yaml']
SUPPORTED_TYPES = [
    'templates', 'hosts', 'host_groups', 'template_groups',
    'maps', 'images', 'mediaTypes'
]

TYPE_TO_API_PARAM = {
    'templates': 'templates',
    'hosts': 'hosts',
    'host_groups': 'host_groups',
    'template_groups': 'template_groups',
    'maps': 'maps',
    'images': 'images',
    'mediaTypes': 'mediaTypes'
}


class ZabbixConfigExporter:
    """Handles Zabbix configuration export operations."""

    def __init__(self, url: str, token: str, verify_ssl: bool = True):
        """
        Initialize Zabbix API connection.

        Args:
            url: Zabbix server URL
            token: API authentication token
            verify_ssl: Whether to verify SSL certificates
        """
        self.zapi = ZabbixAPI(url)
        self.zapi.session.verify = verify_ssl
        self.zapi.login(api_token=token)
        self.dependency_graph = defaultdict(set)

    def get_objects_by_ids(self, object_type: str, ids: List[str]) -> List[Dict]:
        """
        Retrieve objects by their IDs.

        Args:
            object_type: Type of object (templates, hosts, etc.)
            ids: List of object IDs

        Returns:
            List of object dictionaries
        """
        method_map = {
            'templates': self.zapi.template.get,
            'hosts': self.zapi.host.get,
            'host_groups': self.zapi.hostgroup.get,
            'template_groups': self.zapi.templategroup.get,
            'maps': self.zapi.map.get,
            'images': self.zapi.image.get,
            'mediaTypes': self.zapi.mediatype.get
        }

        if object_type not in method_map:
            raise ValueError(f"Unsupported object type: {object_type}")

        method = method_map[object_type]

        # Build filter based on object type
        filter_key = 'templateids' if object_type == 'templates' else \
                     'hostids' if object_type == 'hosts' else \
                     'groupids' if object_type in ['host_groups', 'template_groups'] else \
                     'sysmapids' if object_type == 'maps' else \
                     'imageids' if object_type == 'images' else \
                     'mediatypeids'

        return method(**{filter_key: ids, 'output': 'extend'})

    def get_objects_by_pattern(self, object_type: str, pattern: str) -> List[Dict]:
        """
        Retrieve objects by name pattern.

        Args:
            object_type: Type of object
            pattern: Name pattern (supports wildcards)

        Returns:
            List of matching objects
        """
        method_map = {
            'templates': self.zapi.template.get,
            'hosts': self.zapi.host.get,
            'host_groups': self.zapi.hostgroup.get,
            'template_groups': self.zapi.templategroup.get,
            'maps': self.zapi.map.get,
            'mediaTypes': self.zapi.mediatype.get
        }

        if object_type not in method_map:
            raise ValueError(f"Unsupported object type: {object_type}")

        method = method_map[object_type]

        # Use search parameter for pattern matching
        name_key = 'name' if object_type != 'templates' else 'host'
        return method(
            output='extend',
            search={name_key: pattern},
            searchWildcardsEnabled=True
        )

    def get_objects_by_tags(self, object_type: str, tags: Dict[str, str]) -> List[Dict]:
        """
        Retrieve objects by tags.

        Args:
            object_type: Type of object
            tags: Dictionary of tag:value pairs

        Returns:
            List of matching objects
        """
        if object_type not in ['templates', 'hosts']:
            raise ValueError(f"Tag filtering not supported for {object_type}")

        method = self.zapi.template.get if object_type == 'templates' else self.zapi.host.get

        # Convert tags dict to Zabbix tag format
        tag_list = [{'tag': k, 'value': v} for k, v in tags.items()]

        return method(
            output='extend',
            tags=tag_list,
            evaltype=0  # AND/OR evaluation
        )

    def resolve_dependencies(self, object_type: str, object_ids: List[str],
                            include_groups: bool = True) -> Set[str]:
        """
        Resolve dependencies for objects.

        Args:
            object_type: Type of object
            object_ids: List of object IDs
            include_groups: Whether to include host/template groups

        Returns:
            Set of all dependent object IDs
        """
        all_ids = set(object_ids)

        if object_type == 'templates':
            for template_id in object_ids:
                # Get parent templates
                template = self.zapi.template.get(
                    templateids=template_id,
                    selectParentTemplates=['templateid']
                )

                if template and template[0].get('parentTemplates'):
                    parent_ids = [t['templateid'] for t in template[0]['parentTemplates']]
                    all_ids.update(parent_ids)
                    self.dependency_graph[template_id].update(parent_ids)

                    # Recursive dependency resolution
                    if parent_ids:
                        parent_deps = self.resolve_dependencies('templates', parent_ids, False)
                        all_ids.update(parent_deps)

        elif object_type == 'hosts':
            for host_id in object_ids:
                # Get linked templates
                host = self.zapi.host.get(
                    hostids=host_id,
                    selectParentTemplates=['templateid']
                )

                if host and host[0].get('parentTemplates'):
                    template_ids = [t['templateid'] for t in host[0]['parentTemplates']]
                    all_ids.update(template_ids)

        return all_ids

    def export_configuration(self, object_type: str, object_ids: List[str],
                            format: str, pretty_print: bool = True) -> str:
        """
        Export configuration using Zabbix API.

        Args:
            object_type: Type of object to export
            object_ids: List of object IDs
            format: Output format (xml, json, yaml)
            pretty_print: Whether to format output

        Returns:
            Exported configuration as string
        """
        # Map our type names to API parameter names
        api_param = TYPE_TO_API_PARAM.get(object_type, object_type)

        # Build export options
        options = {api_param: object_ids}

        # Call configuration.export API
        export_format = 'json' if format == 'yaml' else format

        result = self.zapi.configuration.export(
            format=export_format,
            prettyprint=pretty_print,
            options=options
        )

        # Convert JSON to YAML if needed
        if format == 'yaml':
            data = json.loads(result)
            result = yaml.dump(data, default_flow_style=False, sort_keys=False)

        return result

    def add_metadata(self, config_data: str, format: str, metadata: Dict) -> str:
        """
        Add metadata to exported configuration.

        Args:
            config_data: Exported configuration
            format: Format of configuration
            metadata: Metadata to add

        Returns:
            Configuration with metadata
        """
        if format == 'yaml':
            data = yaml.safe_load(config_data)
            data['_metadata'] = metadata
            return yaml.dump(data, default_flow_style=False, sort_keys=False)

        elif format == 'json':
            data = json.loads(config_data)
            data['_metadata'] = metadata
            return json.dumps(data, indent=2)

        elif format == 'xml':
            # Add metadata as XML comment
            metadata_str = json.dumps(metadata, indent=2)
            return f"<!-- Metadata:\n{metadata_str}\n-->\n{config_data}"

        return config_data

    def export_with_dependencies(self, object_type: str, object_ids: List[str],
                                 format: str, include_groups: bool = True,
                                 pretty_print: bool = True) -> str:
        """
        Export configuration with all dependencies.

        Args:
            object_type: Type of object
            object_ids: List of object IDs
            format: Output format
            include_groups: Whether to include groups
            pretty_print: Whether to format output

        Returns:
            Exported configuration
        """
        # Resolve dependencies
        all_ids = self.resolve_dependencies(object_type, object_ids, include_groups)

        # Export all objects
        return self.export_configuration(object_type, list(all_ids), format, pretty_print)

    def save_to_file(self, content: str, output_path: Path, create_dirs: bool = True):
        """
        Save exported configuration to file.

        Args:
            content: Configuration content
            output_path: Output file path
            create_dirs: Whether to create parent directories
        """
        if create_dirs:
            output_path.parent.mkdir(parents=True, exist_ok=True)

        output_path.write_text(content, encoding='utf-8')
        print(f"Configuration exported to: {output_path}")


def parse_tags(tag_string: str) -> Dict[str, str]:
    """
    Parse tag string into dictionary.

    Args:
        tag_string: String like "tag1:value1,tag2:value2"

    Returns:
        Dictionary of tags
    """
    tags = {}
    if tag_string:
        for pair in tag_string.split(','):
            if ':' in pair:
                key, value = pair.split(':', 1)
                tags[key.strip()] = value.strip()
    return tags


def main():
    parser = argparse.ArgumentParser(
        description='Export Zabbix configurations with dependency resolution',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Export single template
  %(prog)s --url https://zabbix.example.com --token TOKEN --type templates --ids 10571 --format yaml --output template.yaml

  # Export multiple templates with dependencies
  %(prog)s --url https://zabbix.example.com --token TOKEN --type templates --ids 10571,10572 --include-dependencies --format json --output templates.json

  # Export by name pattern
  %(prog)s --url https://zabbix.example.com --token TOKEN --type templates --name-pattern "Linux*" --format yaml --output linux_templates.yaml

  # Export by tags
  %(prog)s --url https://zabbix.example.com --token TOKEN --type templates --tags "env:prod,team:ops" --format yaml --output prod_templates.yaml
        """
    )

    # Connection parameters
    parser.add_argument('--url', required=True, help='Zabbix server URL')
    parser.add_argument('--token', required=True, help='API authentication token')
    parser.add_argument('--no-verify-ssl', action='store_true', help='Disable SSL verification')

    # Object selection
    parser.add_argument('--type', required=True, choices=SUPPORTED_TYPES,
                       help='Type of objects to export')
    parser.add_argument('--ids', help='Comma-separated object IDs')
    parser.add_argument('--name-pattern', help='Name pattern (supports wildcards)')
    parser.add_argument('--tags', help='Tag filters (tag1:value1,tag2:value2)')

    # Export options
    parser.add_argument('--format', choices=SUPPORTED_FORMATS, default='yaml',
                       help='Output format (default: yaml)')
    parser.add_argument('--output', type=Path, required=True,
                       help='Output file path')
    parser.add_argument('--include-dependencies', action='store_true',
                       help='Include all dependencies')
    parser.add_argument('--include-groups', action='store_true', default=True,
                       help='Include host/template groups (default: true)')
    parser.add_argument('--add-metadata', action='store_true',
                       help='Add export metadata to output')
    parser.add_argument('--no-pretty-print', action='store_true',
                       help='Disable pretty printing')

    args = parser.parse_args()

    # Validate inputs
    if not any([args.ids, args.name_pattern, args.tags]):
        parser.error("Must specify one of: --ids, --name-pattern, or --tags")

    try:
        # Initialize exporter
        exporter = ZabbixConfigExporter(
            args.url,
            args.token,
            verify_ssl=not args.no_verify_ssl
        )

        # Get object IDs
        object_ids = []

        if args.ids:
            object_ids = args.ids.split(',')
            print(f"Exporting {len(object_ids)} {args.type} by ID...")

        elif args.name_pattern:
            objects = exporter.get_objects_by_pattern(args.type, args.name_pattern)
            id_key = 'templateid' if args.type == 'templates' else \
                     'hostid' if args.type == 'hosts' else \
                     'groupid' if args.type in ['host_groups', 'template_groups'] else \
                     'sysmapid' if args.type == 'maps' else \
                     'imageid' if args.type == 'images' else \
                     'mediatypeid'
            object_ids = [obj[id_key] for obj in objects]
            print(f"Found {len(object_ids)} {args.type} matching pattern '{args.name_pattern}'")

        elif args.tags:
            tags = parse_tags(args.tags)
            objects = exporter.get_objects_by_tags(args.type, tags)
            id_key = 'templateid' if args.type == 'templates' else 'hostid'
            object_ids = [obj[id_key] for obj in objects]
            print(f"Found {len(object_ids)} {args.type} matching tags {tags}")

        if not object_ids:
            print("No objects found to export")
            return 1

        # Export configuration
        if args.include_dependencies:
            print("Resolving dependencies...")
            config = exporter.export_with_dependencies(
                args.type,
                object_ids,
                args.format,
                args.include_groups,
                not args.no_pretty_print
            )
        else:
            config = exporter.export_configuration(
                args.type,
                object_ids,
                args.format,
                not args.no_pretty_print
            )

        # Add metadata if requested
        if args.add_metadata:
            metadata = {
                'export_date': datetime.now().isoformat(),
                'zabbix_url': args.url,
                'object_type': args.type,
                'object_count': len(object_ids),
                'format': args.format,
                'with_dependencies': args.include_dependencies
            }
            config = exporter.add_metadata(config, args.format, metadata)

        # Save to file
        exporter.save_to_file(config, args.output)

        print(f"Successfully exported {len(object_ids)} {args.type}")
        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
