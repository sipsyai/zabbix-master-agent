#!/usr/bin/env python3
"""
Zabbix Configuration Merge Tool

Merge multiple Zabbix configurations into one.
"""

import argparse
import json
import sys
import yaml
from pathlib import Path
from typing import Dict, List


import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
def load_config(file_path: Path, format: str) -> Dict:
    """Load configuration from file."""
    content = file_path.read_text(encoding='utf-8')

    if format == 'json':
        return json.loads(content)
    elif format == 'yaml':
        return yaml.safe_load(content)
    return {}


def merge_configs(configs: List[Dict], strategy: str = 'prefer-newer') -> Dict:
    """
    Merge multiple configurations.

    Strategies:
        - prefer-newer: Later configs override earlier
        - prefer-older: Earlier configs take precedence
        - combine: Combine all unique items
    """
    if not configs:
        return {}

    merged = configs[0].copy()

    for config in configs[1:]:
        if strategy == 'prefer-newer':
            # Deep merge with newer values taking precedence
            merged = deep_merge(merged, config, prefer='right')
        elif strategy == 'prefer-older':
            merged = deep_merge(merged, config, prefer='left')
        elif strategy == 'combine':
            merged = deep_merge(merged, config, prefer='combine')

    return merged


def deep_merge(dict1: Dict, dict2: Dict, prefer: str = 'right') -> Dict:
    """Deep merge two dictionaries."""
    result = dict1.copy()

    for key, value in dict2.items():
        if key in result:
            if isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = deep_merge(result[key], value, prefer)
            elif isinstance(result[key], list) and isinstance(value, list):
                if prefer == 'combine':
                    result[key] = result[key] + value
                elif prefer == 'right':
                    result[key] = value
            else:
                if prefer == 'right':
                    result[key] = value
        else:
            result[key] = value

    return result


def main():
    parser = argparse.ArgumentParser(description='Merge Zabbix configurations')
    parser.add_argument('--inputs', nargs='+', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--format', choices=['json', 'yaml'], default='yaml')
    parser.add_argument('--resolve-conflicts', choices=['prefer-newer', 'prefer-older', 'combine'],
                       default='prefer-newer')
    parser.add_argument('--validate', action='store_true')

    args = parser.parse_args()

    try:
        # Load all configurations
        configs = []
        for input_file in args.inputs:
            config = load_config(input_file, args.format)
            configs.append(config)
            print(f"Loaded: {input_file}")

        # Merge
        print(f"\nMerging {len(configs)} configurations...")
        merged = merge_configs(configs, args.resolve_conflicts)

        # Save
        if args.format == 'json':
            output_content = json.dumps(merged, indent=2)
        else:
            output_content = yaml.dump(merged, default_flow_style=False)

        args.output.write_text(output_content)
        print(f"Merged configuration saved to: {args.output}")

        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
