#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Configuration Migration Tool

Migrate configurations between Zabbix environments with transformation support.

Usage:
    python zabbix_config_migrate.py \
        --source-url https://dev.example.com --source-token TOKEN1 \
        --target-url https://prod.example.com --target-token TOKEN2 \
        --types templates hosts --dry-run
"""

import argparse
import json
import sys
import yaml
from pathlib import Path
from typing import Dict, List, Optional

try:
    from pyzabbix import ZabbixAPI
except ImportError:
    print("Error: pyzabbix library not found. Install with: pip install pyzabbix")
    sys.exit(1)


class ZabbixConfigMigrator:
    """Handles configuration migration between Zabbix environments."""

    def __init__(self, source_url: str, source_token: str,
                 target_url: str, target_token: str, verify_ssl: bool = True):
        """Initialize connections to source and target Zabbix servers."""
        self.source = ZabbixAPI(source_url)
        self.source.session.verify = verify_ssl
        self.source.login(api_token=source_token)

        self.target = ZabbixAPI(target_url)
        self.target.session.verify = verify_ssl
        self.target.login(api_token=target_token)

    def export_from_source(self, object_type: str, object_ids: List[str],
                          format: str = 'json') -> str:
        """Export configuration from source environment."""
        api_params = {
            'templates': 'templates',
            'hosts': 'hosts',
            'host_groups': 'host_groups',
            'template_groups': 'template_groups',
            'maps': 'maps',
            'mediaTypes': 'mediaTypes'
        }

        options = {api_params[object_type]: object_ids}

        return self.source.configuration.export(
            format=format,
            prettyprint=True,
            options=options
        )

    def transform_configuration(self, config: str, format: str,
                               transformations: Dict) -> str:
        """
        Apply transformations to configuration.

        Transformations can include:
        - Hostname mapping
        - IP address changes
        - Tag updates
        - Macro replacements
        """
        if format == 'json':
            data = json.loads(config)
        elif format == 'yaml':
            data = yaml.safe_load(config)
        else:
            return config

        # Apply transformations
        for transform_type, transform_rules in transformations.items():
            if transform_type == 'hostname_mapping':
                data = self._transform_hostnames(data, transform_rules)
            elif transform_type == 'macro_replacements':
                data = self._transform_macros(data, transform_rules)
            elif transform_type == 'tag_updates':
                data = self._transform_tags(data, transform_rules)

        # Convert back to string
        if format == 'json':
            return json.dumps(data, indent=2)
        elif format == 'yaml':
            return yaml.dump(data, default_flow_style=False)
        return config

    def _transform_hostnames(self, data: Dict, mappings: Dict) -> Dict:
        """Transform hostnames according to mapping."""
        # This is a simplified implementation
        data_str = json.dumps(data)
        for old, new in mappings.items():
            data_str = data_str.replace(old, new)
        return json.loads(data_str)

    def _transform_macros(self, data: Dict, replacements: Dict) -> Dict:
        """Transform macro values."""
        data_str = json.dumps(data)
        for old, new in replacements.items():
            data_str = data_str.replace(old, new)
        return json.loads(data_str)

    def _transform_tags(self, data: Dict, tag_updates: Dict) -> Dict:
        """Update tag values."""
        # Simplified implementation
        return data

    def import_to_target(self, config: str, format: str, rules: Dict,
                        dry_run: bool = False) -> Dict:
        """Import configuration to target environment."""
        if dry_run:
            print("DRY RUN: Would import configuration")
            return {'success': True, 'dry_run': True}

        try:
            result = self.target.configuration.import_configuration(
                format=format,
                source=config,
                rules=rules
            )
            return {'success': True, 'result': result}
        except Exception as e:
            return {'success': False, 'error': str(e)}

    def migrate(self, object_type: str, object_ids: List[str],
               transformations: Optional[Dict] = None,
               import_rules: Optional[Dict] = None,
               dry_run: bool = False) -> Dict:
        """
        Perform complete migration from source to target.

        Args:
            object_type: Type of objects to migrate
            object_ids: IDs of objects in source
            transformations: Configuration transformations
            import_rules: Import rules for target
            dry_run: Test mode

        Returns:
            Migration results
        """
        print(f"Migrating {len(object_ids)} {object_type}...")

        # Export from source
        print("1. Exporting from source...")
        config = self.export_from_source(object_type, object_ids, 'json')

        # Apply transformations
        if transformations:
            print("2. Applying transformations...")
            config = self.transform_configuration(config, 'json', transformations)

        # Import to target
        print("3. Importing to target...")
        result = self.import_to_target(config, 'json', import_rules or {}, dry_run)

        return result


def load_migration_config(config_file: Path) -> Dict:
    """Load migration configuration from YAML file."""
    return yaml.safe_load(config_file.read_text())


def main():
    parser = argparse.ArgumentParser(
        description='Migrate Zabbix configurations between environments'
    )

    # Source connection
    parser.add_argument('--source-url', required=True, help='Source Zabbix URL')
    parser.add_argument('--source-token', required=True, help='Source API token')

    # Target connection
    parser.add_argument('--target-url', required=True, help='Target Zabbix URL')
    parser.add_argument('--target-token', required=True, help='Target API token')

    # Migration options
    parser.add_argument('--types', nargs='+', required=True,
                       help='Object types to migrate')
    parser.add_argument('--ids', help='Comma-separated object IDs')
    parser.add_argument('--transform-config', type=Path,
                       help='YAML file with transformation rules')
    parser.add_argument('--config', type=Path,
                       help='Complete migration configuration file')

    # Operation mode
    parser.add_argument('--dry-run', action='store_true',
                       help='Test migration without applying')
    parser.add_argument('--apply', action='store_true',
                       help='Apply migration')

    parser.add_argument('--no-verify-ssl', action='store_true')

    args = parser.parse_args()

    try:
        # Load configuration if provided
        if args.config:
            config = load_migration_config(args.config)
            transformations = config.get('transformations', {})
            import_rules = config.get('import_rules', {})
        else:
            transformations = None
            import_rules = {
                'templates': {'createMissing': True, 'updateExisting': True},
                'hosts': {'createMissing': True, 'updateExisting': True}
            }

        # Load transformation config
        if args.transform_config:
            trans_config = yaml.safe_load(args.transform_config.read_text())
            transformations = trans_config.get('transformations', {})

        # Initialize migrator
        migrator = ZabbixConfigMigrator(
            args.source_url, args.source_token,
            args.target_url, args.target_token,
            verify_ssl=not args.no_verify_ssl
        )

        # Perform migration
        for obj_type in args.types:
            object_ids = args.ids.split(',') if args.ids else []

            result = migrator.migrate(
                obj_type,
                object_ids,
                transformations,
                import_rules,
                args.dry_run
            )

            if result['success']:
                print(f"[OK] Migration of {obj_type} successful")
            else:
                print(f"[ERROR] Migration of {obj_type} failed: {result.get('error')}")
                return 1

        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
