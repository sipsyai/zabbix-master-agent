# Implementing Low-Level Discovery (LLD) in Zabbix

Complete Agent Skill for automating Zabbix Low-Level Discovery implementation through the API.

## Overview

This skill provides comprehensive tools and examples for implementing Zabbix Low-Level Discovery (LLD), enabling automatic discovery and monitoring of dynamic infrastructure components including file systems, network interfaces, containers, databases, and custom applications.

## Contents

### Documentation
- `SKILL.md` - Complete skill documentation with examples and best practices

### Core Scripts
- `scripts/zabbix_lld_manager.py` - Main LLD rule management tool
- `scripts/lld_rule_creator.py` - Create rules from predefined templates
- `scripts/validate_lld_config.py` - Validate LLD configurations
- `scripts/test_lld_discovery.py` - Test and debug discovery rules

### Custom Discovery Scripts
- `scripts/custom_lld_scripts/filesystem_discovery.py` - File system discovery (cross-platform)
- `scripts/custom_lld_scripts/network_interface_discovery.sh` - Network interface discovery (Linux)
- `scripts/custom_lld_scripts/docker_discovery.py` - Docker container discovery
- `scripts/custom_lld_scripts/windows_service_discovery.ps1` - Windows service discovery
- `scripts/custom_lld_scripts/database_discovery.py` - Multi-database discovery

### Examples
- `examples/filesystem_lld.json` - Complete file system discovery configuration
- `examples/lld_filters_overrides.yaml` - Filter and override patterns
- `examples/custom_lld.json` - Custom application discovery

## Quick Start

### 1. Install Dependencies

```bash
pip install pyzabbix psutil pyyaml
```

### 2. List Available Templates

```bash
python scripts/lld_rule_creator.py --list-templates
```

### 3. Create LLD Rule from Template

```bash
# Create filesystem discovery rule
python scripts/lld_rule_creator.py \
    --template filesystem \
    --host-id 10001 \
    --output fs_lld.json

# Apply to Zabbix
python scripts/zabbix_lld_manager.py \
    --action create \
    --config fs_lld.json \
    --host "Web Server 01" \
    --url "http://zabbix.example.com" \
    --username "Admin" \
    --password "zabbix"
```

### 4. Test Discovery

```bash
# Execute discovery and show results
python scripts/test_lld_discovery.py \
    --rule-id 12345 \
    --execute \
    --show-entities \
    --url "http://zabbix.example.com" \
    --username "Admin" \
    --password "zabbix"
```

## Common Use Cases

### File System Monitoring

```bash
# Create with validation
python scripts/lld_rule_creator.py --template filesystem --host-id 10001 --output fs_lld.json
python scripts/validate_lld_config.py --config fs_lld.json
python scripts/zabbix_lld_manager.py --action create --config fs_lld.json --host "Server01"
```

### Network Interface Monitoring

```bash
# Custom discovery script
python scripts/custom_lld_scripts/filesystem_discovery.py --exclude-types tmpfs,devtmpfs

# Create network LLD rule
python scripts/lld_rule_creator.py --template network --host-id 10001 --output net_lld.json
python scripts/zabbix_lld_manager.py --action create --config net_lld.json --host "Server01"
```

### Docker Container Monitoring

```bash
# Test discovery locally
python scripts/custom_lld_scripts/docker_discovery.py --only-running --pretty

# Create Docker LLD rule
python scripts/lld_rule_creator.py --template docker --host-id 10001 --output docker_lld.json
python scripts/zabbix_lld_manager.py --action create --config docker_lld.json --host "Docker Host"
```

### Database Monitoring

```bash
# Discover PostgreSQL databases
python scripts/custom_lld_scripts/database_discovery.py \
    --type postgresql \
    --host localhost \
    --user zabbix \
    --password secret \
    --exclude-system

# Create database LLD rule
python scripts/lld_rule_creator.py --template database --host-id 10001 --output db_lld.json
python scripts/zabbix_lld_manager.py --action create --config db_lld.json --host "DB Server"
```

### Windows Service Monitoring

```powershell
# Test discovery on Windows
powershell -File scripts/custom_lld_scripts/windows_service_discovery.ps1 -OnlyRunning -Pretty

# Create service LLD rule
python scripts/lld_rule_creator.py --template service --host-id 10001 --output service_lld.json
python scripts/zabbix_lld_manager.py --action create --config service_lld.json --host "Windows Server"
```

## Validation and Testing

### Validate Configuration

```bash
# Validate LLD rule configuration
python scripts/validate_lld_config.py --config examples/filesystem_lld.json --strict

# Validate JSON discovery output
python scripts/test_lld_discovery.py --json-file discovery_output.json --validate

# Validate with output report
python scripts/validate_lld_config.py --config lld_config.json --output validation_report.txt
```

### Test Discovery Rules

```bash
# Check rule status
python scripts/test_lld_discovery.py --rule-id 12345 --status

# Execute and show entities
python scripts/test_lld_discovery.py --rule-id 12345 --execute --show-entities --limit 50

# Test custom script output
python scripts/custom_lld_scripts/filesystem_discovery.py --pretty
python scripts/test_lld_discovery.py --json-file <(python scripts/custom_lld_scripts/filesystem_discovery.py) --validate
```

## Management Operations

### List LLD Rules

```bash
# List all rules for a host
python scripts/zabbix_lld_manager.py --action list --host "Web Server 01"

# List all rules (no host filter)
python scripts/zabbix_lld_manager.py --action list --output all_rules.json
```

### Update LLD Rule

```bash
# Modify configuration file, then update
python scripts/zabbix_lld_manager.py --action update --rule-id 12345 --config updated_config.json
```

### Delete LLD Rule

```bash
# Delete rule and all discovered entities
python scripts/zabbix_lld_manager.py --action delete --rule-id 12345
```

## Available Templates

The `lld_rule_creator.py` script includes these predefined templates:

1. **filesystem** - File system discovery with disk space monitoring
2. **network** - Network interface discovery with traffic monitoring
3. **cpu** - CPU core discovery with utilization monitoring
4. **service** - Windows service discovery with state monitoring
5. **docker** - Docker container discovery with resource monitoring
6. **database** - Database discovery with connection monitoring

Each template includes:
- Discovery rule configuration
- Item prototypes for metrics
- Trigger prototypes for alerting
- Appropriate filters and tags

## Custom Discovery Scripts

### Python Script Template

```python
#!/usr/bin/env python3
import json
import sys

def discover():
    """Your discovery logic"""
    entities = []

    # Discover entities
    # ...

    # Build LLD JSON
    for entity in discovered_items:
        entities.append({
            "{#ENTITY.NAME}": entity.name,
            "{#ENTITY.TYPE}": entity.type,
            "{#ENTITY.ID}": entity.id
        })

    return entities

if __name__ == "__main__":
    try:
        result = discover()
        print(json.dumps(result))
        sys.exit(0)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        print("[]")
        sys.exit(1)
```

### Bash Script Template

```bash
#!/bin/bash
set -euo pipefail

echo "["
first=true

# Discovery logic
for item in $items; do
    if [ "$first" = false ]; then
        echo -n ","
    fi
    first=false

    cat <<EOF
  {
    "{#ITEM.NAME}": "$item_name",
    "{#ITEM.TYPE}": "$item_type"
  }
EOF
done

echo "]"
exit 0
```

## LLD Macro Guidelines

### Naming Convention
- Use uppercase: `{#FSNAME}` not `{#fsname}`
- Include context: `{#CONTAINER.NAME}` not `{#NAME}`
- Be descriptive: `{#DB.CONNECTION.COUNT}` not `{#COUNT}`

### Common Macros
- **File Systems**: `{#FSNAME}`, `{#FSTYPE}`, `{#FSDRIVETYPE}`
- **Network**: `{#IFNAME}`, `{#IFTYPE}`, `{#IFMAC}`
- **Containers**: `{#CONTAINER.ID}`, `{#CONTAINER.NAME}`, `{#CONTAINER.IMAGE}`
- **Databases**: `{#DB.NAME}`, `{#DB.TYPE}`, `{#DB.SIZE}`
- **Services**: `{#SERVICE.NAME}`, `{#SERVICE.DISPLAYNAME}`, `{#SERVICE.STATE}`

## Filter Patterns

Common regex patterns for filtering:

```yaml
# Include physical network interfaces
{#IFNAME} matches: ^(eth|ens|enp|eno)[0-9]+

# Exclude temporary filesystems
{#FSTYPE} does not match: ^(tmpfs|devtmpfs|overlay)

# Include production databases
{#DB.NAME} matches: ^(prod_|production_)

# Exclude test containers
{#CONTAINER.NAME} does not match: ^(test_|tmp_)

# Include critical services
{#SERVICE.DISPLAYNAME} matches: (SQL|IIS|Apache|nginx)
```

See `examples/lld_filters_overrides.yaml` for comprehensive filter examples.

## Best Practices

### Discovery Rule Configuration
1. Set appropriate update intervals (1h for static, 5m for dynamic)
2. Configure lifetime to be 2-3x update interval
3. Use "After 7d" for delete lost resources (never "Immediately")
4. Test filters thoroughly before production deployment
5. Document filter logic in rule description

### Item Prototypes
1. Use appropriate value types and units
2. Set realistic history/trend retention
3. Add comprehensive tags for organization
4. Include descriptions for clarity
5. Consider preprocessing for data transformation

### Trigger Prototypes
1. Use descriptive names with LLD macros
2. Set appropriate severity levels
3. Include operational data when useful
4. Add tags for filtering and grouping
5. Document trigger logic in comments

### Performance
1. Avoid too frequent discovery (increases load)
2. Use filters to limit discovered entities
3. Disable unnecessary item prototypes via overrides
4. Monitor discovery rule execution time
5. Use preprocessing to reduce data volume

## Troubleshooting

### Discovery Not Working

**Check:**
1. Rule is enabled and not in error state
2. Host is monitored and accessible
3. Item key returns valid JSON
4. Filters aren't blocking all entities

**Debug:**
```bash
# Check rule status
python scripts/test_lld_discovery.py --rule-id <id> --status

# Validate JSON output
python scripts/test_lld_discovery.py --json-file output.json --validate

# Test manually on host
zabbix_get -s <host> -k <discovery_key>
```

### No Items Created

**Possible causes:**
- Filters blocking entities
- Item prototype key conflicts
- Invalid LLD macros
- Insufficient permissions

**Verify:**
```bash
# Show discovered entities
python scripts/test_lld_discovery.py --rule-id <id> --show-entities

# Validate configuration
python scripts/validate_lld_config.py --config config.json --strict
```

### Invalid JSON Error

**Common issues:**
- Missing quotes around macro names
- Trailing commas
- Invalid escape sequences
- Non-UTF8 characters

**Fix:**
```bash
# Validate JSON
python -m json.tool < discovery_output.json

# Use validation script
python scripts/validate_lld_config.py --json-file output.json
```

## Integration

This skill integrates with:
- Zabbix API Authentication skill
- Template Management skill
- Item Management skill
- Trigger Management skill
- Monitoring Configuration skill

## Support

For issues, questions, or contributions:
- Review Zabbix LLD documentation
- Check `examples/` directory for patterns
- Test configurations with validation scripts
- Use `--help` flag on all scripts for detailed usage

## Version

- Skill Version: 1.0.0
- Compatible with: Zabbix 5.0+, 6.0+, 7.0+
- Python: 3.8+
- Dependencies: pyzabbix, psutil, pyyaml

## License

This skill is part of the Zabbix Skills collection.
