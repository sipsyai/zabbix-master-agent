---
name: Implementing Low-Level Discovery (LLD) in Zabbix
description: Automates Zabbix Low-Level Discovery implementation including creating discovery rules, managing LLD macros, configuring item/trigger prototypes, handling filters and overrides, and implementing custom LLD scripts through the Zabbix API. Use when automatically discovering and monitoring dynamic infrastructure components like file systems, network interfaces, containers, databases, or any entities that require automatic detection and configuration.
version: 1.0.0
dependencies:
  - zabbix-api-authentication
  - python >= 3.8
  - pyzabbix library
---

# Implementing Low-Level Discovery in Zabbix

## Quick Start

### Basic LLD Rule Creation

Create a file system discovery rule:

```python
# Basic filesystem LLD rule
lld_rule = {
    "name": "File system discovery",
    "key_": "vfs.fs.discovery",
    "type": 0,  # Zabbix agent
    "delay": "1h",
    "hostid": "10001"
}
```

Create with item and trigger prototypes:

```python
# Item prototype for discovered file systems
item_prototype = {
    "name": "Free disk space on {#FSNAME}",
    "key_": "vfs.fs.size[{#FSNAME},free]",
    "hostid": "10001",
    "ruleid": "<discovery_rule_id>",
    "type": 0,
    "value_type": 3,  # Numeric unsigned
    "units": "B"
}

# Trigger prototype
trigger_prototype = {
    "description": "Free disk space is less than 20% on {#FSNAME}",
    "expression": "last(/hostname/vfs.fs.size[{#FSNAME},pfree])<20",
    "priority": 2  # Warning
}
```

### Common LLD Keys

**Built-in Discovery Keys:**
- `vfs.fs.discovery` - File system discovery
- `vfs.fs.get` - File system data (requires preprocessing)
- `net.if.discovery` - Network interface discovery
- `system.cpu.discovery` - CPU discovery
- `vfs.dev.discovery` - Block device discovery

**Custom Script Keys:**
- `system.run[custom_discovery.py]` - Custom Python script
- `system.run[custom_discovery.sh]` - Custom shell script

### LLD Workflow

1. **Create Discovery Rule** → Define the item key that returns JSON
2. **Add LLD Macros** → Extract values from JSON using JSONPath
3. **Configure Filters** → Include/exclude discovered entities
4. **Create Prototypes** → Define item, trigger, graph templates
5. **Set Overrides** → Customize behavior for specific entities
6. **Test and Validate** → Verify discovery works correctly

---

## Core Concepts

### LLD JSON Format

LLD rules must return JSON in this format:

**New Format (Zabbix 4.2+):**
```json
[
  {"{#FSNAME}": "/", "{#FSTYPE}": "ext4"},
  {"{#FSNAME}": "/boot", "{#FSTYPE}": "ext4"},
  {"{#FSNAME}": "/home", "{#FSTYPE}": "xfs"}
]
```

**Legacy Format (still supported):**
```json
{
  "data": [
    {"{#FSNAME}": "/", "{#FSTYPE}": "ext4"},
    {"{#FSNAME}": "/boot", "{#FSTYPE}": "ext4"}
  ]
}
```

### LLD Macros

**Naming Convention:** `{#MACRO_NAME}` (uppercase recommended)

**Built-in Macros:**
- `{#FSNAME}` - File system name
- `{#FSTYPE}` - File system type
- `{#FSDRIVETYPE}` - Drive type (Windows)
- `{#IFNAME}` - Network interface name
- `{#SNMPINDEX}` - SNMP index
- `{#SNMPVALUE}` - SNMP value

**Custom Macros:**
Define via JSONPath in the LLD Macros tab:
- `{#CONTAINER_NAME}` → `$.container.name`
- `{#PORT}` → `$.port`
- `{#DATABASE}` → `$.db_name`

### Discovery Rule Components

**Five Configuration Tabs:**

1. **Discovery Rule** - Item key, update interval, lost resource handling
2. **Preprocessing** - Transform discovery data (JSONPath, regex, JavaScript)
3. **LLD Macros** - Custom macro definitions with JSONPath
4. **Filters** - Include/exclude entities based on regex patterns
5. **Overrides** - Modify prototypes for specific discovered entities

---

## Implementation Tasks

### Task 1: Create Basic LLD Rule

Use the Zabbix API to create a discovery rule:

```python
from zabbix_api import ZabbixAPI

# Create discovery rule
result = zapi.discoveryrule.create({
    "name": "Network interface discovery",
    "key_": "net.if.discovery",
    "hostid": hostid,
    "type": 0,  # Zabbix agent
    "delay": "1h",
    "lifetime": "7d",
    "description": "Discovers all network interfaces"
})
```

**Reference:** scripts/lld_rule_creator.py for complete implementation

### Task 2: Configure LLD Macros

Extract custom values from JSON:

```python
# Add custom LLD macros
lld_macros = [
    {"lld_macro": "{#IFNAME}", "path": "$.name"},
    {"lld_macro": "{#IFTYPE}", "path": "$.type"},
    {"lld_macro": "{#IFSPEED}", "path": "$.speed"}
]

zapi.discoveryrule.update({
    "itemid": rule_id,
    "lld_macro_paths": lld_macros
})
```

**Reference:** examples/filesystem_lld.json for macro configuration examples

### Task 3: Create Item Prototypes

Define items to be created for each discovered entity:

```python
# Create item prototype
zapi.itemprototype.create({
    "name": "Incoming traffic on {#IFNAME}",
    "key_": "net.if.in[{#IFNAME}]",
    "hostid": hostid,
    "ruleid": rule_id,
    "type": 0,
    "value_type": 3,
    "units": "bps",
    "delay": "1m",
    "preprocessing": [
        {
            "type": 10,  # Change per second
            "params": ""
        },
        {
            "type": 1,  # Multiplier
            "params": "8"
        }
    ]
})
```

**Reference:** scripts/zabbix_lld_manager.py for prototype management

### Task 4: Create Trigger Prototypes

Define triggers with LLD macros:

```python
# Create trigger prototype
zapi.triggerprototype.create({
    "description": "High bandwidth usage on {#IFNAME}",
    "expression": "avg(/hostname/net.if.in[{#IFNAME}],5m)>100M",
    "priority": 3,  # Average
    "tags": [
        {"tag": "interface", "value": "{#IFNAME}"},
        {"tag": "component", "value": "network"}
    ]
})
```

### Task 5: Configure Filters

Include or exclude entities based on patterns:

```python
# Add filters to discovery rule
filter_config = {
    "evaltype": 0,  # And/Or
    "conditions": [
        {
            "macro": "{#FSTYPE}",
            "value": "^ext|^xfs|^btrfs",
            "formulaid": "A"
        },
        {
            "macro": "{#FSNAME}",
            "value": "^/boot|^/tmp",
            "operator": 2,  # does not match
            "formulaid": "B"
        }
    ],
    "formula": "A and B"
}

zapi.discoveryrule.update({
    "itemid": rule_id,
    "filter": filter_config
})
```

**Filter Operators:**
- `0` - matches
- `1` - does not match
- `2` - exists
- `3` - does not exist

**Reference:** examples/lld_filters_overrides.yaml for filter patterns

### Task 6: Configure Overrides

Customize prototypes for specific entities:

```python
# Override configuration
override = {
    "name": "Disable monitoring for loop devices",
    "step": 1,
    "stop": 1,  # Stop processing
    "filter": {
        "evaltype": 0,
        "conditions": [
            {
                "macro": "{#FSNAME}",
                "value": "^/dev/loop",
                "formulaid": "A"
            }
        ]
    },
    "operations": [
        {
            "operationobject": 0,  # Item prototype
            "operator": 0,  # Equals
            "value": "Free disk space on {#FSNAME}",
            "opstatus": {"status": 1}  # Disabled
        }
    ]
}

zapi.discoveryrule.update({
    "itemid": rule_id,
    "overrides": [override]
})
```

**Reference:** examples/lld_filters_overrides.yaml for override examples

### Task 7: Implement Custom LLD Script

Create a custom discovery script that returns proper JSON:

**Python Example:**
```python
#!/usr/bin/env python3
import json
import psutil

def discover_processes():
    """Discover running processes"""
    processes = []
    for proc in psutil.process_iter(['pid', 'name', 'username']):
        try:
            processes.append({
                "{#PID}": proc.info['pid'],
                "{#PNAME}": proc.info['name'],
                "{#PUSER}": proc.info['username']
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

    return processes

if __name__ == "__main__":
    result = discover_processes()
    print(json.dumps(result, indent=2))
```

**Reference:** scripts/custom_lld_scripts/ for complete examples

### Task 8: Add Preprocessing

Transform discovery data before processing:

```python
# Add preprocessing steps
preprocessing = [
    {
        "type": 12,  # JSONPath
        "params": "$.filesystems",
        "error_handler": 0
    },
    {
        "type": 11,  # JavaScript
        "params": """
            var data = JSON.parse(value);
            return JSON.stringify(data.filter(item => item.type !== 'tmpfs'));
        """,
        "error_handler": 0
    }
]

zapi.discoveryrule.update({
    "itemid": rule_id,
    "preprocessing": preprocessing
})
```

**Preprocessing Types:**
- Type 11: JavaScript
- Type 12: JSONPath
- Type 5: Regular expression
- Type 1: Multiplier
- Type 25: Discard unchanged with heartbeat

**Reference:** Check preprocessing documentation for all types

### Task 9: Test and Validate LLD

Execute discovery immediately and check results:

```python
# Execute discovery now
zapi.task.create({
    "type": 6,  # Check now
    "itemids": [rule_id]
})

# Check discovered items
discovered_items = zapi.item.get({
    "discoveryids": rule_id,
    "output": ["name", "key_", "status", "lastclock"]
})

for item in discovered_items:
    print(f"Item: {item['name']}, Status: {item['status']}")
```

**Reference:** scripts/test_lld_discovery.py for validation scripts

### Task 10: Monitor LLD Performance

Track discovery rule execution and performance:

```python
# Get discovery rule status
lld_status = zapi.discoveryrule.get({
    "itemids": rule_id,
    "output": ["name", "status", "error", "lastclock"],
    "selectItems": ["count"]
})

# Check for discovery errors
if lld_status[0]['error']:
    print(f"Discovery error: {lld_status[0]['error']}")
```

---

## Advanced Patterns

### Nested Discovery (Multi-Level)

Discover databases, then tablespaces for each database:

```python
# Parent discovery rule
parent_rule = {
    "name": "Database discovery",
    "key_": "db.discovery",
    "type": 0,
    "delay": "1h"
}

# Nested discovery prototype
nested_rule = {
    "name": "Tablespace discovery for {#DBNAME}",
    "key_": "db.tablespace.discovery[{#DBNAME}]",
    "type": 27,  # Dependent item
    "master_itemid": parent_rule_id,
    "preprocessing": [
        {"type": 12, "params": "$.tablespaces"}
    ]
}
```

**Reference:** Check discovery_prototypes.md documentation

### SNMP OID Discovery

Discover SNMP OIDs dynamically:

```python
lld_rule = {
    "name": "SNMP interface discovery",
    "key_": "snmpwalk[{#SNMPINDEX},.1.3.6.1.2.1.2.2.1]",
    "type": 20,  # SNMP agent
    "snmp_oid": "discovery[{#SNMPINDEX},.1.3.6.1.2.1.2.2.1.2]",
    "preprocessing": [
        {
            "type": 25,  # SNMP walk to JSON
            "params": "{#IFNAME}\n.1.3.6.1.2.1.2.2.1.2\n{#IFTYPE}\n.1.3.6.1.2.1.2.2.1.3"
        }
    ]
}
```

### Database Query Discovery

Use ODBC to discover database objects:

```python
lld_rule = {
    "name": "Database table discovery",
    "key_": "db.odbc.discovery[{$DSN}]",
    "type": 11,  # Database monitor
    "params": """
        SELECT
            table_name as "{#TABLE}",
            table_schema as "{#SCHEMA}"
        FROM information_schema.tables
        WHERE table_schema NOT IN ('mysql', 'information_schema')
    """
}
```

### Container Discovery

Discover Docker containers:

```python
# Custom script for Docker discovery
script_content = """
import docker
import json

client = docker.from_env()
containers = []

for container in client.containers.list():
    containers.append({
        "{#CONTAINER_ID}": container.id[:12],
        "{#CONTAINER_NAME}": container.name,
        "{#CONTAINER_IMAGE}": container.image.tags[0] if container.image.tags else "unknown",
        "{#CONTAINER_STATUS}": container.status
    })

print(json.dumps(containers))
"""
```

**Reference:** scripts/custom_lld_scripts/docker_discovery.py

### Bulk LLD Operations

Create multiple discovery rules efficiently:

```python
# Bulk create discovery rules with prototypes
rules_config = [
    {
        "name": "CPU discovery",
        "key_": "system.cpu.discovery",
        "prototypes": [
            {"name": "CPU {#CPU.NUMBER} usage", "key_": "system.cpu.util[,{#CPU.NUMBER}]"}
        ]
    },
    {
        "name": "Disk discovery",
        "key_": "vfs.dev.discovery",
        "prototypes": [
            {"name": "Disk {#DEVNAME} read rate", "key_": "vfs.dev.read[{#DEVNAME}]"}
        ]
    }
]

# Process bulk creation
for rule_config in rules_config:
    create_lld_rule_with_prototypes(rule_config)
```

**Reference:** examples/bulk_lld.yaml for bulk configurations

---

## Best Practices

### Discovery Rule Design

**Update Intervals:**
- Static infrastructure: 1h - 1d
- Dynamic containers: 5m - 30m
- Critical services: 1m - 10m

**Lost Resource Handling:**
- Set "Disable lost resources" to at least 2x update interval
- Set "Delete lost resources" to 7d or more
- Never use "Immediately" delete in production

**Macro Naming:**
- Use descriptive uppercase names: `{#IFNAME}` not `{#N}`
- Include entity type: `{#DB_NAME}`, `{#CONTAINER_ID}`
- Be consistent across related rules

### Filter Configuration

**Filter Strategy:**
- Use "And/Or" calculation for flexibility
- Test regex patterns before deployment
- Document filter logic in rule description
- Consider using "exists/does not exist" for optional fields

**Common Filter Patterns:**
```regex
# Include only physical interfaces
{#IFNAME} matches: ^(eth|ens|enp)[0-9]+

# Exclude temporary filesystems
{#FSTYPE} does not match: ^tmpfs|^devtmpfs|^overlay

# Include only production databases
{#DB_NAME} matches: ^prod_|^production_

# Exclude system processes
{#PNAME} does not match: ^system|^kernel
```

### Prototype Design

**Item Prototypes:**
- Use appropriate value types (numeric, text, log)
- Set proper units (B, bps, %, etc.)
- Configure history/trend retention
- Add preprocessing when needed
- Use tags for organization

**Trigger Prototypes:**
- Include entity name in description: "High CPU on {#CPU.NUMBER}"
- Set appropriate severity
- Add tags for filtering: `component`, `entity_type`
- Use operational data for context
- Test expressions before deployment

### Custom Script Guidelines

**Script Requirements:**
1. Output valid JSON to stdout
2. Handle errors gracefully (empty array on error)
3. Include error messages in stderr
4. Exit with status 0 on success
5. Execute within 30s (default timeout)

**Script Template:**
```python
#!/usr/bin/env python3
import json
import sys

def discover():
    """Discovery logic"""
    try:
        # Discovery code here
        results = []
        return results
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return []

if __name__ == "__main__":
    data = discover()
    print(json.dumps(data))
    sys.exit(0)
```

### Performance Optimization

**Reduce Discovery Load:**
- Increase update intervals for stable infrastructure
- Use preprocessing to filter data before LLD processing
- Limit discovered items with filters
- Use overrides to disable unnecessary items

**Efficient JSON:**
- Keep JSON compact (no unnecessary whitespace)
- Limit macro count per entity (< 20 recommended)
- Avoid deep nesting in custom scripts
- Use preprocessing for data transformation

### Error Handling

**Common Issues:**

1. **Invalid JSON** - Validate JSON format in custom scripts
2. **Missing Macros** - Ensure all required macros exist in JSON
3. **Filter Errors** - Test regex patterns separately
4. **Timeout** - Optimize slow discovery scripts
5. **Duplicate Keys** - Ensure unique item keys for each entity

**Debugging Steps:**
1. Check discovery rule error field
2. Test custom script manually
3. Validate JSON format
4. Review filter configuration
5. Check Zabbix server logs

**Reference:** scripts/test_lld_discovery.py for validation tools

---

## Script Usage

### Main LLD Manager

Comprehensive LLD rule management:

```bash
python scripts/zabbix_lld_manager.py \
    --action create \
    --config examples/filesystem_lld.json \
    --host "Web Server 01"
```

**Actions:** create, update, delete, list, test

**Reference:** scripts/zabbix_lld_manager.py

### LLD Rule Creator

Create rules from templates:

```bash
python scripts/lld_rule_creator.py \
    --template filesystem \
    --host-id 10001 \
    --output rule_config.json
```

**Reference:** scripts/lld_rule_creator.py

### Validation Tool

Validate LLD configurations:

```bash
python scripts/validate_lld_config.py \
    --config examples/custom_lld.json \
    --check-json \
    --check-macros \
    --check-filters
```

**Reference:** scripts/validate_lld_config.py

### Test Discovery

Test discovery rules without applying:

```bash
python scripts/test_lld_discovery.py \
    --rule-id 12345 \
    --execute \
    --show-entities \
    --check-prototypes
```

**Reference:** scripts/test_lld_discovery.py

### Custom Discovery Scripts

Platform-specific discovery scripts:

```bash
# File system discovery
python scripts/custom_lld_scripts/filesystem_discovery.py

# Network interface discovery
bash scripts/custom_lld_scripts/network_interface_discovery.sh

# Docker container discovery
python scripts/custom_lld_scripts/docker_discovery.py

# Windows service discovery
powershell scripts/custom_lld_scripts/windows_service_discovery.ps1

# Database discovery
python scripts/custom_lld_scripts/database_discovery.py
```

**Reference:** scripts/custom_lld_scripts/ directory

---

## Examples

Comprehensive LLD examples in examples/ directory:

- **filesystem_lld.json** - Complete file system discovery with prototypes
- **network_lld.yaml** - Network interface discovery
- **service_lld.json** - Service discovery configuration
- **snmp_lld.yaml** - SNMP-based discovery
- **custom_lld.json** - Custom script-based LLD
- **lld_filters_overrides.yaml** - Filter and override patterns
- **bulk_lld.yaml** - Bulk LLD configurations

---

## Related Documentation

- Zabbix LLD documentation: zabbix-docs-masters/zabbix-docs/15_Discovery/3_low_level_discovery.md
- LLD macros: zabbix-docs-masters/zabbix-docs/07_Configuration/5_lld_macros.md
- Discovery prototypes: zabbix-docs-masters/zabbix-docs/15_Discovery/5_discovery_prototypes.md
- API reference: zabbix-docs-masters/zabbix-docs/20_API/183_discoveryrule.md

---

## Troubleshooting

### Discovery Not Working

**Check:**
1. Discovery rule enabled and not in error state
2. Host is monitored and agent accessible
3. Item key returns valid JSON
4. Filters not blocking all entities
5. Update interval allows sufficient time

**Debug:**
```bash
# Test discovery rule manually
zabbix_get -s <host> -k vfs.fs.discovery

# Check rule status via API
python scripts/test_lld_discovery.py --rule-id <id> --status
```

### No Items Created

**Possible Causes:**
- No entities match filters
- Item prototypes have errors
- Duplicate item keys
- Host/template configuration issue

**Verify:**
```bash
# Check discovered entities
python scripts/test_lld_discovery.py --rule-id <id> --show-entities

# Validate item prototypes
python scripts/validate_lld_config.py --rule-id <id> --check-prototypes
```

### Invalid JSON Error

**Common Issues:**
- Missing quotes around macro names
- Trailing commas in JSON
- Invalid escape sequences
- Non-UTF8 characters

**Fix:**
```python
# Validate JSON from custom script
python -m json.tool < discovery_output.json

# Test with validation script
python scripts/validate_lld_config.py --json-file discovery_output.json
```

### Performance Issues

**Optimize:**
- Increase update interval
- Add filters to reduce entities
- Use preprocessing to reduce data size
- Disable unnecessary item prototypes via overrides
- Check script execution time

---

## Integration Points

This skill integrates with:

- **Zabbix API Authentication** - Requires valid API credentials
- **Template Management** - LLD rules typically defined in templates
- **Item Management** - Creates item prototypes
- **Trigger Management** - Creates trigger prototypes
- **Graph Management** - Creates graph prototypes
- **Host Management** - Can create host prototypes
- **Monitoring Configuration** - Core monitoring setup
