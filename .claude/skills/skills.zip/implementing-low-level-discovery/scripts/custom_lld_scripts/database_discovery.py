#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Database Discovery Script for Zabbix LLD

Discovers databases across multiple database types:
- PostgreSQL
- MySQL/MariaDB
- Microsoft SQL Server
- MongoDB

Output format:
[
    {
        "{#DB.NAME}": "production_db",
        "{#DB.TYPE}": "postgresql",
        "{#DB.SIZE}": "1073741824",
        "{#DB.OWNER}": "admin"
    }
]

Usage:
    python database_discovery.py --type postgresql --host localhost --user admin --password secret
    python database_discovery.py --type mysql --host localhost --exclude-system
    python database_discovery.py --type mongodb --host localhost:27017

Author: Zabbix Skills
Version: 1.0.0
"""

import json
import sys
import argparse
from typing import List, Dict, Any


def discover_postgresql(host, port, user, password, database, exclude_system):
    """Discover PostgreSQL databases"""
    try:
        import psycopg2
    except ImportError:
        print("Error: psycopg2 library required. Install with: pip install psycopg2-binary", file=sys.stderr)
        return []

    databases = []

    try:
        # Connect to PostgreSQL
        conn = psycopg2.connect(
            host=host,
            port=port,
            user=user,
            password=password,
            database=database
        )
        cursor = conn.cursor()

        # Query databases
        query = """
            SELECT
                d.datname as name,
                pg_database_size(d.datname) as size,
                pg_catalog.pg_get_userbyid(d.datdba) as owner,
                pg_encoding_to_char(d.encoding) as encoding,
                d.datcollate as collation
            FROM pg_database d
            WHERE d.datistemplate = false
        """

        if exclude_system:
            query += " AND d.datname NOT IN ('postgres', 'template0', 'template1')"

        cursor.execute(query)

        for row in cursor.fetchall():
            db_info = {
                "{#DB.NAME}": row[0],
                "{#DB.TYPE}": "postgresql",
                "{#DB.SIZE}": str(row[1] if row[1] else 0),
                "{#DB.OWNER}": row[2],
                "{#DB.ENCODING}": row[3],
                "{#DB.COLLATION}": row[4]
            }
            databases.append(db_info)

        cursor.close()
        conn.close()

    except Exception as e:
        print(f"Error discovering PostgreSQL databases: {e}", file=sys.stderr)
        return []

    return databases


def discover_mysql(host, port, user, password, exclude_system):
    """Discover MySQL/MariaDB databases"""
    try:
        import pymysql
    except ImportError:
        print("Error: pymysql library required. Install with: pip install pymysql", file=sys.stderr)
        return []

    databases = []

    try:
        # Connect to MySQL
        conn = pymysql.connect(
            host=host,
            port=port,
            user=user,
            password=password
        )
        cursor = conn.cursor()

        # Query databases
        query = """
            SELECT
                SCHEMA_NAME as name,
                DEFAULT_CHARACTER_SET_NAME as charset,
                DEFAULT_COLLATION_NAME as collation
            FROM information_schema.SCHEMATA
        """

        if exclude_system:
            query += " WHERE SCHEMA_NAME NOT IN ('information_schema', 'mysql', 'performance_schema', 'sys')"

        cursor.execute(query)

        for row in cursor.fetchall():
            # Get database size
            size_query = """
                SELECT SUM(data_length + index_length)
                FROM information_schema.TABLES
                WHERE table_schema = %s
            """
            cursor.execute(size_query, (row[0],))
            size_row = cursor.fetchone()
            size = size_row[0] if size_row[0] else 0

            db_info = {
                "{#DB.NAME}": row[0],
                "{#DB.TYPE}": "mysql",
                "{#DB.SIZE}": str(size),
                "{#DB.CHARSET}": row[1],
                "{#DB.COLLATION}": row[2]
            }
            databases.append(db_info)

        cursor.close()
        conn.close()

    except Exception as e:
        print(f"Error discovering MySQL databases: {e}", file=sys.stderr)
        return []

    return databases


def discover_mssql(host, port, user, password, exclude_system):
    """Discover Microsoft SQL Server databases"""
    try:
        import pymssql
    except ImportError:
        print("Error: pymssql library required. Install with: pip install pymssql", file=sys.stderr)
        return []

    databases = []

    try:
        # Connect to SQL Server
        conn = pymssql.connect(
            server=host,
            port=port,
            user=user,
            password=password
        )
        cursor = conn.cursor()

        # Query databases
        query = """
            SELECT
                d.name,
                d.database_id,
                d.create_date,
                d.collation_name,
                d.state_desc,
                d.recovery_model_desc,
                SUSER_SNAME(d.owner_sid) as owner,
                (SELECT SUM(size) * 8 / 1024 FROM sys.master_files WHERE database_id = d.database_id) as size_mb
            FROM sys.databases d
        """

        if exclude_system:
            query += " WHERE d.database_id > 4"  # Exclude master, tempdb, model, msdb

        cursor.execute(query)

        for row in cursor.fetchall():
            size_bytes = int(row[7] * 1024 * 1024) if row[7] else 0

            db_info = {
                "{#DB.NAME}": row[0],
                "{#DB.TYPE}": "mssql",
                "{#DB.SIZE}": str(size_bytes),
                "{#DB.OWNER}": row[6],
                "{#DB.COLLATION}": row[3],
                "{#DB.STATE}": row[4],
                "{#DB.RECOVERY_MODEL}": row[5],
                "{#DB.CREATED}": row[2].isoformat() if row[2] else ""
            }
            databases.append(db_info)

        cursor.close()
        conn.close()

    except Exception as e:
        print(f"Error discovering MSSQL databases: {e}", file=sys.stderr)
        return []

    return databases


def discover_mongodb(host, port, user, password, exclude_system):
    """Discover MongoDB databases"""
    try:
        from pymongo import MongoClient
    except ImportError:
        print("Error: pymongo library required. Install with: pip install pymongo", file=sys.stderr)
        return []

    databases = []

    try:
        # Connect to MongoDB
        if user and password:
            client = MongoClient(
                host=host,
                port=port,
                username=user,
                password=password
            )
        else:
            client = MongoClient(host=host, port=port)

        # Get database names
        db_names = client.list_database_names()

        for db_name in db_names:
            # Skip system databases if requested
            if exclude_system and db_name in ['admin', 'config', 'local']:
                continue

            db = client[db_name]

            # Get database stats
            stats = db.command("dbStats")

            db_info = {
                "{#DB.NAME}": db_name,
                "{#DB.TYPE}": "mongodb",
                "{#DB.SIZE}": str(stats.get('dataSize', 0)),
                "{#DB.COLLECTIONS}": str(stats.get('collections', 0)),
                "{#DB.INDEXES}": str(stats.get('indexes', 0)),
                "{#DB.STORAGE_SIZE}": str(stats.get('storageSize', 0))
            }
            databases.append(db_info)

        client.close()

    except Exception as e:
        print(f"Error discovering MongoDB databases: {e}", file=sys.stderr)
        return []

    return databases


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='Discover databases for Zabbix LLD',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # PostgreSQL
  python database_discovery.py --type postgresql --host localhost --user zabbix --password secret

  # MySQL
  python database_discovery.py --type mysql --host localhost --user root --password secret --exclude-system

  # SQL Server
  python database_discovery.py --type mssql --host localhost --user sa --password secret

  # MongoDB
  python database_discovery.py --type mongodb --host localhost --port 27017
        """
    )

    parser.add_argument(
        '--type',
        required=True,
        choices=['postgresql', 'mysql', 'mssql', 'mongodb'],
        help='Database type'
    )
    parser.add_argument(
        '--host',
        default='localhost',
        help='Database host (default: localhost)'
    )
    parser.add_argument(
        '--port',
        type=int,
        help='Database port (default: DB-specific default port)'
    )
    parser.add_argument(
        '--user',
        help='Database user'
    )
    parser.add_argument(
        '--password',
        help='Database password'
    )
    parser.add_argument(
        '--database',
        default='postgres',
        help='Initial database to connect to (PostgreSQL only, default: postgres)'
    )
    parser.add_argument(
        '--exclude-system',
        action='store_true',
        help='Exclude system databases'
    )
    parser.add_argument(
        '--pretty',
        action='store_true',
        help='Pretty print JSON output'
    )

    args = parser.parse_args()

    # Set default ports
    if not args.port:
        default_ports = {
            'postgresql': 5432,
            'mysql': 3306,
            'mssql': 1433,
            'mongodb': 27017
        }
        args.port = default_ports[args.type]

    # Discover databases based on type
    if args.type == 'postgresql':
        databases = discover_postgresql(
            args.host, args.port, args.user, args.password,
            args.database, args.exclude_system
        )
    elif args.type == 'mysql':
        databases = discover_mysql(
            args.host, args.port, args.user, args.password,
            args.exclude_system
        )
    elif args.type == 'mssql':
        databases = discover_mssql(
            args.host, args.port, args.user, args.password,
            args.exclude_system
        )
    elif args.type == 'mongodb':
        databases = discover_mongodb(
            args.host, args.port, args.user, args.password,
            args.exclude_system
        )
    else:
        print(f"Error: Unknown database type: {args.type}", file=sys.stderr)
        sys.exit(1)

    # Output JSON
    if args.pretty:
        print(json.dumps(databases, indent=2))
    else:
        print(json.dumps(databases))

    sys.exit(0)


if __name__ == "__main__":
    main()
