#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Docker Container Discovery Script for Zabbix LLD

Discovers running and stopped Docker containers.

Output format:
[
    {
        "{#CONTAINER.ID}": "abc123",
        "{#CONTAINER.NAME}": "web-app",
        "{#CONTAINER.IMAGE}": "nginx:latest",
        "{#CONTAINER.STATUS}": "running"
    }
]

Usage:
    python docker_discovery.py
    python docker_discovery.py --only-running
    python docker_discovery.py --exclude-pattern "^test_"

Author: Zabbix Skills
Version: 1.0.0
"""

import json
import sys
import argparse
import re

try:
    import docker
except ImportError:
    print("Error: docker library required. Install with: pip install docker", file=sys.stderr)
    sys.exit(1)


def discover_containers(only_running=False, include_pattern=None, exclude_pattern=None):
    """
    Discover Docker containers

    Args:
        only_running: Only discover running containers
        include_pattern: Regex pattern for container names to include
        exclude_pattern: Regex pattern for container names to exclude

    Returns:
        List of discovered containers
    """
    containers = []

    try:
        # Connect to Docker daemon
        client = docker.from_env()

        # Get all containers
        all_containers = client.containers.list(all=not only_running)

        for container in all_containers:
            try:
                # Get container name (remove leading /)
                name = container.name

                # Apply include pattern if specified
                if include_pattern and not re.search(include_pattern, name):
                    continue

                # Apply exclude pattern if specified
                if exclude_pattern and re.search(exclude_pattern, name):
                    continue

                # Get container details
                attrs = container.attrs

                # Get image name
                image_name = "unknown"
                if container.image.tags:
                    image_name = container.image.tags[0]
                else:
                    # Use image ID if no tags
                    image_name = container.image.id[:12]

                # Get network info
                networks = list(attrs['NetworkSettings']['Networks'].keys())
                network_str = ",".join(networks) if networks else ""

                # Get port mappings
                ports = []
                port_bindings = attrs['NetworkSettings'].get('Ports', {})
                for container_port, host_bindings in port_bindings.items():
                    if host_bindings:
                        for binding in host_bindings:
                            host_port = binding.get('HostPort', '')
                            if host_port:
                                ports.append(f"{host_port}:{container_port}")
                ports_str = ",".join(ports) if ports else ""

                # Get container labels
                labels = attrs['Config'].get('Labels', {})

                # Get restart policy
                restart_policy = attrs['HostConfig'].get('RestartPolicy', {}).get('Name', 'no')

                # Build LLD entity
                container_info = {
                    "{#CONTAINER.ID}": container.id[:12],
                    "{#CONTAINER.NAME}": name,
                    "{#CONTAINER.IMAGE}": image_name,
                    "{#CONTAINER.STATUS}": container.status,
                    "{#CONTAINER.STATE}": attrs['State']['Status'],
                    "{#CONTAINER.NETWORKS}": network_str,
                    "{#CONTAINER.PORTS}": ports_str,
                    "{#CONTAINER.RESTART_POLICY}": restart_policy,
                    "{#CONTAINER.CREATED}": attrs['Created']
                }

                # Add custom labels if present
                if 'com.docker.compose.project' in labels:
                    container_info["{#CONTAINER.COMPOSE_PROJECT}"] = labels['com.docker.compose.project']
                if 'com.docker.compose.service' in labels:
                    container_info["{#CONTAINER.COMPOSE_SERVICE}"] = labels['com.docker.compose.service']

                containers.append(container_info)

            except Exception as e:
                print(f"Warning: Could not process container {container.name}: {e}", file=sys.stderr)
                continue

    except docker.errors.DockerException as e:
        print(f"Error: Could not connect to Docker daemon: {e}", file=sys.stderr)
        print("Make sure Docker is running and you have permission to access it.", file=sys.stderr)
        return []
    except Exception as e:
        print(f"Error during discovery: {e}", file=sys.stderr)
        return []

    return containers


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='Discover Docker containers for Zabbix LLD',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument(
        '--only-running',
        action='store_true',
        help='Only discover running containers'
    )
    parser.add_argument(
        '--include-pattern',
        help='Include only containers matching this regex pattern (by name)',
        default=None
    )
    parser.add_argument(
        '--exclude-pattern',
        help='Exclude containers matching this regex pattern (by name)',
        default=None
    )
    parser.add_argument(
        '--pretty',
        action='store_true',
        help='Pretty print JSON output'
    )

    args = parser.parse_args()

    # Discover containers
    containers = discover_containers(
        only_running=args.only_running,
        include_pattern=args.include_pattern,
        exclude_pattern=args.exclude_pattern
    )

    # Output JSON
    if args.pretty:
        print(json.dumps(containers, indent=2))
    else:
        print(json.dumps(containers))

    sys.exit(0)


if __name__ == "__main__":
    main()
