#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
File System Discovery Script for Zabbix LLD

Discovers mounted file systems and returns JSON for Zabbix LLD.
Cross-platform support: Linux, Windows, macOS

Output format:
[
    {"{#FSNAME}": "/", "{#FSTYPE}": "ext4", "{#FSTOTAL}": "1000000"},
    {"{#FSNAME}": "/home", "{#FSTYPE}": "xfs", "{#FSTOTAL}": "2000000"}
]

Usage:
    python filesystem_discovery.py
    python filesystem_discovery.py --exclude-types tmpfs,devtmpfs
    python filesystem_discovery.py --min-size 1073741824  # 1GB minimum

Author: Zabbix Skills
Version: 1.0.0
"""

import json
import sys
import argparse
import platform

try:
    import psutil
except ImportError:
    print("Error: psutil library required. Install with: pip install psutil", file=sys.stderr)
    sys.exit(1)


def discover_filesystems(exclude_types=None, min_size=0, include_pseudo=False):
    """
    Discover mounted file systems

    Args:
        exclude_types: List of filesystem types to exclude
        min_size: Minimum filesystem size in bytes
        include_pseudo: Include pseudo filesystems (tmpfs, devtmpfs, etc.)

    Returns:
        List of discovered filesystems
    """
    if exclude_types is None:
        # Default exclusions for pseudo filesystems
        exclude_types = [
            'tmpfs', 'devtmpfs', 'devfs', 'procfs', 'sysfs', 'cgroup',
            'cgroup2', 'pstore', 'hugetlbfs', 'debugfs', 'tracefs',
            'securityfs', 'bpf', 'fusectl', 'configfs', 'mqueue',
            'autofs', 'overlay', 'squashfs'
        ]

    filesystems = []

    try:
        # Get all mounted partitions
        partitions = psutil.disk_partitions(all=True)

        for partition in partitions:
            try:
                # Skip excluded filesystem types
                if not include_pseudo and partition.fstype.lower() in [t.lower() for t in exclude_types]:
                    continue

                # Get disk usage
                usage = psutil.disk_usage(partition.mountpoint)

                # Skip if below minimum size
                if usage.total < min_size:
                    continue

                # Determine drive type (Windows only)
                drive_type = "unknown"
                if platform.system() == "Windows":
                    if partition.opts and "fixed" in partition.opts.lower():
                        drive_type = "fixed"
                    elif partition.opts and "removable" in partition.opts.lower():
                        drive_type = "removable"
                    elif partition.opts and "cdrom" in partition.opts.lower():
                        drive_type = "cdrom"
                    elif partition.opts and "remote" in partition.opts.lower():
                        drive_type = "remote"
                else:
                    drive_type = "fixed"

                # Build LLD entity
                fs_info = {
                    "{#FSNAME}": partition.mountpoint,
                    "{#FSTYPE}": partition.fstype,
                    "{#FSDEVICE}": partition.device,
                    "{#FSOPTS}": partition.opts if partition.opts else "",
                    "{#FSDRIVETYPE}": drive_type,
                    "{#FSTOTAL}": str(usage.total),
                    "{#FSUSED}": str(usage.used),
                    "{#FSFREE}": str(usage.free),
                    "{#FSPERCENT}": str(usage.percent)
                }

                filesystems.append(fs_info)

            except (PermissionError, OSError) as e:
                # Skip filesystems we can't access
                print(f"Warning: Could not access {partition.mountpoint}: {e}", file=sys.stderr)
                continue

    except Exception as e:
        print(f"Error during discovery: {e}", file=sys.stderr)
        return []

    return filesystems


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='Discover file systems for Zabbix LLD',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument(
        '--exclude-types',
        help='Comma-separated list of filesystem types to exclude',
        default=None
    )
    parser.add_argument(
        '--min-size',
        type=int,
        help='Minimum filesystem size in bytes',
        default=0
    )
    parser.add_argument(
        '--include-pseudo',
        action='store_true',
        help='Include pseudo filesystems (tmpfs, devtmpfs, etc.)'
    )
    parser.add_argument(
        '--pretty',
        action='store_true',
        help='Pretty print JSON output'
    )

    args = parser.parse_args()

    # Parse excluded types
    exclude_types = None
    if args.exclude_types:
        exclude_types = [t.strip() for t in args.exclude_types.split(',')]

    # Discover filesystems
    filesystems = discover_filesystems(
        exclude_types=exclude_types,
        min_size=args.min_size,
        include_pseudo=args.include_pseudo
    )

    # Output JSON
    if args.pretty:
        print(json.dumps(filesystems, indent=2))
    else:
        print(json.dumps(filesystems))

    sys.exit(0)


if __name__ == "__main__":
    main()
