#!/bin/bash
#
# Network Interface Discovery Script for Zabbix LLD
#
# Discovers network interfaces and returns JSON for Zabbix LLD.
# Linux only (uses ip command)
#
# Output format:
# [
#     {"{#IFNAME}": "eth0", "{#IFTYPE}": "ether", "{#IFSTATUS}": "up"},
#     {"{#IFNAME}": "eth1", "{#IFTYPE}": "ether", "{#IFSTATUS}": "down"}
# ]
#
# Usage:
#     bash network_interface_discovery.sh
#     bash network_interface_discovery.sh --exclude-loopback
#     bash network_interface_discovery.sh --only-physical
#
# Author: Zabbix Skills
# Version: 1.0.0

set -euo pipefail

# Default options
EXCLUDE_LOOPBACK=false
ONLY_PHYSICAL=false
EXCLUDE_DOWN=false

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --exclude-loopback)
            EXCLUDE_LOOPBACK=true
            shift
            ;;
        --only-physical)
            ONLY_PHYSICAL=true
            shift
            ;;
        --exclude-down)
            EXCLUDE_DOWN=true
            shift
            ;;
        --help)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --exclude-loopback    Exclude loopback interface"
            echo "  --only-physical       Only include physical interfaces"
            echo "  --exclude-down        Exclude interfaces that are down"
            echo "  --help                Show this help message"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            echo "Use --help for usage information" >&2
            exit 1
            ;;
    esac
done

# Check if ip command is available
if ! command -v ip &> /dev/null; then
    echo "Error: 'ip' command not found. This script requires iproute2 package." >&2
    exit 1
fi

# Start JSON array
echo -n "["

first=true

# Get all network interfaces
for iface in /sys/class/net/*; do
    ifname=$(basename "$iface")

    # Skip loopback if requested
    if [ "$EXCLUDE_LOOPBACK" = true ] && [ "$ifname" = "lo" ]; then
        continue
    fi

    # Get interface details
    if [ -f "$iface/operstate" ]; then
        status=$(cat "$iface/operstate")
    else
        status="unknown"
    fi

    # Skip down interfaces if requested
    if [ "$EXCLUDE_DOWN" = true ] && [ "$status" = "down" ]; then
        continue
    fi

    # Determine interface type
    if [ -f "$iface/type" ]; then
        typecode=$(cat "$iface/type")
        case $typecode in
            1) iftype="ether";;
            24) iftype="ieee1394";;
            512) iftype="ppp";;
            768) iftype="ipip";;
            769) iftype="ip6tnl";;
            772) iftype="loopback";;
            776) iftype="sit";;
            778) iftype="gre";;
            783) iftype="irda";;
            801) iftype="wlan";;
            *) iftype="other";;
        esac
    else
        iftype="unknown"
    fi

    # Skip non-physical interfaces if requested
    if [ "$ONLY_PHYSICAL" = true ]; then
        # Check if it's a virtual interface
        if [ -d "$iface/device" ]; then
            is_physical=true
        elif [ "$iftype" = "ether" ] || [ "$iftype" = "wlan" ]; then
            # Some physical interfaces might not have device directory
            is_physical=true
        else
            is_physical=false
        fi

        if [ "$is_physical" = false ]; then
            continue
        fi
    fi

    # Get MAC address
    if [ -f "$iface/address" ]; then
        mac=$(cat "$iface/address")
    else
        mac=""
    fi

    # Get MTU
    if [ -f "$iface/mtu" ]; then
        mtu=$(cat "$iface/mtu")
    else
        mtu="0"
    fi

    # Get speed (Mbps) - only for interfaces that support it
    speed="0"
    if [ -f "$iface/speed" ]; then
        speed=$(cat "$iface/speed" 2>/dev/null || echo "0")
    fi

    # Get duplex
    duplex="unknown"
    if [ -f "$iface/duplex" ]; then
        duplex=$(cat "$iface/duplex" 2>/dev/null || echo "unknown")
    fi

    # Get IP addresses using ip command
    ipv4=""
    ipv6=""
    if command -v ip &> /dev/null; then
        ipv4=$(ip -4 addr show "$ifname" 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -1 || echo "")
        ipv6=$(ip -6 addr show "$ifname" 2>/dev/null | grep -oP '(?<=inet6\s)[0-9a-f:]+' | grep -v '^fe80' | head -1 || echo "")
    fi

    # Add comma if not first element
    if [ "$first" = false ]; then
        echo -n ","
    fi
    first=false

    # Output JSON object
    cat <<EOF

  {
    "{#IFNAME}": "$ifname",
    "{#IFTYPE}": "$iftype",
    "{#IFSTATUS}": "$status",
    "{#IFMAC}": "$mac",
    "{#IFMTU}": "$mtu",
    "{#IFSPEED}": "$speed",
    "{#IFDUPLEX}": "$duplex",
    "{#IFIPV4}": "$ipv4",
    "{#IFIPV6}": "$ipv6"
  }
EOF
done

# Close JSON array
echo ""
echo "]"

exit 0
