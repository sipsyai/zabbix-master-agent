# Windows Service Discovery Script for Zabbix LLD
#
# Discovers Windows services and returns JSON for Zabbix LLD.
#
# Output format:
# [
#     {"{#SERVICE.NAME}": "wuauserv", "{#SERVICE.DISPLAYNAME}": "Windows Update", "{#SERVICE.STATE}": "Running"},
#     {"{#SERVICE.NAME}": "MSSQLSERVER", "{#SERVICE.DISPLAYNAME}": "SQL Server", "{#SERVICE.STATE}": "Running"}
# ]
#
# Usage:
#     powershell -ExecutionPolicy Bypass -File windows_service_discovery.ps1
#     powershell -File windows_service_discovery.ps1 -OnlyRunning
#     powershell -File windows_service_discovery.ps1 -IncludePattern "SQL"
#     powershell -File windows_service_discovery.ps1 -ExcludePattern "^Windows"
#
# Author: Zabbix Skills
# Version: 1.0.0

param(
    [switch]$OnlyRunning,
    [string]$IncludePattern,
    [string]$ExcludePattern,
    [switch]$OnlyAutomatic,
    [switch]$Pretty,
    [switch]$Help
)

# Show help
if ($Help) {
    Write-Host "Windows Service Discovery for Zabbix LLD"
    Write-Host ""
    Write-Host "Usage:"
    Write-Host "  powershell -File windows_service_discovery.ps1 [OPTIONS]"
    Write-Host ""
    Write-Host "Options:"
    Write-Host "  -OnlyRunning      Only discover running services"
    Write-Host "  -OnlyAutomatic    Only discover services with automatic startup"
    Write-Host "  -IncludePattern   Include only services matching regex pattern (by DisplayName)"
    Write-Host "  -ExcludePattern   Exclude services matching regex pattern (by DisplayName)"
    Write-Host "  -Pretty           Pretty print JSON output"
    Write-Host "  -Help             Show this help message"
    Write-Host ""
    Write-Host "Examples:"
    Write-Host "  powershell -File windows_service_discovery.ps1 -OnlyRunning"
    Write-Host "  powershell -File windows_service_discovery.ps1 -IncludePattern 'SQL|IIS'"
    Write-Host "  powershell -File windows_service_discovery.ps1 -ExcludePattern '^Windows' -OnlyAutomatic"
    exit 0
}

# Function to convert startup type to string
function Get-StartupTypeString {
    param($StartType)

    switch ($StartType) {
        "Automatic" { return "auto" }
        "Manual" { return "manual" }
        "Disabled" { return "disabled" }
        "AutomaticDelayedStart" { return "auto-delayed" }
        default { return $StartType.ToString().ToLower() }
    }
}

# Function to get service state as number (for Zabbix)
function Get-ServiceStateNumber {
    param($Status)

    switch ($Status) {
        "Running" { return 0 }
        "Stopped" { return 1 }
        "Paused" { return 2 }
        "StartPending" { return 3 }
        "StopPending" { return 4 }
        "ContinuePending" { return 5 }
        "PausePending" { return 6 }
        default { return 255 }
    }
}

try {
    # Get all services
    $services = Get-Service | Sort-Object DisplayName

    # Build array of discovered services
    $discoveredServices = @()

    foreach ($service in $services) {
        # Filter by running status
        if ($OnlyRunning -and $service.Status -ne "Running") {
            continue
        }

        # Get additional service details
        $serviceDetails = Get-WmiObject -Class Win32_Service -Filter "Name='$($service.Name)'" -ErrorAction SilentlyContinue

        # Filter by startup type
        if ($OnlyAutomatic -and $serviceDetails) {
            if ($serviceDetails.StartMode -ne "Auto" -and $serviceDetails.StartMode -ne "Automatic") {
                continue
            }
        }

        # Apply include pattern
        if ($IncludePattern -and $service.DisplayName -notmatch $IncludePattern) {
            continue
        }

        # Apply exclude pattern
        if ($ExcludePattern -and $service.DisplayName -match $ExcludePattern) {
            continue
        }

        # Get startup type
        $startupType = "unknown"
        $pathName = ""
        $description = ""
        if ($serviceDetails) {
            $startupType = Get-StartupTypeString -StartType $serviceDetails.StartMode
            $pathName = $serviceDetails.PathName
            $description = $serviceDetails.Description
        }

        # Build service object
        $serviceInfo = [PSCustomObject]@{
            "{#SERVICE.NAME}" = $service.Name
            "{#SERVICE.DISPLAYNAME}" = $service.DisplayName
            "{#SERVICE.STATUS}" = $service.Status.ToString()
            "{#SERVICE.STATE}" = Get-ServiceStateNumber -Status $service.Status
            "{#SERVICE.STARTTYPE}" = $startupType
            "{#SERVICE.CANSTOP}" = $service.CanStop.ToString().ToLower()
            "{#SERVICE.CANPAUSE}" = $service.CanPauseAndContinue.ToString().ToLower()
            "{#SERVICE.PATH}" = $pathName
            "{#SERVICE.DESCRIPTION}" = $description
        }

        $discoveredServices += $serviceInfo
    }

    # Convert to JSON
    if ($Pretty) {
        $json = $discoveredServices | ConvertTo-Json -Depth 3
    } else {
        $json = $discoveredServices | ConvertTo-Json -Depth 3 -Compress
    }

    # Output JSON
    Write-Output $json

} catch {
    Write-Error "Error during service discovery: $_"
    # Return empty array on error
    Write-Output "[]"
    exit 1
}

exit 0
