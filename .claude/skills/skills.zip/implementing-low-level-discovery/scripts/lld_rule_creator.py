#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix LLD Rule Creator

Create LLD rules from predefined templates or custom configurations.
Supports common discovery patterns: filesystem, network, services, containers, databases.

Usage:
    python lld_rule_creator.py --template filesystem --host-id 10001
    python lld_rule_creator.py --custom config.json --host-id 10001
    python lld_rule_creator.py --list-templates

Author: Zabbix Skills
Version: 1.0.0
"""

import argparse
import json
import sys
from typing import Dict, List, Any

# Predefined LLD rule templates
LLD_TEMPLATES = {
    "filesystem": {
        "name": "File system discovery",
        "key": "vfs.fs.discovery",
        "type": 0,
        "delay": "1h",
        "lifetime": "7d",
        "description": "Discovery file systems on the host",
        "filter": {
            "evaltype": 0,
            "conditions": [
                {
                    "macro": "{#FSTYPE}",
                    "value": "^(btrfs|ext2|ext3|ext4|reiser|xfs|ffs|ufs|jfs|jfs2|vxfs|hfs|apfs|refs|ntfs|fat32|zfs)$",
                    "formulaid": "A",
                }
            ],
        },
        "item_prototypes": [
            {
                "name": "Free disk space on {#FSNAME}",
                "key": "vfs.fs.size[{#FSNAME},free]",
                "type": 0,
                "value_type": 3,
                "units": "B",
                "delay": "1m",
                "history": "7d",
                "trends": "365d",
                "tags": [
                    {"tag": "component", "value": "storage"},
                    {"tag": "filesystem", "value": "{#FSNAME}"},
                ],
            },
            {
                "name": "Free disk space on {#FSNAME} (percentage)",
                "key": "vfs.fs.size[{#FSNAME},pfree]",
                "type": 0,
                "value_type": 0,
                "units": "%",
                "delay": "1m",
                "history": "7d",
                "trends": "365d",
            },
            {
                "name": "Total disk space on {#FSNAME}",
                "key": "vfs.fs.size[{#FSNAME},total]",
                "type": 0,
                "value_type": 3,
                "units": "B",
                "delay": "1h",
                "history": "7d",
                "trends": "365d",
            },
            {
                "name": "Used disk space on {#FSNAME}",
                "key": "vfs.fs.size[{#FSNAME},used]",
                "type": 0,
                "value_type": 3,
                "units": "B",
                "delay": "1m",
                "history": "7d",
                "trends": "365d",
            },
        ],
        "trigger_prototypes": [
            {
                "description": "Free disk space is less than 20% on {#FSNAME}",
                "expression": "last(/HOSTNAME/vfs.fs.size[{#FSNAME},pfree])<20",
                "priority": 2,
                "tags": [
                    {"tag": "component", "value": "storage"},
                    {"tag": "filesystem", "value": "{#FSNAME}"},
                ],
            },
            {
                "description": "Free disk space is less than 10% on {#FSNAME}",
                "expression": "last(/HOSTNAME/vfs.fs.size[{#FSNAME},pfree])<10",
                "priority": 3,
                "tags": [
                    {"tag": "component", "value": "storage"},
                    {"tag": "filesystem", "value": "{#FSNAME}"},
                ],
            },
        ],
    },
    "network": {
        "name": "Network interface discovery",
        "key": "net.if.discovery",
        "type": 0,
        "delay": "1h",
        "lifetime": "7d",
        "description": "Discovery network interfaces",
        "filter": {
            "evaltype": 0,
            "conditions": [
                {
                    "macro": "{#IFNAME}",
                    "value": "@Network interfaces for discovery",
                    "formulaid": "A",
                }
            ],
        },
        "item_prototypes": [
            {
                "name": "Incoming traffic on {#IFNAME}",
                "key": "net.if.in[{#IFNAME}]",
                "type": 0,
                "value_type": 3,
                "units": "bps",
                "delay": "1m",
                "history": "7d",
                "trends": "365d",
                "preprocessing": [
                    {"type": 10, "params": "", "error_handler": 0},
                    {"type": 1, "params": "8", "error_handler": 0},
                ],
                "tags": [
                    {"tag": "component", "value": "network"},
                    {"tag": "interface", "value": "{#IFNAME}"},
                ],
            },
            {
                "name": "Outgoing traffic on {#IFNAME}",
                "key": "net.if.out[{#IFNAME}]",
                "type": 0,
                "value_type": 3,
                "units": "bps",
                "delay": "1m",
                "history": "7d",
                "trends": "365d",
                "preprocessing": [
                    {"type": 10, "params": "", "error_handler": 0},
                    {"type": 1, "params": "8", "error_handler": 0},
                ],
            },
        ],
        "trigger_prototypes": [
            {
                "description": "High bandwidth usage on {#IFNAME} (incoming)",
                "expression": "avg(/HOSTNAME/net.if.in[{#IFNAME}],5m)>100M",
                "priority": 3,
                "tags": [
                    {"tag": "component", "value": "network"},
                    {"tag": "interface", "value": "{#IFNAME}"},
                ],
            }
        ],
    },
    "cpu": {
        "name": "CPU discovery",
        "key": "system.cpu.discovery",
        "type": 0,
        "delay": "1h",
        "lifetime": "7d",
        "description": "Discovery CPU cores",
        "item_prototypes": [
            {
                "name": "CPU {#CPU.NUMBER} usage",
                "key": "system.cpu.util[,{#CPU.NUMBER}]",
                "type": 0,
                "value_type": 0,
                "units": "%",
                "delay": "1m",
                "history": "7d",
                "trends": "365d",
                "tags": [
                    {"tag": "component", "value": "cpu"},
                    {"tag": "cpu", "value": "{#CPU.NUMBER}"},
                ],
            }
        ],
        "trigger_prototypes": [
            {
                "description": "High CPU usage on core {#CPU.NUMBER}",
                "expression": "avg(/HOSTNAME/system.cpu.util[,{#CPU.NUMBER}],5m)>80",
                "priority": 2,
                "tags": [{"tag": "component", "value": "cpu"}],
            }
        ],
    },
    "service": {
        "name": "Windows service discovery",
        "key": "service.discovery",
        "type": 0,
        "delay": "1h",
        "lifetime": "7d",
        "description": "Discovery Windows services",
        "item_prototypes": [
            {
                "name": "State of service {#SERVICE.NAME}",
                "key": "service.info[{#SERVICE.NAME},state]",
                "type": 0,
                "value_type": 3,
                "delay": "1m",
                "history": "7d",
                "trends": "365d",
                "tags": [
                    {"tag": "component", "value": "service"},
                    {"tag": "service", "value": "{#SERVICE.NAME}"},
                ],
            }
        ],
        "trigger_prototypes": [
            {
                "description": "Service {#SERVICE.NAME} is not running",
                "expression": "last(/HOSTNAME/service.info[{#SERVICE.NAME},state])<>0",
                "priority": 3,
                "tags": [
                    {"tag": "component", "value": "service"},
                    {"tag": "service", "value": "{#SERVICE.NAME}"},
                ],
            }
        ],
    },
    "docker": {
        "name": "Docker container discovery",
        "key": "docker.container.discovery",
        "type": 0,
        "delay": "5m",
        "lifetime": "1d",
        "description": "Discovery Docker containers",
        "lld_macro_paths": [
            {"lld_macro": "{#CONTAINER.ID}", "path": "$.id"},
            {"lld_macro": "{#CONTAINER.NAME}", "path": "$.name"},
            {"lld_macro": "{#CONTAINER.IMAGE}", "path": "$.image"},
        ],
        "item_prototypes": [
            {
                "name": "Container {#CONTAINER.NAME}: CPU usage",
                "key": "docker.container.cpu[{#CONTAINER.ID}]",
                "type": 0,
                "value_type": 0,
                "units": "%",
                "delay": "1m",
                "history": "7d",
                "trends": "365d",
                "tags": [
                    {"tag": "component", "value": "docker"},
                    {"tag": "container", "value": "{#CONTAINER.NAME}"},
                ],
            },
            {
                "name": "Container {#CONTAINER.NAME}: Memory usage",
                "key": "docker.container.memory[{#CONTAINER.ID}]",
                "type": 0,
                "value_type": 3,
                "units": "B",
                "delay": "1m",
                "history": "7d",
                "trends": "365d",
            },
        ],
        "trigger_prototypes": [
            {
                "description": "Container {#CONTAINER.NAME}: High CPU usage",
                "expression": "avg(/HOSTNAME/docker.container.cpu[{#CONTAINER.ID}],5m)>80",
                "priority": 2,
                "tags": [
                    {"tag": "component", "value": "docker"},
                    {"tag": "container", "value": "{#CONTAINER.NAME}"},
                ],
            }
        ],
    },
    "database": {
        "name": "Database discovery",
        "key": "database.discovery",
        "type": 0,
        "delay": "1h",
        "lifetime": "7d",
        "description": "Discovery databases",
        "lld_macro_paths": [
            {"lld_macro": "{#DB.NAME}", "path": "$.name"},
            {"lld_macro": "{#DB.TYPE}", "path": "$.type"},
        ],
        "item_prototypes": [
            {
                "name": "Database {#DB.NAME}: Active connections",
                "key": "db.connections[{#DB.NAME}]",
                "type": 0,
                "value_type": 3,
                "delay": "1m",
                "history": "7d",
                "trends": "365d",
                "tags": [
                    {"tag": "component", "value": "database"},
                    {"tag": "database", "value": "{#DB.NAME}"},
                ],
            },
            {
                "name": "Database {#DB.NAME}: Size",
                "key": "db.size[{#DB.NAME}]",
                "type": 0,
                "value_type": 3,
                "units": "B",
                "delay": "1h",
                "history": "7d",
                "trends": "365d",
            },
        ],
        "trigger_prototypes": [
            {
                "description": "Database {#DB.NAME}: Too many connections",
                "expression": "last(/HOSTNAME/db.connections[{#DB.NAME}])>100",
                "priority": 2,
                "tags": [
                    {"tag": "component", "value": "database"},
                    {"tag": "database", "value": "{#DB.NAME}"},
                ],
            }
        ],
    },
}


def list_templates():
    """Display all available templates"""
    print("\nAvailable LLD Templates:")
    print("=" * 80)
    for name, template in LLD_TEMPLATES.items():
        print(f"\n{name.upper()}")
        print("-" * 80)
        print(f"  Name: {template['name']}")
        print(f"  Key: {template['key']}")
        print(f"  Description: {template['description']}")
        print(f"  Item Prototypes: {len(template.get('item_prototypes', []))}")
        print(f"  Trigger Prototypes: {len(template.get('trigger_prototypes', []))}")
        if "lld_macro_paths" in template:
            print(f"  Custom Macros: {len(template['lld_macro_paths'])}")


def create_rule_from_template(template_name: str, host_id: str) -> Dict[str, Any]:
    """
    Create LLD rule configuration from template

    Args:
        template_name: Name of the template
        host_id: Host ID

    Returns:
        LLD rule configuration
    """
    if template_name not in LLD_TEMPLATES:
        print(f"Error: Template '{template_name}' not found")
        print("\nAvailable templates:")
        for name in LLD_TEMPLATES.keys():
            print(f"  - {name}")
        sys.exit(1)

    config = LLD_TEMPLATES[template_name].copy()
    config["hostid"] = host_id

    return config


def customize_template(
    template: Dict[str, Any], customizations: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Apply customizations to a template

    Args:
        template: Base template configuration
        customizations: Custom modifications

    Returns:
        Customized configuration
    """
    config = template.copy()

    # Update basic fields
    for field in ["name", "key", "delay", "lifetime", "description"]:
        if field in customizations:
            config[field] = customizations[field]

    # Update filter
    if "filter" in customizations:
        config["filter"] = customizations["filter"]

    # Add additional item prototypes
    if "additional_items" in customizations:
        config.setdefault("item_prototypes", []).extend(
            customizations["additional_items"]
        )

    # Add additional trigger prototypes
    if "additional_triggers" in customizations:
        config.setdefault("trigger_prototypes", []).extend(
            customizations["additional_triggers"]
        )

    return config


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Zabbix LLD Rule Creator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # List all available templates
  python lld_rule_creator.py --list-templates

  # Create filesystem discovery rule
  python lld_rule_creator.py --template filesystem --host-id 10001 --output fs_lld.json

  # Create network discovery rule with customizations
  python lld_rule_creator.py --template network --host-id 10001 --customize custom.json

  # Create rule from custom configuration
  python lld_rule_creator.py --custom myconfig.json --host-id 10001
        """,
    )

    parser.add_argument(
        "--template",
        choices=list(LLD_TEMPLATES.keys()),
        help="Use predefined template",
    )
    parser.add_argument("--custom", help="Path to custom configuration file (JSON)")
    parser.add_argument("--host-id", help="Host ID for the LLD rule")
    parser.add_argument(
        "--customize", help="Path to customization file (JSON)", default=None
    )
    parser.add_argument(
        "--output", help="Output file path (JSON)", default="lld_rule.json"
    )
    parser.add_argument(
        "--list-templates", action="store_true", help="List all available templates"
    )
    parser.add_argument(
        "--pretty", action="store_true", help="Pretty print JSON output"
    )

    args = parser.parse_args()

    # List templates
    if args.list_templates:
        list_templates()
        sys.exit(0)

    # Validate required arguments
    if not args.template and not args.custom:
        print("Error: Either --template or --custom is required")
        parser.print_help()
        sys.exit(1)

    if not args.host_id:
        print("Error: --host-id is required")
        sys.exit(1)

    # Create configuration
    if args.template:
        config = create_rule_from_template(args.template, args.host_id)

        # Apply customizations if provided
        if args.customize:
            with open(args.customize, "r") as f:
                customizations = json.load(f)
            config = customize_template(config, customizations)

    else:
        # Load custom configuration
        with open(args.custom, "r") as f:
            config = json.load(f)
        config["hostid"] = args.host_id

    # Write output
    with open(args.output, "w") as f:
        if args.pretty:
            json.dump(config, f, indent=2)
        else:
            json.dump(config, f)

    print(f"LLD rule configuration saved to: {args.output}")
    print(f"\nRule details:")
    print(f"  Name: {config['name']}")
    print(f"  Key: {config['key']}")
    print(f"  Host ID: {config['hostid']}")
    print(f"  Item Prototypes: {len(config.get('item_prototypes', []))}")
    print(f"  Trigger Prototypes: {len(config.get('trigger_prototypes', []))}")


if __name__ == "__main__":
    main()
