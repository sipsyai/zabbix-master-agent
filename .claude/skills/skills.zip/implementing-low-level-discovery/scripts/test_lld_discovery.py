#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix LLD Discovery Testing Tool

Test and debug LLD rules:
- Execute discovery immediately
- Show discovered entities
- Validate discovery JSON output
- Check prototype creation
- Monitor discovery status

Usage:
    python test_lld_discovery.py --rule-id 12345 --execute
    python test_lld_discovery.py --rule-id 12345 --show-entities
    python test_lld_discovery.py --json-file discovery_output.json --validate

Author: Zabbix Skills
Version: 1.0.0
"""

import argparse
import json
import sys
import time
from typing import Dict, List, Any
from datetime import datetime

try:
    from pyzabbix import ZabbixAPI, ZabbixAPIException
except ImportError:
    print("Error: pyzabbix library not found. Install with: pip install pyzabbix")
    sys.exit(1)


class LLDTester:
    """Test and debug LLD rules"""

    def __init__(self, url: str, username: str, password: str):
        """Initialize Zabbix API connection"""
        self.zapi = ZabbixAPI(url)
        try:
            self.zapi.login(username, password)
            print(f"[OK] Connected to Zabbix API version {self.zapi.api_version()}\n")
        except ZabbixAPIException as e:
            print(f"[ERROR] Failed to connect to Zabbix API: {e}")
            sys.exit(1)

    def execute_discovery(self, rule_id: str) -> bool:
        """
        Execute discovery rule immediately

        Args:
            rule_id: Discovery rule ID

        Returns:
            True on success, False on error
        """
        try:
            # Get rule info
            rule = self.zapi.discoveryrule.get(
                itemids=rule_id,
                output=["name", "key_", "hostid"],
                selectHosts=["host", "name"],
            )

            if not rule:
                print(f"[ERROR] Discovery rule ID {rule_id} not found")
                return False

            rule_info = rule[0]
            print(f"Executing discovery rule: {rule_info['name']}")
            print(f"  Key: {rule_info['key_']}")
            print(f"  Host: {rule_info['hosts'][0]['host']}")

            # Execute discovery
            result = self.zapi.task.create({"type": 6, "itemids": [rule_id]})

            print(f"\n[OK] Discovery task created (Task ID: {result['taskids'][0]})")
            print("  Waiting for execution...")

            # Wait a bit for discovery to execute
            time.sleep(3)

            # Check if discovery executed successfully
            rule_status = self.zapi.discoveryrule.get(
                itemids=rule_id, output=["lastclock", "error", "status"]
            )

            if rule_status:
                status_info = rule_status[0]
                if status_info.get("error"):
                    print(f"\n[ERROR] Discovery error: {status_info['error']}")
                    return False
                else:
                    last_check = datetime.fromtimestamp(int(status_info["lastclock"]))
                    print(f"\n[OK] Discovery executed successfully")
                    print(f"  Last check: {last_check}")
                    return True

            return True

        except ZabbixAPIException as e:
            print(f"[ERROR] Error executing discovery: {e}")
            return False

    def show_discovered_entities(self, rule_id: str, limit: int = 20) -> None:
        """
        Show discovered entities from LLD rule

        Args:
            rule_id: Discovery rule ID
            limit: Maximum entities to show
        """
        try:
            # Get rule info
            rule = self.zapi.discoveryrule.get(
                itemids=rule_id, output=["name", "key_"], selectHosts=["host"]
            )

            if not rule:
                print(f"[ERROR] Discovery rule ID {rule_id} not found")
                return

            rule_info = rule[0]

            print(f"\nDiscovered Entities for: {rule_info['name']}")
            print("=" * 80)

            # Get discovered items
            items = self.zapi.item.get(
                discoveryids=rule_id,
                output=["name", "key_", "status", "lastclock", "lastvalue", "error"],
                sortfield="name",
                limit=limit,
            )

            if items:
                print(f"\n📦 Discovered Items ({len(items)}):")
                print("-" * 80)
                for item in items:
                    status = "[OK] Enabled" if item["status"] == "0" else "[ERROR] Disabled"
                    last_check = (
                        datetime.fromtimestamp(int(item["lastclock"]))
                        if item["lastclock"] != "0"
                        else "Never"
                    )

                    print(f"\n  {item['name']}")
                    print(f"    Key: {item['key_']}")
                    print(f"    Status: {status}")
                    print(f"    Last check: {last_check}")
                    if item.get("lastvalue"):
                        print(f"    Last value: {item['lastvalue']}")
                    if item.get("error"):
                        print(f"    [WARN]️  Error: {item['error']}")
            else:
                print("\n  No items discovered yet")

            # Get discovered triggers
            triggers = self.zapi.trigger.get(
                discoveryids=rule_id,
                output=["description", "status", "priority", "value"],
                sortfield="description",
                limit=limit,
            )

            if triggers:
                print(f"\n🔔 Discovered Triggers ({len(triggers)}):")
                print("-" * 80)
                for trigger in triggers:
                    status = "[OK] Enabled" if trigger["status"] == "0" else "[ERROR] Disabled"
                    priority_map = {
                        "0": "Not classified",
                        "1": "Information",
                        "2": "Warning",
                        "3": "Average",
                        "4": "High",
                        "5": "Disaster",
                    }
                    priority = priority_map.get(trigger["priority"], "Unknown")
                    state = "🔴 PROBLEM" if trigger["value"] == "1" else "🟢 OK"

                    print(f"\n  {trigger['description']}")
                    print(f"    Status: {status}")
                    print(f"    Priority: {priority}")
                    print(f"    State: {state}")
            else:
                print("\n  No triggers discovered yet")

            # Get discovered graphs
            graphs = self.zapi.graph.get(
                discoveryids=rule_id, output=["name"], sortfield="name", limit=limit
            )

            if graphs:
                print(f"\n📊 Discovered Graphs ({len(graphs)}):")
                print("-" * 80)
                for graph in graphs:
                    print(f"  * {graph['name']}")
            else:
                print("\n  No graphs discovered yet")

        except ZabbixAPIException as e:
            print(f"[ERROR] Error showing entities: {e}")

    def check_discovery_status(self, rule_id: str) -> Dict[str, Any]:
        """
        Get detailed discovery rule status

        Args:
            rule_id: Discovery rule ID

        Returns:
            Dictionary with status information
        """
        try:
            rule = self.zapi.discoveryrule.get(
                itemids=rule_id,
                output=[
                    "name",
                    "key_",
                    "delay",
                    "status",
                    "error",
                    "lastclock",
                    "lifetime",
                    "state",
                ],
                selectHosts=["host", "name"],
                selectItems="count",
                selectTriggers="count",
                selectGraphs="count",
            )

            if not rule:
                return {"success": False, "error": "Rule not found"}

            rule_info = rule[0]

            # Format status
            status_map = {"0": "Enabled", "1": "Disabled"}
            state_map = {"0": "Normal", "1": "Not supported"}

            status = {
                "success": True,
                "rule_name": rule_info["name"],
                "rule_key": rule_info["key_"],
                "host": rule_info["hosts"][0]["host"],
                "status": status_map.get(rule_info["status"], "Unknown"),
                "state": state_map.get(rule_info["state"], "Unknown"),
                "update_interval": rule_info["delay"],
                "lifetime": rule_info["lifetime"],
                "last_check": (
                    datetime.fromtimestamp(int(rule_info["lastclock"])).isoformat()
                    if rule_info["lastclock"] != "0"
                    else "Never"
                ),
                "error": rule_info.get("error", ""),
                "discovered_items": rule_info["items"],
                "discovered_triggers": rule_info["triggers"],
                "discovered_graphs": rule_info["graphs"],
            }

            return status

        except ZabbixAPIException as e:
            return {"success": False, "error": str(e)}

    def validate_json_output(self, json_data: str) -> Dict[str, Any]:
        """
        Validate LLD JSON output

        Args:
            json_data: JSON string to validate

        Returns:
            Dictionary with validation results
        """
        try:
            data = json.loads(json_data)
        except json.JSONDecodeError as e:
            return {
                "valid": False,
                "error": f"Invalid JSON: {e}",
                "format": None,
                "entity_count": 0,
                "macros": [],
            }

        # Determine format
        if isinstance(data, list):
            discovery_data = data
            format_type = "array (Zabbix 4.2+)"
        elif isinstance(data, dict) and "data" in data:
            discovery_data = data["data"]
            format_type = "object with 'data' key (legacy)"
        else:
            return {
                "valid": False,
                "error": "JSON must be an array or object with 'data' key",
                "format": None,
                "entity_count": 0,
                "macros": [],
            }

        # Extract macros
        all_macros = set()
        for entity in discovery_data:
            if isinstance(entity, dict):
                for key in entity.keys():
                    if key.startswith("{#"):
                        all_macros.add(key)

        return {
            "valid": True,
            "format": format_type,
            "entity_count": len(discovery_data),
            "macros": sorted(list(all_macros)),
            "sample_entity": discovery_data[0] if discovery_data else None,
        }


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Zabbix LLD Discovery Testing Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Execute discovery and show entities
  python test_lld_discovery.py --rule-id 12345 --execute --show-entities

  # Check discovery status
  python test_lld_discovery.py --rule-id 12345 --status

  # Validate JSON output from file
  python test_lld_discovery.py --json-file discovery.json --validate

  # Validate JSON output from command
  python test_lld_discovery.py --json-data '[{"{#FSNAME}": "/"}]' --validate
        """,
    )

    parser.add_argument(
        "--url", default="http://localhost/zabbix", help="Zabbix server URL"
    )
    parser.add_argument("--username", default="Admin", help="Zabbix username")
    parser.add_argument("--password", default="zabbix", help="Zabbix password")
    parser.add_argument("--rule-id", help="Discovery rule ID to test")
    parser.add_argument(
        "--execute", action="store_true", help="Execute discovery immediately"
    )
    parser.add_argument(
        "--show-entities", action="store_true", help="Show discovered entities"
    )
    parser.add_argument("--status", action="store_true", help="Show rule status")
    parser.add_argument("--json-file", help="Path to JSON file to validate")
    parser.add_argument("--json-data", help="JSON data string to validate")
    parser.add_argument(
        "--validate", action="store_true", help="Validate JSON output format"
    )
    parser.add_argument(
        "--limit", type=int, default=20, help="Limit entities to show (default: 20)"
    )

    args = parser.parse_args()

    # JSON validation without API
    if args.validate:
        if args.json_file:
            try:
                with open(args.json_file, "r") as f:
                    json_data = f.read()
            except FileNotFoundError:
                print(f"[ERROR] File not found: {args.json_file}")
                sys.exit(1)
        elif args.json_data:
            json_data = args.json_data
        else:
            print("Error: --json-file or --json-data required with --validate")
            sys.exit(1)

        # Create a temporary tester instance just for validation
        print("Validating JSON output format...")
        print("=" * 80)

        # Simple validation without API
        try:
            data = json.loads(json_data)
            if isinstance(data, list):
                discovery_data = data
                format_type = "array (Zabbix 4.2+)"
            elif isinstance(data, dict) and "data" in data:
                discovery_data = data["data"]
                format_type = "object with 'data' key (legacy)"
            else:
                print(
                    "[ERROR] Invalid format: JSON must be an array or object with 'data' key"
                )
                sys.exit(1)

            # Extract macros
            all_macros = set()
            for entity in discovery_data:
                if isinstance(entity, dict):
                    for key in entity.keys():
                        if key.startswith("{#"):
                            all_macros.add(key)

            print(f"[OK] Valid LLD JSON format")
            print(f"  Format: {format_type}")
            print(f"  Entities: {len(discovery_data)}")
            print(f"  Macros: {', '.join(sorted(all_macros))}")

            if discovery_data:
                print(f"\nSample entity:")
                print(json.dumps(discovery_data[0], indent=2))

        except json.JSONDecodeError as e:
            print(f"[ERROR] Invalid JSON: {e}")
            sys.exit(1)

        sys.exit(0)

    # API operations require rule ID
    if not args.rule_id:
        print("Error: --rule-id is required for API operations")
        parser.print_help()
        sys.exit(1)

    # Initialize tester
    tester = LLDTester(args.url, args.username, args.password)

    # Execute discovery
    if args.execute:
        tester.execute_discovery(args.rule_id)
        print()

    # Show status
    if args.status:
        status = tester.check_discovery_status(args.rule_id)
        if status["success"]:
            print("Discovery Rule Status:")
            print("=" * 80)
            print(f"  Rule: {status['rule_name']}")
            print(f"  Key: {status['rule_key']}")
            print(f"  Host: {status['host']}")
            print(f"  Status: {status['status']}")
            print(f"  State: {status['state']}")
            print(f"  Update Interval: {status['update_interval']}")
            print(f"  Lifetime: {status['lifetime']}")
            print(f"  Last Check: {status['last_check']}")
            if status["error"]:
                print(f"  [WARN]️  Error: {status['error']}")
            print(f"\nDiscovered entities:")
            print(f"  Items: {status['discovered_items']}")
            print(f"  Triggers: {status['discovered_triggers']}")
            print(f"  Graphs: {status['discovered_graphs']}")
        else:
            print(f"[ERROR] Error: {status['error']}")

    # Show entities
    if args.show_entities:
        tester.show_discovered_entities(args.rule_id, args.limit)


if __name__ == "__main__":
    main()
