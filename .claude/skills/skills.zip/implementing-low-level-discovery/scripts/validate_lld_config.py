#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix LLD Configuration Validator

Validates LLD configurations for:
- JSON format correctness
- LLD macro syntax
- Filter regex patterns
- Item prototype keys
- Trigger expressions
- Required fields

Usage:
    python validate_lld_config.py --config lld_config.json
    python validate_lld_config.py --json-data '{"data": []}'
    python validate_lld_config.py --config lld.json --strict

Author: Zabbix Skills
Version: 1.0.0
"""

import argparse
import json
import re
import sys
from typing import Dict, List, Tuple, Any

# LLD macro pattern
LLD_MACRO_PATTERN = re.compile(r"\{#[A-Z0-9_\.]+\}")

# Valid item types
ITEM_TYPES = {
    0: "Zabbix agent",
    2: "Zabbix trapper",
    3: "Simple check",
    5: "Zabbix internal",
    7: "Zabbix agent (active)",
    10: "External check",
    11: "Database monitor",
    12: "IPMI agent",
    13: "SSH agent",
    14: "Telnet agent",
    15: "Calculated",
    16: "JMX agent",
    17: "SNMP trap",
    18: "Dependent item",
    19: "HTTP agent",
    20: "SNMP agent",
    21: "Script",
}

# Valid value types
VALUE_TYPES = {
    0: "Numeric (float)",
    1: "Character",
    2: "Log",
    3: "Numeric (unsigned)",
    4: "Text",
}


class LLDValidator:
    """Validator for LLD configurations"""

    def __init__(self, strict: bool = False):
        """
        Initialize validator

        Args:
            strict: Enable strict validation mode
        """
        self.strict = strict
        self.errors = []
        self.warnings = []

    def validate_json_data(self, json_data: str) -> bool:
        """
        Validate LLD JSON data format

        Args:
            json_data: JSON string to validate

        Returns:
            True if valid, False otherwise
        """
        try:
            data = json.loads(json_data)
        except json.JSONDecodeError as e:
            self.errors.append(f"Invalid JSON format: {e}")
            return False

        # Check if it's an array or has 'data' key (legacy format)
        if isinstance(data, list):
            discovery_data = data
        elif isinstance(data, dict) and "data" in data:
            self.warnings.append(
                "Using legacy JSON format with 'data' key. Consider updating to array format."
            )
            discovery_data = data["data"]
        else:
            self.errors.append(
                "JSON must be an array or object with 'data' key containing an array"
            )
            return False

        if not isinstance(discovery_data, list):
            self.errors.append("Discovery data must be an array")
            return False

        # Validate each discovery entity
        for idx, entity in enumerate(discovery_data):
            if not isinstance(entity, dict):
                self.errors.append(f"Entity at index {idx} must be an object")
                continue

            # Check for LLD macros
            has_macros = False
            for key in entity.keys():
                if LLD_MACRO_PATTERN.match(key):
                    has_macros = True
                    # Validate macro value type
                    value = entity[key]
                    if not isinstance(value, (str, int, float, bool)):
                        self.errors.append(
                            f"Entity {idx}: Macro {key} has invalid value type. "
                            f"Must be string, number, or boolean, not {type(value).__name__}"
                        )

            if not has_macros:
                self.warnings.append(
                    f"Entity at index {idx} has no LLD macros (keys starting with {{#}})"
                )

        return len(self.errors) == 0

    def validate_lld_macros(self, text: str) -> List[str]:
        """
        Extract and validate LLD macros in text

        Args:
            text: Text to check for macros

        Returns:
            List of found macros
        """
        macros = LLD_MACRO_PATTERN.findall(text)
        return macros

    def validate_item_key(self, key: str) -> bool:
        """
        Validate item key syntax

        Args:
            key: Item key to validate

        Returns:
            True if valid, False otherwise
        """
        if not key:
            self.errors.append("Item key cannot be empty")
            return False

        # Check for basic key format
        if "[" in key:
            # Has parameters
            if not key.endswith("]"):
                self.errors.append(f"Invalid key format (unclosed bracket): {key}")
                return False

            key_name = key[: key.index("[")]
            params = key[key.index("[") + 1 : -1]

            if not key_name:
                self.errors.append(f"Missing key name: {key}")
                return False

        else:
            # Simple key without parameters
            key_name = key

        # Validate key name (alphanumeric, dots, underscores)
        if not re.match(r"^[a-zA-Z0-9._]+$", key_name):
            self.errors.append(f"Invalid characters in key name: {key_name}")
            return False

        return True

    def validate_filter(self, filter_config: Dict[str, Any]) -> bool:
        """
        Validate filter configuration

        Args:
            filter_config: Filter configuration

        Returns:
            True if valid, False otherwise
        """
        if "evaltype" not in filter_config:
            self.errors.append("Filter must have 'evaltype' field")
            return False

        evaltype = filter_config["evaltype"]
        if evaltype not in [0, 1, 2, 3]:
            self.errors.append(f"Invalid evaltype: {evaltype}. Must be 0-3")
            return False

        if "conditions" not in filter_config:
            self.errors.append("Filter must have 'conditions' array")
            return False

        conditions = filter_config["conditions"]
        if not isinstance(conditions, list) or len(conditions) == 0:
            self.warnings.append("Filter has no conditions")
            return True

        # Validate each condition
        for idx, condition in enumerate(conditions):
            if "macro" not in condition:
                self.errors.append(f"Condition {idx}: Missing 'macro' field")
                continue

            macro = condition["macro"]
            if not LLD_MACRO_PATTERN.match(macro):
                self.errors.append(
                    f"Condition {idx}: Invalid macro format: {macro}. Must be {{#MACRO}}"
                )

            if "value" in condition:
                # Validate regex if using matches/does not match
                operator = condition.get("operator", 0)
                if operator in [0, 1]:  # matches or does not match
                    try:
                        re.compile(condition["value"])
                    except re.error as e:
                        self.errors.append(
                            f"Condition {idx}: Invalid regex pattern: {e}"
                        )

        return len(self.errors) == 0

    def validate_lld_rule(self, config: Dict[str, Any]) -> bool:
        """
        Validate complete LLD rule configuration

        Args:
            config: LLD rule configuration

        Returns:
            True if valid, False otherwise
        """
        # Check required fields
        required_fields = ["name", "key_", "hostid", "type", "delay"]
        for field in required_fields:
            if field not in config:
                self.errors.append(f"Missing required field: {field}")

        # Validate name
        if "name" in config and not config["name"]:
            self.errors.append("Rule name cannot be empty")

        # Validate key
        if "key_" in config:
            self.validate_item_key(config["key_"])

        # Validate type
        if "type" in config:
            if config["type"] not in ITEM_TYPES:
                self.errors.append(
                    f"Invalid item type: {config['type']}. Valid types: {list(ITEM_TYPES.keys())}"
                )

        # Validate delay
        if "delay" in config:
            delay = config["delay"]
            if not re.match(r"^\d+[smhdw]?$", str(delay)):
                self.errors.append(
                    f"Invalid delay format: {delay}. Use format like '1h', '30s', '1d'"
                )

        # Validate filter if present
        if "filter" in config:
            self.validate_filter(config["filter"])

        # Validate LLD macro paths
        if "lld_macro_paths" in config:
            for macro_path in config["lld_macro_paths"]:
                if "lld_macro" not in macro_path or "path" not in macro_path:
                    self.errors.append("LLD macro path must have 'lld_macro' and 'path'")
                    continue

                if not LLD_MACRO_PATTERN.match(macro_path["lld_macro"]):
                    self.errors.append(
                        f"Invalid LLD macro: {macro_path['lld_macro']}. Must be {{#MACRO}}"
                    )

                # Validate JSONPath
                path = macro_path["path"]
                if not path.startswith("$."):
                    self.warnings.append(
                        f"JSONPath should start with '$.' : {path}"
                    )

        # Validate item prototypes
        if "item_prototypes" in config:
            for idx, item in enumerate(config["item_prototypes"]):
                self._validate_item_prototype(item, idx)

        # Validate trigger prototypes
        if "trigger_prototypes" in config:
            for idx, trigger in enumerate(config["trigger_prototypes"]):
                self._validate_trigger_prototype(trigger, idx)

        return len(self.errors) == 0

    def _validate_item_prototype(self, item: Dict[str, Any], idx: int) -> None:
        """Validate item prototype configuration"""
        # Required fields
        if "name" not in item:
            self.errors.append(f"Item prototype {idx}: Missing 'name' field")

        if "key_" not in item:
            self.errors.append(f"Item prototype {idx}: Missing 'key_' field")
        else:
            self.validate_item_key(item["key_"])
            # Check for LLD macros in key
            macros = self.validate_lld_macros(item["key_"])
            if not macros and self.strict:
                self.warnings.append(
                    f"Item prototype {idx}: Key has no LLD macros: {item['key_']}"
                )

        # Validate value type
        if "value_type" in item:
            if item["value_type"] not in VALUE_TYPES:
                self.errors.append(
                    f"Item prototype {idx}: Invalid value_type: {item['value_type']}"
                )

        # Check for LLD macros in name
        if "name" in item:
            macros = self.validate_lld_macros(item["name"])
            if not macros and self.strict:
                self.warnings.append(
                    f"Item prototype {idx}: Name has no LLD macros: {item['name']}"
                )

    def _validate_trigger_prototype(self, trigger: Dict[str, Any], idx: int) -> None:
        """Validate trigger prototype configuration"""
        # Required fields
        if "description" not in trigger:
            self.errors.append(f"Trigger prototype {idx}: Missing 'description' field")

        if "expression" not in trigger:
            self.errors.append(f"Trigger prototype {idx}: Missing 'expression' field")
        else:
            # Check for LLD macros in expression
            macros = self.validate_lld_macros(trigger["expression"])
            if not macros and self.strict:
                self.warnings.append(
                    f"Trigger prototype {idx}: Expression has no LLD macros"
                )

        # Validate priority
        if "priority" in trigger:
            if trigger["priority"] not in range(0, 6):
                self.errors.append(
                    f"Trigger prototype {idx}: Invalid priority: {trigger['priority']}. Must be 0-5"
                )

    def get_report(self) -> str:
        """
        Get validation report

        Returns:
            Formatted report string
        """
        report = []
        report.append("=" * 80)
        report.append("LLD Configuration Validation Report")
        report.append("=" * 80)

        if self.errors:
            report.append(f"\n[ERROR] ERRORS ({len(self.errors)}):")
            report.append("-" * 80)
            for i, error in enumerate(self.errors, 1):
                report.append(f"{i}. {error}")

        if self.warnings:
            report.append(f"\n[WARN]️  WARNINGS ({len(self.warnings)}):")
            report.append("-" * 80)
            for i, warning in enumerate(self.warnings, 1):
                report.append(f"{i}. {warning}")

        if not self.errors and not self.warnings:
            report.append("\n[OK] Configuration is valid!")

        report.append("\n" + "=" * 80)
        return "\n".join(report)


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Zabbix LLD Configuration Validator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Validate LLD rule configuration
  python validate_lld_config.py --config lld_rule.json

  # Validate JSON discovery data
  python validate_lld_config.py --json-data '[{"{#FSNAME}": "/"}]'

  # Validate with strict checks
  python validate_lld_config.py --config lld_rule.json --strict

  # Save report to file
  python validate_lld_config.py --config lld_rule.json --output report.txt
        """,
    )

    parser.add_argument("--config", help="Path to LLD rule configuration file (JSON)")
    parser.add_argument("--json-data", help="JSON discovery data to validate")
    parser.add_argument(
        "--strict", action="store_true", help="Enable strict validation mode"
    )
    parser.add_argument("--output", help="Save report to file", default=None)

    args = parser.parse_args()

    if not args.config and not args.json_data:
        print("Error: Either --config or --json-data is required")
        parser.print_help()
        sys.exit(1)

    validator = LLDValidator(strict=args.strict)

    # Validate JSON data
    if args.json_data:
        validator.validate_json_data(args.json_data)

    # Validate configuration file
    if args.config:
        try:
            with open(args.config, "r") as f:
                config = json.load(f)

            validator.validate_lld_rule(config)

        except FileNotFoundError:
            print(f"Error: Configuration file not found: {args.config}")
            sys.exit(1)
        except json.JSONDecodeError as e:
            print(f"Error: Invalid JSON in configuration file: {e}")
            sys.exit(1)

    # Generate and display report
    report = validator.get_report()
    print(report)

    # Save report to file if requested
    if args.output:
        with open(args.output, "w") as f:
            f.write(report)
        print(f"\nReport saved to: {args.output}")

    # Exit with error code if validation failed
    sys.exit(1 if validator.errors else 0)


if __name__ == "__main__":
    main()
