#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Low-Level Discovery (LLD) Manager

Comprehensive tool for managing Zabbix LLD rules, including:
- Creating discovery rules with full configuration
- Managing LLD macros and preprocessing
- Creating item, trigger, and graph prototypes
- Configuring filters and overrides
- Testing and validating LLD configurations
- Bulk operations on multiple rules

Usage:
    python zabbix_lld_manager.py --action create --config lld_config.json --host "Web Server"
    python zabbix_lld_manager.py --action list --host "Web Server"
    python zabbix_lld_manager.py --action test --rule-id 12345
    python zabbix_lld_manager.py --action delete --rule-id 12345

Author: Zabbix Skills
Version: 1.0.0
"""

import argparse
import json
import sys
import yaml
from typing import Dict, List, Optional, Any
from pathlib import Path

try:
    from pyzabbix import ZabbixAPI, ZabbixAPIException
except ImportError:
    print("Error: pyzabbix library not found. Install with: pip install pyzabbix")
    sys.exit(1)


class ZabbixLLDManager:
    """Manager for Zabbix Low-Level Discovery operations"""

    def __init__(self, url: str, username: str, password: str):
        """
        Initialize Zabbix API connection

        Args:
            url: Zabbix server URL
            username: API username
            password: API password
        """
        self.zapi = ZabbixAPI(url)
        try:
            self.zapi.login(username, password)
            print(f"Connected to Zabbix API version {self.zapi.api_version()}")
        except ZabbixAPIException as e:
            print(f"Failed to connect to Zabbix API: {e}")
            sys.exit(1)

    def get_host_id(self, host_name: str) -> Optional[str]:
        """
        Get host ID by hostname

        Args:
            host_name: Name of the host

        Returns:
            Host ID or None if not found
        """
        try:
            hosts = self.zapi.host.get(filter={"host": host_name}, output=["hostid"])
            if hosts:
                return hosts[0]["hostid"]
            else:
                print(f"Error: Host '{host_name}' not found")
                return None
        except ZabbixAPIException as e:
            print(f"Error getting host ID: {e}")
            return None

    def create_lld_rule(self, config: Dict[str, Any], host_id: str) -> Optional[str]:
        """
        Create a new LLD rule with full configuration

        Args:
            config: LLD rule configuration dictionary
            host_id: Host ID to create the rule on

        Returns:
            Discovery rule ID or None on error
        """
        try:
            # Base discovery rule configuration
            rule_data = {
                "name": config.get("name", "Unnamed Discovery Rule"),
                "key_": config.get("key", ""),
                "hostid": host_id,
                "type": config.get("type", 0),  # 0 = Zabbix agent
                "delay": config.get("delay", "1h"),
                "lifetime": config.get("lifetime", "7d"),
                "description": config.get("description", ""),
                "status": config.get("status", 0)  # 0 = enabled
            }

            # Add preprocessing steps if defined
            if "preprocessing" in config:
                rule_data["preprocessing"] = config["preprocessing"]

            # Add LLD macro paths if defined
            if "lld_macro_paths" in config:
                rule_data["lld_macro_paths"] = config["lld_macro_paths"]

            # Add filter if defined
            if "filter" in config:
                rule_data["filter"] = config["filter"]

            # Add overrides if defined
            if "overrides" in config:
                rule_data["overrides"] = config["overrides"]

            # Create the discovery rule
            result = self.zapi.discoveryrule.create(rule_data)
            rule_id = result["itemids"][0]
            print(f"Created LLD rule: {config['name']} (ID: {rule_id})")

            # Create item prototypes if defined
            if "item_prototypes" in config:
                self._create_item_prototypes(rule_id, config["item_prototypes"], host_id)

            # Create trigger prototypes if defined
            if "trigger_prototypes" in config:
                self._create_trigger_prototypes(rule_id, config["trigger_prototypes"])

            # Create graph prototypes if defined
            if "graph_prototypes" in config:
                self._create_graph_prototypes(rule_id, config["graph_prototypes"])

            return rule_id

        except ZabbixAPIException as e:
            print(f"Error creating LLD rule: {e}")
            return None

    def _create_item_prototypes(
        self, rule_id: str, prototypes: List[Dict], host_id: str
    ) -> None:
        """
        Create item prototypes for a discovery rule

        Args:
            rule_id: Discovery rule ID
            prototypes: List of item prototype configurations
            host_id: Host ID
        """
        for prototype in prototypes:
            try:
                item_data = {
                    "name": prototype.get("name", "Unnamed Item"),
                    "key_": prototype.get("key", ""),
                    "hostid": host_id,
                    "ruleid": rule_id,
                    "type": prototype.get("type", 0),
                    "value_type": prototype.get("value_type", 3),
                    "delay": prototype.get("delay", "1m"),
                    "history": prototype.get("history", "7d"),
                    "trends": prototype.get("trends", "365d"),
                    "status": prototype.get("status", 0),
                    "units": prototype.get("units", ""),
                    "description": prototype.get("description", ""),
                }

                # Add preprocessing if defined
                if "preprocessing" in prototype:
                    item_data["preprocessing"] = prototype["preprocessing"]

                # Add tags if defined
                if "tags" in prototype:
                    item_data["tags"] = prototype["tags"]

                result = self.zapi.itemprototype.create(item_data)
                print(f"  Created item prototype: {prototype['name']}")

            except ZabbixAPIException as e:
                print(f"  Error creating item prototype '{prototype.get('name')}': {e}")

    def _create_trigger_prototypes(
        self, rule_id: str, prototypes: List[Dict]
    ) -> None:
        """
        Create trigger prototypes for a discovery rule

        Args:
            rule_id: Discovery rule ID
            prototypes: List of trigger prototype configurations
        """
        for prototype in prototypes:
            try:
                trigger_data = {
                    "description": prototype.get("description", "Unnamed Trigger"),
                    "expression": prototype.get("expression", ""),
                    "priority": prototype.get("priority", 0),
                    "status": prototype.get("status", 0),
                    "comments": prototype.get("comments", ""),
                    "url": prototype.get("url", ""),
                    "recovery_mode": prototype.get("recovery_mode", 0),
                }

                # Add tags if defined
                if "tags" in prototype:
                    trigger_data["tags"] = prototype["tags"]

                # Add dependencies if defined
                if "dependencies" in prototype:
                    trigger_data["dependencies"] = prototype["dependencies"]

                result = self.zapi.triggerprototype.create(trigger_data)
                print(f"  Created trigger prototype: {prototype['description']}")

            except ZabbixAPIException as e:
                print(
                    f"  Error creating trigger prototype '{prototype.get('description')}': {e}"
                )

    def _create_graph_prototypes(self, rule_id: str, prototypes: List[Dict]) -> None:
        """
        Create graph prototypes for a discovery rule

        Args:
            rule_id: Discovery rule ID
            prototypes: List of graph prototype configurations
        """
        for prototype in prototypes:
            try:
                graph_data = {
                    "name": prototype.get("name", "Unnamed Graph"),
                    "width": prototype.get("width", 900),
                    "height": prototype.get("height", 200),
                    "gitems": prototype.get("gitems", []),
                }

                result = self.zapi.graphprototype.create(graph_data)
                print(f"  Created graph prototype: {prototype['name']}")

            except ZabbixAPIException as e:
                print(f"  Error creating graph prototype '{prototype.get('name')}': {e}")

    def update_lld_rule(self, rule_id: str, config: Dict[str, Any]) -> bool:
        """
        Update an existing LLD rule

        Args:
            rule_id: Discovery rule ID
            config: Updated configuration

        Returns:
            True on success, False on error
        """
        try:
            update_data = {"itemid": rule_id}
            update_data.update(config)

            self.zapi.discoveryrule.update(update_data)
            print(f"Updated LLD rule ID: {rule_id}")
            return True

        except ZabbixAPIException as e:
            print(f"Error updating LLD rule: {e}")
            return False

    def delete_lld_rule(self, rule_id: str) -> bool:
        """
        Delete an LLD rule and all its prototypes

        Args:
            rule_id: Discovery rule ID

        Returns:
            True on success, False on error
        """
        try:
            self.zapi.discoveryrule.delete([rule_id])
            print(f"Deleted LLD rule ID: {rule_id}")
            return True

        except ZabbixAPIException as e:
            print(f"Error deleting LLD rule: {e}")
            return False

    def list_lld_rules(self, host_id: Optional[str] = None) -> List[Dict]:
        """
        List all LLD rules for a host

        Args:
            host_id: Host ID (optional)

        Returns:
            List of LLD rule information
        """
        try:
            params = {
                "output": ["itemid", "name", "key_", "delay", "status", "error"],
                "selectItems": "count",
                "selectTriggers": "count",
                "selectGraphs": "count",
            }

            if host_id:
                params["hostids"] = host_id

            rules = self.zapi.discoveryrule.get(**params)
            return rules

        except ZabbixAPIException as e:
            print(f"Error listing LLD rules: {e}")
            return []

    def test_lld_rule(self, rule_id: str) -> Dict[str, Any]:
        """
        Test an LLD rule by executing it and showing results

        Args:
            rule_id: Discovery rule ID

        Returns:
            Dictionary with test results
        """
        try:
            # Get rule details
            rule = self.zapi.discoveryrule.get(
                itemids=rule_id,
                output=["itemid", "name", "key_", "status", "error", "lastclock"],
                selectHosts=["host"],
            )

            if not rule:
                return {"success": False, "error": "Rule not found"}

            rule_info = rule[0]

            # Execute discovery now
            self.zapi.task.create({"type": 6, "itemids": [rule_id]})

            # Get discovered items
            discovered_items = self.zapi.item.get(
                discoveryids=rule_id, output=["name", "key_", "status", "lastclock"]
            )

            # Get discovered triggers
            discovered_triggers = self.zapi.trigger.get(
                discoveryids=rule_id, output=["description", "status", "priority"]
            )

            result = {
                "success": True,
                "rule": rule_info,
                "discovered_items_count": len(discovered_items),
                "discovered_triggers_count": len(discovered_triggers),
                "discovered_items": discovered_items[:10],  # Limit output
                "discovered_triggers": discovered_triggers[:10],  # Limit output
            }

            return result

        except ZabbixAPIException as e:
            return {"success": False, "error": str(e)}

    def get_lld_status(self, rule_id: str) -> Dict[str, Any]:
        """
        Get detailed status of an LLD rule

        Args:
            rule_id: Discovery rule ID

        Returns:
            Dictionary with rule status information
        """
        try:
            rule = self.zapi.discoveryrule.get(
                itemids=rule_id,
                output=[
                    "itemid",
                    "name",
                    "key_",
                    "delay",
                    "status",
                    "error",
                    "lastclock",
                    "lifetime",
                ],
                selectHosts=["host", "name"],
                selectItems="count",
                selectTriggers="count",
                selectGraphs="count",
            )

            if not rule:
                return {"success": False, "error": "Rule not found"}

            return {"success": True, "rule": rule[0]}

        except ZabbixAPIException as e:
            return {"success": False, "error": str(e)}


def load_config_file(filepath: str) -> Dict[str, Any]:
    """
    Load configuration from JSON or YAML file

    Args:
        filepath: Path to configuration file

    Returns:
        Configuration dictionary
    """
    path = Path(filepath)
    if not path.exists():
        print(f"Error: Configuration file '{filepath}' not found")
        sys.exit(1)

    with open(path, "r") as f:
        if path.suffix in [".json"]:
            return json.load(f)
        elif path.suffix in [".yaml", ".yml"]:
            return yaml.safe_load(f)
        else:
            print(f"Error: Unsupported file format '{path.suffix}'")
            sys.exit(1)


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Zabbix Low-Level Discovery Manager",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Create LLD rule from config file
  python zabbix_lld_manager.py --action create --config lld.json --host "Web Server"

  # List all LLD rules for a host
  python zabbix_lld_manager.py --action list --host "Web Server"

  # Test an LLD rule
  python zabbix_lld_manager.py --action test --rule-id 12345

  # Update LLD rule
  python zabbix_lld_manager.py --action update --rule-id 12345 --config update.json

  # Delete LLD rule
  python zabbix_lld_manager.py --action delete --rule-id 12345
        """,
    )

    parser.add_argument(
        "--url", default="http://localhost/zabbix", help="Zabbix server URL"
    )
    parser.add_argument("--username", default="Admin", help="Zabbix username")
    parser.add_argument("--password", default="zabbix", help="Zabbix password")
    parser.add_argument(
        "--action",
        required=True,
        choices=["create", "update", "delete", "list", "test", "status"],
        help="Action to perform",
    )
    parser.add_argument("--config", help="Path to configuration file (JSON/YAML)")
    parser.add_argument("--host", help="Host name for LLD rule")
    parser.add_argument("--rule-id", help="LLD rule ID for update/delete/test/status")
    parser.add_argument(
        "--output", help="Output file for results (JSON)", default=None
    )

    args = parser.parse_args()

    # Initialize manager
    manager = ZabbixLLDManager(args.url, args.username, args.password)

    # Execute action
    if args.action == "create":
        if not args.config or not args.host:
            print("Error: --config and --host required for create action")
            sys.exit(1)

        config = load_config_file(args.config)
        host_id = manager.get_host_id(args.host)
        if host_id:
            rule_id = manager.create_lld_rule(config, host_id)
            if rule_id and args.output:
                with open(args.output, "w") as f:
                    json.dump({"rule_id": rule_id}, f, indent=2)

    elif args.action == "update":
        if not args.rule_id or not args.config:
            print("Error: --rule-id and --config required for update action")
            sys.exit(1)

        config = load_config_file(args.config)
        manager.update_lld_rule(args.rule_id, config)

    elif args.action == "delete":
        if not args.rule_id:
            print("Error: --rule-id required for delete action")
            sys.exit(1)

        manager.delete_lld_rule(args.rule_id)

    elif args.action == "list":
        host_id = None
        if args.host:
            host_id = manager.get_host_id(args.host)

        rules = manager.list_lld_rules(host_id)
        print(f"\nFound {len(rules)} LLD rules:")
        print("-" * 80)
        for rule in rules:
            status = "Enabled" if rule["status"] == "0" else "Disabled"
            print(f"ID: {rule['itemid']}")
            print(f"  Name: {rule['name']}")
            print(f"  Key: {rule['key_']}")
            print(f"  Status: {status}")
            print(f"  Items: {rule['items']}")
            print(f"  Triggers: {rule['triggers']}")
            print(f"  Graphs: {rule['graphs']}")
            if rule.get("error"):
                print(f"  Error: {rule['error']}")
            print("-" * 80)

        if args.output:
            with open(args.output, "w") as f:
                json.dump(rules, f, indent=2)

    elif args.action == "test":
        if not args.rule_id:
            print("Error: --rule-id required for test action")
            sys.exit(1)

        result = manager.test_lld_rule(args.rule_id)
        print("\nTest Results:")
        print(json.dumps(result, indent=2))

        if args.output:
            with open(args.output, "w") as f:
                json.dump(result, f, indent=2)

    elif args.action == "status":
        if not args.rule_id:
            print("Error: --rule-id required for status action")
            sys.exit(1)

        result = manager.get_lld_status(args.rule_id)
        if result["success"]:
            print("\nLLD Rule Status:")
            print(json.dumps(result["rule"], indent=2))
        else:
            print(f"Error: {result['error']}")

        if args.output:
            with open(args.output, "w") as f:
                json.dump(result, f, indent=2)


if __name__ == "__main__":
    main()
