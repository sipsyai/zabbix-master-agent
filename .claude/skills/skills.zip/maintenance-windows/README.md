# Maintenance Windows in Zabbix - Quick Start Guide

Complete automation toolkit for managing Zabbix maintenance periods, from scheduled windows to emergency maintenance and CI/CD integration.

## Overview

This skill provides comprehensive maintenance window management for Zabbix including:

- **Scheduled Maintenance**: Create one-time and recurring maintenance windows
- **Emergency Maintenance**: Quick activation for unplanned maintenance
- **CI/CD Integration**: Automatic maintenance during deployments
- **Change Management**: Integration with ServiceNow and JIRA
- **Calendar Sync**: Export to iCal, Google Calendar
- **Compliance Reporting**: Track maintenance history and compliance

## Quick Start

### 1. Setup

```bash
# Set environment variables
export ZABBIX_URL="https://zabbix.example.com/api_jsonrpc.php"
export ZABBIX_TOKEN="your-api-token-here"

# Install dependencies
pip install requests pyyaml
```

### 2. Create One-Time Maintenance

```bash
python scripts/zabbix_maintenance_manager.py create \
  --name "Database Upgrade - DB01" \
  --start "2025-12-15 22:00" \
  --duration 120 \
  --hosts "db-server-01" \
  --type no-data \
  --description "PostgreSQL upgrade from 14 to 15"
```

### 3. Schedule Recurring Maintenance

```bash
# Weekly Sunday backup window
python scripts/maintenance_scheduler.py weekly \
  --name "Weekly Backup Window" \
  --days "sunday" \
  --time "03:00" \
  --duration 180 \
  --hostgroups "Database Servers" \
  --start "2025-01-01" \
  --end "2026-12-31"
```

### 4. Emergency Maintenance

```bash
python scripts/emergency_maintenance.py activate \
  --hosts "web-01,web-02,web-03" \
  --duration 30 \
  --reason "Critical security patch - CVE-2024-1234"
```

## Common Use Cases

### Patch Tuesday Schedule

```bash
python scripts/maintenance_scheduler.py monthly-weekday \
  --name "Patch Tuesday - Windows Servers" \
  --week "second" \
  --days "tuesday" \
  --months "january,february,march,april,may,june,july,august,september,october,november,december" \
  --time "02:00" \
  --duration 240 \
  --hostgroups "Windows Servers" \
  --start "2025-01-01" \
  --end "2026-12-31" \
  --type no-data
```

### CI/CD Deployment

```yaml
# .gitlab-ci.yml
deploy_production:
  script:
    - python scripts/cicd_maintenance_trigger.py create-deployment-window --app myapp --environment production
    - ./deploy.sh
    - python scripts/cicd_maintenance_trigger.py end-maintenance --maintenance-id $(cat .maintenance_id)
```

### Business Hours Suppression

```bash
python scripts/maintenance_scheduler.py business-hours \
  --name "Business Hours Alert Suppression" \
  --start-time "09:00" \
  --end-time "17:00" \
  --weekdays-only \
  --hostgroups "Office Infrastructure" \
  --start "2025-01-01" \
  --end "2026-12-31"
```

## Directory Structure

```
maintenance-windows/
├── SKILL.md                          # Complete skill documentation
├── README.md                         # This file
├── scripts/
│   ├── zabbix_maintenance_manager.py    # Core CRUD operations
│   ├── maintenance_scheduler.py         # Recurring schedules
│   ├── emergency_maintenance.py         # Emergency activation
│   ├── validate_maintenance_config.py   # Configuration validation
│   ├── cicd_maintenance_trigger.py      # CI/CD integration
│   ├── maintenance_reporter.py          # History and compliance reports
│   ├── maintenance_calendar.py          # Calendar integration
│   └── integrations/
│       ├── servicenow_change.py         # ServiceNow integration
│       └── jira_change.py               # JIRA integration
└── examples/
    ├── onetime_maintenance.json         # One-time examples
    ├── recurring_maintenance.yaml       # Recurring patterns
    ├── deployment_maintenance.json      # CI/CD deployments
    ├── emergency_maintenance.yaml       # Emergency templates
    ├── business_hours.json              # Business hours patterns
    ├── patch_management.yaml            # Patch schedules
    ├── bulk_maintenance.yaml            # Bulk operations
    └── calendar_integration.json        # Calendar configs
```

## Key Scripts

### zabbix_maintenance_manager.py

Core maintenance management script for CRUD operations.

**Commands:**
- `create` - Create new maintenance
- `list` - List maintenances
- `update` - Update maintenance
- `delete` - Delete maintenance
- `check` - Check if host in maintenance
- `bulk-create` - Create from YAML/JSON file
- `cleanup` - Remove expired maintenances

**Example:**
```bash
# List all maintenances
python scripts/zabbix_maintenance_manager.py list --format table

# Update maintenance duration
python scripts/zabbix_maintenance_manager.py update --id 123 --duration 180

# Check host maintenance status
python scripts/zabbix_maintenance_manager.py check --host db-server-01
```

### maintenance_scheduler.py

Create recurring maintenance schedules.

**Commands:**
- `daily` - Daily recurring
- `weekly` - Weekly recurring
- `monthly-date` - Monthly by date (e.g., 1st of month)
- `monthly-weekday` - Monthly by weekday (e.g., second Tuesday)
- `patch-tuesday` - Microsoft Patch Tuesday
- `business-hours` - Business hours suppression

**Example:**
```bash
# First Monday of every month
python scripts/maintenance_scheduler.py monthly-weekday \
  --name "Monthly Security Review" \
  --week "first" \
  --days "monday" \
  --months "january,february,march,april,may,june,july,august,september,october,november,december" \
  --time "08:00" \
  --duration 180 \
  --hostgroups "All Servers" \
  --start "2025-01-01" \
  --end "2026-12-31"
```

### emergency_maintenance.py

Quick emergency maintenance activation.

**Commands:**
- `activate` - Create emergency maintenance
- `extend` - Extend existing maintenance
- `end` - End maintenance early
- `list` - List active emergency maintenances
- `from-incident` - Create from incident ticket

**Example:**
```bash
# Extend emergency maintenance
python scripts/emergency_maintenance.py extend \
  --id 123 \
  --minutes 30 \
  --reason "Additional troubleshooting required"
```

### validate_maintenance_config.py

Validate configurations before creating maintenance.

**Commands:**
- `check` - Validate config file
- `verify-hosts` - Verify hosts exist
- `verify-groups` - Verify hostgroups exist
- `check-conflicts` - Check for schedule conflicts

**Example:**
```bash
# Validate configuration file
python scripts/validate_maintenance_config.py check \
  --config examples/bulk_maintenance.yaml \
  --verify-hosts

# Check for conflicts
python scripts/validate_maintenance_config.py check-conflicts \
  --start "2025-12-01 02:00" \
  --duration 120 \
  --hostgroups "Database Servers"
```

## Maintenance Types

### With Data Collection (maintenance_type=0)

- Monitoring continues
- Data collection active
- Alerts suppressed (if action configured)
- Historical graphs remain complete
- Use for: Planned changes, deployments, testing

### Without Data Collection (maintenance_type=1)

- Monitoring paused
- No data collected
- Complete alert suppression
- Gaps in historical data
- Use for: Server reboots, hardware maintenance, known outages

## Time Periods

### One-Time (timeperiod_type=0)

```json
{
  "timeperiod_type": 0,
  "start_date": 1733443200,
  "period": 7200
}
```

### Daily (timeperiod_type=2)

```json
{
  "timeperiod_type": 2,
  "every": 1,
  "start_time": 3600,
  "period": 10800
}
```

### Weekly (timeperiod_type=3)

```json
{
  "timeperiod_type": 3,
  "every": 1,
  "dayofweek": 64,
  "start_time": 10800,
  "period": 7200
}
```

**Day of week bitmap:**
- Monday: 1
- Tuesday: 2
- Wednesday: 4
- Thursday: 8
- Friday: 16
- Saturday: 32
- Sunday: 64

### Monthly (timeperiod_type=4)

By date:
```json
{
  "timeperiod_type": 4,
  "day": 1,
  "month": 4095,
  "start_time": 7200,
  "period": 14400
}
```

By weekday:
```json
{
  "timeperiod_type": 4,
  "every": 2,
  "dayofweek": 2,
  "month": 4095,
  "start_time": 7200,
  "period": 14400
}
```

**Month bitmap:**
- Jan: 1, Feb: 2, Mar: 4, Apr: 8, May: 16, Jun: 32
- Jul: 64, Aug: 128, Sep: 256, Oct: 512, Nov: 1024, Dec: 2048

## Problem Tag Filtering

Selectively suppress problems with matching tags (only with maintenance_type=0):

```json
{
  "tags": [
    {"tag": "service", "operator": 0, "value": "web"},
    {"tag": "severity", "operator": 2, "value": "low"}
  ],
  "tags_evaltype": 0
}
```

**Operators:**
- 0: Equals (exact match)
- 2: Contains (substring match)

**Evaluation types:**
- 0: And/Or (all conditions must be met, OR between same tag names)
- 2: Or (any condition matches)

## Integration Examples

### ServiceNow Change Request

```bash
# Create maintenance from approved change
python scripts/integrations/servicenow_change.py create-from-change \
  --change-number CHG0012345

# Update change with maintenance info
python scripts/integrations/servicenow_change.py update-change \
  --change-number CHG0012345 \
  --maintenance-id 123 \
  --status "Maintenance window active"
```

### JIRA Change Ticket

```bash
# Link maintenance to JIRA issue
python scripts/integrations/jira_change.py link-maintenance \
  --issue INFRA-1234 \
  --maintenance-id 123

# Extract parameters from JIRA
python scripts/integrations/jira_change.py create-from-issue \
  --issue INFRA-1234
```

### Calendar Export

```bash
# Export to iCal
python scripts/maintenance_calendar.py export-ical \
  --output maintenance_schedule.ics \
  --filter "hostgroup:Production" \
  --next-days 90
```

## Best Practices

### 1. Timing

- Set `active_since`/`active_till` wider than actual maintenance periods
- Use server timezone for recurring maintenances
- Account for DST changes in scheduling
- Plan around business hours and SLAs

### 2. Scope

- Use hostgroups for scalability
- Tag-based filtering for selective suppression
- Test in non-production first
- Document affected services

### 3. Notifications

- Configure "Pause operations for suppressed problems" in actions
- Notify stakeholders before maintenance
- Set appropriate escalation delays
- Document emergency contacts

### 4. Validation

- Always validate configurations before applying
- Check for schedule conflicts
- Verify host/group existence
- Test in development environment

### 5. Documentation

- Include change request references
- Document rollback procedures
- Record actual vs planned duration
- Update runbooks

## Troubleshooting

### Maintenance Not Activating

1. Check `active_since` is in the past
2. Verify `active_till` is in the future
3. Confirm time period within active_since/till range
4. Check Zabbix server timezone

### Problems Not Suppressed

1. Verify maintenance_type is correct
2. Check tag filters match problem tags (case-sensitive)
3. Confirm "Pause operations" enabled in action
4. Verify hosts/groups correctly assigned

### Permission Errors

- Maintenance operations require Admin or Super admin role
- Check user role permissions
- Verify API token has sufficient privileges

## Environment Variables

```bash
# Required
export ZABBIX_URL="https://zabbix.example.com/api_jsonrpc.php"
export ZABBIX_TOKEN="your-api-token"

# Optional integrations
export SERVICENOW_INSTANCE="yourcompany.service-now.com"
export SERVICENOW_USERNAME="api-user"
export SERVICENOW_PASSWORD="api-password"

export JIRA_URL="https://yourcompany.atlassian.net"
export JIRA_USERNAME="your-email@example.com"
export JIRA_API_TOKEN="your-api-token"
```

## Support

For detailed documentation, see [SKILL.md](SKILL.md)

For examples, see [examples/](examples/) directory

For Zabbix documentation:
- [Maintenance](https://www.zabbix.com/documentation/current/en/manual/maintenance)
- [Maintenance API](https://www.zabbix.com/documentation/current/en/manual/api/reference/maintenance)

## Version

Version: 1.0
Last Updated: 2025-11-14
Zabbix Version: 6.0+
