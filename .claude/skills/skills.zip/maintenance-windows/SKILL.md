---
name: Maintenance Windows in Zabbix
description: Automates Zabbix maintenance period management including creating scheduled maintenance windows, managing maintenance types (with/without data collection), handling recurring schedules, coordinating change management workflows, and integrating with CI/CD pipelines. Use when scheduling server maintenance, application deployments, infrastructure upgrades, patch management, backup windows, or coordinating planned changes.
dependencies:
  - Zabbix API access with Admin or Super admin privileges
  - Python 3.7+ with requests library
  - Valid Zabbix authentication credentials
version: "1.0"
---

# Maintenance Windows in Zabbix

Automate creation, management, and coordination of Zabbix maintenance periods for planned maintenance activities.

## Quick Start

**Create one-time maintenance:**
```python
python scripts/zabbix_maintenance_manager.py create \
  --name "Database upgrade" \
  --start "2025-12-01 02:00" \
  --duration 120 \
  --hosts "db-server-01" \
  --type with-data
```

**Schedule recurring weekly maintenance:**
```python
python scripts/maintenance_scheduler.py create-recurring \
  --name "Weekly backup window" \
  --type weekly \
  --day sunday \
  --time "03:00" \
  --duration 180 \
  --hostgroups "Production Servers"
```

**Emergency maintenance activation:**
```python
python scripts/emergency_maintenance.py activate \
  --hosts "web-server-01,web-server-02" \
  --duration 30 \
  --reason "Critical security patch"
```

## Core Capabilities

### Maintenance Types

**With Data Collection** (maintenance_type=0)
- Continues monitoring and data collection
- Suppresses problem notifications and escalations
- Maintains historical data continuity
- Ideal for planned changes where monitoring is needed
- Operations paused only if action configured with "Pause operations for suppressed problems"

**Without Data Collection** (maintenance_type=1)
- Stops all data collection during maintenance
- No triggers processed
- Gaps in historical data
- Used for complete monitoring suspension during known outages
- Data collection happens at proxy/server but discarded

### Schedule Patterns

**One-time maintenance:**
- Specific date and time
- Fixed duration
- Use `timeperiod_type=0`

**Daily recurring:**
- Every N days
- Specific time of day
- Use `timeperiod_type=2`
- `every=1` for daily, `every=2` for every 2 days

**Weekly recurring:**
- Specific days of week (bitmap)
- Set time each day
- Use `timeperiod_type=3`
- Days: Mon=1, Tue=2, Wed=4, Thu=8, Fri=16, Sat=32, Sun=64

**Monthly recurring:**
- By date: specific day of month (1-31)
- By day of week: "first Monday", "last Friday", etc.
- Use `timeperiod_type=4`
- Multiple months via bitmap

### Scope Assignment

**Host Groups:**
```python
"groups": [{"groupid": "10"}]
```

**Individual Hosts:**
```python
"hosts": [{"hostid": "10084"}]
```

**Tag-based Suppression (only with data collection):**
```python
"tags": [
    {"tag": "service", "operator": 0, "value": "web"},  # Equals
    {"tag": "severity", "operator": 2, "value": "high"}  # Contains
]
```

### Problem Tag Filtering

When `maintenance_type=0` (with data collection), use tags to suppress specific problems:

**tags_evaltype:**
- `0` = And/Or (all conditions must be met, OR between same tag names)
- `2` = Or (any condition can match)

**operators:**
- `0` = Equals (exact match, case-sensitive)
- `2` = Contains (substring match, case-sensitive)

**Example - Suppress specific service problems:**
```json
{
  "tags_evaltype": 0,
  "tags": [
    {"tag": "service", "operator": 0, "value": "mysql"},
    {"tag": "component", "operator": 2, "value": "database"}
  ]
}
```

## Common Workflows

### Planned Application Deployment

1. **Pre-deployment:** Schedule maintenance window
2. **Deploy:** Application deployment proceeds
3. **Monitor:** Alerts suppressed during deployment
4. **Post-deployment:** Maintenance ends, monitoring resumes
5. **Validate:** Check for any issues after maintenance

**Example:**
```bash
# Schedule 2-hour deployment window starting at 10 PM
python scripts/zabbix_maintenance_manager.py create \
  --name "App v2.0 deployment" \
  --start "2025-12-15 22:00" \
  --duration 120 \
  --hostgroups "Application Servers" \
  --type with-data \
  --tags "service:app,component:backend"
```

### Patch Tuesday Schedule

Schedule recurring monthly maintenance for Windows patch cycles:

```bash
python scripts/maintenance_scheduler.py create-recurring \
  --name "Patch Tuesday - Windows Servers" \
  --type monthly \
  --day-of-week "tuesday" \
  --week "second" \
  --time "02:00" \
  --duration 240 \
  --hostgroups "Windows Servers" \
  --type no-data
```

### Multi-Region Rolling Maintenance

For applications across multiple regions, stagger maintenance windows:

```bash
# US East - 2 AM local
python scripts/maintenance_scheduler.py create \
  --name "Weekly maintenance - US East" \
  --region us-east \
  --schedule weekly --day sunday --time "02:00"

# US West - 2 AM local (5 AM UTC if East is 7 AM UTC)
python scripts/maintenance_scheduler.py create \
  --name "Weekly maintenance - US West" \
  --region us-west \
  --schedule weekly --day sunday --time "05:00"
```

### CI/CD Integration

Automatically create maintenance windows during deployment:

```yaml
# .gitlab-ci.yml
deploy:
  script:
    - python scripts/cicd_maintenance_trigger.py create-deployment-window
    - ./deploy.sh
    - python scripts/cicd_maintenance_trigger.py end-maintenance
```

### Emergency Maintenance

Quick activation for unplanned maintenance:

```bash
# Immediate 30-minute maintenance
python scripts/emergency_maintenance.py activate \
  --hosts "web-01,web-02,web-03" \
  --duration 30 \
  --reason "Emergency kernel update" \
  --notify-team
```

## Best Practices

### Timing Considerations

**Active Since/Till Window:**
- `active_since`: When maintenance periods become eligible to execute
- `active_till`: When maintenance periods stop executing
- Values rounded down to minutes
- Must be at least as wide as scheduled periods

**Time Zone Handling:**
- Recurring maintenances use Zabbix server timezone
- One-time maintenances use creator's timezone at creation
- Recommend: Use single timezone across all Zabbix components
- Document timezone in maintenance descriptions

**DST Changes:**
- Maintenance duration not affected by DST shifts
- 2-hour maintenance stays 2 hours even if clock changes
- Maintenance starting during skipped DST hour won't start
- Plan around DST transitions for critical maintenance

### Escalation Behavior

With "Pause operations for suppressed problems" in action:
- Problem occurs → Escalation starts
- Maintenance begins at +10min → Escalation pauses
- Maintenance ends at +40min → Escalation resumes (+30min added)
- Step 2 executes at +60min (originally +30min)
- Step 3 executes at +90min (originally +60min)

Without "Pause operations":
- Notifications continue during maintenance
- Use when immediate alerting needed even during maintenance

### Tag Strategy

**Selective Suppression:**
```json
{
  "maintenance_type": 0,
  "tags": [
    {"tag": "service", "operator": 0, "value": "database"},
    {"tag": "planned", "operator": 0, "value": "true"}
  ]
}
```

**No Tags = All Problems Suppressed:**
- If `tags` array empty or not specified
- All active problems for hosts/groups in maintenance suppressed

### Performance Considerations

**Open Problems Impact:**
- Server reads all open problems when host enters maintenance
- Can impact performance with many open problems
- Plan maintenance during lower problem volumes if possible
- Server also reads open problems on startup

**Configuration Updates:**
- Changes take effect after cache synchronization
- Timer processes check every minute at 0 seconds
- Changes to periods activate within config update interval (default 10s)
- `active_since`/`active_till` changes don't trigger immediate reload

### Data Collection Notes

**No Data Maintenance:**
- Server/proxy still collect data but server discards it
- Timestamped values (zabbix_sender) during maintenance are dropped
- Can send timestamped values for expired maintenance period (accepted)
- Log items: only new entries after maintenance will be gathered
- nodata() triggers won't fire until next check after maintenance ends

**With Data Maintenance:**
- Full data collection continues
- Historical graphs remain complete
- Triggers still process
- Only notifications/escalations affected

## Validation

**Before creating maintenance:**
```bash
python scripts/validate_maintenance_config.py check \
  --config maintenance.json \
  --verify-hosts \
  --check-schedule
```

**Validation checks:**
- Host/group existence
- Time period validity
- Active since/till range coverage
- Schedule conflicts
- Tag syntax
- Permission levels

## Change Management Integration

### ServiceNow Integration

Link Zabbix maintenance to ServiceNow change requests:

```python
python scripts/integrations/servicenow_change.py create-maintenance \
  --change-number CHG0012345 \
  --sync-schedule \
  --auto-update-status
```

**Features:**
- Auto-create maintenance from approved change requests
- Sync maintenance window with change schedule
- Update change status when maintenance completes
- Attach maintenance reports to change record

### JIRA Integration

Coordinate maintenance with JIRA change tickets:

```python
python scripts/integrations/jira_change.py link-maintenance \
  --issue INFRA-1234 \
  --create-from-issue \
  --update-status
```

## Calendar Integration

### Export to iCal

Generate calendar file for maintenance schedules:

```bash
python scripts/maintenance_calendar.py export-ical \
  --output maintenance_schedule.ics \
  --filter "hostgroup:Production" \
  --next-months 3
```

### Google Calendar Sync

Synchronize maintenance windows with Google Calendar:

```bash
python scripts/maintenance_calendar.py sync-google \
  --calendar "Zabbix Maintenance" \
  --two-way-sync \
  --notification-hours 24
```

## Bulk Operations

**Create multiple maintenances from YAML:**
```bash
python scripts/zabbix_maintenance_manager.py bulk-create \
  --input examples/bulk_maintenance.yaml \
  --validate-first \
  --dry-run
```

**Update all maintenances matching criteria:**
```bash
python scripts/zabbix_maintenance_manager.py bulk-update \
  --filter "name:Weekly" \
  --set duration=240 \
  --confirm
```

**Clean up expired maintenances:**
```bash
python scripts/zabbix_maintenance_manager.py cleanup \
  --expired-days 90 \
  --archive-before-delete
```

## Reporting

### Maintenance History

Generate compliance reports:

```bash
python scripts/maintenance_reporter.py history \
  --start "2025-01-01" \
  --end "2025-03-31" \
  --format pdf \
  --output q1_maintenance_report.pdf
```

**Report includes:**
- All maintenance windows executed
- Duration actual vs planned
- Hosts/groups affected
- Problems suppressed
- Change request linkage

### Compliance Tracking

Track maintenance against change management policy:

```bash
python scripts/maintenance_reporter.py compliance \
  --policy ITIL \
  --check-approvals \
  --verify-change-tickets \
  --alert-violations
```

## API Reference

### Core Methods

**maintenance.create**
- Creates new maintenance periods
- Requires Admin or Super admin role
- Returns maintenanceid

**maintenance.get**
- Retrieves maintenance configurations
- Available to all user types
- Supports filtering by host, group, or ID

**maintenance.update**
- Modifies existing maintenance
- Requires Admin or Super admin role
- Can update all properties

**maintenance.delete**
- Removes maintenance periods
- Requires Admin or Super admin role
- Takes array of maintenanceids

### Key Properties

**Maintenance Object:**
```json
{
  "name": "string (required)",
  "active_since": "timestamp (required, rounded to minutes)",
  "active_till": "timestamp (required, rounded to minutes)",
  "maintenance_type": "0=with data, 1=no data (default: 0)",
  "description": "string (optional)",
  "tags_evaltype": "0=And/Or, 2=Or (default: 0)"
}
```

**Time Period Object:**
```json
{
  "timeperiod_type": "0=one-time, 2=daily, 3=weekly, 4=monthly",
  "period": "duration in seconds (default: 3600, rounded to minutes)",
  "start_date": "timestamp (for one-time only)",
  "start_time": "seconds since midnight (for recurring)",
  "every": "interval for daily/weekly, or day/week of month",
  "dayofweek": "bitmap: Mon=1, Tue=2, Wed=4, Thu=8, Fri=16, Sat=32, Sun=64",
  "day": "day of month 1-31 (for monthly)",
  "month": "bitmap: Jan=1, Feb=2, Mar=4, Apr=8, May=16, Jun=32, Jul=64, Aug=128, Sep=256, Oct=512, Nov=1024, Dec=2048"
}
```

## Examples

See `examples/` directory for comprehensive examples:

- `onetime_maintenance.json` - One-time maintenance patterns
- `recurring_maintenance.yaml` - Recurring schedule configurations
- `deployment_maintenance.json` - CI/CD deployment windows
- `emergency_maintenance.yaml` - Emergency maintenance templates
- `business_hours.json` - Business hours suppression
- `patch_management.yaml` - Patch Tuesday and update schedules
- `bulk_maintenance.yaml` - Bulk operation configurations
- `calendar_integration.json` - Calendar sync configurations

## Troubleshooting

**Maintenance not activating:**
- Verify active_since is in the past
- Check active_till is in the future
- Confirm time period falls within active_since/till range
- Check server timezone for recurring maintenances

**Problems not suppressed:**
- Verify maintenance_type is correct
- Check tag filters match problem tags exactly (case-sensitive)
- Confirm "Pause operations for suppressed problems" enabled in action
- Verify hosts/groups correctly assigned

**Unexpected maintenance duration:**
- Remember DST doesn't change duration
- Verify period value (in seconds, rounded to minutes)
- Check for overlapping maintenance periods

**Permission errors:**
- Maintenance create/update/delete requires Admin or Super admin
- Check user role permissions
- Verify API token has sufficient privileges

## Integration Patterns

**Pre-deployment hook:**
```python
# In deployment script
from scripts.cicd_maintenance_trigger import create_deployment_maintenance

maintenance_id = create_deployment_maintenance(
    hosts=["app-01", "app-02"],
    duration_minutes=60,
    deployment_id=os.environ['CI_PIPELINE_ID']
)
```

**Post-deployment cleanup:**
```python
# After successful deployment
from scripts.cicd_maintenance_trigger import end_deployment_maintenance

end_deployment_maintenance(maintenance_id)
```

**Monitoring integration:**
```python
# Check if host in maintenance before alerting
from scripts.zabbix_maintenance_manager import is_host_in_maintenance

if not is_host_in_maintenance(hostname):
    send_alert(hostname, problem)
```

## References

- [Zabbix Maintenance Documentation](https://www.zabbix.com/documentation/current/en/manual/maintenance)
- [Maintenance API Reference](https://www.zabbix.com/documentation/current/en/manual/api/reference/maintenance)
- ITIL Change Management Best Practices
- CI/CD Integration Patterns
