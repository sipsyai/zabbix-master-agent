#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
CI/CD Maintenance Trigger - Automate maintenance for deployments

Integrates with CI/CD pipelines to automatically create/end maintenance
windows during application deployments.

Usage:
    python cicd_maintenance_trigger.py create-deployment-window --app "myapp" --environment "production"
    python cicd_maintenance_trigger.py end-maintenance --maintenance-id 123
    python cicd_maintenance_trigger.py pipeline-wrap --command "./deploy.sh"

Author: Zabbix Skills Automation
Version: 1.0
"""

import argparse
import sys
import os
import subprocess
from datetime import datetime
from typing import Optional
from zabbix_maintenance_manager import ZabbixMaintenanceManager


class CICDMaintenanceTrigger:
    """Handle CI/CD pipeline maintenance automation"""

    def __init__(self, manager: ZabbixMaintenanceManager):
        self.manager = manager

    def create_deployment_window(
        self,
        application: str,
        environment: str,
        duration_minutes: int = 60,
        hostgroup_pattern: str = None,
        deployment_id: str = None
    ) -> str:
        """
        Create maintenance window for deployment

        Args:
            application: Application name
            environment: Environment (production, staging, etc.)
            duration_minutes: Expected deployment duration
            hostgroup_pattern: Hostgroup name pattern (default: {app}-{env})
            deployment_id: CI/CD pipeline ID

        Returns:
            Maintenance ID
        """
        # Build maintenance name
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        deployment_ref = deployment_id or os.getenv("CI_PIPELINE_ID", "manual")
        name = f"Deployment: {application} [{environment}] - {deployment_ref}"

        # Determine hostgroup
        if not hostgroup_pattern:
            hostgroup_pattern = f"{application}-{environment}"

        description = f"""Automated deployment maintenance
Application: {application}
Environment: {environment}
Deployment ID: {deployment_ref}
Pipeline: {os.getenv('CI_PIPELINE_URL', 'N/A')}
Triggered by: {os.getenv('GITLAB_USER_LOGIN') or os.getenv('GITHUB_ACTOR', 'unknown')}
Timestamp: {timestamp}
"""

        print(f"Creating deployment maintenance window...")
        print(f"  Application: {application}")
        print(f"  Environment: {environment}")
        print(f"  Hostgroup: {hostgroup_pattern}")
        print(f"  Duration: {duration_minutes} minutes")

        now = int(datetime.now().timestamp())
        maintenance_id = self.manager.create_maintenance(
            name=name,
            active_since=now,
            active_till=now + (duration_minutes * 60),
            maintenance_type=0,  # With data collection
            hostgroups=[hostgroup_pattern],
            description=description
        )

        # Export maintenance ID for pipeline use
        print(f"\n[OK] Maintenance created: {maintenance_id}")
        print(f"\nExport for pipeline:")
        print(f"export ZABBIX_MAINTENANCE_ID={maintenance_id}")

        # Write to file for pipeline stages
        with open(".maintenance_id", "w") as f:
            f.write(maintenance_id)

        return maintenance_id

    def end_deployment_maintenance(self, maintenance_id: str) -> bool:
        """End deployment maintenance window"""
        print(f"Ending deployment maintenance {maintenance_id}...")

        now = int(datetime.now().timestamp())
        self.manager.update_maintenance(
            maintenance_id=maintenance_id,
            active_till=now,
            description="Deployment completed, maintenance ended early"
        )

        print("[OK] Maintenance ended")

        # Clean up file
        if os.path.exists(".maintenance_id"):
            os.remove(".maintenance_id")

        return True

    def wrap_deployment_command(
        self,
        command: str,
        application: str,
        environment: str,
        duration_minutes: int = 60
    ) -> int:
        """
        Wrap deployment command with automatic maintenance

        Args:
            command: Command to execute
            application: Application name
            environment: Environment
            duration_minutes: Maintenance duration

        Returns:
            Command exit code
        """
        # Create maintenance
        maintenance_id = self.create_deployment_window(
            application=application,
            environment=environment,
            duration_minutes=duration_minutes
        )

        try:
            print(f"\n{'='*60}")
            print(f"Executing deployment command...")
            print(f"{'='*60}\n")

            # Execute command
            result = subprocess.run(command, shell=True)
            exit_code = result.returncode

            print(f"\n{'='*60}")
            print(f"Deployment {'succeeded' if exit_code == 0 else 'failed'}")
            print(f"Exit code: {exit_code}")
            print(f"{'='*60}\n")

            return exit_code

        finally:
            # Always end maintenance
            self.end_deployment_maintenance(maintenance_id)


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(description="CI/CD Maintenance Trigger")

    parser.add_argument("--url", default=os.getenv("ZABBIX_URL"))
    parser.add_argument("--token", default=os.getenv("ZABBIX_TOKEN"))
    parser.add_argument("--no-verify-ssl", action="store_true")

    subparsers = parser.add_subparsers(dest="command")

    # Create deployment window
    create_parser = subparsers.add_parser("create-deployment-window")
    create_parser.add_argument("--app", required=True, help="Application name")
    create_parser.add_argument("--environment", required=True, help="Environment")
    create_parser.add_argument("--duration", type=int, default=60, help="Duration in minutes")
    create_parser.add_argument("--hostgroup", help="Hostgroup name pattern")
    create_parser.add_argument("--deployment-id", help="Deployment ID")

    # End maintenance
    end_parser = subparsers.add_parser("end-maintenance")
    end_parser.add_argument("--maintenance-id", required=True, help="Maintenance ID")

    # Wrap command
    wrap_parser = subparsers.add_parser("pipeline-wrap")
    wrap_parser.add_argument("--command", required=True, help="Command to wrap")
    wrap_parser.add_argument("--app", required=True, help="Application name")
    wrap_parser.add_argument("--environment", required=True, help="Environment")
    wrap_parser.add_argument("--duration", type=int, default=60, help="Duration in minutes")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    if not args.url or not args.token:
        print("Error: Zabbix URL and token required")
        return 1

    manager = ZabbixMaintenanceManager(args.url, args.token, verify_ssl=not args.no_verify_ssl)
    trigger = CICDMaintenanceTrigger(manager)

    try:
        if args.command == "create-deployment-window":
            trigger.create_deployment_window(
                application=args.app,
                environment=args.environment,
                duration_minutes=args.duration,
                hostgroup_pattern=args.hostgroup,
                deployment_id=args.deployment_id
            )
            return 0

        elif args.command == "end-maintenance":
            trigger.end_deployment_maintenance(args.maintenance_id)
            return 0

        elif args.command == "pipeline-wrap":
            exit_code = trigger.wrap_deployment_command(
                command=args.command,
                application=args.app,
                environment=args.environment,
                duration_minutes=args.duration
            )
            return exit_code

    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
