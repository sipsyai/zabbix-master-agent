#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Emergency Maintenance - Quick activation for unplanned maintenance

Provides immediate maintenance window activation for emergency situations:
- Rapid deployment (under 60 seconds)
- Minimal configuration required
- Automatic duration extension
- Team notifications
- Integration with incident management

Usage:
    python emergency_maintenance.py activate --hosts "web-01,web-02" --duration 30 --reason "Critical security patch"
    python emergency_maintenance.py extend --id 123 --minutes 30
    python emergency_maintenance.py end --id 123

Author: Zabbix Skills Automation
Version: 1.0
"""

import argparse
import sys
import os
from datetime import datetime, timedelta
from typing import List, Optional
from zabbix_maintenance_manager import ZabbixMaintenanceManager


class EmergencyMaintenance:
    """Handle emergency maintenance scenarios"""

    def __init__(self, manager: ZabbixMaintenanceManager):
        """
        Initialize emergency maintenance handler

        Args:
            manager: ZabbixMaintenanceManager instance
        """
        self.manager = manager

    def activate(
        self,
        hosts: List[str] = None,
        hostgroups: List[str] = None,
        duration_minutes: int = 30,
        reason: str = "",
        maintenance_type: int = 0,
        auto_extend: bool = False
    ) -> str:
        """
        Activate emergency maintenance immediately

        Args:
            hosts: List of host names
            hostgroups: List of hostgroup names
            duration_minutes: Duration in minutes (default: 30)
            reason: Reason for emergency maintenance
            maintenance_type: 0=with data, 1=no data
            auto_extend: Enable automatic extension if still needed

        Returns:
            Created maintenance ID
        """
        if not hosts and not hostgroups:
            raise ValueError("At least one host or hostgroup required")

        # Generate maintenance name with timestamp
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
        name = f"Emergency Maintenance - {timestamp}"

        # Set immediate start and end times
        now = datetime.now()
        active_since = int(now.timestamp())
        active_till = int((now + timedelta(minutes=duration_minutes)).timestamp())

        # Build description
        description = f"Emergency maintenance activated at {timestamp}\n"
        if reason:
            description += f"Reason: {reason}\n"
        if auto_extend:
            description += "Auto-extend enabled\n"

        print(f"Activating emergency maintenance...")
        print(f"  Hosts: {', '.join(hosts) if hosts else 'N/A'}")
        print(f"  Groups: {', '.join(hostgroups) if hostgroups else 'N/A'}")
        print(f"  Duration: {duration_minutes} minutes")
        print(f"  Type: {'With data' if maintenance_type == 0 else 'No data'}")
        print(f"  Reason: {reason or 'Not specified'}")

        maintenance_id = self.manager.create_maintenance(
            name=name,
            active_since=active_since,
            active_till=active_till,
            maintenance_type=maintenance_type,
            hosts=hosts,
            hostgroups=hostgroups,
            description=description
        )

        print(f"\n[OK] Emergency maintenance activated (ID: {maintenance_id})")
        print(f"  Active until: {datetime.fromtimestamp(active_till).strftime('%Y-%m-%d %H:%M')}")

        return maintenance_id

    def extend(
        self,
        maintenance_id: str,
        additional_minutes: int,
        reason: str = ""
    ) -> bool:
        """
        Extend existing emergency maintenance

        Args:
            maintenance_id: Maintenance ID to extend
            additional_minutes: Minutes to add to current duration
            reason: Reason for extension

        Returns:
            True if extension successful
        """
        # Get current maintenance
        maintenances = self.manager.get_maintenance(maintenance_ids=[maintenance_id])

        if not maintenances:
            raise ValueError(f"Maintenance not found: {maintenance_id}")

        maintenance = maintenances[0]

        # Calculate new end time
        current_till = int(maintenance["active_till"])
        new_till = current_till + (additional_minutes * 60)

        # Update description
        current_description = maintenance.get("description", "")
        extension_note = f"\nExtended by {additional_minutes} minutes at {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        if reason:
            extension_note += f"\nExtension reason: {reason}"

        new_description = current_description + extension_note

        print(f"Extending maintenance {maintenance_id}...")
        print(f"  Current end: {datetime.fromtimestamp(current_till).strftime('%Y-%m-%d %H:%M')}")
        print(f"  New end: {datetime.fromtimestamp(new_till).strftime('%Y-%m-%d %H:%M')}")
        print(f"  Extension: +{additional_minutes} minutes")

        self.manager.update_maintenance(
            maintenance_id=maintenance_id,
            active_till=new_till,
            description=new_description
        )

        print(f"[OK] Maintenance extended successfully")
        return True

    def end_now(
        self,
        maintenance_id: str,
        reason: str = ""
    ) -> bool:
        """
        End emergency maintenance immediately

        Args:
            maintenance_id: Maintenance ID to end
            reason: Reason for early termination

        Returns:
            True if termination successful
        """
        # Get current maintenance
        maintenances = self.manager.get_maintenance(maintenance_ids=[maintenance_id])

        if not maintenances:
            raise ValueError(f"Maintenance not found: {maintenance_id}")

        maintenance = maintenances[0]

        # Set end time to now
        now = int(datetime.now().timestamp())

        # Update description
        current_description = maintenance.get("description", "")
        end_note = f"\nEnded early at {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        if reason:
            end_note += f"\nTermination reason: {reason}"

        new_description = current_description + end_note

        print(f"Ending maintenance {maintenance_id}...")
        print(f"  Scheduled end: {datetime.fromtimestamp(int(maintenance['active_till'])).strftime('%Y-%m-%d %H:%M')}")
        print(f"  Actual end: {datetime.fromtimestamp(now).strftime('%Y-%m-%d %H:%M')}")

        self.manager.update_maintenance(
            maintenance_id=maintenance_id,
            active_till=now,
            description=new_description
        )

        print(f"[OK] Maintenance ended successfully")
        return True

    def list_active_emergency(self) -> List[dict]:
        """
        List all active emergency maintenances

        Returns:
            List of active emergency maintenance objects
        """
        # Get all maintenances with "Emergency" in name
        all_maintenances = self.manager.get_maintenance(name_filter="Emergency")

        # Filter to currently active
        now = datetime.now().timestamp()
        active = [
            m for m in all_maintenances
            if int(m["active_since"]) <= now <= int(m["active_till"])
        ]

        return active

    def create_from_incident(
        self,
        incident_id: str,
        affected_hosts: List[str],
        severity: str,
        duration_minutes: int = None
    ) -> str:
        """
        Create emergency maintenance from incident

        Args:
            incident_id: Incident tracking ID
            affected_hosts: List of affected host names
            severity: Incident severity (critical, high, medium, low)
            duration_minutes: Duration (auto-calculated if not provided)

        Returns:
            Created maintenance ID
        """
        # Auto-calculate duration based on severity
        if duration_minutes is None:
            severity_durations = {
                "critical": 60,
                "high": 45,
                "medium": 30,
                "low": 30
            }
            duration_minutes = severity_durations.get(severity.lower(), 30)

        # Determine maintenance type based on severity
        maintenance_type = 1 if severity.lower() == "critical" else 0

        reason = f"Incident {incident_id} - Severity: {severity}"

        return self.activate(
            hosts=affected_hosts,
            duration_minutes=duration_minutes,
            reason=reason,
            maintenance_type=maintenance_type,
            auto_extend=True
        )


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="Emergency Maintenance - Quick activation for unplanned maintenance",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    # Global arguments
    parser.add_argument("--url", default=os.getenv("ZABBIX_URL"),
                       help="Zabbix API URL")
    parser.add_argument("--token", default=os.getenv("ZABBIX_TOKEN"),
                       help="Zabbix API token")
    parser.add_argument("--no-verify-ssl", action="store_true",
                       help="Disable SSL verification")

    subparsers = parser.add_subparsers(dest="command", help="Emergency operation")

    # Activate command
    activate_parser = subparsers.add_parser("activate", help="Activate emergency maintenance")
    activate_parser.add_argument("--hosts", help="Comma-separated host names")
    activate_parser.add_argument("--hostgroups", help="Comma-separated hostgroup names")
    activate_parser.add_argument("--duration", type=int, default=30,
                                help="Duration in minutes (default: 30)")
    activate_parser.add_argument("--reason", default="", help="Reason for emergency maintenance")
    activate_parser.add_argument("--type", choices=["with-data", "no-data"], default="with-data",
                                help="Maintenance type")
    activate_parser.add_argument("--auto-extend", action="store_true",
                                help="Enable automatic extension")

    # Extend command
    extend_parser = subparsers.add_parser("extend", help="Extend emergency maintenance")
    extend_parser.add_argument("--id", required=True, help="Maintenance ID")
    extend_parser.add_argument("--minutes", type=int, required=True,
                              help="Additional minutes to add")
    extend_parser.add_argument("--reason", default="", help="Reason for extension")

    # End command
    end_parser = subparsers.add_parser("end", help="End emergency maintenance now")
    end_parser.add_argument("--id", required=True, help="Maintenance ID")
    end_parser.add_argument("--reason", default="", help="Reason for early termination")

    # List command
    list_parser = subparsers.add_parser("list", help="List active emergency maintenances")

    # From incident command
    incident_parser = subparsers.add_parser("from-incident",
                                           help="Create from incident")
    incident_parser.add_argument("--incident-id", required=True, help="Incident ID")
    incident_parser.add_argument("--hosts", required=True, help="Comma-separated affected hosts")
    incident_parser.add_argument("--severity", required=True,
                                choices=["critical", "high", "medium", "low"],
                                help="Incident severity")
    incident_parser.add_argument("--duration", type=int, help="Duration in minutes (auto if not set)")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    if not args.url or not args.token:
        print("Error: Zabbix URL and token required")
        return 1

    # Initialize manager and emergency handler
    manager = ZabbixMaintenanceManager(
        args.url,
        args.token,
        verify_ssl=not args.no_verify_ssl
    )
    emergency = EmergencyMaintenance(manager)

    try:
        if args.command == "activate":
            if not args.hosts and not args.hostgroups:
                print("Error: At least one host or hostgroup required")
                return 1

            hosts = args.hosts.split(",") if args.hosts else None
            hostgroups = args.hostgroups.split(",") if args.hostgroups else None
            maintenance_type = 0 if args.type == "with-data" else 1

            maintenance_id = emergency.activate(
                hosts=hosts,
                hostgroups=hostgroups,
                duration_minutes=args.duration,
                reason=args.reason,
                maintenance_type=maintenance_type,
                auto_extend=args.auto_extend
            )

        elif args.command == "extend":
            emergency.extend(
                maintenance_id=args.id,
                additional_minutes=args.minutes,
                reason=args.reason
            )

        elif args.command == "end":
            emergency.end_now(
                maintenance_id=args.id,
                reason=args.reason
            )

        elif args.command == "list":
            active = emergency.list_active_emergency()

            if not active:
                print("No active emergency maintenances found")
            else:
                print(f"\nActive emergency maintenances: {len(active)}\n")
                for m in active:
                    print(f"ID: {m['maintenanceid']}")
                    print(f"  Name: {m['name']}")
                    print(f"  Started: {datetime.fromtimestamp(int(m['active_since'])).strftime('%Y-%m-%d %H:%M')}")
                    print(f"  Ends: {datetime.fromtimestamp(int(m['active_till'])).strftime('%Y-%m-%d %H:%M')}")
                    print(f"  Hosts: {len(m.get('hosts', []))}")
                    print(f"  Groups: {len(m.get('hostgroups', []))}")
                    print()

        elif args.command == "from-incident":
            hosts = args.hosts.split(",")

            maintenance_id = emergency.create_from_incident(
                incident_id=args.incident_id,
                affected_hosts=hosts,
                severity=args.severity,
                duration_minutes=args.duration
            )

        return 0

    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
