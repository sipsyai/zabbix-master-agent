#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
JIRA Change Management Integration

Links Zabbix maintenance windows with JIRA change tickets.

Usage:
    python jira_change.py link-maintenance --issue INFRA-1234 --maintenance-id 123
    python jira_change.py create-from-issue --issue INFRA-1234

Configuration:
    Set environment variables:
    - JIRA_URL (e.g., https://yourcompany.atlassian.net)
    - JIRA_USERNAME (email)
    - JIRA_API_TOKEN

Author: Zabbix Skills Automation
Version: 1.0
"""

import argparse
import sys
import os
import json
from typing import Dict
import requests
from requests.auth import HTTPBasicAuth


class JIRAIntegration:
    """JIRA change management integration"""

    def __init__(self, url: str, username: str, api_token: str):
        self.url = url.rstrip("/")
        self.auth = HTTPBasicAuth(username, api_token)
        self.headers = {"Content-Type": "application/json"}

    def get_issue(self, issue_key: str) -> Dict:
        """Get JIRA issue details"""
        url = f"{self.url}/rest/api/3/issue/{issue_key}"
        response = requests.get(url, auth=self.auth, headers=self.headers)
        response.raise_for_status()
        return response.json()

    def add_comment(self, issue_key: str, comment: str) -> bool:
        """Add comment to JIRA issue"""
        url = f"{self.url}/rest/api/3/issue/{issue_key}/comment"
        data = {"body": {"type": "doc", "version": 1, "content": [
            {"type": "paragraph", "content": [{"type": "text", "text": comment}]}
        ]}}

        response = requests.post(url, auth=self.auth, headers=self.headers, json=data)
        response.raise_for_status()
        return True

    def extract_maintenance_params(self, issue_key: str) -> Dict:
        """Extract maintenance parameters from JIRA issue"""
        issue = self.get_issue(issue_key)
        fields = issue["fields"]

        return {
            "name": f"JIRA {issue_key}: {fields['summary']}",
            "description": f"JIRA Issue: {issue_key}\nSummary: {fields['summary']}\nDescription: {fields.get('description', 'N/A')}",
            "issue_key": issue_key
        }


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(description="JIRA Change Management Integration")

    parser.add_argument("--url", default=os.getenv("JIRA_URL"))
    parser.add_argument("--username", default=os.getenv("JIRA_USERNAME"))
    parser.add_argument("--api-token", default=os.getenv("JIRA_API_TOKEN"))

    subparsers = parser.add_subparsers(dest="command")

    # Get issue
    get_parser = subparsers.add_parser("get-issue")
    get_parser.add_argument("--issue", required=True)

    # Link maintenance
    link_parser = subparsers.add_parser("link-maintenance")
    link_parser.add_argument("--issue", required=True)
    link_parser.add_argument("--maintenance-id", required=True)

    # Create from issue
    create_parser = subparsers.add_parser("create-from-issue")
    create_parser.add_argument("--issue", required=True)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    if not all([args.url, args.username, args.api_token]):
        print("Error: JIRA credentials required")
        return 1

    integration = JIRAIntegration(args.url, args.username, args.api_token)

    try:
        if args.command == "get-issue":
            issue = integration.get_issue(args.issue)
            print(json.dumps(issue, indent=2))
            return 0

        elif args.command == "link-maintenance":
            comment = f"Zabbix maintenance window created: ID {args.maintenance_id}"
            integration.add_comment(args.issue, comment)
            print(f"[OK] Linked maintenance to {args.issue}")
            return 0

        elif args.command == "create-from-issue":
            params = integration.extract_maintenance_params(args.issue)
            print("Maintenance parameters extracted from JIRA:")
            print(json.dumps(params, indent=2))
            return 0

    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
