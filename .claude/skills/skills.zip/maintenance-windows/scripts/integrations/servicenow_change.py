#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
ServiceNow Change Request Integration

Links Zabbix maintenance windows with ServiceNow change requests.
Creates maintenance from approved changes and syncs status.

Usage:
    python servicenow_change.py create-from-change --change-number CHG0012345
    python servicenow_change.py link-maintenance --change CHG0012345 --maintenance-id 123
    python servicenow_change.py sync-status --change CHG0012345

Configuration:
    Set environment variables:
    - SERVICENOW_INSTANCE (e.g., yourcompany.service-now.com)
    - SERVICENOW_USERNAME
    - SERVICENOW_PASSWORD or SERVICENOW_TOKEN

Author: Zabbix Skills Automation
Version: 1.0
"""

import argparse
import sys
import os
import json
from datetime import datetime
from typing import Dict, Optional
import requests


class ServiceNowIntegration:
    """ServiceNow change request integration"""

    def __init__(self, instance: str, username: str, password: str):
        """
        Initialize ServiceNow integration

        Args:
            instance: ServiceNow instance URL
            username: ServiceNow username
            password: ServiceNow password or token
        """
        self.instance = instance
        self.auth = (username, password)
        self.base_url = f"https://{instance}/api/now"

    def get_change_request(self, change_number: str) -> Dict:
        """
        Retrieve change request details

        Args:
            change_number: Change request number (e.g., CHG0012345)

        Returns:
            Change request data
        """
        url = f"{self.base_url}/table/change_request"
        params = {"sysparm_query": f"number={change_number}"}

        response = requests.get(url, auth=self.auth, params=params)
        response.raise_for_status()

        result = response.json()
        if not result.get("result"):
            raise ValueError(f"Change request not found: {change_number}")

        return result["result"][0]

    def update_change_status(self, change_number: str, work_notes: str) -> bool:
        """
        Update change request with maintenance information

        Args:
            change_number: Change request number
            work_notes: Work notes to add

        Returns:
            True if update successful
        """
        # Get change sys_id
        change = self.get_change_request(change_number)
        sys_id = change["sys_id"]

        url = f"{self.base_url}/table/change_request/{sys_id}"
        data = {"work_notes": work_notes}

        response = requests.patch(url, auth=self.auth, json=data)
        response.raise_for_status()

        return True

    def create_maintenance_from_change(self, change_number: str) -> Dict:
        """
        Extract maintenance parameters from change request

        Args:
            change_number: Change request number

        Returns:
            Dictionary with maintenance parameters
        """
        change = self.get_change_request(change_number)

        # Extract relevant fields
        maintenance_params = {
            "name": f"Change {change_number}: {change.get('short_description', 'N/A')}",
            "description": f"""ServiceNow Change Request Integration
Change Number: {change_number}
Short Description: {change.get('short_description', 'N/A')}
State: {change.get('state', 'N/A')}
Risk: {change.get('risk', 'N/A')}
Impact: {change.get('impact', 'N/A')}
Assignment Group: {change.get('assignment_group', 'N/A')}
""",
            "start_date": change.get("start_date"),
            "end_date": change.get("end_date"),
            "affected_hosts": change.get("cmdb_ci", "").split(",")  # Configuration items
        }

        return maintenance_params


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="ServiceNow Change Request Integration",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument("--instance", default=os.getenv("SERVICENOW_INSTANCE"),
                       help="ServiceNow instance")
    parser.add_argument("--username", default=os.getenv("SERVICENOW_USERNAME"),
                       help="ServiceNow username")
    parser.add_argument("--password", default=os.getenv("SERVICENOW_PASSWORD"),
                       help="ServiceNow password/token")

    subparsers = parser.add_subparsers(dest="command")

    # Get change details
    get_parser = subparsers.add_parser("get-change")
    get_parser.add_argument("--change-number", required=True, help="Change request number")

    # Create maintenance from change
    create_parser = subparsers.add_parser("create-from-change")
    create_parser.add_argument("--change-number", required=True, help="Change request number")
    create_parser.add_argument("--zabbix-url", default=os.getenv("ZABBIX_URL"))
    create_parser.add_argument("--zabbix-token", default=os.getenv("ZABBIX_TOKEN"))

    # Update change with maintenance info
    update_parser = subparsers.add_parser("update-change")
    update_parser.add_argument("--change-number", required=True, help="Change request number")
    update_parser.add_argument("--maintenance-id", required=True, help="Zabbix maintenance ID")
    update_parser.add_argument("--status", required=True, help="Status message")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    if not all([args.instance, args.username, args.password]):
        print("Error: ServiceNow credentials required")
        return 1

    integration = ServiceNowIntegration(args.instance, args.username, args.password)

    try:
        if args.command == "get-change":
            change = integration.get_change_request(args.change_number)
            print(json.dumps(change, indent=2))
            return 0

        elif args.command == "create-from-change":
            params = integration.create_maintenance_from_change(args.change_number)
            print("Maintenance parameters extracted from change:")
            print(json.dumps(params, indent=2))
            print("\nNote: Use zabbix_maintenance_manager.py to create the actual maintenance")
            return 0

        elif args.command == "update-change":
            work_notes = f"Zabbix maintenance window created: ID {args.maintenance_id}\nStatus: {args.status}"
            integration.update_change_status(args.change_number, work_notes)
            print(f"[OK] Updated change {args.change_number}")
            return 0

    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
