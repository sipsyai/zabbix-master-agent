#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Maintenance Calendar Integration

Export maintenance schedules to iCal format or sync with Google Calendar.

Usage:
    python maintenance_calendar.py export-ical --output schedule.ics
    python maintenance_calendar.py sync-google --calendar "Zabbix Maintenance"

Author: Zabbix Skills Automation
Version: 1.0
"""

import argparse
import sys
import os
from datetime import datetime
from zabbix_maintenance_manager import ZabbixMaintenanceManager


def generate_ical(maintenances: list) -> str:
    """Generate iCal format from maintenances"""

    ical = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Zabbix Maintenance//EN
CALSCALE:GREGORIAN
METHOD:PUBLISH
X-WR-CALNAME:Zabbix Maintenance Windows
X-WR-TIMEZONE:UTC

"""

    for m in maintenances:
        start_dt = datetime.fromtimestamp(int(m["active_since"]))
        end_dt = datetime.fromtimestamp(int(m["active_till"]))

        ical += f"""BEGIN:VEVENT
UID:{m['maintenanceid']}@zabbix
DTSTAMP:{datetime.now().strftime('%Y%m%dT%H%M%SZ')}
DTSTART:{start_dt.strftime('%Y%m%dT%H%M%SZ')}
DTEND:{end_dt.strftime('%Y%m%dT%H%M%SZ')}
SUMMARY:{m['name']}
DESCRIPTION:{m.get('description', '').replace('\n', '\\n')}
LOCATION:Zabbix
STATUS:CONFIRMED
END:VEVENT

"""

    ical += "END:VCALENDAR"
    return ical


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(description="Maintenance Calendar Integration")

    parser.add_argument("--url", default=os.getenv("ZABBIX_URL"))
    parser.add_argument("--token", default=os.getenv("ZABBIX_TOKEN"))
    parser.add_argument("--no-verify-ssl", action="store_true")

    subparsers = parser.add_subparsers(dest="command")

    # Export iCal
    ical_parser = subparsers.add_parser("export-ical")
    ical_parser.add_argument("--output", required=True, help="Output .ics file")
    ical_parser.add_argument("--filter", help="Filter maintenances")
    ical_parser.add_argument("--next-days", type=int, help="Only export next N days")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    if not args.url or not args.token:
        print("Error: Zabbix URL and token required")
        return 1

    manager = ZabbixMaintenanceManager(args.url, args.token, verify_ssl=not args.no_verify_ssl)

    try:
        if args.command == "export-ical":
            maintenances = manager.get_maintenance()

            # Filter future maintenances
            now = datetime.now().timestamp()
            future = [m for m in maintenances if int(m["active_till"]) > now]

            ical_content = generate_ical(future)

            with open(args.output, 'w') as f:
                f.write(ical_content)

            print(f"[OK] Exported {len(future)} maintenance(s) to {args.output}")
            return 0

    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
