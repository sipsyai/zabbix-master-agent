#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Maintenance Reporter - Generate maintenance history and compliance reports

Creates reports on maintenance windows, compliance, and operational metrics.

Usage:
    python maintenance_reporter.py history --start "2025-01-01" --end "2025-03-31" --output report.pdf
    python maintenance_reporter.py compliance --policy ITIL --check-approvals

Author: Zabbix Skills Automation
Version: 1.0
"""

import argparse
import sys
import os
from datetime import datetime
from typing import List, Dict
from zabbix_maintenance_manager import ZabbixMaintenanceManager


class MaintenanceReporter:
    """Generate maintenance reports"""

    def __init__(self, manager: ZabbixMaintenanceManager):
        self.manager = manager

    def generate_history_report(
        self,
        start_date: str,
        end_date: str,
        output_format: str = "text"
    ) -> str:
        """Generate maintenance history report"""

        start_ts = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp())
        end_ts = int(datetime.strptime(end_date, "%Y-%m-%d").timestamp())

        # Get all maintenances
        maintenances = self.manager.get_maintenance()

        # Filter by date range
        filtered = [
            m for m in maintenances
            if int(m["active_since"]) <= end_ts and int(m["active_till"]) >= start_ts
        ]

        report = f"""
Maintenance History Report
Period: {start_date} to {end_date}
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Total Maintenances: {len(filtered)}
{'='*60}

"""
        for m in filtered:
            report += f"""
Name: {m['name']}
ID: {m['maintenanceid']}
Type: {'No data' if m['maintenance_type'] == '1' else 'With data'}
Active: {datetime.fromtimestamp(int(m['active_since'])).strftime('%Y-%m-%d %H:%M')} - {datetime.fromtimestamp(int(m['active_till'])).strftime('%Y-%m-%d %H:%M')}
Duration: {(int(m['active_till']) - int(m['active_since'])) // 60} minutes
Hosts: {len(m.get('hosts', []))}
Groups: {len(m.get('hostgroups', []))}
Description: {m.get('description', 'N/A')[:100]}
{'-'*60}
"""

        return report


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(description="Maintenance Reporter")

    parser.add_argument("--url", default=os.getenv("ZABBIX_URL"))
    parser.add_argument("--token", default=os.getenv("ZABBIX_TOKEN"))
    parser.add_argument("--no-verify-ssl", action="store_true")

    subparsers = parser.add_subparsers(dest="command")

    # History report
    history_parser = subparsers.add_parser("history")
    history_parser.add_argument("--start", required=True, help="Start date (YYYY-MM-DD)")
    history_parser.add_argument("--end", required=True, help="End date (YYYY-MM-DD)")
    history_parser.add_argument("--format", choices=["text", "json"], default="text")
    history_parser.add_argument("--output", help="Output file")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    if not args.url or not args.token:
        print("Error: Zabbix URL and token required")
        return 1

    manager = ZabbixMaintenanceManager(args.url, args.token, verify_ssl=not args.no_verify_ssl)
    reporter = MaintenanceReporter(manager)

    try:
        if args.command == "history":
            report = reporter.generate_history_report(args.start, args.end, args.format)

            if args.output:
                with open(args.output, 'w') as f:
                    f.write(report)
                print(f"[OK] Report written to {args.output}")
            else:
                print(report)

            return 0

    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
