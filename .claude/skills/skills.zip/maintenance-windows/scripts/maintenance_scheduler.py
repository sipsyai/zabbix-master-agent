#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Maintenance Scheduler - Create recurring and scheduled maintenance patterns

Supports:
- Daily recurring schedules
- Weekly recurring schedules (specific days)
- Monthly recurring schedules (by date or day of week)
- Complex recurring patterns
- Multi-region scheduling
- Patch management schedules

Usage:
    python maintenance_scheduler.py create-recurring --name "Weekly Backup" --type weekly --day sunday --time "03:00" --duration 180
    python maintenance_scheduler.py create-patch-tuesday --name "Windows Patching" --time "02:00" --duration 240
    python maintenance_scheduler.py create-daily --name "Nightly Maintenance" --time "01:00" --duration 60 --every 1

Author: Zabbix Skills Automation
Version: 1.0
"""

import argparse
import sys
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from zabbix_maintenance_manager import ZabbixMaintenanceManager, parse_datetime


class MaintenanceScheduler:
    """Creates recurring maintenance schedules"""

    # Day of week bitmap values
    DAYS_OF_WEEK = {
        "monday": 1,
        "tuesday": 2,
        "wednesday": 4,
        "thursday": 8,
        "friday": 16,
        "saturday": 32,
        "sunday": 64
    }

    # Month bitmap values
    MONTHS = {
        "january": 1,
        "february": 2,
        "march": 4,
        "april": 8,
        "may": 16,
        "june": 32,
        "july": 64,
        "august": 128,
        "september": 256,
        "october": 512,
        "november": 1024,
        "december": 2048
    }

    # Week of month values
    WEEK_OF_MONTH = {
        "first": 1,
        "second": 2,
        "third": 3,
        "fourth": 4,
        "last": 5
    }

    def __init__(self, manager: ZabbixMaintenanceManager):
        """
        Initialize scheduler

        Args:
            manager: ZabbixMaintenanceManager instance
        """
        self.manager = manager

    def create_daily_maintenance(
        self,
        name: str,
        time: str,
        duration_minutes: int,
        every_n_days: int,
        start_date: str,
        end_date: str,
        hosts: List[str] = None,
        hostgroups: List[str] = None,
        maintenance_type: int = 0,
        description: str = ""
    ) -> str:
        """
        Create daily recurring maintenance

        Args:
            name: Maintenance name
            time: Time of day (HH:MM format)
            duration_minutes: Duration in minutes
            every_n_days: Frequency (1=every day, 2=every 2 days, etc.)
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            hosts: List of hosts
            hostgroups: List of hostgroups
            maintenance_type: 0=with data, 1=no data
            description: Description

        Returns:
            Created maintenance ID
        """
        # Parse time
        hour, minute = map(int, time.split(":"))
        start_time = hour * 3600 + minute * 60

        # Parse dates
        active_since = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp())
        active_till = int(datetime.strptime(end_date, "%Y-%m-%d").timestamp())

        # Create time period
        timeperiod = {
            "timeperiod_type": 2,  # Daily
            "every": every_n_days,
            "start_time": start_time,
            "period": duration_minutes * 60
        }

        return self.manager.create_maintenance(
            name=name,
            active_since=active_since,
            active_till=active_till,
            maintenance_type=maintenance_type,
            hosts=hosts,
            hostgroups=hostgroups,
            timeperiods=[timeperiod],
            description=description
        )

    def create_weekly_maintenance(
        self,
        name: str,
        days: List[str],
        time: str,
        duration_minutes: int,
        every_n_weeks: int,
        start_date: str,
        end_date: str,
        hosts: List[str] = None,
        hostgroups: List[str] = None,
        maintenance_type: int = 0,
        description: str = ""
    ) -> str:
        """
        Create weekly recurring maintenance

        Args:
            name: Maintenance name
            days: List of day names (e.g., ["monday", "friday"])
            time: Time of day (HH:MM format)
            duration_minutes: Duration in minutes
            every_n_weeks: Frequency (1=every week, 2=every 2 weeks, etc.)
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            hosts: List of hosts
            hostgroups: List of hostgroups
            maintenance_type: 0=with data, 1=no data
            description: Description

        Returns:
            Created maintenance ID
        """
        # Calculate day of week bitmap
        dayofweek = 0
        for day in days:
            day_lower = day.lower()
            if day_lower not in self.DAYS_OF_WEEK:
                raise ValueError(f"Invalid day: {day}. Must be one of: {list(self.DAYS_OF_WEEK.keys())}")
            dayofweek += self.DAYS_OF_WEEK[day_lower]

        # Parse time
        hour, minute = map(int, time.split(":"))
        start_time = hour * 3600 + minute * 60

        # Parse dates
        active_since = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp())
        active_till = int(datetime.strptime(end_date, "%Y-%m-%d").timestamp())

        # Create time period
        timeperiod = {
            "timeperiod_type": 3,  # Weekly
            "every": every_n_weeks,
            "dayofweek": dayofweek,
            "start_time": start_time,
            "period": duration_minutes * 60
        }

        return self.manager.create_maintenance(
            name=name,
            active_since=active_since,
            active_till=active_till,
            maintenance_type=maintenance_type,
            hosts=hosts,
            hostgroups=hostgroups,
            timeperiods=[timeperiod],
            description=description
        )

    def create_monthly_by_date_maintenance(
        self,
        name: str,
        day_of_month: int,
        months: List[str],
        time: str,
        duration_minutes: int,
        start_date: str,
        end_date: str,
        hosts: List[str] = None,
        hostgroups: List[str] = None,
        maintenance_type: int = 0,
        description: str = ""
    ) -> str:
        """
        Create monthly maintenance on specific day of month

        Args:
            name: Maintenance name
            day_of_month: Day of month (1-31)
            months: List of month names (e.g., ["january", "july"])
            time: Time of day (HH:MM format)
            duration_minutes: Duration in minutes
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            hosts: List of hosts
            hostgroups: List of hostgroups
            maintenance_type: 0=with data, 1=no data
            description: Description

        Returns:
            Created maintenance ID
        """
        if not 1 <= day_of_month <= 31:
            raise ValueError("day_of_month must be between 1 and 31")

        # Calculate month bitmap
        month_bitmap = 0
        for month in months:
            month_lower = month.lower()
            if month_lower not in self.MONTHS:
                raise ValueError(f"Invalid month: {month}. Must be one of: {list(self.MONTHS.keys())}")
            month_bitmap += self.MONTHS[month_lower]

        # Parse time
        hour, minute = map(int, time.split(":"))
        start_time = hour * 3600 + minute * 60

        # Parse dates
        active_since = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp())
        active_till = int(datetime.strptime(end_date, "%Y-%m-%d").timestamp())

        # Create time period
        timeperiod = {
            "timeperiod_type": 4,  # Monthly
            "day": day_of_month,
            "month": month_bitmap,
            "start_time": start_time,
            "period": duration_minutes * 60
        }

        return self.manager.create_maintenance(
            name=name,
            active_since=active_since,
            active_till=active_till,
            maintenance_type=maintenance_type,
            hosts=hosts,
            hostgroups=hostgroups,
            timeperiods=[timeperiod],
            description=description
        )

    def create_monthly_by_weekday_maintenance(
        self,
        name: str,
        week_of_month: str,
        days: List[str],
        months: List[str],
        time: str,
        duration_minutes: int,
        start_date: str,
        end_date: str,
        hosts: List[str] = None,
        hostgroups: List[str] = None,
        maintenance_type: int = 0,
        description: str = ""
    ) -> str:
        """
        Create monthly maintenance on specific week/day (e.g., "second Tuesday")

        Args:
            name: Maintenance name
            week_of_month: Week of month (first, second, third, fourth, last)
            days: List of day names (e.g., ["tuesday"])
            months: List of month names (e.g., ["january", "july"])
            time: Time of day (HH:MM format)
            duration_minutes: Duration in minutes
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            hosts: List of hosts
            hostgroups: List of hostgroups
            maintenance_type: 0=with data, 1=no data
            description: Description

        Returns:
            Created maintenance ID
        """
        # Get week value
        week_lower = week_of_month.lower()
        if week_lower not in self.WEEK_OF_MONTH:
            raise ValueError(f"Invalid week: {week_of_month}. Must be one of: {list(self.WEEK_OF_MONTH.keys())}")
        every = self.WEEK_OF_MONTH[week_lower]

        # Calculate day of week bitmap
        dayofweek = 0
        for day in days:
            day_lower = day.lower()
            if day_lower not in self.DAYS_OF_WEEK:
                raise ValueError(f"Invalid day: {day}. Must be one of: {list(self.DAYS_OF_WEEK.keys())}")
            dayofweek += self.DAYS_OF_WEEK[day_lower]

        # Calculate month bitmap
        month_bitmap = 0
        for month in months:
            month_lower = month.lower()
            if month_lower not in self.MONTHS:
                raise ValueError(f"Invalid month: {month}. Must be one of: {list(self.MONTHS.keys())}")
            month_bitmap += self.MONTHS[month_lower]

        # Parse time
        hour, minute = map(int, time.split(":"))
        start_time = hour * 3600 + minute * 60

        # Parse dates
        active_since = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp())
        active_till = int(datetime.strptime(end_date, "%Y-%m-%d").timestamp())

        # Create time period
        timeperiod = {
            "timeperiod_type": 4,  # Monthly
            "every": every,
            "dayofweek": dayofweek,
            "month": month_bitmap,
            "start_time": start_time,
            "period": duration_minutes * 60
        }

        return self.manager.create_maintenance(
            name=name,
            active_since=active_since,
            active_till=active_till,
            maintenance_type=maintenance_type,
            hosts=hosts,
            hostgroups=hostgroups,
            timeperiods=[timeperiod],
            description=description
        )

    def create_patch_tuesday_maintenance(
        self,
        name: str,
        time: str,
        duration_minutes: int,
        start_date: str,
        end_date: str,
        hosts: List[str] = None,
        hostgroups: List[str] = None,
        description: str = "Microsoft Patch Tuesday maintenance window"
    ) -> str:
        """
        Create Patch Tuesday maintenance (second Tuesday of every month)

        Args:
            name: Maintenance name
            time: Time of day (HH:MM format)
            duration_minutes: Duration in minutes
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            hosts: List of hosts
            hostgroups: List of hostgroups
            description: Description

        Returns:
            Created maintenance ID
        """
        # All months
        all_months = list(self.MONTHS.keys())

        return self.create_monthly_by_weekday_maintenance(
            name=name,
            week_of_month="second",
            days=["tuesday"],
            months=all_months,
            time=time,
            duration_minutes=duration_minutes,
            start_date=start_date,
            end_date=end_date,
            hosts=hosts,
            hostgroups=hostgroups,
            maintenance_type=1,  # No data collection for patching
            description=description
        )

    def create_business_hours_suppression(
        self,
        name: str,
        business_hours_start: str,
        business_hours_end: str,
        weekdays_only: bool,
        start_date: str,
        end_date: str,
        hosts: List[str] = None,
        hostgroups: List[str] = None,
        description: str = "Business hours alert suppression"
    ) -> str:
        """
        Create maintenance for business hours alert suppression

        Args:
            name: Maintenance name
            business_hours_start: Start time (HH:MM)
            business_hours_end: End time (HH:MM)
            weekdays_only: True to exclude weekends
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            hosts: List of hosts
            hostgroups: List of hostgroups
            description: Description

        Returns:
            Created maintenance ID
        """
        # Parse times
        start_hour, start_minute = map(int, business_hours_start.split(":"))
        end_hour, end_minute = map(int, business_hours_end.split(":"))

        start_time = start_hour * 3600 + start_minute * 60
        end_time = end_hour * 3600 + end_minute * 60

        duration = end_time - start_time
        if duration <= 0:
            duration += 86400  # Add 24 hours if end is next day

        # Determine days
        if weekdays_only:
            days = ["monday", "tuesday", "wednesday", "thursday", "friday"]
        else:
            days = list(self.DAYS_OF_WEEK.keys())

        return self.create_weekly_maintenance(
            name=name,
            days=days,
            time=business_hours_start,
            duration_minutes=duration // 60,
            every_n_weeks=1,
            start_date=start_date,
            end_date=end_date,
            hosts=hosts,
            hostgroups=hostgroups,
            maintenance_type=0,  # With data collection
            description=description
        )


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="Maintenance Scheduler - Create recurring maintenance patterns",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    # Global arguments
    parser.add_argument("--url", default=os.getenv("ZABBIX_URL"),
                       help="Zabbix API URL")
    parser.add_argument("--token", default=os.getenv("ZABBIX_TOKEN"),
                       help="Zabbix API token")
    parser.add_argument("--no-verify-ssl", action="store_true",
                       help="Disable SSL verification")

    subparsers = parser.add_subparsers(dest="command", help="Schedule type")

    # Daily schedule
    daily_parser = subparsers.add_parser("daily", help="Daily recurring maintenance")
    daily_parser.add_argument("--name", required=True, help="Maintenance name")
    daily_parser.add_argument("--time", required=True, help="Time (HH:MM)")
    daily_parser.add_argument("--duration", type=int, required=True, help="Duration in minutes")
    daily_parser.add_argument("--every", type=int, default=1, help="Every N days (default: 1)")
    daily_parser.add_argument("--start", required=True, help="Start date (YYYY-MM-DD)")
    daily_parser.add_argument("--end", required=True, help="End date (YYYY-MM-DD)")
    daily_parser.add_argument("--hosts", help="Comma-separated host names")
    daily_parser.add_argument("--hostgroups", help="Comma-separated hostgroup names")
    daily_parser.add_argument("--type", choices=["with-data", "no-data"], default="with-data")
    daily_parser.add_argument("--description", default="", help="Description")

    # Weekly schedule
    weekly_parser = subparsers.add_parser("weekly", help="Weekly recurring maintenance")
    weekly_parser.add_argument("--name", required=True, help="Maintenance name")
    weekly_parser.add_argument("--days", required=True, help="Comma-separated day names")
    weekly_parser.add_argument("--time", required=True, help="Time (HH:MM)")
    weekly_parser.add_argument("--duration", type=int, required=True, help="Duration in minutes")
    weekly_parser.add_argument("--every", type=int, default=1, help="Every N weeks (default: 1)")
    weekly_parser.add_argument("--start", required=True, help="Start date (YYYY-MM-DD)")
    weekly_parser.add_argument("--end", required=True, help="End date (YYYY-MM-DD)")
    weekly_parser.add_argument("--hosts", help="Comma-separated host names")
    weekly_parser.add_argument("--hostgroups", help="Comma-separated hostgroup names")
    weekly_parser.add_argument("--type", choices=["with-data", "no-data"], default="with-data")
    weekly_parser.add_argument("--description", default="", help="Description")

    # Monthly by date
    monthly_date_parser = subparsers.add_parser("monthly-date", help="Monthly by date")
    monthly_date_parser.add_argument("--name", required=True, help="Maintenance name")
    monthly_date_parser.add_argument("--day", type=int, required=True, help="Day of month (1-31)")
    monthly_date_parser.add_argument("--months", required=True, help="Comma-separated month names")
    monthly_date_parser.add_argument("--time", required=True, help="Time (HH:MM)")
    monthly_date_parser.add_argument("--duration", type=int, required=True, help="Duration in minutes")
    monthly_date_parser.add_argument("--start", required=True, help="Start date (YYYY-MM-DD)")
    monthly_date_parser.add_argument("--end", required=True, help="End date (YYYY-MM-DD)")
    monthly_date_parser.add_argument("--hosts", help="Comma-separated host names")
    monthly_date_parser.add_argument("--hostgroups", help="Comma-separated hostgroup names")
    monthly_date_parser.add_argument("--type", choices=["with-data", "no-data"], default="with-data")
    monthly_date_parser.add_argument("--description", default="", help="Description")

    # Monthly by weekday
    monthly_weekday_parser = subparsers.add_parser("monthly-weekday", help="Monthly by weekday")
    monthly_weekday_parser.add_argument("--name", required=True, help="Maintenance name")
    monthly_weekday_parser.add_argument("--week", required=True,
                                       choices=["first", "second", "third", "fourth", "last"],
                                       help="Week of month")
    monthly_weekday_parser.add_argument("--days", required=True, help="Comma-separated day names")
    monthly_weekday_parser.add_argument("--months", required=True, help="Comma-separated month names")
    monthly_weekday_parser.add_argument("--time", required=True, help="Time (HH:MM)")
    monthly_weekday_parser.add_argument("--duration", type=int, required=True, help="Duration in minutes")
    monthly_weekday_parser.add_argument("--start", required=True, help="Start date (YYYY-MM-DD)")
    monthly_weekday_parser.add_argument("--end", required=True, help="End date (YYYY-MM-DD)")
    monthly_weekday_parser.add_argument("--hosts", help="Comma-separated host names")
    monthly_weekday_parser.add_argument("--hostgroups", help="Comma-separated hostgroup names")
    monthly_weekday_parser.add_argument("--type", choices=["with-data", "no-data"], default="with-data")
    monthly_weekday_parser.add_argument("--description", default="", help="Description")

    # Patch Tuesday
    patch_parser = subparsers.add_parser("patch-tuesday", help="Patch Tuesday schedule")
    patch_parser.add_argument("--name", required=True, help="Maintenance name")
    patch_parser.add_argument("--time", required=True, help="Time (HH:MM)")
    patch_parser.add_argument("--duration", type=int, required=True, help="Duration in minutes")
    patch_parser.add_argument("--start", required=True, help="Start date (YYYY-MM-DD)")
    patch_parser.add_argument("--end", required=True, help="End date (YYYY-MM-DD)")
    patch_parser.add_argument("--hosts", help="Comma-separated host names")
    patch_parser.add_argument("--hostgroups", help="Comma-separated hostgroup names")
    patch_parser.add_argument("--description", default="", help="Description")

    # Business hours
    business_parser = subparsers.add_parser("business-hours", help="Business hours suppression")
    business_parser.add_argument("--name", required=True, help="Maintenance name")
    business_parser.add_argument("--start-time", required=True, help="Business hours start (HH:MM)")
    business_parser.add_argument("--end-time", required=True, help="Business hours end (HH:MM)")
    business_parser.add_argument("--weekdays-only", action="store_true", help="Weekdays only")
    business_parser.add_argument("--start", required=True, help="Start date (YYYY-MM-DD)")
    business_parser.add_argument("--end", required=True, help="End date (YYYY-MM-DD)")
    business_parser.add_argument("--hosts", help="Comma-separated host names")
    business_parser.add_argument("--hostgroups", help="Comma-separated hostgroup names")
    business_parser.add_argument("--description", default="", help="Description")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    if not args.url or not args.token:
        print("Error: Zabbix URL and token required")
        return 1

    # Initialize manager and scheduler
    manager = ZabbixMaintenanceManager(
        args.url,
        args.token,
        verify_ssl=not args.no_verify_ssl
    )
    scheduler = MaintenanceScheduler(manager)

    try:
        hosts = args.hosts.split(",") if hasattr(args, 'hosts') and args.hosts else None
        hostgroups = args.hostgroups.split(",") if hasattr(args, 'hostgroups') and args.hostgroups else None

        if args.command == "daily":
            maintenance_type = 0 if args.type == "with-data" else 1
            maintenance_id = scheduler.create_daily_maintenance(
                name=args.name,
                time=args.time,
                duration_minutes=args.duration,
                every_n_days=args.every,
                start_date=args.start,
                end_date=args.end,
                hosts=hosts,
                hostgroups=hostgroups,
                maintenance_type=maintenance_type,
                description=args.description
            )
            print(f"[OK] Created daily maintenance (ID: {maintenance_id})")

        elif args.command == "weekly":
            days = [d.strip() for d in args.days.split(",")]
            maintenance_type = 0 if args.type == "with-data" else 1
            maintenance_id = scheduler.create_weekly_maintenance(
                name=args.name,
                days=days,
                time=args.time,
                duration_minutes=args.duration,
                every_n_weeks=args.every,
                start_date=args.start,
                end_date=args.end,
                hosts=hosts,
                hostgroups=hostgroups,
                maintenance_type=maintenance_type,
                description=args.description
            )
            print(f"[OK] Created weekly maintenance (ID: {maintenance_id})")

        elif args.command == "monthly-date":
            months = [m.strip() for m in args.months.split(",")]
            maintenance_type = 0 if args.type == "with-data" else 1
            maintenance_id = scheduler.create_monthly_by_date_maintenance(
                name=args.name,
                day_of_month=args.day,
                months=months,
                time=args.time,
                duration_minutes=args.duration,
                start_date=args.start,
                end_date=args.end,
                hosts=hosts,
                hostgroups=hostgroups,
                maintenance_type=maintenance_type,
                description=args.description
            )
            print(f"[OK] Created monthly maintenance (ID: {maintenance_id})")

        elif args.command == "monthly-weekday":
            days = [d.strip() for d in args.days.split(",")]
            months = [m.strip() for m in args.months.split(",")]
            maintenance_type = 0 if args.type == "with-data" else 1
            maintenance_id = scheduler.create_monthly_by_weekday_maintenance(
                name=args.name,
                week_of_month=args.week,
                days=days,
                months=months,
                time=args.time,
                duration_minutes=args.duration,
                start_date=args.start,
                end_date=args.end,
                hosts=hosts,
                hostgroups=hostgroups,
                maintenance_type=maintenance_type,
                description=args.description
            )
            print(f"[OK] Created monthly maintenance (ID: {maintenance_id})")

        elif args.command == "patch-tuesday":
            maintenance_id = scheduler.create_patch_tuesday_maintenance(
                name=args.name,
                time=args.time,
                duration_minutes=args.duration,
                start_date=args.start,
                end_date=args.end,
                hosts=hosts,
                hostgroups=hostgroups,
                description=args.description or "Microsoft Patch Tuesday maintenance"
            )
            print(f"[OK] Created Patch Tuesday maintenance (ID: {maintenance_id})")

        elif args.command == "business-hours":
            maintenance_id = scheduler.create_business_hours_suppression(
                name=args.name,
                business_hours_start=args.start_time,
                business_hours_end=args.end_time,
                weekdays_only=args.weekdays_only,
                start_date=args.start,
                end_date=args.end,
                hosts=hosts,
                hostgroups=hostgroups,
                description=args.description or "Business hours alert suppression"
            )
            print(f"[OK] Created business hours suppression (ID: {maintenance_id})")

        return 0

    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
