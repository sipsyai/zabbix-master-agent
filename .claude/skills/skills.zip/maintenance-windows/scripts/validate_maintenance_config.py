#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Validate Maintenance Configuration

Validates maintenance configurations before creation:
- Host/hostgroup existence
- Time period validity
- Schedule conflicts
- Tag syntax
- Permission checks

Usage:
    python validate_maintenance_config.py check --config maintenance.json
    python validate_maintenance_config.py verify-hosts --hosts "host1,host2"
    python validate_maintenance_config.py check-conflicts --start "2025-12-01 02:00" --duration 120

Author: Zabbix Skills Automation
Version: 1.0
"""

import argparse
import json
import sys
import os
from datetime import datetime
from typing import Dict, List, Tuple
from pathlib import Path
import yaml
from zabbix_maintenance_manager import ZabbixMaintenanceManager


class MaintenanceValidator:
    """Validate maintenance configurations"""

    def __init__(self, manager: ZabbixMaintenanceManager):
        self.manager = manager
        self.errors = []
        self.warnings = []

    def validate_config_file(self, filepath: str) -> Tuple[bool, List[str], List[str]]:
        """
        Validate maintenance configuration from file

        Args:
            filepath: Path to config file (JSON or YAML)

        Returns:
            Tuple of (is_valid, errors, warnings)
        """
        path = Path(filepath)

        if not path.exists():
            return False, [f"File not found: {filepath}"], []

        # Load configuration
        try:
            with open(path, 'r') as f:
                if path.suffix in ['.yaml', '.yml']:
                    config = yaml.safe_load(f)
                elif path.suffix == '.json':
                    config = json.load(f)
                else:
                    return False, ["File must be YAML or JSON"], []
        except Exception as e:
            return False, [f"Failed to parse file: {str(e)}"], []

        # Validate structure
        if "maintenances" in config:
            maintenances = config["maintenances"]
        elif isinstance(config, dict) and "name" in config:
            maintenances = [config]
        else:
            return False, ["Invalid config structure"], []

        # Validate each maintenance
        for idx, maint in enumerate(maintenances, 1):
            self._validate_maintenance_object(maint, f"Maintenance {idx}")

        return len(self.errors) == 0, self.errors, self.warnings

    def _validate_maintenance_object(self, maint: Dict, context: str):
        """Validate single maintenance object"""

        # Required fields
        if not maint.get("name"):
            self.errors.append(f"{context}: Missing 'name'")

        if "active_since" not in maint:
            self.errors.append(f"{context}: Missing 'active_since'")

        if "active_till" not in maint:
            self.errors.append(f"{context}: Missing 'active_till'")

        # Parse timestamps if strings
        try:
            if isinstance(maint.get("active_since"), str):
                since_ts = datetime.strptime(maint["active_since"], "%Y-%m-%d %H:%M").timestamp()
            else:
                since_ts = maint.get("active_since", 0)

            if isinstance(maint.get("active_till"), str):
                till_ts = datetime.strptime(maint["active_till"], "%Y-%m-%d %H:%M").timestamp()
            else:
                till_ts = maint.get("active_till", 0)

            # Validate time range
            if since_ts >= till_ts:
                self.errors.append(f"{context}: active_since must be before active_till")

            # Warn if in the past
            if till_ts < datetime.now().timestamp():
                self.warnings.append(f"{context}: Maintenance period is in the past")

        except ValueError as e:
            self.errors.append(f"{context}: Invalid datetime format - {str(e)}")

        # Validate hosts/groups
        if not maint.get("hosts") and not maint.get("hostgroups"):
            self.errors.append(f"{context}: Must specify hosts or hostgroups")

        # Validate maintenance type
        maint_type = maint.get("maintenance_type", 0)
        if maint_type not in [0, 1]:
            self.errors.append(f"{context}: maintenance_type must be 0 or 1")

        # Validate tags (only for with-data maintenance)
        if maint.get("tags"):
            if maint_type != 0:
                self.errors.append(f"{context}: Tags only allowed with maintenance_type=0")
            else:
                self._validate_tags(maint["tags"], context)

        # Validate time periods
        if maint.get("timeperiods"):
            for idx, tp in enumerate(maint["timeperiods"], 1):
                self._validate_timeperiod(tp, f"{context} timeperiod {idx}")

    def _validate_tags(self, tags: List[Dict], context: str):
        """Validate problem tags"""
        for idx, tag in enumerate(tags, 1):
            if not tag.get("tag"):
                self.errors.append(f"{context} tag {idx}: Missing 'tag' field")

            operator = tag.get("operator", 2)
            if operator not in [0, 2]:
                self.errors.append(f"{context} tag {idx}: operator must be 0 or 2")

    def _validate_timeperiod(self, tp: Dict, context: str):
        """Validate time period"""
        tp_type = tp.get("timeperiod_type", 0)

        if tp_type not in [0, 2, 3, 4]:
            self.errors.append(f"{context}: Invalid timeperiod_type")
            return

        # Type-specific validation
        if tp_type == 0:  # One-time
            if "start_date" not in tp:
                self.warnings.append(f"{context}: start_date recommended for one-time")

        elif tp_type == 2:  # Daily
            if "start_time" not in tp:
                self.warnings.append(f"{context}: start_time recommended for daily")

        elif tp_type == 3:  # Weekly
            if "dayofweek" not in tp:
                self.errors.append(f"{context}: dayofweek required for weekly")
            if "start_time" not in tp:
                self.warnings.append(f"{context}: start_time recommended for weekly")

        elif tp_type == 4:  # Monthly
            if "month" not in tp:
                self.errors.append(f"{context}: month required for monthly")

            has_day = "day" in tp
            has_dayofweek = "dayofweek" in tp

            if not has_day and not has_dayofweek:
                self.errors.append(f"{context}: Must specify day or dayofweek for monthly")
            elif has_day and has_dayofweek:
                self.errors.append(f"{context}: Cannot specify both day and dayofweek")

    def verify_hosts_exist(self, hosts: List[str]) -> Tuple[List[str], List[str]]:
        """
        Verify hosts exist in Zabbix

        Args:
            hosts: List of host names

        Returns:
            Tuple of (found_hosts, missing_hosts)
        """
        found = []
        missing = []

        for host in hosts:
            try:
                result = self.manager._call_api("host.get", {
                    "filter": {"host": host},
                    "output": ["hostid", "host"]
                })

                if result:
                    found.append(host)
                else:
                    missing.append(host)
            except Exception:
                missing.append(host)

        return found, missing

    def verify_hostgroups_exist(self, groups: List[str]) -> Tuple[List[str], List[str]]:
        """
        Verify hostgroups exist in Zabbix

        Args:
            groups: List of hostgroup names

        Returns:
            Tuple of (found_groups, missing_groups)
        """
        found = []
        missing = []

        for group in groups:
            try:
                result = self.manager._call_api("hostgroup.get", {
                    "filter": {"name": group},
                    "output": ["groupid", "name"]
                })

                if result:
                    found.append(group)
                else:
                    missing.append(group)
            except Exception:
                missing.append(group)

        return found, missing

    def check_schedule_conflicts(
        self,
        start_timestamp: int,
        end_timestamp: int,
        hosts: List[str] = None,
        hostgroups: List[str] = None
    ) -> List[Dict]:
        """
        Check for overlapping maintenance periods

        Args:
            start_timestamp: Proposed start time
            end_timestamp: Proposed end time
            hosts: Host names to check
            hostgroups: Hostgroup names to check

        Returns:
            List of conflicting maintenance objects
        """
        conflicts = []

        # Get existing maintenances
        kwargs = {}
        if hosts:
            # Resolve host IDs
            host_ids = []
            for host in hosts:
                result = self.manager._call_api("host.get", {
                    "filter": {"host": host},
                    "output": ["hostid"]
                })
                if result:
                    host_ids.append(result[0]["hostid"])
            kwargs["hostids"] = host_ids

        if hostgroups:
            # Resolve group IDs
            group_ids = []
            for group in hostgroups:
                result = self.manager._call_api("hostgroup.get", {
                    "filter": {"name": group},
                    "output": ["groupid"]
                })
                if result:
                    group_ids.append(result[0]["groupid"])
            kwargs["groupids"] = group_ids

        maintenances = self.manager.get_maintenance(**kwargs)

        # Check for overlaps
        for m in maintenances:
            m_start = int(m["active_since"])
            m_end = int(m["active_till"])

            # Check if time ranges overlap
            if not (end_timestamp <= m_start or start_timestamp >= m_end):
                conflicts.append(m)

        return conflicts


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="Validate Maintenance Configuration",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument("--url", default=os.getenv("ZABBIX_URL"))
    parser.add_argument("--token", default=os.getenv("ZABBIX_TOKEN"))
    parser.add_argument("--no-verify-ssl", action="store_true")

    subparsers = parser.add_subparsers(dest="command")

    # Check config file
    check_parser = subparsers.add_parser("check", help="Validate config file")
    check_parser.add_argument("--config", required=True, help="Config file path")
    check_parser.add_argument("--verify-hosts", action="store_true",
                             help="Verify hosts exist in Zabbix")

    # Verify hosts
    hosts_parser = subparsers.add_parser("verify-hosts", help="Verify hosts exist")
    hosts_parser.add_argument("--hosts", required=True, help="Comma-separated host names")

    # Verify groups
    groups_parser = subparsers.add_parser("verify-groups", help="Verify hostgroups exist")
    groups_parser.add_argument("--groups", required=True, help="Comma-separated group names")

    # Check conflicts
    conflict_parser = subparsers.add_parser("check-conflicts", help="Check for conflicts")
    conflict_parser.add_argument("--start", required=True, help="Start time (YYYY-MM-DD HH:MM)")
    conflict_parser.add_argument("--duration", type=int, required=True, help="Duration in minutes")
    conflict_parser.add_argument("--hosts", help="Comma-separated host names")
    conflict_parser.add_argument("--hostgroups", help="Comma-separated hostgroup names")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    if not args.url or not args.token:
        print("Error: Zabbix URL and token required")
        return 1

    manager = ZabbixMaintenanceManager(args.url, args.token, verify_ssl=not args.no_verify_ssl)
    validator = MaintenanceValidator(manager)

    try:
        if args.command == "check":
            is_valid, errors, warnings = validator.validate_config_file(args.config)

            print(f"\nValidation Results for: {args.config}\n")

            if errors:
                print("Errors:")
                for error in errors:
                    print(f"  [ERROR] {error}")

            if warnings:
                print("\nWarnings:")
                for warning in warnings:
                    print(f"  [WARN] {warning}")

            if not errors and not warnings:
                print("[OK] Configuration is valid")

            # Verify hosts if requested
            if args.verify_hosts and is_valid:
                # Parse config to extract hosts
                with open(args.config) as f:
                    if args.config.endswith('.json'):
                        config = json.load(f)
                    else:
                        config = yaml.safe_load(f)

                # Extract hosts
                all_hosts = set()
                maintenances = config.get("maintenances", [config] if "name" in config else [])
                for m in maintenances:
                    if m.get("hosts"):
                        all_hosts.update(m["hosts"])

                if all_hosts:
                    found, missing = validator.verify_hosts_exist(list(all_hosts))
                    print(f"\nHost Verification:")
                    print(f"  Found: {len(found)}")
                    if missing:
                        print(f"  Missing: {len(missing)}")
                        for host in missing:
                            print(f"    - {host}")

            return 0 if is_valid else 1

        elif args.command == "verify-hosts":
            hosts = args.hosts.split(",")
            found, missing = validator.verify_hosts_exist(hosts)

            print(f"\nHost Verification Results:\n")
            print(f"Total hosts: {len(hosts)}")
            print(f"Found: {len(found)}")

            if missing:
                print(f"Missing: {len(missing)}")
                for host in missing:
                    print(f"  [ERROR] {host}")
                return 1
            else:
                print("[OK] All hosts found")
                return 0

        elif args.command == "verify-groups":
            groups = args.groups.split(",")
            found, missing = validator.verify_hostgroups_exist(groups)

            print(f"\nHostgroup Verification Results:\n")
            print(f"Total groups: {len(groups)}")
            print(f"Found: {len(found)}")

            if missing:
                print(f"Missing: {len(missing)}")
                for group in missing:
                    print(f"  [ERROR] {group}")
                return 1
            else:
                print("[OK] All groups found")
                return 0

        elif args.command == "check-conflicts":
            start_dt = datetime.strptime(args.start, "%Y-%m-%d %H:%M")
            start_ts = int(start_dt.timestamp())
            end_ts = start_ts + (args.duration * 60)

            hosts = args.hosts.split(",") if args.hosts else None
            groups = args.hostgroups.split(",") if args.hostgroups else None

            conflicts = validator.check_schedule_conflicts(
                start_ts, end_ts, hosts, groups
            )

            print(f"\nConflict Check Results:\n")
            print(f"Proposed: {args.start} for {args.duration} minutes")

            if conflicts:
                print(f"\n[WARN] Found {len(conflicts)} conflicting maintenance(s):\n")
                for m in conflicts:
                    print(f"  - {m['name']} (ID: {m['maintenanceid']})")
                    print(f"    Period: {datetime.fromtimestamp(int(m['active_since'])).strftime('%Y-%m-%d %H:%M')} - "
                          f"{datetime.fromtimestamp(int(m['active_till'])).strftime('%Y-%m-%d %H:%M')}")
                return 1
            else:
                print("[OK] No conflicts found")
                return 0

    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
