#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Maintenance Manager - Core CRUD operations for maintenance windows

This script provides comprehensive maintenance period management including:
- Create one-time and recurring maintenance periods
- Update existing maintenance configurations
- Delete maintenance periods
- Query and list maintenance windows
- Bulk operations for multiple maintenances

Usage:
    python zabbix_maintenance_manager.py create --name "Server Maintenance" --start "2025-12-01 02:00" --duration 120 --hosts "host1,host2"
    python zabbix_maintenance_manager.py list --filter "name:Weekly"
    python zabbix_maintenance_manager.py update --id 123 --duration 180
    python zabbix_maintenance_manager.py delete --id 123
    python zabbix_maintenance_manager.py bulk-create --input maintenances.yaml

Author: Zabbix Skills Automation
Version: 1.0
"""

import argparse
import json
import sys
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Union, Any
import requests
from pathlib import Path
import yaml


class ZabbixMaintenanceManager:
    """Manages Zabbix maintenance windows via API"""

    def __init__(self, url: str, token: str, verify_ssl: bool = True):
        """
        Initialize Zabbix maintenance manager

        Args:
            url: Zabbix API URL (e.g., https://zabbix.example.com/api_jsonrpc.php)
            token: Zabbix API authentication token
            verify_ssl: Verify SSL certificates (default: True)
        """
        self.url = url
        self.token = token
        self.verify_ssl = verify_ssl
        self.request_id = 1

    def _call_api(self, method: str, params: Dict = None) -> Dict:
        """
        Call Zabbix API method

        Args:
            method: Zabbix API method name
            params: Method parameters

        Returns:
            API response result

        Raises:
            Exception: If API call fails
        """
        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params or {},
            "id": self.request_id,
            "auth": self.token
        }

        try:
            response = requests.post(
                self.url,
                json=payload,
                headers={"Content-Type": "application/json"},
                verify=self.verify_ssl,
                timeout=30
            )
            response.raise_for_status()

            result = response.json()
            self.request_id += 1

            if "error" in result:
                raise Exception(f"API Error: {result['error']['message']} (Code: {result['error']['code']})")

            return result.get("result", {})

        except requests.exceptions.RequestException as e:
            raise Exception(f"HTTP request failed: {str(e)}")
        except json.JSONDecodeError as e:
            raise Exception(f"Invalid JSON response: {str(e)}")

    def create_maintenance(
        self,
        name: str,
        active_since: int,
        active_till: int,
        maintenance_type: int = 0,
        hosts: List[str] = None,
        hostgroups: List[str] = None,
        timeperiods: List[Dict] = None,
        tags: List[Dict] = None,
        tags_evaltype: int = 0,
        description: str = ""
    ) -> str:
        """
        Create new maintenance period

        Args:
            name: Maintenance name
            active_since: Start timestamp (will be rounded down to minutes)
            active_till: End timestamp (will be rounded down to minutes)
            maintenance_type: 0=with data collection, 1=without data collection
            hosts: List of host names or IDs
            hostgroups: List of hostgroup names or IDs
            timeperiods: List of time period objects (default: one-time for full duration)
            tags: List of problem tags for selective suppression
            tags_evaltype: 0=And/Or, 2=Or
            description: Maintenance description

        Returns:
            Created maintenance ID

        Raises:
            Exception: If creation fails or validation errors
        """
        # Validate parameters
        if not name:
            raise ValueError("Maintenance name is required")

        if not hosts and not hostgroups:
            raise ValueError("At least one host or hostgroup must be specified")

        if active_since >= active_till:
            raise ValueError("active_since must be before active_till")

        if maintenance_type not in [0, 1]:
            raise ValueError("maintenance_type must be 0 (with data) or 1 (no data)")

        if tags and maintenance_type != 0:
            raise ValueError("Tags can only be specified with maintenance_type=0 (with data collection)")

        # Build maintenance object
        maintenance = {
            "name": name,
            "active_since": active_since,
            "active_till": active_till,
            "maintenance_type": maintenance_type,
            "description": description,
            "tags_evaltype": tags_evaltype
        }

        # Resolve hosts
        if hosts:
            host_objects = []
            for host in hosts:
                if isinstance(host, str) and not host.isdigit():
                    # Resolve host name to ID
                    host_result = self._call_api("host.get", {
                        "filter": {"host": host},
                        "output": ["hostid"]
                    })
                    if not host_result:
                        raise ValueError(f"Host not found: {host}")
                    host_objects.append({"hostid": host_result[0]["hostid"]})
                else:
                    host_objects.append({"hostid": str(host)})
            maintenance["hosts"] = host_objects

        # Resolve hostgroups
        if hostgroups:
            group_objects = []
            for group in hostgroups:
                if isinstance(group, str) and not group.isdigit():
                    # Resolve group name to ID
                    group_result = self._call_api("hostgroup.get", {
                        "filter": {"name": group},
                        "output": ["groupid"]
                    })
                    if not group_result:
                        raise ValueError(f"Hostgroup not found: {group}")
                    group_objects.append({"groupid": group_result[0]["groupid"]})
                else:
                    group_objects.append({"groupid": str(group)})
            maintenance["groups"] = group_objects

        # Set time periods (default to one-time full duration)
        if not timeperiods:
            timeperiods = [{
                "timeperiod_type": 0,  # One time only
                "start_date": active_since,
                "period": active_till - active_since
            }]
        maintenance["timeperiods"] = timeperiods

        # Add tags if specified
        if tags:
            maintenance["tags"] = tags

        # Create maintenance
        result = self._call_api("maintenance.create", maintenance)

        maintenance_id = result["maintenanceids"][0]
        print(f"[OK] Created maintenance: {name} (ID: {maintenance_id})")

        return maintenance_id

    def get_maintenance(
        self,
        maintenance_ids: List[str] = None,
        hostids: List[str] = None,
        groupids: List[str] = None,
        name_filter: str = None
    ) -> List[Dict]:
        """
        Retrieve maintenance periods

        Args:
            maintenance_ids: Filter by maintenance IDs
            hostids: Filter by host IDs
            groupids: Filter by hostgroup IDs
            name_filter: Filter by name (substring match)

        Returns:
            List of maintenance objects
        """
        params = {
            "output": "extend",
            "selectHostGroups": "extend",
            "selectHosts": "extend",
            "selectTimeperiods": "extend",
            "selectTags": "extend"
        }

        if maintenance_ids:
            params["maintenanceids"] = maintenance_ids

        if hostids:
            params["hostids"] = hostids

        if groupids:
            params["groupids"] = groupids

        if name_filter:
            params["search"] = {"name": name_filter}
            params["searchWildcardsEnabled"] = True

        return self._call_api("maintenance.get", params)

    def update_maintenance(
        self,
        maintenance_id: str,
        name: str = None,
        active_since: int = None,
        active_till: int = None,
        maintenance_type: int = None,
        hosts: List[str] = None,
        hostgroups: List[str] = None,
        timeperiods: List[Dict] = None,
        tags: List[Dict] = None,
        tags_evaltype: int = None,
        description: str = None
    ) -> bool:
        """
        Update existing maintenance period

        Args:
            maintenance_id: ID of maintenance to update
            name: New name (optional)
            active_since: New start timestamp (optional)
            active_till: New end timestamp (optional)
            maintenance_type: New type (optional)
            hosts: New host list (optional)
            hostgroups: New hostgroup list (optional)
            timeperiods: New time periods (optional)
            tags: New tags (optional)
            tags_evaltype: New tags evaltype (optional)
            description: New description (optional)

        Returns:
            True if update successful
        """
        update_data = {"maintenanceid": maintenance_id}

        if name is not None:
            update_data["name"] = name

        if active_since is not None:
            update_data["active_since"] = active_since

        if active_till is not None:
            update_data["active_till"] = active_till

        if maintenance_type is not None:
            if maintenance_type not in [0, 1]:
                raise ValueError("maintenance_type must be 0 or 1")
            update_data["maintenance_type"] = maintenance_type

        if description is not None:
            update_data["description"] = description

        if tags_evaltype is not None:
            update_data["tags_evaltype"] = tags_evaltype

        # Resolve hosts if provided
        if hosts is not None:
            host_objects = []
            for host in hosts:
                if isinstance(host, str) and not host.isdigit():
                    host_result = self._call_api("host.get", {
                        "filter": {"host": host},
                        "output": ["hostid"]
                    })
                    if not host_result:
                        raise ValueError(f"Host not found: {host}")
                    host_objects.append({"hostid": host_result[0]["hostid"]})
                else:
                    host_objects.append({"hostid": str(host)})
            update_data["hosts"] = host_objects

        # Resolve hostgroups if provided
        if hostgroups is not None:
            group_objects = []
            for group in hostgroups:
                if isinstance(group, str) and not group.isdigit():
                    group_result = self._call_api("hostgroup.get", {
                        "filter": {"name": group},
                        "output": ["groupid"]
                    })
                    if not group_result:
                        raise ValueError(f"Hostgroup not found: {group}")
                    group_objects.append({"groupid": group_result[0]["groupid"]})
                else:
                    group_objects.append({"groupid": str(group)})
            update_data["groups"] = group_objects

        if timeperiods is not None:
            update_data["timeperiods"] = timeperiods

        if tags is not None:
            update_data["tags"] = tags

        result = self._call_api("maintenance.update", update_data)

        print(f"[OK] Updated maintenance ID: {maintenance_id}")
        return True

    def delete_maintenance(self, maintenance_ids: List[str]) -> bool:
        """
        Delete maintenance periods

        Args:
            maintenance_ids: List of maintenance IDs to delete

        Returns:
            True if deletion successful
        """
        if not maintenance_ids:
            raise ValueError("At least one maintenance ID required")

        result = self._call_api("maintenance.delete", maintenance_ids)

        print(f"[OK] Deleted {len(maintenance_ids)} maintenance(s)")
        return True

    def is_host_in_maintenance(self, hostname: str) -> Dict[str, Any]:
        """
        Check if host is currently in maintenance

        Args:
            hostname: Host name to check

        Returns:
            Dict with maintenance status and details
        """
        # Get host
        host_result = self._call_api("host.get", {
            "filter": {"host": hostname},
            "output": ["hostid", "maintenance_status", "maintenance_from", "maintenance_type"]
        })

        if not host_result:
            return {"in_maintenance": False, "error": f"Host not found: {hostname}"}

        host = host_result[0]
        in_maintenance = host.get("maintenance_status") == "1"

        result = {
            "in_maintenance": in_maintenance,
            "hostid": host["hostid"]
        }

        if in_maintenance:
            result["maintenance_from"] = host.get("maintenance_from")
            result["maintenance_type"] = "no data" if host.get("maintenance_type") == "1" else "with data"

            # Get active maintenance details
            maintenances = self.get_maintenance(hostids=[host["hostid"]])
            active_maintenances = [
                m for m in maintenances
                if int(m["active_since"]) <= datetime.now().timestamp() <= int(m["active_till"])
            ]
            result["active_maintenances"] = active_maintenances

        return result

    def bulk_create_from_file(self, filepath: str, validate_only: bool = False) -> List[str]:
        """
        Create multiple maintenances from YAML or JSON file

        Args:
            filepath: Path to configuration file
            validate_only: Only validate without creating

        Returns:
            List of created maintenance IDs
        """
        path = Path(filepath)

        if not path.exists():
            raise FileNotFoundError(f"File not found: {filepath}")

        # Load configuration
        with open(path, 'r') as f:
            if path.suffix in ['.yaml', '.yml']:
                config = yaml.safe_load(f)
            elif path.suffix == '.json':
                config = json.load(f)
            else:
                raise ValueError("File must be YAML or JSON")

        maintenances = config.get("maintenances", [])

        if not maintenances:
            raise ValueError("No maintenances defined in file")

        print(f"Processing {len(maintenances)} maintenance(s) from {filepath}")

        created_ids = []

        for idx, maint in enumerate(maintenances, 1):
            print(f"\n[{idx}/{len(maintenances)}] {maint.get('name', 'Unnamed')}")

            try:
                # Parse timestamps if strings
                if isinstance(maint.get("active_since"), str):
                    maint["active_since"] = int(datetime.strptime(
                        maint["active_since"], "%Y-%m-%d %H:%M"
                    ).timestamp())

                if isinstance(maint.get("active_till"), str):
                    maint["active_till"] = int(datetime.strptime(
                        maint["active_till"], "%Y-%m-%d %H:%M"
                    ).timestamp())

                if validate_only:
                    print("  [OK] Validation passed")
                else:
                    maintenance_id = self.create_maintenance(**maint)
                    created_ids.append(maintenance_id)

            except Exception as e:
                print(f"  [ERROR] Error: {str(e)}")
                if not validate_only:
                    raise

        return created_ids

    def cleanup_expired(self, days_old: int = 90, dry_run: bool = False) -> List[str]:
        """
        Delete expired maintenance periods

        Args:
            days_old: Delete maintenances expired for more than N days
            dry_run: Only show what would be deleted

        Returns:
            List of deleted maintenance IDs
        """
        cutoff_timestamp = int((datetime.now() - timedelta(days=days_old)).timestamp())

        # Get all maintenances
        all_maintenances = self.get_maintenance()

        expired = [
            m for m in all_maintenances
            if int(m["active_till"]) < cutoff_timestamp
        ]

        if not expired:
            print(f"No expired maintenances older than {days_old} days found")
            return []

        print(f"Found {len(expired)} expired maintenance(s) older than {days_old} days:")

        for m in expired:
            expired_date = datetime.fromtimestamp(int(m["active_till"])).strftime("%Y-%m-%d %H:%M")
            print(f"  - {m['name']} (ID: {m['maintenanceid']}, expired: {expired_date})")

        if dry_run:
            print("\nDry run - no deletions performed")
            return []

        # Delete expired maintenances
        ids_to_delete = [m["maintenanceid"] for m in expired]
        self.delete_maintenance(ids_to_delete)

        return ids_to_delete


def parse_datetime(dt_string: str) -> int:
    """Parse datetime string to timestamp"""
    try:
        dt = datetime.strptime(dt_string, "%Y-%m-%d %H:%M")
        return int(dt.timestamp())
    except ValueError as e:
        raise ValueError(f"Invalid datetime format. Use 'YYYY-MM-DD HH:MM': {str(e)}")


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="Zabbix Maintenance Manager - Manage maintenance windows",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    # Global arguments
    parser.add_argument("--url", default=os.getenv("ZABBIX_URL"),
                       help="Zabbix API URL (or ZABBIX_URL env)")
    parser.add_argument("--token", default=os.getenv("ZABBIX_TOKEN"),
                       help="Zabbix API token (or ZABBIX_TOKEN env)")
    parser.add_argument("--no-verify-ssl", action="store_true",
                       help="Disable SSL certificate verification")

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Create command
    create_parser = subparsers.add_parser("create", help="Create maintenance")
    create_parser.add_argument("--name", required=True, help="Maintenance name")
    create_parser.add_argument("--start", required=True, help="Start time (YYYY-MM-DD HH:MM)")
    create_parser.add_argument("--duration", type=int, required=True, help="Duration in minutes")
    create_parser.add_argument("--hosts", help="Comma-separated host names or IDs")
    create_parser.add_argument("--hostgroups", help="Comma-separated hostgroup names or IDs")
    create_parser.add_argument("--type", choices=["with-data", "no-data"], default="with-data",
                              help="Maintenance type")
    create_parser.add_argument("--description", default="", help="Maintenance description")
    create_parser.add_argument("--tags", help="JSON array of tag objects")
    create_parser.add_argument("--tags-evaltype", choices=["and-or", "or"], default="and-or",
                              help="Tag evaluation type")

    # List command
    list_parser = subparsers.add_parser("list", help="List maintenances")
    list_parser.add_argument("--filter", help="Filter by name (substring match)")
    list_parser.add_argument("--ids", help="Comma-separated maintenance IDs")
    list_parser.add_argument("--format", choices=["table", "json", "yaml"], default="table",
                            help="Output format")

    # Update command
    update_parser = subparsers.add_parser("update", help="Update maintenance")
    update_parser.add_argument("--id", required=True, help="Maintenance ID")
    update_parser.add_argument("--name", help="New name")
    update_parser.add_argument("--duration", type=int, help="New duration in minutes")
    update_parser.add_argument("--description", help="New description")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete maintenance")
    delete_parser.add_argument("--id", "--ids", required=True, help="Comma-separated maintenance IDs")
    delete_parser.add_argument("--confirm", action="store_true", help="Skip confirmation")

    # Check command
    check_parser = subparsers.add_parser("check", help="Check if host in maintenance")
    check_parser.add_argument("--host", required=True, help="Host name")

    # Bulk create command
    bulk_parser = subparsers.add_parser("bulk-create", help="Bulk create from file")
    bulk_parser.add_argument("--input", required=True, help="YAML or JSON input file")
    bulk_parser.add_argument("--validate-only", action="store_true", help="Only validate")

    # Cleanup command
    cleanup_parser = subparsers.add_parser("cleanup", help="Clean up expired maintenances")
    cleanup_parser.add_argument("--days", type=int, default=90, help="Delete expired for N days")
    cleanup_parser.add_argument("--dry-run", action="store_true", help="Dry run only")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    # Validate credentials
    if not args.url or not args.token:
        print("Error: Zabbix URL and token required (--url, --token or env vars)")
        return 1

    # Initialize manager
    manager = ZabbixMaintenanceManager(
        args.url,
        args.token,
        verify_ssl=not args.no_verify_ssl
    )

    try:
        if args.command == "create":
            start_ts = parse_datetime(args.start)
            end_ts = start_ts + (args.duration * 60)

            hosts = args.hosts.split(",") if args.hosts else None
            hostgroups = args.hostgroups.split(",") if args.hostgroups else None

            maintenance_type = 0 if args.type == "with-data" else 1
            tags_evaltype = 0 if args.tags_evaltype == "and-or" else 2

            tags = None
            if args.tags:
                tags = json.loads(args.tags)

            maintenance_id = manager.create_maintenance(
                name=args.name,
                active_since=start_ts,
                active_till=end_ts,
                maintenance_type=maintenance_type,
                hosts=hosts,
                hostgroups=hostgroups,
                tags=tags,
                tags_evaltype=tags_evaltype,
                description=args.description
            )

            print(f"\nMaintenance ID: {maintenance_id}")

        elif args.command == "list":
            ids = args.ids.split(",") if args.ids else None
            maintenances = manager.get_maintenance(
                maintenance_ids=ids,
                name_filter=args.filter
            )

            if args.format == "json":
                print(json.dumps(maintenances, indent=2))
            elif args.format == "yaml":
                print(yaml.dump(maintenances, default_flow_style=False))
            else:
                # Table format
                print(f"\nFound {len(maintenances)} maintenance(s):\n")
                for m in maintenances:
                    print(f"ID: {m['maintenanceid']}")
                    print(f"  Name: {m['name']}")
                    print(f"  Type: {'No data' if m['maintenance_type'] == '1' else 'With data'}")
                    print(f"  Active: {datetime.fromtimestamp(int(m['active_since'])).strftime('%Y-%m-%d %H:%M')} - "
                          f"{datetime.fromtimestamp(int(m['active_till'])).strftime('%Y-%m-%d %H:%M')}")
                    print(f"  Hosts: {len(m.get('hosts', []))}, Groups: {len(m.get('hostgroups', []))}")
                    print()

        elif args.command == "update":
            kwargs = {"maintenance_id": args.id}

            if args.name:
                kwargs["name"] = args.name
            if args.duration:
                # Get current maintenance to calculate new end time
                current = manager.get_maintenance(maintenance_ids=[args.id])[0]
                start_ts = int(current["active_since"])
                kwargs["active_till"] = start_ts + (args.duration * 60)
            if args.description:
                kwargs["description"] = args.description

            manager.update_maintenance(**kwargs)

        elif args.command == "delete":
            ids = args.id.split(",")

            if not args.confirm:
                response = input(f"Delete {len(ids)} maintenance(s)? [y/N]: ")
                if response.lower() != 'y':
                    print("Cancelled")
                    return 0

            manager.delete_maintenance(ids)

        elif args.command == "check":
            result = manager.is_host_in_maintenance(args.host)

            print(f"\nHost: {args.host}")
            print(f"In maintenance: {result['in_maintenance']}")

            if result['in_maintenance']:
                print(f"Type: {result['maintenance_type']}")
                print(f"Since: {datetime.fromtimestamp(int(result['maintenance_from'])).strftime('%Y-%m-%d %H:%M')}")
                print(f"\nActive maintenances:")
                for m in result.get('active_maintenances', []):
                    print(f"  - {m['name']} (ID: {m['maintenanceid']})")

        elif args.command == "bulk-create":
            manager.bulk_create_from_file(args.input, validate_only=args.validate_only)

        elif args.command == "cleanup":
            manager.cleanup_expired(days_old=args.days, dry_run=args.dry_run)

        return 0

    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
