# Managing Items & Data Collection in Zabbix

Complete Agent Skill for automating Zabbix item management through the API.

## Quick Start

### Prerequisites

1. **Python 3.7+** with required packages:
   ```bash
   pip install requests pyyaml
   ```

2. **Zabbix API Access**:
   - Zabbix server URL
   - Valid API authentication token

3. **Environment Variables** (recommended):
   ```bash
   export ZABBIX_URL="https://zabbix.example.com"
   export ZABBIX_TOKEN="your_api_token_here"
   ```

### Installation

1. Clone or copy this skill directory
2. Install Python dependencies
3. Configure environment variables
4. Test connection with a simple query

### Basic Usage

#### Create Items from Configuration

```bash
# Create a single item
python scripts/zabbix_item_manager.py create --config examples/agent_items.json

# Create multiple items
python scripts/zabbix_item_manager.py bulk-create --config examples/bulk_items.yaml
```

#### Validate Before Creating

Always validate configurations first:

```bash
# Validate configuration file
python scripts/validate_item_config.py examples/agent_items.json

# Validate with verbose output
python scripts/validate_item_config.py examples/snmp_items.json --verbose
```

#### Update Item Properties

```bash
# Update polling interval
python scripts/zabbix_item_manager.py update --item-id 12345 --delay 30s

# Update history retention
python scripts/zabbix_item_manager.py update --item-id 12345 --history 14d --trends 730d

# Update item name
python scripts/zabbix_item_manager.py update --item-id 12345 --name "New Item Name"
```

#### Copy Items Between Hosts

```bash
# Copy all items from source to target host
python scripts/zabbix_item_manager.py copy --source-host 10084 --target-host 10085
```

#### Enable/Disable Items

```bash
# Disable item
python scripts/zabbix_item_manager.py disable --item-id 12345

# Enable item
python scripts/zabbix_item_manager.py enable --item-id 12345
```

#### Delete Items

```bash
# Delete with confirmation prompt
python scripts/zabbix_item_manager.py delete --item-id 12345

# Delete without confirmation
python scripts/zabbix_item_manager.py delete --item-id 12345 --force
```

## Directory Structure

```
managing-items-data-collection/
├── SKILL.md                          # Complete skill documentation
├── README.md                         # This file - quick start guide
├── scripts/
│   ├── zabbix_item_manager.py       # Main item management script
│   └── validate_item_config.py      # Configuration validation script
└── examples/
    ├── agent_items.json              # Zabbix agent monitoring items
    ├── snmp_items.json               # SNMP network device items
    ├── calculated_items.yaml         # Calculated item examples
    ├── preprocessing_examples.json   # All preprocessing types
    └── bulk_items.yaml               # Bulk item configuration
```

## Configuration File Format

### JSON Format

```json
{
  "hostid": "10084",
  "name": "CPU Load Average",
  "key_": "system.cpu.load[percpu,avg5]",
  "type": 0,
  "value_type": 0,
  "interfaceid": "30050",
  "delay": "60s",
  "history": "7d",
  "trends": "365d",
  "units": "",
  "description": "5-minute average CPU load",
  "tags": [
    {"tag": "component", "value": "cpu"}
  ],
  "preprocessing": [
    {
      "type": 1,
      "params": "8",
      "error_handler": 0,
      "error_handler_params": ""
    }
  ]
}
```

### YAML Format

```yaml
hostid: "10084"
name: "CPU Load Average"
key_: "system.cpu.load[percpu,avg5]"
type: 0  # Zabbix agent
value_type: 0  # Numeric (float)
interfaceid: "30050"
delay: "60s"
history: "7d"
trends: "365d"
description: "5-minute average CPU load"
tags:
  - tag: "component"
    value: "cpu"
preprocessing:
  - type: 1  # Multiplier
    params: "8"
    error_handler: 0
    error_handler_params: ""
```

## Common Item Types

| Type | ID | Description | Use Case |
|------|-----|-------------|----------|
| Zabbix agent | 0 | Passive agent checks | Standard monitoring |
| Zabbix agent (active) | 7 | Active agent checks | Large deployments |
| SNMP | 4 | SNMPv2 checks | Network devices |
| Simple check | 3 | TCP/ICMP checks | Service availability |
| Calculated | 15 | Formula-based | Derived metrics |
| Dependent | 18 | Extract from master | Parse API responses |
| HTTP agent | 19 | REST API calls | Web APIs |
| Database monitor | 11 | ODBC queries | Database metrics |

## Common Value Types

| Type | ID | Description | Storage |
|------|-----|-------------|---------|
| Numeric (float) | 0 | Floating point | Supports trends |
| Character | 1 | Short text (255 chars) | No trends |
| Log | 2 | Log data with metadata | No trends |
| Numeric (unsigned) | 3 | Unsigned integer | Supports trends |
| Text | 4 | Long text | No trends |

## Preprocessing Types Reference

| Type | ID | Parameters | Use Case |
|------|-----|-----------|----------|
| Custom multiplier | 1 | Multiplier value | Unit conversion |
| Simple change | 2 | None | Delta between values |
| Regular expression | 5 | Pattern, output | Extract from text |
| Trim | 6 | Characters | Remove whitespace |
| XML XPath | 10 | XPath query | Extract from XML |
| JSONPath | 12 | JSONPath query | Extract from JSON |
| Boolean to decimal | 13 | None | Convert boolean |
| Hex to decimal | 15 | None | Convert hexadecimal |
| Discard unchanged | 19 | None | Reduce storage |
| Discard with heartbeat | 20 | Seconds | Throttle updates |
| Change per second | 10 | None | Calculate rate |

## Examples

### Example 1: Monitor CPU Load

```bash
# Validate configuration
python scripts/validate_item_config.py examples/agent_items.json

# Create items
python scripts/zabbix_item_manager.py bulk-create --config examples/agent_items.json
```

### Example 2: Monitor SNMP Devices

```bash
# Validate SNMP items
python scripts/validate_item_config.py examples/snmp_items.json --type snmp

# Create SNMP items
python scripts/zabbix_item_manager.py bulk-create --config examples/snmp_items.json
```

### Example 3: Create Calculated Items

```bash
# Validate calculated items
python scripts/validate_item_config.py examples/calculated_items.yaml --type calculated

# Create calculated items
python scripts/zabbix_item_manager.py bulk-create --config examples/calculated_items.yaml
```

### Example 4: Bulk Update History Settings

Create a Python script for bulk updates:

```python
from scripts.zabbix_item_manager import ZabbixItemManager

manager = ZabbixItemManager(
    url="https://zabbix.example.com",
    token="your_token"
)

# Get all items for a host
items = manager.get_items(hostids="10084")

# Update history for all items
for item in items:
    manager.update_item(
        item['itemid'],
        history="14d",
        trends="730d"
    )
```

## Best Practices

### 1. Always Validate First

```bash
# Validate before creating
python scripts/validate_item_config.py config.json

# Only create if validation passes
if [ $? -eq 0 ]; then
    python scripts/zabbix_item_manager.py create --config config.json
fi
```

### 2. Use Version Control

Store your item configurations in Git to track changes:

```bash
git add examples/production_items.yaml
git commit -m "Add production monitoring items"
git push
```

### 3. Test in Development First

Always test new items in a development environment before production:

```bash
# Development
ZABBIX_URL="https://dev-zabbix.example.com" \
ZABBIX_TOKEN="dev_token" \
python scripts/zabbix_item_manager.py create --config items.json

# Production (after testing)
ZABBIX_URL="https://zabbix.example.com" \
ZABBIX_TOKEN="prod_token" \
python scripts/zabbix_item_manager.py create --config items.json
```

### 4. Monitor Item Performance

Regularly review:
- Unsupported items
- Items with long collection times
- Preprocessing errors
- Database growth

### 5. Optimize Storage

- Set appropriate history retention
- Use trends for long-term data
- Enable "Discard unchanged" for static values
- Use dependent items to reduce API calls

## Troubleshooting

### Issue: API Authentication Failed

**Solution**: Verify your API token:

```bash
# Test API connection
curl -X POST https://zabbix.example.com/api_jsonrpc.php \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "apiinfo.version",
    "params": {},
    "id": 1
  }'
```

### Issue: Item Becomes Unsupported

**Causes**:
- Invalid item key
- Agent/host unreachable
- Preprocessing failure
- Permission issues

**Solution**: Check item error in Zabbix UI and logs.

### Issue: Validation Errors

**Solution**: Review validation output carefully:

```bash
python scripts/validate_item_config.py config.json --verbose
```

Fix all ERROR level issues before creating items.

### Issue: Preprocessing Not Working

**Solution**: Test preprocessing steps individually using Zabbix UI item testing feature.

## Additional Resources

- **Full Documentation**: See [SKILL.md](SKILL.md) for complete skill documentation
- **Zabbix Documentation**: `/zabbix-docs-masters/zabbix-docs/07_Configuration/`
- **API Reference**: Zabbix API documentation for item methods
- **Examples**: Browse `examples/` directory for templates

## Support

For issues or questions:
1. Check [SKILL.md](SKILL.md) for detailed documentation
2. Review Zabbix documentation
3. Validate configurations before creating items
4. Check Zabbix server logs for errors

## Version

- **Skill Version**: 1.0.0
- **Compatible with**: Zabbix 6.0+
- **Python**: 3.7+

## License

This skill is provided as-is for Zabbix monitoring automation.
