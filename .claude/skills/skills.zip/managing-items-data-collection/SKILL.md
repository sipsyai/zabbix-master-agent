---
name: Managing Items & Data Collection in Zabbix
description: Automates Zabbix item management including creating, updating, and deleting items of all types (Zabbix agent, SNMP, calculated, dependent, HTTP, etc.), configuring preprocessing steps (JSON, regex, JavaScript, arithmetic), managing history and trends, and implementing data collection strategies through the Zabbix API. Use when setting up monitoring for new metrics, standardizing data collection across hosts, implementing custom monitoring solutions, migrating configurations, or performance tuning monitoring intervals.
version: 1.0.0
author: Zabbix Skills Team
tags: [zabbix, items, monitoring, data-collection, preprocessing, api]
---

# Managing Items & Data Collection in Zabbix

## Quick Start

Items are the foundation of Zabbix monitoring - they define what data to collect from hosts. This skill helps you create, update, and manage items programmatically using the Zabbix API.

### Basic Item Creation

```python
from scripts.zabbix_item_manager import ZabbixItemManager

# Initialize manager
manager = ZabbixItemManager(
    url="https://zabbix.example.com",
    token="your_api_token"
)

# Create a simple Zabbix agent item
item = manager.create_item(
    hostid="10084",
    name="CPU Load Average",
    key="system.cpu.load[percpu,avg5]",
    type=0,  # Zabbix agent
    value_type=0,  # Numeric (float)
    delay="60s",
    history="7d",
    trends="365d"
)
```

### Common Item Types

- **Zabbix agent (type=0)**: Monitor via Zabbix agent (passive)
- **SNMP agent (type=4)**: Monitor SNMP-enabled devices
- **Simple check (type=3)**: TCP/ICMP checks, service availability
- **Calculated (type=15)**: Calculate based on other items
- **Dependent (type=18)**: Extract from master item
- **HTTP agent (type=19)**: Query web APIs and services

## Core Concepts

### Item Types

Zabbix supports 15+ item types for different data collection methods:

1. **Zabbix agent** (0/7): Active and passive agent checks
2. **SNMP** (4): v1/v2c/v3 network device monitoring
3. **Simple checks** (3): Basic connectivity and service checks
4. **Internal** (5): Zabbix server/proxy internal metrics
5. **Calculated** (15): Formula-based derived metrics
6. **Dependent** (18): Parse data from master items
7. **HTTP agent** (19): REST APIs and web monitoring
8. **Database monitor** (11): ODBC database queries
9. **SSH/Telnet** (13/14): Remote command execution
10. **External** (10): Custom external scripts
11. **JMX** (16): Java application monitoring
12. **IPMI** (12): Hardware sensor monitoring
13. **Browser** (22): Browser-based synthetic monitoring

See [examples/agent_items.json](examples/agent_items.json) for Zabbix agent examples.

### Value Types

Items store data in specific formats:

- **Numeric (unsigned)** (0): 64-bit unsigned integers
- **Numeric (float)** (0): Floating-point numbers
- **Character** (1): Short text (255 chars)
- **Log** (2): Log files with metadata
- **Text** (4): Long text data

### Key Parameters

**Update Interval**: How often to collect data
```yaml
delay: "60s"  # Every minute
delay: "5m"   # Every 5 minutes
delay: "1h"   # Every hour
```

**History Storage**: Detailed historical data
```yaml
history: "7d"    # Keep 7 days
history: "30d"   # Keep 30 days
history: "90d"   # Keep 90 days
```

**Trends Storage**: Aggregated hourly data (numeric only)
```yaml
trends: "365d"   # Keep 1 year
trends: "730d"   # Keep 2 years
```

## Using the Scripts

### Item Manager Script

The main script provides comprehensive item management:

```bash
# Create items from configuration file
python scripts/zabbix_item_manager.py create --config examples/agent_items.json

# Update item properties
python scripts/zabbix_item_manager.py update --item-id 12345 --delay 30s --history 14d

# Delete items with confirmation
python scripts/zabbix_item_manager.py delete --item-id 12345

# Bulk operations
python scripts/zabbix_item_manager.py bulk-create --config examples/bulk_items.yaml

# Copy items between hosts
python scripts/zabbix_item_manager.py copy --source-host 10084 --target-host 10085

# Enable/disable items
python scripts/zabbix_item_manager.py disable --item-id 12345
```

### Validation Script

Always validate configurations before applying:

```bash
# Validate item configuration
python scripts/validate_item_config.py examples/agent_items.json

# Validate with detailed output
python scripts/validate_item_config.py examples/snmp_items.json --verbose

# Check specific item type
python scripts/validate_item_config.py config.yaml --type calculated
```

## Item Preprocessing

Preprocessing transforms data before storage. Configure preprocessing steps to:

- Extract values from JSON/XML
- Apply regular expressions
- Execute JavaScript transformations
- Convert units and formats
- Throttle unchanged values
- Calculate changes and deltas

### Common Preprocessing Steps

**JSONPath Extraction**
```json
{
  "type": 12,
  "params": "$.data.cpu_usage",
  "error_handler": 0
}
```

**Regular Expression**
```json
{
  "type": 5,
  "params": "Temperature: ([0-9.]+)C\n\\1",
  "error_handler": 0
}
```

**JavaScript Transformation**
```json
{
  "type": 1,
  "params": "return JSON.parse(value).result * 100;",
  "error_handler": 0
}
```

**Custom Multiplier**
```json
{
  "type": 1,
  "params": "8",
  "error_handler": 0
}
```

See [examples/preprocessing_examples.json](examples/preprocessing_examples.json) for complete examples.

## Advanced Features

### Calculated Items

Create items that derive values from other items:

```python
manager.create_item(
    hostid="10084",
    name="Total Network Traffic",
    key="net.total",
    type=15,  # Calculated
    value_type=0,
    params="last(//net.if.in[eth0]) + last(//net.if.out[eth0])",
    delay="60s"
)
```

### Dependent Items

Extract multiple metrics from a single master item:

```python
# Master item gets JSON data
master = manager.create_item(
    hostid="10084",
    name="System Info (Master)",
    key="system.info",
    type=19,  # HTTP agent
    url="http://api.example.com/metrics"
)

# Dependent item extracts CPU from JSON
dependent = manager.create_item(
    hostid="10084",
    name="CPU Usage",
    key="system.cpu.extract",
    type=18,  # Dependent
    master_itemid=master["itemids"][0],
    preprocessing=[
        {"type": 12, "params": "$.cpu.usage"}
    ]
)
```

### Custom Intervals

Configure flexible and scheduled intervals:

```python
# Flexible: different frequency during specific times
manager.create_item(
    hostid="10084",
    name="Monitored Service",
    key="service.check",
    type=3,
    delay="5m",  # Default: every 5 minutes
    custom_intervals=[
        # Every 1 minute during business hours (9-17)
        "m0-6,09-17:1m"
    ]
)
```

### SNMP Monitoring

Monitor network devices via SNMP:

```python
manager.create_item(
    hostid="10084",
    name="Interface eth0 Inbound Traffic",
    key="snmp.if.in[eth0]",
    type=4,  # SNMPv2 agent
    snmp_oid="1.3.6.1.2.1.2.2.1.10.1",
    delay="60s",
    preprocessing=[
        {"type": 10, "params": "8"}  # Multiply by 8 for bits
    ]
)
```

See [examples/snmp_items.json](examples/snmp_items.json) for SNMP examples.

## Best Practices

### Performance Optimization

1. **Set appropriate intervals**: Don't poll more frequently than needed
   - Metrics that change slowly: 5-15 minutes
   - Important metrics: 1-5 minutes
   - Critical real-time metrics: 30-60 seconds

2. **Optimize history retention**: Balance detail vs. storage
   - High-frequency items: 7-14 days history
   - Low-frequency items: 30-90 days history
   - Always keep trends longer than history

3. **Use dependent items**: Reduce API calls by parsing master item data
   - One HTTP call → multiple dependent items
   - One SNMP walk → multiple extracted values

4. **Throttle unchanged values**: Use "Discard unchanged" preprocessing
   - Reduces database writes
   - Saves storage space
   - Best for infrequently changing metrics

### Item Key Naming

Follow consistent naming conventions:

```
# Good examples
system.cpu.load[percpu,avg5]
net.if.in[eth0]
vfs.fs.size[/,used]
web.page.perf[https://example.com]

# Include context
mysql.queries.slow[production]
apache.requests[website1]
disk.io.read[sda]
```

### Error Handling

Always configure preprocessing error handlers:

```python
preprocessing = [
    {
        "type": 12,  # JSONPath
        "params": "$.data.value",
        "error_handler": 2,  # Set custom value
        "error_handler_params": "0"  # Default to 0 on error
    }
]
```

### Testing Items

1. **Validate configuration** before creating items
2. **Test preprocessing** steps individually
3. **Use item testing** feature in Zabbix UI
4. **Monitor unsupported items** regularly
5. **Check preprocessing errors** in item details

## Workflows

### Adding Monitoring for New Hosts

1. Identify metrics to monitor
2. Create configuration file (YAML/JSON)
3. Validate configuration
4. Create items via script
5. Verify items are supported
6. Configure triggers and graphs

### Migrating Items Between Environments

1. Export items from source using item.get
2. Validate exported configuration
3. Adjust host IDs and interface IDs
4. Import to target environment
5. Verify functionality
6. Update dependent triggers/graphs

### Bulk Item Updates

1. Query existing items with filters
2. Modify parameters in batch
3. Validate changes
4. Apply updates via item.update
5. Verify changes took effect
6. Monitor for issues

## Troubleshooting

### Unsupported Items

Items become unsupported when:
- Host/agent is unreachable
- Item key is invalid or not supported
- Preprocessing step fails
- Permission issues
- Timeout occurs

**Resolution steps**:
1. Check item error message in UI
2. Verify host connectivity
3. Test item key manually
4. Review preprocessing steps
5. Check agent/server logs

### Preprocessing Failures

Common preprocessing issues:
- JSONPath doesn't match structure
- Regular expression doesn't match format
- JavaScript syntax errors
- Type conversion failures
- Validation range violations

**Debugging**:
1. Use preprocessing test feature
2. Check error messages
3. Validate data format
4. Test regex/JSONPath separately
5. Add error handlers

### Performance Issues

If items cause performance problems:
- Reduce polling frequency
- Shorten history retention
- Use dependent items to reduce checks
- Enable "Discard unchanged" preprocessing
- Consider using calculated items
- Review item timeout settings

## API Reference

### Key API Methods

**item.create**: Create new items
```python
zapi.item.create({
    "hostid": "10084",
    "name": "Item Name",
    "key_": "item.key",
    "type": 0,
    "value_type": 0,
    "interfaceid": "30050",
    "delay": "60s"
})
```

**item.update**: Update existing items
```python
zapi.item.update({
    "itemid": "12345",
    "delay": "30s",
    "history": "14d"
})
```

**item.delete**: Delete items
```python
zapi.item.delete(["12345", "12346"])
```

**item.get**: Retrieve items with filters
```python
zapi.item.get({
    "hostids": "10084",
    "output": "extend",
    "selectPreprocessing": "extend"
})
```

See Zabbix API documentation for complete parameter reference.

## Examples Directory

Browse the examples directory for ready-to-use configurations:

- **[agent_items.json](examples/agent_items.json)**: Zabbix agent monitoring items
- **[snmp_items.json](examples/snmp_items.json)**: SNMP network device items
- **[calculated_items.yaml](examples/calculated_items.yaml)**: Calculated item formulas
- **[preprocessing_examples.json](examples/preprocessing_examples.json)**: All preprocessing types
- **[bulk_items.yaml](examples/bulk_items.yaml)**: Bulk item configuration template

## Additional Resources

- Zabbix Documentation: `/zabbix-docs-masters/zabbix-docs/07_Configuration/`
  - `2_items.md`: Item overview
  - `1_item.md`: Item creation and configuration
  - `2_preprocessing.md`: Preprocessing steps reference
  - `3_itemtypes.md`: Item types details
  - `4_history_and_trends.md`: History and trends management

## Summary

This skill enables comprehensive Zabbix item management through API automation. Use the provided scripts to:

- Create and configure items of all types
- Apply preprocessing transformations
- Manage history and trends settings
- Bulk operations across multiple hosts
- Validate configurations before deployment
- Copy and migrate items between environments

Start with the examples directory for common use cases, then customize for your monitoring requirements.
