#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Item Configuration Validator

Validates item configurations before applying them to Zabbix.
Checks syntax, required fields, value ranges, and logical consistency.

Usage:
    python validate_item_config.py config.json
    python validate_item_config.py config.yaml --verbose
    python validate_item_config.py config.json --type calculated

Author: Zabbix Skills Team
Version: 1.0.0
"""

import sys
import json
import yaml
import argparse
import re
from pathlib import Path
from typing import Dict, List, Any, Tuple, Optional
from dataclasses import dataclass
from enum import Enum


class Severity(Enum):
    """Validation issue severity levels"""
    ERROR = "ERROR"
    WARNING = "WARNING"
    INFO = "INFO"


@dataclass
class ValidationIssue:
    """Represents a validation issue"""
    severity: Severity
    field: str
    message: str
    item_name: Optional[str] = None

    def __str__(self):
        item_info = f" [{self.item_name}]" if self.item_name else ""
        return f"{self.severity.value}{item_info}: {self.field} - {self.message}"


class ItemConfigValidator:
    """
    Validates Zabbix item configurations

    Performs comprehensive validation including:
    - Required field checks
    - Data type validation
    - Value range validation
    - Item key syntax validation
    - Preprocessing step validation
    - Logical consistency checks
    """

    # Valid item types
    VALID_ITEM_TYPES = {
        0: 'Zabbix agent',
        1: 'SNMPv1 agent',
        2: 'Zabbix trapper',
        3: 'Simple check',
        4: 'SNMPv2 agent',
        5: 'Zabbix internal',
        6: 'SNMPv3 agent',
        7: 'Zabbix agent (active)',
        8: 'Aggregate',
        10: 'External check',
        11: 'Database monitor',
        12: 'IPMI agent',
        13: 'SSH agent',
        14: 'Telnet agent',
        15: 'Calculated',
        16: 'JMX agent',
        17: 'SNMP trap',
        18: 'Dependent item',
        19: 'HTTP agent',
        20: 'SNMP agent',
        21: 'Script',
        22: 'Browser'
    }

    # Valid value types
    VALID_VALUE_TYPES = {
        0: 'Numeric (float)',
        1: 'Character',
        2: 'Log',
        3: 'Numeric (unsigned)',
        4: 'Text'
    }

    # Valid preprocessing types
    VALID_PREPROCESSING_TYPES = {
        1: 'Custom multiplier',
        2: 'Simple change',
        5: 'Regular expression',
        6: 'Trim',
        7: 'Right trim',
        8: 'Left trim',
        10: 'XML XPath',
        12: 'JSONPath',
        13: 'Boolean to decimal',
        14: 'Octal to decimal',
        15: 'Hexadecimal to decimal',
        16: 'CSV to JSON',
        17: 'XML to JSON',
        19: 'Discard unchanged',
        20: 'Discard unchanged with heartbeat',
        21: 'In range',
        22: 'Prometheus pattern',
        23: 'Prometheus to JSON',
        24: 'Change per second'
    }

    # Item types that require interface
    TYPES_REQUIRING_INTERFACE = [0, 1, 3, 4, 6, 12, 13, 14, 20]

    # Item types that support preprocessing
    TYPES_SUPPORTING_PREPROCESSING = [0, 1, 2, 3, 4, 5, 6, 7, 10, 11, 12, 13, 14, 15, 16, 18, 19, 20, 21, 22]

    def __init__(self, verbose: bool = False):
        """
        Initialize validator

        Args:
            verbose: Enable verbose output
        """
        self.verbose = verbose
        self.issues: List[ValidationIssue] = []

    def add_issue(self, severity: Severity, field: str, message: str, item_name: Optional[str] = None):
        """Add validation issue"""
        issue = ValidationIssue(severity, field, message, item_name)
        self.issues.append(issue)

    def validate_required_fields(self, item: Dict[str, Any], item_name: str) -> bool:
        """
        Validate required fields are present

        Args:
            item: Item configuration
            item_name: Item name for error reporting

        Returns:
            True if all required fields present
        """
        required_fields = ['hostid', 'name', 'key_', 'type', 'value_type']
        valid = True

        for field in required_fields:
            if field not in item:
                self.add_issue(Severity.ERROR, field, f"Required field missing", item_name)
                valid = False

        return valid

    def validate_item_type(self, item: Dict[str, Any], item_name: str) -> bool:
        """
        Validate item type

        Args:
            item: Item configuration
            item_name: Item name for error reporting

        Returns:
            True if valid
        """
        if 'type' not in item:
            return False

        item_type = item['type']

        # Check if type is valid integer
        try:
            item_type = int(item_type)
        except (ValueError, TypeError):
            self.add_issue(Severity.ERROR, 'type', f"Must be an integer, got: {type(item_type).__name__}", item_name)
            return False

        # Check if type is supported
        if item_type not in self.VALID_ITEM_TYPES:
            self.add_issue(
                Severity.ERROR,
                'type',
                f"Invalid item type: {item_type}. Must be one of: {list(self.VALID_ITEM_TYPES.keys())}",
                item_name
            )
            return False

        # Check interface requirement
        if item_type in self.TYPES_REQUIRING_INTERFACE and 'interfaceid' not in item:
            self.add_issue(
                Severity.WARNING,
                'interfaceid',
                f"Item type '{self.VALID_ITEM_TYPES[item_type]}' typically requires an interface",
                item_name
            )

        return True

    def validate_value_type(self, item: Dict[str, Any], item_name: str) -> bool:
        """
        Validate value type

        Args:
            item: Item configuration
            item_name: Item name for error reporting

        Returns:
            True if valid
        """
        if 'value_type' not in item:
            return False

        value_type = item['value_type']

        # Check if value_type is valid integer
        try:
            value_type = int(value_type)
        except (ValueError, TypeError):
            self.add_issue(Severity.ERROR, 'value_type', f"Must be an integer, got: {type(value_type).__name__}", item_name)
            return False

        # Check if value_type is supported
        if value_type not in self.VALID_VALUE_TYPES:
            self.add_issue(
                Severity.ERROR,
                'value_type',
                f"Invalid value type: {value_type}. Must be one of: {list(self.VALID_VALUE_TYPES.keys())}",
                item_name
            )
            return False

        # Validate trends for non-numeric types
        if value_type in [1, 2, 4] and 'trends' in item and item['trends'] != '0':
            self.add_issue(
                Severity.WARNING,
                'trends',
                f"Trends not applicable for value type '{self.VALID_VALUE_TYPES[value_type]}'",
                item_name
            )

        return True

    def validate_item_key(self, item: Dict[str, Any], item_name: str) -> bool:
        """
        Validate item key syntax

        Args:
            item: Item configuration
            item_name: Item name for error reporting

        Returns:
            True if valid
        """
        if 'key_' not in item:
            return False

        key = item['key_']

        # Check key length (max 2048 characters)
        if len(key) > 2048:
            self.add_issue(Severity.ERROR, 'key_', f"Key too long: {len(key)} characters (max: 2048)", item_name)
            return False

        # Basic syntax validation
        # Key format: key[param1,param2,...]
        if not re.match(r'^[a-zA-Z0-9_\.]+(\[.*\])?$', key):
            self.add_issue(
                Severity.WARNING,
                'key_',
                f"Key may have invalid syntax: '{key}'. Expected format: 'key' or 'key[params]'",
                item_name
            )

        # Check for empty key
        if not key or key.isspace():
            self.add_issue(Severity.ERROR, 'key_', "Key cannot be empty", item_name)
            return False

        return True

    def validate_delay(self, item: Dict[str, Any], item_name: str) -> bool:
        """
        Validate update interval (delay)

        Args:
            item: Item configuration
            item_name: Item name for error reporting

        Returns:
            True if valid
        """
        if 'delay' not in item:
            # Delay is optional, default is 60s
            return True

        delay = str(item['delay'])

        # Check for valid format: number with optional suffix (s, m, h, d)
        # or flexible/scheduled interval
        patterns = [
            r'^\d+[smhd]?$',  # Simple delay: 60, 60s, 5m, 1h, 1d
            r'^[mh]\d+-\d+,\d+-\d+:\d+[smhd]?$',  # Flexible: m0-6,09-17:30s
        ]

        valid = any(re.match(pattern, delay) for pattern in patterns)

        if not valid:
            self.add_issue(
                Severity.WARNING,
                'delay',
                f"Delay format may be invalid: '{delay}'. Use format: '60s', '5m', '1h' or flexible intervals",
                item_name
            )

        # Check maximum delay (86400 seconds = 1 day for simple intervals)
        if delay.isdigit():
            if int(delay) > 86400:
                self.add_issue(
                    Severity.WARNING,
                    'delay',
                    f"Delay exceeds maximum: {delay} seconds (max: 86400)",
                    item_name
                )

        return True

    def validate_history_trends(self, item: Dict[str, Any], item_name: str) -> bool:
        """
        Validate history and trends storage periods

        Args:
            item: Item configuration
            item_name: Item name for error reporting

        Returns:
            True if valid
        """
        valid = True

        # Validate history
        if 'history' in item:
            history = str(item['history'])
            if not re.match(r'^\d+[smhd]?$', history):
                self.add_issue(
                    Severity.WARNING,
                    'history',
                    f"History format may be invalid: '{history}'. Use format: '7d', '30d', '90d'",
                    item_name
                )
                valid = False

        # Validate trends
        if 'trends' in item:
            trends = str(item['trends'])
            if not re.match(r'^\d+[smhd]?$', trends):
                self.add_issue(
                    Severity.WARNING,
                    'trends',
                    f"Trends format may be invalid: '{trends}'. Use format: '365d', '730d'",
                    item_name
                )
                valid = False

        # Best practice: trends should be longer than history
        if 'history' in item and 'trends' in item:
            try:
                history_val = self._parse_time_suffix(item['history'])
                trends_val = self._parse_time_suffix(item['trends'])

                if trends_val < history_val:
                    self.add_issue(
                        Severity.WARNING,
                        'trends',
                        f"Trends period ({trends}) should be longer than history period ({item['history']})",
                        item_name
                    )
            except:
                pass  # Already reported format errors above

        return valid

    def validate_preprocessing(self, item: Dict[str, Any], item_name: str) -> bool:
        """
        Validate preprocessing steps

        Args:
            item: Item configuration
            item_name: Item name for error reporting

        Returns:
            True if valid
        """
        if 'preprocessing' not in item:
            return True

        preprocessing = item['preprocessing']

        if not isinstance(preprocessing, list):
            self.add_issue(Severity.ERROR, 'preprocessing', "Must be a list", item_name)
            return False

        # Check if item type supports preprocessing
        item_type = item.get('type')
        if item_type not in self.TYPES_SUPPORTING_PREPROCESSING:
            self.add_issue(
                Severity.WARNING,
                'preprocessing',
                f"Item type '{self.VALID_ITEM_TYPES.get(item_type, 'unknown')}' may not support preprocessing",
                item_name
            )

        valid = True
        for idx, step in enumerate(preprocessing):
            if not isinstance(step, dict):
                self.add_issue(Severity.ERROR, f'preprocessing[{idx}]', "Step must be a dictionary", item_name)
                valid = False
                continue

            # Check required fields
            if 'type' not in step:
                self.add_issue(Severity.ERROR, f'preprocessing[{idx}].type', "Type is required", item_name)
                valid = False
                continue

            step_type = step['type']

            # Validate preprocessing type
            if step_type not in self.VALID_PREPROCESSING_TYPES:
                self.add_issue(
                    Severity.ERROR,
                    f'preprocessing[{idx}].type',
                    f"Invalid preprocessing type: {step_type}",
                    item_name
                )
                valid = False

            # Validate params based on type
            if step_type in [5, 10, 12]:  # Regex, XPath, JSONPath
                if 'params' not in step or not step['params']:
                    self.add_issue(
                        Severity.ERROR,
                        f'preprocessing[{idx}].params',
                        f"Parameters required for {self.VALID_PREPROCESSING_TYPES[step_type]}",
                        item_name
                    )
                    valid = False

        return valid

    def validate_calculated_formula(self, item: Dict[str, Any], item_name: str) -> bool:
        """
        Validate calculated item formula

        Args:
            item: Item configuration
            item_name: Item name for error reporting

        Returns:
            True if valid
        """
        if item.get('type') != 15:  # Not a calculated item
            return True

        if 'params' not in item or not item['params']:
            self.add_issue(Severity.ERROR, 'params', "Formula required for calculated items", item_name)
            return False

        formula = item['params']

        # Basic syntax check for formula
        # Should contain item references like last(//item.key)
        if not re.search(r'(last|avg|min|max|sum)\(//', formula):
            self.add_issue(
                Severity.WARNING,
                'params',
                f"Formula may be invalid: '{formula}'. Expected item references like 'last(//item.key)'",
                item_name
            )

        return True

    def validate_dependent_item(self, item: Dict[str, Any], item_name: str) -> bool:
        """
        Validate dependent item configuration

        Args:
            item: Item configuration
            item_name: Item name for error reporting

        Returns:
            True if valid
        """
        if item.get('type') != 18:  # Not a dependent item
            return True

        if 'master_itemid' not in item:
            self.add_issue(Severity.ERROR, 'master_itemid', "Master item ID required for dependent items", item_name)
            return False

        # Dependent items typically need preprocessing
        if 'preprocessing' not in item or not item['preprocessing']:
            self.add_issue(
                Severity.WARNING,
                'preprocessing',
                "Dependent items typically require preprocessing steps to extract data",
                item_name
            )

        return True

    def _parse_time_suffix(self, value: str) -> int:
        """
        Parse time value with suffix to seconds

        Args:
            value: Time value (e.g., '60s', '5m', '1h', '7d')

        Returns:
            Value in seconds
        """
        value = str(value)

        if value.isdigit():
            return int(value)

        match = re.match(r'^(\d+)([smhd])$', value)
        if not match:
            raise ValueError(f"Invalid time format: {value}")

        amount, unit = match.groups()
        amount = int(amount)

        multipliers = {'s': 1, 'm': 60, 'h': 3600, 'd': 86400}
        return amount * multipliers[unit]

    def validate_item(self, item: Dict[str, Any]) -> bool:
        """
        Validate a single item configuration

        Args:
            item: Item configuration dictionary

        Returns:
            True if item is valid (no errors)
        """
        item_name = item.get('name', 'Unknown')

        # Run all validations
        validations = [
            self.validate_required_fields(item, item_name),
            self.validate_item_type(item, item_name),
            self.validate_value_type(item, item_name),
            self.validate_item_key(item, item_name),
            self.validate_delay(item, item_name),
            self.validate_history_trends(item, item_name),
            self.validate_preprocessing(item, item_name),
            self.validate_calculated_formula(item, item_name),
            self.validate_dependent_item(item, item_name)
        ]

        return all(validations)

    def validate_config(self, config: Any) -> Tuple[bool, List[ValidationIssue]]:
        """
        Validate configuration (single item or list of items)

        Args:
            config: Configuration to validate

        Returns:
            Tuple of (is_valid, list of issues)
        """
        self.issues = []

        # Handle single item or list of items
        if isinstance(config, dict):
            items = [config]
        elif isinstance(config, list):
            items = config
        else:
            self.add_issue(Severity.ERROR, 'root', f"Configuration must be dict or list, got {type(config).__name__}")
            return False, self.issues

        if not items:
            self.add_issue(Severity.ERROR, 'root', "Configuration is empty")
            return False, self.issues

        # Validate each item
        for idx, item in enumerate(items):
            if not isinstance(item, dict):
                self.add_issue(Severity.ERROR, f'item[{idx}]', f"Item must be a dictionary, got {type(item).__name__}")
                continue

            self.validate_item(item)

        # Check for errors
        has_errors = any(issue.severity == Severity.ERROR for issue in self.issues)

        return not has_errors, self.issues

    def print_report(self):
        """Print validation report"""
        if not self.issues:
            print("[OK] Configuration is valid!")
            return

        # Group by severity
        errors = [i for i in self.issues if i.severity == Severity.ERROR]
        warnings = [i for i in self.issues if i.severity == Severity.WARNING]
        infos = [i for i in self.issues if i.severity == Severity.INFO]

        print("\n" + "=" * 80)
        print("VALIDATION REPORT")
        print("=" * 80)

        if errors:
            print(f"\n{len(errors)} ERROR(S):")
            for issue in errors:
                print(f"  {issue}")

        if warnings:
            print(f"\n{len(warnings)} WARNING(S):")
            for issue in warnings:
                print(f"  {issue}")

        if self.verbose and infos:
            print(f"\n{len(infos)} INFO:")
            for issue in infos:
                print(f"  {issue}")

        print("\n" + "=" * 80)
        print(f"Summary: {len(errors)} errors, {len(warnings)} warnings")
        print("=" * 80 + "\n")


def load_config(filepath: str) -> Any:
    """Load configuration from file"""
    path = Path(filepath)

    if not path.exists():
        raise FileNotFoundError(f"File not found: {filepath}")

    with open(path, 'r') as f:
        if path.suffix in ['.yaml', '.yml']:
            return yaml.safe_load(f)
        elif path.suffix == '.json':
            return json.load(f)
        else:
            raise ValueError(f"Unsupported file format: {path.suffix}")


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='Validate Zabbix item configurations',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument('config', help='Configuration file to validate (JSON or YAML)')
    parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    parser.add_argument('--type', choices=['all', 'calculated', 'dependent', 'snmp'],
                       help='Validate specific item type only')

    args = parser.parse_args()

    # Load configuration
    try:
        config = load_config(args.config)
    except Exception as e:
        print(f"Error loading configuration: {e}", file=sys.stderr)
        sys.exit(1)

    # Filter by type if specified
    if args.type and args.type != 'all':
        type_map = {'calculated': 15, 'dependent': 18, 'snmp': 4}
        target_type = type_map.get(args.type)

        if isinstance(config, list):
            config = [item for item in config if item.get('type') == target_type]
        elif isinstance(config, dict) and config.get('type') != target_type:
            print(f"Item type does not match filter: {args.type}")
            sys.exit(1)

        if not config:
            print(f"No items of type '{args.type}' found in configuration")
            sys.exit(1)

    # Validate
    validator = ItemConfigValidator(verbose=args.verbose)
    is_valid, issues = validator.validate_config(config)

    # Print report
    validator.print_report()

    # Exit with appropriate code
    sys.exit(0 if is_valid else 1)


if __name__ == '__main__':
    main()
