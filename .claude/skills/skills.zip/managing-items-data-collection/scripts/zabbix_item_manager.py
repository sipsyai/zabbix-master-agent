#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Item Manager

A comprehensive tool for managing Zabbix items via API including create, update,
delete, bulk operations, and item copying between hosts.

Usage:
    python zabbix_item_manager.py create --config items.json
    python zabbix_item_manager.py update --item-id 12345 --delay 30s
    python zabbix_item_manager.py delete --item-id 12345
    python zabbix_item_manager.py bulk-create --config bulk_items.yaml
    python zabbix_item_manager.py copy --source-host 10084 --target-host 10085

Environment Variables:
    ZABBIX_URL: Zabbix server URL (e.g., https://zabbix.example.com)
    ZABBIX_TOKEN: API authentication token

Author: Zabbix Skills Team
Version: 1.0.0
"""

import os
import sys
import json
import yaml
import argparse
import logging
from typing import Dict, List, Optional, Any, Union
from pathlib import Path
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ZabbixAPIError(Exception):
    """Custom exception for Zabbix API errors"""
    pass


class ZabbixItemManager:
    """
    Manages Zabbix items through the API

    Supports all item operations: create, read, update, delete, copy
    """

    # Item type constants
    ITEM_TYPES = {
        'zabbix_agent': 0,
        'snmp_v1': 1,
        'zabbix_trapper': 2,
        'simple_check': 3,
        'snmp_v2': 4,
        'internal': 5,
        'snmp_v3': 6,
        'zabbix_agent_active': 7,
        'aggregate': 8,
        'external': 10,
        'database_monitor': 11,
        'ipmi': 12,
        'ssh': 13,
        'telnet': 14,
        'calculated': 15,
        'jmx': 16,
        'snmp_trap': 17,
        'dependent': 18,
        'http_agent': 19,
        'snmp_agent': 20,
        'script': 21,
        'browser': 22
    }

    # Value type constants
    VALUE_TYPES = {
        'float': 0,
        'character': 1,
        'log': 2,
        'unsigned': 3,
        'text': 4
    }

    # Preprocessing type constants
    PREPROCESSING_TYPES = {
        'regex': 5,
        'trim': 6,
        'rtrim': 7,
        'ltrim': 8,
        'xpath': 10,
        'jsonpath': 12,
        'multiplier': 1,
        'simple_change': 2,
        'change_per_second': 10,
        'boolean_to_decimal': 13,
        'octal_to_decimal': 14,
        'hex_to_decimal': 15,
        'javascript': 1,
        'discard_unchanged': 19,
        'discard_unchanged_heartbeat': 20,
        'prometheus_pattern': 22,
        'prometheus_to_json': 23,
        'csv_to_json': 16,
        'xml_to_json': 17
    }

    def __init__(self, url: str, token: str, verify_ssl: bool = True):
        """
        Initialize Zabbix Item Manager

        Args:
            url: Zabbix server URL
            token: API authentication token
            verify_ssl: Whether to verify SSL certificates
        """
        self.url = url.rstrip('/') + '/api_jsonrpc.php'
        self.token = token
        self.verify_ssl = verify_ssl
        self.session = self._create_session()

        logger.info(f"Initialized Zabbix Item Manager for {url}")

    def _create_session(self) -> requests.Session:
        """Create requests session with retry logic"""
        session = requests.Session()
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["POST"]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        return session

    def _call_api(self, method: str, params: Dict[str, Any]) -> Any:
        """
        Make Zabbix API call

        Args:
            method: API method name (e.g., 'item.create')
            params: Method parameters

        Returns:
            API response result

        Raises:
            ZabbixAPIError: If API call fails
        """
        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "id": 1,
            "auth": self.token
        }

        try:
            response = self.session.post(
                self.url,
                json=payload,
                headers={"Content-Type": "application/json"},
                verify=self.verify_ssl,
                timeout=30
            )
            response.raise_for_status()

            result = response.json()

            if "error" in result:
                error_msg = result["error"].get("data", result["error"].get("message", "Unknown error"))
                raise ZabbixAPIError(f"API Error: {error_msg}")

            return result.get("result")

        except requests.exceptions.RequestException as e:
            logger.error(f"Request failed: {e}")
            raise ZabbixAPIError(f"Request failed: {e}")

    def create_item(self, **kwargs) -> Dict[str, Any]:
        """
        Create a new item

        Required kwargs:
            hostid: Host ID
            name: Item name
            key_: Item key
            type: Item type (0-22)
            value_type: Value type (0-4)

        Optional kwargs:
            interfaceid: Interface ID (required for some types)
            delay: Update interval (default: 60s)
            history: History storage period (default: 7d)
            trends: Trends storage period (default: 365d)
            units: Value units
            description: Item description
            preprocessing: List of preprocessing steps
            tags: List of item tags
            applications: List of application IDs (deprecated but supported)

        Returns:
            Created item information with itemids
        """
        # Validate required fields
        required_fields = ['hostid', 'name', 'key_', 'type', 'value_type']
        for field in required_fields:
            if field not in kwargs:
                raise ValueError(f"Missing required field: {field}")

        # Set defaults
        if 'delay' not in kwargs:
            kwargs['delay'] = '60s'
        if 'history' not in kwargs:
            kwargs['history'] = '7d'
        if 'trends' not in kwargs and kwargs.get('value_type') in [0, 3]:  # Only for numeric
            kwargs['trends'] = '365d'

        logger.info(f"Creating item: {kwargs['name']} (key: {kwargs['key_']})")

        try:
            result = self._call_api('item.create', kwargs)
            logger.info(f"Item created successfully. ID: {result['itemids'][0]}")
            return result
        except ZabbixAPIError as e:
            logger.error(f"Failed to create item: {e}")
            raise

    def update_item(self, itemid: str, **kwargs) -> Dict[str, Any]:
        """
        Update an existing item

        Args:
            itemid: Item ID to update
            **kwargs: Fields to update

        Returns:
            Update result with itemids
        """
        kwargs['itemid'] = itemid

        logger.info(f"Updating item {itemid}")

        try:
            result = self._call_api('item.update', kwargs)
            logger.info(f"Item {itemid} updated successfully")
            return result
        except ZabbixAPIError as e:
            logger.error(f"Failed to update item: {e}")
            raise

    def delete_item(self, itemid: Union[str, List[str]], force: bool = False) -> Dict[str, Any]:
        """
        Delete item(s)

        Args:
            itemid: Item ID or list of item IDs
            force: Skip confirmation (default: False)

        Returns:
            Delete result with itemids
        """
        if isinstance(itemid, str):
            itemid = [itemid]

        if not force:
            confirm = input(f"Delete {len(itemid)} item(s)? [y/N]: ")
            if confirm.lower() != 'y':
                logger.info("Deletion cancelled")
                return {"itemids": []}

        logger.info(f"Deleting {len(itemid)} item(s)")

        try:
            result = self._call_api('item.delete', itemid)
            logger.info(f"Deleted {len(result['itemids'])} item(s)")
            return result
        except ZabbixAPIError as e:
            logger.error(f"Failed to delete items: {e}")
            raise

    def get_items(self, **filters) -> List[Dict[str, Any]]:
        """
        Get items with filters

        Common filters:
            hostids: Filter by host ID(s)
            groupids: Filter by host group ID(s)
            itemids: Filter by item ID(s)
            templateids: Filter by template ID(s)
            name: Filter by item name (supports wildcards)
            key_: Filter by item key (supports wildcards)

        Returns:
            List of items
        """
        params = {
            'output': 'extend',
            'selectPreprocessing': 'extend',
            'selectTags': 'extend',
            **filters
        }

        try:
            items = self._call_api('item.get', params)
            logger.info(f"Retrieved {len(items)} item(s)")
            return items
        except ZabbixAPIError as e:
            logger.error(f"Failed to get items: {e}")
            raise

    def bulk_create_items(self, items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Create multiple items

        Args:
            items: List of item configurations

        Returns:
            List of created item results
        """
        results = []
        total = len(items)

        logger.info(f"Creating {total} items...")

        for idx, item_config in enumerate(items, 1):
            try:
                result = self.create_item(**item_config)
                results.append({
                    'success': True,
                    'itemid': result['itemids'][0],
                    'name': item_config['name']
                })
                logger.info(f"Progress: {idx}/{total}")
            except Exception as e:
                results.append({
                    'success': False,
                    'error': str(e),
                    'name': item_config.get('name', 'Unknown')
                })
                logger.error(f"Failed to create item {idx}/{total}: {e}")

        successful = sum(1 for r in results if r['success'])
        logger.info(f"Bulk create complete: {successful}/{total} successful")

        return results

    def copy_items(self, source_hostid: str, target_hostid: str,
                   item_filter: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Copy items from source host to target host

        Args:
            source_hostid: Source host ID
            target_hostid: Target host ID
            item_filter: Optional filters for items to copy

        Returns:
            List of created item results
        """
        logger.info(f"Copying items from host {source_hostid} to {target_hostid}")

        # Get items from source host
        filters = {'hostids': source_hostid}
        if item_filter:
            filters.update(item_filter)

        source_items = self.get_items(**filters)

        if not source_items:
            logger.warning("No items found on source host")
            return []

        # Prepare items for target host
        new_items = []
        for item in source_items:
            new_item = {
                'hostid': target_hostid,
                'name': item['name'],
                'key_': item['key_'],
                'type': item['type'],
                'value_type': item['value_type'],
                'delay': item['delay'],
                'history': item['history'],
                'trends': item['trends'],
                'status': item['status'],
                'units': item.get('units', ''),
                'description': item.get('description', '')
            }

            # Copy interface if present
            if 'interfaceid' in item and item['interfaceid'] != '0':
                # Note: Interface IDs may differ between hosts
                # This requires additional logic to map interfaces
                logger.warning(f"Item {item['name']} uses interface - may need manual adjustment")

            # Copy preprocessing steps
            if 'preprocessing' in item and item['preprocessing']:
                new_item['preprocessing'] = [
                    {
                        'type': step['type'],
                        'params': step['params'],
                        'error_handler': step['error_handler'],
                        'error_handler_params': step['error_handler_params']
                    }
                    for step in item['preprocessing']
                ]

            # Copy tags
            if 'tags' in item and item['tags']:
                new_item['tags'] = [
                    {'tag': tag['tag'], 'value': tag['value']}
                    for tag in item['tags']
                ]

            new_items.append(new_item)

        # Create items on target host
        return self.bulk_create_items(new_items)

    def enable_items(self, itemids: Union[str, List[str]]) -> Dict[str, Any]:
        """
        Enable item(s)

        Args:
            itemids: Item ID or list of item IDs

        Returns:
            Update result
        """
        if isinstance(itemids, str):
            itemids = [itemids]

        logger.info(f"Enabling {len(itemids)} item(s)")

        results = []
        for itemid in itemids:
            try:
                result = self.update_item(itemid, status=0)
                results.append(result)
            except Exception as e:
                logger.error(f"Failed to enable item {itemid}: {e}")

        return {'itemids': itemids, 'updated': len(results)}

    def disable_items(self, itemids: Union[str, List[str]]) -> Dict[str, Any]:
        """
        Disable item(s)

        Args:
            itemids: Item ID or list of item IDs

        Returns:
            Update result
        """
        if isinstance(itemids, str):
            itemids = [itemids]

        logger.info(f"Disabling {len(itemids)} item(s)")

        results = []
        for itemid in itemids:
            try:
                result = self.update_item(itemid, status=1)
                results.append(result)
            except Exception as e:
                logger.error(f"Failed to disable item {itemid}: {e}")

        return {'itemids': itemids, 'updated': len(results)}


def load_config(filepath: str) -> Union[Dict, List]:
    """Load configuration from JSON or YAML file"""
    path = Path(filepath)

    if not path.exists():
        raise FileNotFoundError(f"Configuration file not found: {filepath}")

    with open(path, 'r') as f:
        if path.suffix in ['.yaml', '.yml']:
            return yaml.safe_load(f)
        elif path.suffix == '.json':
            return json.load(f)
        else:
            raise ValueError(f"Unsupported file format: {path.suffix}")


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='Zabbix Item Manager - Manage items via API',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    # Global arguments
    parser.add_argument('--url', help='Zabbix server URL (or use ZABBIX_URL env var)')
    parser.add_argument('--token', help='API token (or use ZABBIX_TOKEN env var)')
    parser.add_argument('--no-verify-ssl', action='store_true', help='Disable SSL verification')
    parser.add_argument('--verbose', '-v', action='store_true', help='Enable verbose logging')

    # Subcommands
    subparsers = parser.add_subparsers(dest='command', help='Command to execute')

    # Create command
    create_parser = subparsers.add_parser('create', help='Create item')
    create_parser.add_argument('--config', required=True, help='Configuration file (JSON/YAML)')

    # Update command
    update_parser = subparsers.add_parser('update', help='Update item')
    update_parser.add_argument('--item-id', required=True, help='Item ID to update')
    update_parser.add_argument('--delay', help='Update interval')
    update_parser.add_argument('--history', help='History storage period')
    update_parser.add_argument('--trends', help='Trends storage period')
    update_parser.add_argument('--name', help='Item name')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete item')
    delete_parser.add_argument('--item-id', required=True, help='Item ID to delete')
    delete_parser.add_argument('--force', action='store_true', help='Skip confirmation')

    # Bulk create command
    bulk_parser = subparsers.add_parser('bulk-create', help='Create multiple items')
    bulk_parser.add_argument('--config', required=True, help='Configuration file (JSON/YAML)')

    # Copy command
    copy_parser = subparsers.add_parser('copy', help='Copy items between hosts')
    copy_parser.add_argument('--source-host', required=True, help='Source host ID')
    copy_parser.add_argument('--target-host', required=True, help='Target host ID')

    # Enable/disable commands
    enable_parser = subparsers.add_parser('enable', help='Enable items')
    enable_parser.add_argument('--item-id', required=True, help='Item ID(s) to enable')

    disable_parser = subparsers.add_parser('disable', help='Disable items')
    disable_parser.add_argument('--item-id', required=True, help='Item ID(s) to disable')

    args = parser.parse_args()

    # Configure logging
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # Get credentials
    url = args.url or os.environ.get('ZABBIX_URL')
    token = args.token or os.environ.get('ZABBIX_TOKEN')

    if not url or not token:
        parser.error('Zabbix URL and token required (via args or environment variables)')

    # Initialize manager
    manager = ZabbixItemManager(url, token, verify_ssl=not args.no_verify_ssl)

    # Execute command
    try:
        if args.command == 'create':
            config = load_config(args.config)
            if isinstance(config, list):
                # Single item in list
                config = config[0]
            result = manager.create_item(**config)
            print(f"Item created: {result['itemids'][0]}")

        elif args.command == 'update':
            updates = {}
            if args.delay:
                updates['delay'] = args.delay
            if args.history:
                updates['history'] = args.history
            if args.trends:
                updates['trends'] = args.trends
            if args.name:
                updates['name'] = args.name

            result = manager.update_item(args.item_id, **updates)
            print(f"Item updated: {result['itemids'][0]}")

        elif args.command == 'delete':
            result = manager.delete_item(args.item_id, force=args.force)
            print(f"Items deleted: {len(result['itemids'])}")

        elif args.command == 'bulk-create':
            config = load_config(args.config)
            if not isinstance(config, list):
                config = [config]
            results = manager.bulk_create_items(config)
            successful = sum(1 for r in results if r['success'])
            print(f"Created {successful}/{len(results)} items")

        elif args.command == 'copy':
            results = manager.copy_items(args.source_host, args.target_host)
            successful = sum(1 for r in results if r['success'])
            print(f"Copied {successful}/{len(results)} items")

        elif args.command == 'enable':
            result = manager.enable_items(args.item_id)
            print(f"Enabled {result['updated']} items")

        elif args.command == 'disable':
            result = manager.disable_items(args.item_id)
            print(f"Disabled {result['updated']} items")

        else:
            parser.print_help()

    except Exception as e:
        logger.error(f"Command failed: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
