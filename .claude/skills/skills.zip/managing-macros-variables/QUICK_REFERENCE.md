# Quick Reference - Managing Macros & Variables

## Essential Commands

### Create Macros

```bash
# Global macro
python scripts/zabbix_macro_manager.py create-global \
  --macro "{$CPU_WARN}" --value "80" --description "CPU warning threshold"

# Host macro
python scripts/zabbix_macro_manager.py create-host \
  --host "webserver" --macro "{$PORT}" --value "8080"

# Template macro
python scripts/zabbix_macro_manager.py create-template \
  --template "Custom Template" --macro "{$TIMEOUT}" --value "30"

# Secret text macro
python scripts/zabbix_secret_manager.py create-secret \
  --scope host --host "db01" --macro "{$PASSWORD}" --value "secret"

# Vault secret macro
python scripts/zabbix_secret_manager.py create-vault-secret \
  --scope host --host "api" --macro "{$KEY}" \
  --vault-path "secret/data/prod/api:key"
```

### List Macros

```bash
# List global macros
python scripts/zabbix_macro_manager.py list --scope global

# List host macros
python scripts/zabbix_macro_manager.py list --scope host --host "webserver"

# List secret macros
python scripts/zabbix_secret_manager.py list-secrets --scope global
```

### Update Macros

```bash
# Update global macro
python scripts/zabbix_macro_manager.py update-global \
  --macro "{$CPU_WARN}" --value "75"

# Update host macro
python scripts/zabbix_macro_manager.py update-host \
  --host "webserver" --macro "{$PORT}" --value "8443"

# Update secret
python scripts/zabbix_secret_manager.py update-secret \
  --scope host --host "db01" --macro "{$PASSWORD}" --value "new_secret"
```

### Delete Macros

```bash
# Delete global macro
python scripts/zabbix_macro_manager.py delete-global --macro "{$OLD_MACRO}"

# Delete host macro
python scripts/zabbix_macro_manager.py delete-host \
  --host "webserver" --macro "{$OLD_MACRO}"
```

### Bulk Operations

```bash
# Import from file
python scripts/macro_bulk_operations.py import \
  --file examples/host_macros.yaml --overwrite

# Export to file
python scripts/macro_bulk_operations.py export \
  --scope host --host-pattern "web*" --output web_macros.json

# Bulk update
python scripts/macro_bulk_operations.py update \
  --scope host --pattern "prod-*" --macro "{$PORT}" --value "443"

# Dry run (test without applying)
python scripts/macro_bulk_operations.py import \
  --file macros.yaml --dry-run
```

### Validation

```bash
# Validate syntax
python scripts/validate_macro_config.py check-syntax \
  --macro "{$MY_MACRO}"

# Validate file
python scripts/validate_macro_config.py validate-file \
  --file examples/host_macros.yaml

# Test resolution
python scripts/zabbix_macro_manager.py resolve \
  --host "webserver" --macro "{$CPU_WARN}"
```

### Analysis

```bash
# Find usage
python scripts/macro_analyzer.py find-usage --macro "{$CPU_WARN}"

# Analyze inheritance
python scripts/macro_analyzer.py analyze-inheritance \
  --host "webserver" --macro "{$TIMEOUT}"

# Detect conflicts
python scripts/macro_analyzer.py detect-conflicts --scope template

# Generate report
python scripts/macro_analyzer.py report \
  --type usage --output report.html
```

### Vault Integration

```bash
# Test vault connection
python scripts/vault_integration.py test \
  --url "https://vault:8200" --token-file "/etc/zabbix/vault_token"

# List secrets
python scripts/vault_integration.py list-secrets \
  --path "secret/data/prod"

# Configure vault
python scripts/vault_integration.py configure \
  --url "https://vault:8200" --token-file "/path/token"
```

## Macro Syntax

### User Macros
```
{$MACRO_NAME}              # Plain text
{$MACRO_NAME:context}      # With context
{$MACRO_NAME:regex:".*"}   # Regex context
```

### Naming Rules
- Uppercase only: A-Z
- Numbers: 0-9
- Allowed: underscore (_), dot (.)
- Format: {$CATEGORY_DESCRIPTION_SUFFIX}

### Examples
```
{$CPU_LOAD_WARN}           # Good
{$DB_MAX_CONNECTIONS}      # Good
{$WEB_RESPONSE_TIME_CRIT}  # Good
{$threshold}               # Bad (lowercase)
{$TEMP}                    # Bad (too vague)
```

## Macro Types

| Type | Description | Use Case |
|------|-------------|----------|
| 0 | Plain text | Non-sensitive config |
| 1 | Secret text | Masked credentials |
| 2 | Vault secret | Production secrets |

## Scopes

| Scope | Priority | Use For |
|-------|----------|---------|
| Host | 1 (highest) | Overrides, exceptions |
| Template | 2-N | Service parameters |
| Global | Lowest | Universal defaults |

## Environment Variables

```bash
export ZABBIX_URL="http://zabbix.company.com"
export ZABBIX_USER="Admin"
export ZABBIX_PASSWORD="password"
export VAULT_ADDR="https://vault:8200"
export VAULT_TOKEN="vault_token"
```

## Common Patterns

### Context Macros for Filesystems
```
{$LOW_SPACE_LIMIT}         = 10    # Default
{$LOW_SPACE_LIMIT:/home}   = 20    # Specific path
{$LOW_SPACE_LIMIT:regex:"^/var/.*$"} = 30  # Pattern
```

### Secret Macros
```
{$DB_PASSWORD}             # Type 1: Secret text
{$API_KEY}                 # Type 2: Vault secret
```

### Vault Paths
```
# HashiCorp Vault
secret/data/prod/database:password

# CyberArk
Safe=Production;Object=DBCreds;Field=Password
```

## File Formats

### JSON Format
```json
{
  "scope": "host",
  "host": "webserver",
  "macros": [
    {
      "macro": "{$PORT}",
      "value": "8080",
      "type": 0,
      "description": "Web server port"
    }
  ]
}
```

### YAML Format
```yaml
scope: host
host: webserver
macros:
  - macro: "{$PORT}"
    value: "8080"
    type: 0
    description: "Web server port"
```

## Troubleshooting

### Macro Not Resolving
```bash
# Check resolution chain
python scripts/zabbix_macro_manager.py resolve \
  --host "hostname" --macro "{$MACRO}"
```

### Vault Connection Failed
```bash
# Test vault
python scripts/vault_integration.py test
```

### Syntax Error
```bash
# Validate syntax
python scripts/validate_macro_config.py check-syntax \
  --macro "{$YOUR_MACRO}"
```

### Import Failed
```bash
# Validate file first
python scripts/validate_macro_config.py validate-file \
  --file your_file.yaml

# Try dry run
python scripts/macro_bulk_operations.py import \
  --file your_file.yaml --dry-run
```

## Best Practices Checklist

- [ ] Use UPPERCASE macro names
- [ ] Include category prefix
- [ ] Add clear descriptions
- [ ] Choose appropriate scope
- [ ] Use vault for production secrets
- [ ] Test in dry-run mode first
- [ ] Backup before bulk changes
- [ ] Document context values
- [ ] Validate syntax before import
- [ ] Follow naming standards

## Common Use Cases

1. **Setup new host**: Create host macros → Add secrets → Validate
2. **Migrate environment**: Export → Transform → Import with dry-run → Apply
3. **Update thresholds**: Bulk update with pattern matching
4. **Rotate secrets**: Update vault secrets → Reload configuration
5. **Audit macros**: List all → Analyze usage → Generate report

## Quick Links

- Main Documentation: [SKILL.md](SKILL.md)
- Quick Start: [README.md](README.md)
- Examples: [examples/](examples/)
- API Reference: [reference/api.md](reference/api.md)
- Macro Types: [reference/macro-types.md](reference/macro-types.md)

## Support

Check the troubleshooting section in README.md or SKILL.md for detailed help.
