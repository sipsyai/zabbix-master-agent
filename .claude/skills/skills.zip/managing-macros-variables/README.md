# Managing Macros & Variables in Zabbix

Complete toolkit for managing Zabbix macros including user macros, secret macros, and vault integration for secure credential storage.

## Quick Start

### Installation

```bash
# Install dependencies
pip install -r requirements.txt

# Set environment variables
export ZABBIX_URL="http://zabbix.company.com"
export ZABBIX_USER="Admin"
export ZABBIX_PASSWORD="your_password"
```

### Basic Usage

#### Create a Global Macro

```bash
python scripts/zabbix_macro_manager.py create-global \
  --macro "{$MAX_CPULOAD}" \
  --value "80" \
  --description "Maximum CPU load threshold"
```

#### Create a Host Macro

```bash
python scripts/zabbix_macro_manager.py create-host \
  --host "webserver01" \
  --macro "{$NGINX_PORT}" \
  --value "8443" \
  --description "Custom Nginx port"
```

#### Create a Secret Macro

```bash
python scripts/zabbix_secret_manager.py create-secret \
  --scope host \
  --host "database01" \
  --macro "{$DB_PASSWORD}" \
  --value "secure_password" \
  --description "Database password"
```

#### Import Macros from File

```bash
python scripts/macro_bulk_operations.py import \
  --file examples/host_macros.yaml \
  --overwrite
```

## Features

### 1. Macro Management
- Create, update, delete macros at all scopes (global, host, template)
- List and search macros
- Test macro resolution and inheritance
- Validate macro syntax and naming

### 2. Secret Management
- Secret text macros (masked in UI)
- Vault integration (HashiCorp Vault, CyberArk)
- Secure credential storage
- Secret rotation support

### 3. Bulk Operations
- Import/export configurations (JSON/YAML)
- Mass updates across hosts/templates
- Search and replace operations
- Configuration migration

### 4. Analysis & Reporting
- Find macro usage across items/triggers
- Analyze inheritance chains
- Detect conflicts and issues
- Generate usage reports

### 5. Validation
- Syntax validation
- Naming convention checks
- Configuration file validation
- Resolution testing

## Available Scripts

| Script | Purpose |
|--------|---------|
| `zabbix_macro_manager.py` | Main macro CRUD operations |
| `zabbix_secret_manager.py` | Secret and vault management |
| `macro_bulk_operations.py` | Bulk import/export/update |
| `validate_macro_config.py` | Validation and testing |
| `macro_analyzer.py` | Usage analysis and reports |
| `vault_integration.py` | Vault configuration and testing |

## Examples Directory

- **global_macros.json** - System-wide macro examples
- **host_macros.yaml** - Host-specific configurations
- **template_macros.json** - Template parameterization
- **secret_macros.yaml** - Secret macro examples
- **context_macros.json** - Context-aware macro patterns
- **vault_config.yaml** - Vault integration setup
- **bulk_macros.yaml** - Bulk operation examples
- **macro_standards.json** - Naming conventions

## Common Workflows

### Setup Monitoring for New Host

```bash
# 1. Create host-specific macros
python scripts/zabbix_macro_manager.py create-host \
  --host "newserver01" \
  --macro "{$SERVICE_PORT}" \
  --value "8080"

# 2. Add secret credentials
python scripts/zabbix_secret_manager.py create-vault-secret \
  --scope host \
  --host "newserver01" \
  --macro "{$DB_PASSWORD}" \
  --vault-path "secret/data/prod/db:password"

# 3. Validate configuration
python scripts/validate_macro_config.py check-syntax \
  --macro "{$SERVICE_PORT}"
```

### Migrate Environment Configuration

```bash
# 1. Export from source
python scripts/macro_bulk_operations.py export \
  --scope host \
  --host-pattern "dev-*" \
  --output dev_macros.yaml

# 2. Transform for target (manually edit file)

# 3. Import to target
python scripts/macro_bulk_operations.py import \
  --file staging_macros.yaml \
  --dry-run  # Test first

# 4. Apply changes
python scripts/macro_bulk_operations.py import \
  --file staging_macros.yaml
```

### Configure Vault Integration

```bash
# 1. Test vault connectivity
python scripts/vault_integration.py test \
  --url "https://vault.company.com:8200" \
  --token-file "/etc/zabbix/vault_token"

# 2. Read test secret
python scripts/vault_integration.py test \
  --path "secret/data/test/connection"

# 3. Create vault secret macro
python scripts/zabbix_secret_manager.py create-vault-secret \
  --scope host \
  --host "api-server" \
  --macro "{$API_KEY}" \
  --vault-path "secret/data/prod/api:key" \
  --provider hashicorp
```

### Audit and Analyze Macros

```bash
# Find usage of specific macro
python scripts/macro_analyzer.py find-usage \
  --macro "{$CPU_LOAD_WARN}"

# Analyze inheritance
python scripts/macro_analyzer.py analyze-inheritance \
  --host "webserver01" \
  --macro "{$AGENT_TIMEOUT}"

# Detect conflicts
python scripts/macro_analyzer.py detect-conflicts \
  --scope template

# Generate usage report
python scripts/macro_analyzer.py report \
  --type usage \
  --output macro_usage.html
```

## Macro Types

### User Macros (Type 0)
Plain text values visible in UI. Use for non-sensitive configuration.

```json
{
  "macro": "{$CPU_LOAD_WARN}",
  "value": "80",
  "type": 0
}
```

### Secret Text Macros (Type 1)
Values masked with asterisks in UI. Cannot be viewed after creation.

```json
{
  "macro": "{$DB_PASSWORD}",
  "value": "secure_password",
  "type": 1
}
```

### Vault Secret Macros (Type 2)
Values stored in external vault. Path/query shown in UI.

```json
{
  "macro": "{$API_KEY}",
  "value": "secret/data/prod/api:key",
  "type": 2
}
```

## Macro Scopes

### Global Macros
Apply system-wide unless overridden. Use sparingly as changes affect all hosts.

### Template Macros
Defined in templates, inherited by linked hosts. Best for parameterized monitoring.

### Host Macros
Host-specific values. Use for overrides and unique configurations.

## Inheritance Order

Zabbix resolves macros in this order (highest to lowest priority):

1. Host-level macros
2. First-level template macros
3. Second-level template macros
4. Third-level template macros (and deeper)
5. Global macros

## Best Practices

### Naming Conventions
- Use UPPERCASE: `{$CPU_LOAD_WARN}`
- Include category: `{$DB_MAX_CONNECTIONS}`
- Be descriptive: `{$WEB_RESPONSE_TIME_CRIT}`
- Follow standards in `examples/macro_standards.json`

### Scope Selection
- **Global**: Universal defaults only
- **Template**: Service-specific parameters
- **Host**: Environment-specific overrides

### Secret Management
- Use vault secrets for production credentials
- Implement rotation schedules
- Never log secret values
- Document vault paths

### Documentation
- Always provide descriptions
- Document expected formats
- Note dependencies
- Include examples

## Troubleshooting

### Macro Not Resolving

```bash
# Check resolution chain
python scripts/zabbix_macro_manager.py resolve \
  --host "hostname" \
  --macro "{$MACRO}"
```

### Vault Connection Issues

```bash
# Test vault connectivity
python scripts/vault_integration.py test

# Check vault configuration
cat examples/vault_config.yaml
```

### Syntax Validation Errors

```bash
# Validate single macro
python scripts/validate_macro_config.py check-syntax \
  --macro "{$YOUR_MACRO}"

# Validate configuration file
python scripts/validate_macro_config.py validate-file \
  --file your_macros.yaml
```

### Import Failures

```bash
# Run in dry-run mode first
python scripts/macro_bulk_operations.py import \
  --file macros.yaml \
  --dry-run

# Check for validation errors
python scripts/validate_macro_config.py validate-file \
  --file macros.yaml
```

## Environment Variables

```bash
# Required
export ZABBIX_URL="http://zabbix.company.com"
export ZABBIX_USER="Admin"
export ZABBIX_PASSWORD="password"

# Optional for vault integration
export VAULT_ADDR="https://vault.company.com:8200"
export VAULT_TOKEN="your_vault_token"
```

## Requirements

- Python 3.8+
- requests>=2.31.0
- pyyaml>=6.0
- Zabbix 6.0+ (for vault integration)

## Documentation

For complete documentation, see [SKILL.md](SKILL.md)

For detailed macro types and syntax, see Zabbix documentation:
- [User Macros](https://www.zabbix.com/documentation/current/en/manual/config/macros/user_macros)
- [Secret Macros](https://www.zabbix.com/documentation/current/en/manual/config/macros/secret_macros)
- [Vault Integration](https://www.zabbix.com/documentation/current/en/manual/config/secrets)

## Support

For issues or questions:
1. Check troubleshooting section above
2. Validate your configuration files
3. Review examples in `examples/` directory
4. Consult Zabbix API documentation

## License

This skill is part of the Zabbix Skills collection.
