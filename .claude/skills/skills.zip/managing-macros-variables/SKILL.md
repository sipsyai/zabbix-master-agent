---
name: Managing Macros & Variables in Zabbix
description: Automates Zabbix macro and variable management including user macros, global macros, host macros, template macros, low-level discovery (LLD) macros, built-in macros, secret macros, and Vault integration for secure credential storage through the Zabbix API. Use when managing configuration parameters across hosts and templates, implementing secure credential storage, handling environment-specific settings, or standardizing threshold configurations.
version: 1.0.0
dependencies:
  - requests>=2.31.0
  - pyyaml>=6.0
  - python>=3.8
  - zabbix-api>=0.5.4
---

# Managing Macros & Variables in Zabbix

## Overview

This skill automates comprehensive macro and variable management in Zabbix, covering all macro types from simple user macros to advanced secret management with external vault integration. Macros provide flexible, centralized configuration management across your Zabbix infrastructure.

## Quick Start

### Basic User Macro Management

```python
# Create a global macro
python scripts/zabbix_macro_manager.py create-global \
  --macro "{$MAX_CPULOAD}" \
  --value "80" \
  --description "Maximum CPU load threshold"

# Create host-specific macro
python scripts/zabbix_macro_manager.py create-host \
  --host "webserver01" \
  --macro "{$SSH_PORT}" \
  --value "2222"

# Create template macro
python scripts/zabbix_macro_manager.py create-template \
  --template "Linux by Zabbix agent" \
  --macro "{$AGENT_TIMEOUT}" \
  --value "10s"
```

### Secret Macro Management

```python
# Create secret text macro
python scripts/zabbix_secret_manager.py create-secret \
  --host "database01" \
  --macro "{$DB_PASSWORD}" \
  --value "secure_password_123" \
  --type "secret_text"

# Configure Vault secret macro
python scripts/zabbix_secret_manager.py create-vault-secret \
  --host "api_server" \
  --macro "{$API_KEY}" \
  --vault-path "secret/data/prod/api_keys:key"
```

### Bulk Operations

```python
# Import macros from YAML
python scripts/macro_bulk_operations.py import \
  --file examples/host_macros.yaml \
  --scope host

# Export all global macros
python scripts/macro_bulk_operations.py export \
  --scope global \
  --output global_macros_backup.json
```

## Core Capabilities

### 1. Macro Type Management

**User Macros**: Custom macros with syntax `{$MACRO_NAME}`
- Global scope (system-wide)
- Template scope (inherited by linked hosts)
- Host scope (host-specific overrides)

**Context-Aware Macros**: Pattern-based macro values
- Static context: `{$MACRO:"specific_value"}`
- Regex context: `{$MACRO:regex:"^pattern$"}`

**Secret Macros**: Encrypted sensitive data
- Secret text (masked in UI)
- Vault secrets (external storage)

**LLD Macros**: Low-level discovery macros `{#MACRO}`

**Built-in Macros**: System macros like `{HOST.NAME}`, `{ITEM.VALUE}`

### 2. Macro Inheritance

Zabbix resolves macros in precedence order:
1. Host-level macros (highest priority)
2. First-level template macros
3. Second-level template macros
4. Third-level template macros (and deeper)
5. Global macros (lowest priority)

### 3. Secret Management Integration

**Vault Providers**:
- HashiCorp Vault (KV Secrets Engine v2)
- CyberArk Vault (CV12)

**Features**:
- Secure credential storage
- Automatic secret rotation
- Access control and audit trails
- Encrypted transport

### 4. Advanced Operations

**Bulk Operations**:
- Import/export macro configurations
- Mass updates across hosts/templates
- Pattern-based replacements
- Configuration migration

**Validation & Testing**:
- Syntax validation
- Reference checking
- Resolution testing
- Dependency analysis

**Audit & Documentation**:
- Change tracking
- Usage reporting
- Dependency mapping
- Naming standards enforcement

## Usage Instructions

### Creating Macros

#### Global Macros
Use for system-wide defaults that apply to all hosts unless overridden:

```python
python scripts/zabbix_macro_manager.py create-global \
  --macro "{$WORKING_HOURS}" \
  --value "1-5,09:00-18:00" \
  --description "Business hours for maintenance windows"
```

**Note**: Prefer host/template macros over global macros. Global macro changes trigger configuration updates for ALL hosts.

#### Host Macros
Use for host-specific values:

```python
python scripts/zabbix_macro_manager.py create-host \
  --host "webserver01" \
  --macro "{$NGINX_PORT}" \
  --value "8080" \
  --description "Custom Nginx port"
```

#### Template Macros
Use for parameterized templates:

```python
python scripts/zabbix_macro_manager.py create-template \
  --template "Custom Web Service" \
  --macro "{$SERVICE_TIMEOUT}" \
  --value "30" \
  --description "Service response timeout in seconds"
```

#### Context Macros
Use for dynamic thresholds based on discovered items:

```python
# Define base macro and overrides
python scripts/zabbix_macro_manager.py create-context \
  --host "fileserver" \
  --macro "{$LOW_SPACE_LIMIT}" \
  --default-value "10" \
  --contexts '{
    "/home": "20",
    "regex:^/var/log/.*$": "30",
    "/tmp": "5"
  }'
```

Use in trigger expression:
```
last(/host/vfs.fs.size[{#FSNAME},pfree])<{$LOW_SPACE_LIMIT:"{#FSNAME}"}
```

### Secret Macro Management

#### Secret Text Macros
For sensitive data masked in UI:

```python
python scripts/zabbix_secret_manager.py create-secret \
  --host "database01" \
  --macro "{$DB_PASSWORD}" \
  --value "MySecurePassword123!" \
  --type "secret_text" \
  --description "Database root password"
```

**Important**:
- Secret values cannot be viewed after creation
- Not exported in XML/JSON exports
- Cannot be used in trigger expressions
- Can be revealed through item usage (e.g., script output)

#### Vault Secret Macros
For external secret storage:

```python
# HashiCorp Vault
python scripts/zabbix_secret_manager.py create-vault-secret \
  --host "api_server" \
  --macro "{$API_TOKEN}" \
  --vault-path "secret/data/production/api:token" \
  --vault-provider "hashicorp"

# CyberArk Vault
python scripts/zabbix_secret_manager.py create-vault-secret \
  --host "payment_gateway" \
  --macro "{$GATEWAY_KEY}" \
  --vault-path "Safe=Production;Object=PaymentGateway;Field=APIKey" \
  --vault-provider "cyberark"
```

#### Vault Integration Setup

```python
# Configure HashiCorp Vault connection
python scripts/vault_integration.py configure \
  --provider "hashicorp" \
  --url "https://vault.company.com:8200" \
  --token-file "/etc/zabbix/vault_token" \
  --namespace "production"

# Test vault connectivity
python scripts/vault_integration.py test \
  --path "secret/data/test/connection"

# Rotate secrets
python scripts/vault_integration.py rotate \
  --macro-pattern "{$DB_*}" \
  --schedule "0 2 * * 0"  # Weekly at 2 AM
```

### Bulk Operations

#### Import Macros

```python
# Import from YAML
python scripts/macro_bulk_operations.py import \
  --file examples/host_macros.yaml \
  --scope host \
  --dry-run  # Validate before applying

# Import from JSON
python scripts/macro_bulk_operations.py import \
  --file examples/template_macros.json \
  --scope template \
  --overwrite  # Update existing macros
```

#### Export Macros

```python
# Export all global macros
python scripts/macro_bulk_operations.py export \
  --scope global \
  --output backup/global_macros.json \
  --format json

# Export host macros with filter
python scripts/macro_bulk_operations.py export \
  --scope host \
  --host-pattern "web*" \
  --macro-pattern "{$NGINX_*}" \
  --output nginx_configs.yaml \
  --format yaml
```

#### Mass Updates

```python
# Update macro values across multiple hosts
python scripts/macro_bulk_operations.py update \
  --scope host \
  --host-pattern "database*" \
  --macro "{$MAX_CONNECTIONS}" \
  --value "200"

# Search and replace
python scripts/macro_bulk_operations.py replace \
  --scope template \
  --search "{$OLD_THRESHOLD}" \
  --replace "{$NEW_THRESHOLD}" \
  --backup
```

### Validation & Testing

#### Validate Macro Syntax

```python
# Validate single macro
python scripts/validate_macro_config.py check-syntax \
  --macro "{$VALID_MACRO}"

# Validate configuration file
python scripts/validate_macro_config.py validate-file \
  --file examples/host_macros.yaml \
  --schema-check
```

#### Test Macro Resolution

```python
# Test how a macro resolves for specific host
python scripts/validate_macro_config.py test-resolution \
  --host "webserver01" \
  --macro "{$MAX_CPULOAD}" \
  --show-inheritance

# Test context macro resolution
python scripts/validate_macro_config.py test-context \
  --host "fileserver" \
  --macro "{$LOW_SPACE_LIMIT}" \
  --context "/var/log/application"
```

#### Analyze Dependencies

```python
# Find all items using specific macro
python scripts/macro_analyzer.py find-usage \
  --macro "{$SSH_PORT}" \
  --output-format table

# Analyze macro inheritance chain
python scripts/macro_analyzer.py analyze-inheritance \
  --host "webserver01" \
  --macro "{$AGENT_TIMEOUT}" \
  --visualize

# Detect macro conflicts
python scripts/macro_analyzer.py detect-conflicts \
  --scope template \
  --report conflicts_report.html
```

#### Generate Reports

```python
# Macro usage report
python scripts/macro_analyzer.py report \
  --type usage \
  --output macro_usage_report.html

# Undocumented macros
python scripts/macro_analyzer.py report \
  --type undocumented \
  --output undocumented_macros.csv

# Secret macro audit
python scripts/macro_analyzer.py report \
  --type secrets \
  --output secret_audit.pdf
```

## Workflow Examples

See [reference/workflows.md](reference/workflows.md) for detailed multi-step workflows.

### Environment Migration Workflow

1. Export macros from source environment
2. Transform values for target environment
3. Validate transformed configuration
4. Import to target with testing
5. Verify and document changes

### Secret Rotation Workflow

1. Generate new secret in vault
2. Update macro to point to new secret path
3. Trigger configuration reload
4. Verify services using new secret
5. Deprecate old secret after grace period

### Template Standardization Workflow

1. Audit current macro usage across templates
2. Define naming standards and conventions
3. Create migration mapping
4. Perform bulk rename operations
5. Update documentation and validate

## Best Practices

### Naming Conventions

- Use **UPPERCASE** with underscores: `{$MAX_CPU_LOAD}`
- Include scope prefix for organization: `{$DB_MAX_CONNECTIONS}`, `{$WEB_TIMEOUT}`
- Use descriptive names: `{$THRESHOLD}` → `{$CPU_LOAD_WARNING_THRESHOLD}`
- Follow project standards (see [examples/macro_standards.json](examples/macro_standards.json))

### Scope Selection

- **Global**: Truly universal defaults (working hours, default timeouts)
- **Template**: Service-specific parameters that hosts inherit
- **Host**: Environment-specific or exception values

### Secret Management

- Always use vault secrets for production credentials
- Implement secret rotation schedules
- Use secret text only for non-production or low-security scenarios
- Document vault paths in macro descriptions
- Never log or echo secret macro values

### Documentation

- Always provide clear descriptions
- Document expected value formats
- Note dependencies and related macros
- Include examples in descriptions
- Maintain change history

### Testing

- Validate syntax before deployment
- Test resolution in development first
- Check inheritance chains for conflicts
- Verify secret connectivity before going live
- Monitor for unresolved macros

### Version Control

- Export macro configurations regularly
- Store in version control with environments separated
- Use meaningful commit messages
- Tag releases corresponding to Zabbix deployments
- Document migration procedures

## Common Use Cases

### Parameterized Templates

Create flexible templates that adapt to different environments:

```yaml
# Template macros for web service
template: "Generic Web Service"
macros:
  - {$WEB_PORT}: "80"
  - {$WEB_TIMEOUT}: "10s"
  - {$WEB_HEALTH_CHECK}: "/health"
  - {$WEB_MAX_RESPONSE_TIME}: "5s"
```

Override per host:
```yaml
host: "production-web-01"
macros:
  - {$WEB_PORT}: "8443"  # Custom port
  - {$WEB_MAX_RESPONSE_TIME}: "3s"  # Stricter requirement
```

### Multi-Environment Configuration

Manage dev/staging/production differences:

```python
# Development
{$DB_HOST}: "localhost"
{$DB_PORT}: "3306"
{$LOG_LEVEL}: "DEBUG"

# Staging
{$DB_HOST}: "staging-db.internal"
{$DB_PORT}: "3306"
{$LOG_LEVEL}: "INFO"

# Production
{$DB_HOST}: "vault:secret/data/prod/db:host"
{$DB_PORT}: "3306"
{$LOG_LEVEL}: "WARNING"
```

### Dynamic Discovery Thresholds

Adapt thresholds based on discovered items:

```python
# Base threshold
{$DISK_USAGE_WARN}: "80"

# Context-specific overrides
{$DISK_USAGE_WARN:/home}: "85"
{$DISK_USAGE_WARN:/var/log}: "90"
{$DISK_USAGE_WARN:regex:"^/mnt/.*$"}: "75"

# Use in trigger prototype
last(/host/vfs.fs.size[{#FSNAME},pused]) > {$DISK_USAGE_WARN:"{#FSNAME}"}
```

### Centralized Credential Management

Store all credentials in vault:

```python
# API credentials
{$API_KEY}: "vault:secret/data/prod/services/api:key"
{$API_SECRET}: "vault:secret/data/prod/services/api:secret"

# Database credentials
{$DB_USER}: "vault:secret/data/prod/db/app:username"
{$DB_PASSWORD}: "vault:secret/data/prod/db/app:password"

# Service accounts
{$SNMP_COMMUNITY}: "vault:secret/data/prod/monitoring:snmp_community"
{$SSH_KEY}: "vault:secret/data/prod/monitoring:ssh_private_key"
```

## Reference Documentation

For detailed information, see:

- [Macro Types & Syntax](reference/macro-types.md) - Complete macro type reference
- [Inheritance & Resolution](reference/inheritance.md) - How Zabbix resolves macros
- [Secret Management](reference/secrets.md) - Vault integration details
- [API Reference](reference/api.md) - Zabbix API methods for macros
- [Workflows](reference/workflows.md) - Step-by-step procedures
- [Troubleshooting](reference/troubleshooting.md) - Common issues and solutions

## Examples

The `examples/` directory contains:

- [global_macros.json](examples/global_macros.json) - Global macro configurations
- [host_macros.yaml](examples/host_macros.yaml) - Host-specific examples
- [template_macros.json](examples/template_macros.json) - Template parameterization
- [secret_macros.yaml](examples/secret_macros.yaml) - Secret macro configurations
- [context_macros.json](examples/context_macros.json) - Context-aware patterns
- [vault_config.yaml](examples/vault_config.yaml) - Vault integration setup
- [bulk_macros.yaml](examples/bulk_macros.yaml) - Bulk operation examples
- [macro_standards.json](examples/macro_standards.json) - Naming conventions

## Error Handling

All scripts include comprehensive error handling:

- **Validation Errors**: Syntax, naming, value format issues
- **API Errors**: Connection, authentication, permission problems
- **Vault Errors**: Connection, authentication, missing secrets
- **Conflict Errors**: Duplicate macros, circular dependencies
- **Resolution Errors**: Undefined macros, context mismatches

Use `--verbose` flag for detailed error information and troubleshooting.

## Limitations & Considerations

- **Global Macro Performance**: Changes trigger full configuration update for all hosts
- **Secret Exposure**: Macros can be revealed through item outputs (scripts, logs)
- **Trigger Expression Limitations**: Secret macros cannot be used in trigger expressions
- **Context Matching**: Multiple regex contexts may create undefined behavior
- **Template ID Dependencies**: Same-name macros in multiple templates depend on template ID order
- **Export Limitations**: Secret values are not included in XML/JSON exports
- **Vault Latency**: Initial vault secret retrieval may cause startup delays
- **Proxy Considerations**: Vault resolution by proxy requires separate vault access

## Support & Additional Resources

For more information:
- Zabbix Documentation: [Configuration → Macros](https://www.zabbix.com/documentation/current/en/manual/config/macros)
- Zabbix API: [User Macro Object](https://www.zabbix.com/documentation/current/en/manual/api/reference/usermacro)
- Vault Integration: [Secret Storage](https://www.zabbix.com/documentation/current/en/manual/config/secrets)
