# Zabbix API Reference for Macros

## Overview

The Zabbix API provides comprehensive methods for managing user macros at all scopes.

## API Methods

### usermacro.create
Create new host or template-level macros.

**Parameters:**
```json
{
  "hostid": "10084",
  "macro": "{$CUSTOM_MACRO}",
  "value": "macro_value",
  "type": 0,
  "description": "Macro description"
}
```

**Type Values:**
- `0` - Plain text
- `1` - Secret text
- `2` - Vault secret

**Response:**
```json
{
  "hostmacroids": ["12"]
}
```

### usermacro.createglobal
Create new global macros.

**Parameters:**
```json
{
  "macro": "{$GLOBAL_MACRO}",
  "value": "value",
  "type": 0,
  "description": "Description"
}
```

**Response:**
```json
{
  "globalmacroids": ["5"]
}
```

### usermacro.get
Retrieve macro information.

**Parameters:**
```json
{
  "hostids": "10084",
  "output": ["macro", "value", "description", "type"],
  "sortfield": "macro",
  "filter": {
    "macro": "{$SPECIFIC_MACRO}"
  }
}
```

**Global Macros:**
```json
{
  "globalmacro": true,
  "output": "extend"
}
```

### usermacro.update
Update existing host/template macros.

**Parameters:**
```json
{
  "hostmacroid": "12",
  "value": "new_value",
  "description": "Updated description"
}
```

### usermacro.updateglobal
Update global macros.

**Parameters:**
```json
{
  "globalmacroid": "5",
  "value": "new_value",
  "description": "Updated"
}
```

### usermacro.delete
Delete host/template macros.

**Parameters:**
```json
["12", "13", "14"]
```

### usermacro.deleteglobal
Delete global macros.

**Parameters:**
```json
["5", "6"]
```

## Common Queries

### Get All Host Macros
```python
zabbix_api.usermacro.get({
    'hostids': host_id,
    'output': 'extend',
    'sortfield': 'macro'
})
```

### Get All Global Macros
```python
zabbix_api.usermacro.get({
    'globalmacro': True,
    'output': 'extend'
})
```

### Find Macro by Name
```python
zabbix_api.usermacro.get({
    'hostids': host_id,
    'filter': {
        'macro': '{$SPECIFIC_MACRO}'
    }
})
```

### Get Secret Macros Only
```python
zabbix_api.usermacro.get({
    'hostids': host_id,
    'output': 'extend',
    'filter': {
        'type': ['1', '2']  # Secret and vault types
    }
})
```

## Response Objects

### Host Macro Object
```json
{
  "hostmacroid": "12",
  "hostid": "10084",
  "macro": "{$CUSTOM_MACRO}",
  "value": "macro_value",
  "type": "0",
  "description": "Description",
  "automatic": "0"
}
```

### Global Macro Object
```json
{
  "globalmacroid": "5",
  "macro": "{$GLOBAL_MACRO}",
  "value": "value",
  "type": "0",
  "description": "Description"
}
```

## Error Handling

### Common Errors

**Macro Already Exists:**
```json
{
  "error": {
    "code": -32602,
    "message": "Macro already exists",
    "data": "Macro {$MACRO} already exists."
  }
}
```

**Invalid Macro Format:**
```json
{
  "error": {
    "code": -32602,
    "message": "Invalid parameter",
    "data": "Incorrect macro format."
  }
}
```

**Host Not Found:**
```json
{
  "error": {
    "code": -32602,
    "message": "No permissions to referred object or it does not exist"
  }
}
```

## Authentication

### Login
```python
auth_token = zabbix_api.user.login({
    'username': 'Admin',
    'password': 'zabbix'
})
```

### Subsequent Requests
Include `auth` field:
```json
{
  "jsonrpc": "2.0",
  "method": "usermacro.get",
  "params": {...},
  "auth": "auth_token_here",
  "id": 1
}
```

## Best Practices

### Batch Operations
Retrieve multiple items in single call:
```python
zabbix_api.usermacro.get({
    'hostids': [host1_id, host2_id, host3_id],
    'output': 'extend'
})
```

### Selective Output
Request only needed fields:
```python
zabbix_api.usermacro.get({
    'output': ['macro', 'value'],  # Only these fields
    'hostids': host_id
})
```

### Filtering
Use filters instead of retrieving all:
```python
zabbix_api.usermacro.get({
    'hostids': host_id,
    'filter': {
        'macro': '{$PREFIX_*}'  # Pattern matching
    }
})
```

### Error Handling
Always check for errors:
```python
response = zabbix_api.call('usermacro.create', params)
if 'error' in response:
    handle_error(response['error'])
```

## Rate Limiting

- No explicit rate limits in Zabbix API
- Server performance depends on query complexity
- Use batch operations to reduce call count
- Implement retry logic with backoff

## API Version Compatibility

| Feature | Minimum Version |
|---------|----------------|
| User macros | 2.0+ |
| Secret text | 5.0+ |
| Vault secrets | 5.2+ |
| Macro descriptions | 4.2+ |
| Global macros | 2.0+ |

## Examples

See `scripts/` directory for complete Python implementations:
- `zabbix_macro_manager.py` - Full CRUD operations
- `zabbix_secret_manager.py` - Secret and vault handling
- `macro_bulk_operations.py` - Batch operations
