# Macro Types Reference

## Overview

Zabbix supports several types of macros for flexible configuration management.

## User Macros

Custom macros defined by users with syntax `{$MACRO_NAME}`.

### Characteristics
- Can contain: A-Z (uppercase), 0-9, underscore (_), dot (.)
- Maximum length: 2048 characters for value
- Case-sensitive
- Resolved at runtime

### Scopes
1. **Global Macros**: System-wide defaults
2. **Template Macros**: Inherited by linked hosts
3. **Host Macros**: Host-specific values

### Examples
```
{$CPU_LOAD_WARN}
{$DB_MAX_CONNECTIONS}
{$WEB_RESPONSE_TIME_CRIT}
```

## Context Macros

User macros with context for dynamic threshold management.

### Static Context
```
{$MACRO:"static_value"}
```

Example:
```
{$LOW_SPACE_LIMIT:"/home"} = 20
```

### Regex Context
```
{$MACRO:regex:"pattern"}
```

Example:
```
{$LOW_SPACE_LIMIT:regex:"^/var/log/.*$"} = 30
```

### Usage in Triggers
```
last(/host/vfs.fs.size[{#FSNAME},pfree])<{$LOW_SPACE_LIMIT:"{#FSNAME}"}
```

## Secret Macros

### Type 1: Secret Text
- Value masked with asterisks in UI
- Cannot be viewed after creation
- Not exported in XML/JSON
- Can be revealed through item output

### Type 2: Vault Secrets
- Stored in external vault (HashiCorp Vault, CyberArk)
- Only path/query shown in UI
- Supports automatic rotation
- Retrieved on configuration refresh

### Limitations
- Cannot be used in trigger expressions
- May be revealed through script outputs
- Secret text values not included in exports

## Built-in Macros

System macros provided by Zabbix (read-only).

### Host Macros
- `{HOST.NAME}` - Host name
- `{HOST.HOST}` - Technical name
- `{HOST.IP}` - Primary IP address
- `{HOST.CONN}` - Host connection address

### Item Macros
- `{ITEM.VALUE}` - Current item value
- `{ITEM.LASTVALUE}` - Previous value
- `{ITEM.KEY}` - Item key

### Trigger Macros
- `{TRIGGER.NAME}` - Trigger name
- `{TRIGGER.STATUS}` - Current status
- `{EVENT.ID}` - Event ID

See full list in Zabbix documentation.

## LLD Macros

Low-level discovery macros with syntax `{#MACRO}`.

### Characteristics
- Created by discovery rules
- Available in prototypes
- Replaced with discovered values
- Uppercase recommended

### Examples
```
{#FSNAME} - File system name
{#IFNAME} - Interface name
{#SNMPINDEX} - SNMP index
```

### Usage
```
Item key: vfs.fs.size[{#FSNAME},pfree]
Trigger: {$LOW_SPACE_LIMIT:"{#FSNAME}"}
```

## Expression Macros

Perform calculations in macro values.

### Syntax
```
{{EXPRESSION}.function()}
```

### Examples
```
{{HOST:system.cpu.load}.last()} > 5
{{ITEM.VALUE}.regsub("pattern", "replacement")}
```

## Macro Functions

Transform macro values during resolution.

### Available Functions
- `regsub(pattern, output)` - Regex substitution
- `iregsub(pattern, output)` - Case-insensitive regex
- `fmtnum(decimals)` - Format number
- `fmttime(format)` - Format time

### Examples
```
{{ITEM.VALUE}.regsub("^([0-9]+)", "\1")}
{{HOST.HOST}.regsub("^([^.]+).*", "\1")}
```

## Type Comparison

| Type | Use Case | Security | Export | Resolution |
|------|----------|----------|--------|------------|
| Plain Text | Non-sensitive config | None | Yes | Direct |
| Secret Text | Masked credentials | Masked | No | Direct |
| Vault Secret | Production secrets | External | No | Vault API |
| Built-in | System information | Read-only | N/A | System |
| LLD | Discovery data | None | Template | Discovery |

## Best Practices

### Choose Appropriate Type
- **Plain Text**: Thresholds, timeouts, non-sensitive URLs
- **Secret Text**: Development passwords, low-security secrets
- **Vault Secrets**: Production credentials, PCI/compliance data

### Naming
- User macros: `{$CATEGORY_DESCRIPTION_SUFFIX}`
- LLD macros: `{#DESCRIPTIVE_NAME}`
- Context: Clear, documented values

### Documentation
- Always describe macro purpose
- Note expected value format
- Document context meanings
- Link related macros
