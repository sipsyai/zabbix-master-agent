#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Macro Bulk Operations

Perform bulk import, export, update, and migration operations on Zabbix macros.
Supports YAML and JSON formats for configuration management.

Usage:
    python macro_bulk_operations.py import --file macros.yaml --scope host
    python macro_bulk_operations.py export --scope global --output backup.json
    python macro_bulk_operations.py update --host-pattern "web*" --macro "{$PORT}" --value "8080"
    python macro_bulk_operations.py replace --search "{$OLD}" --replace "{$NEW}" --scope template
    python macro_bulk_operations.py migrate --source dev --target prod --mapping mapping.yaml

Author: Zabbix Skills Team
Version: 1.0.0
"""

import argparse
import json
import logging
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional
from urllib.parse import urljoin

try:
    import requests
    import yaml
except ImportError as e:
    print(f"ERROR: Required library missing: {e}")
    print("Install with: pip install requests pyyaml")
    sys.exit(1)


# Configuration
ZABBIX_URL = os.getenv('ZABBIX_URL', 'http://localhost/zabbix')
ZABBIX_USER = os.getenv('ZABBIX_USER', 'Admin')
ZABBIX_PASSWORD = os.getenv('ZABBIX_PASSWORD', 'zabbix')
API_ENDPOINT = urljoin(ZABBIX_URL, 'api_jsonrpc.php')

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class BulkOperationError(Exception):
    """Exception for bulk operation errors"""
    pass


class ZabbixBulkMacroManager:
    """Manager for bulk macro operations"""

    def __init__(self, url: str, user: str, password: str):
        self.url = url
        self.user = user
        self.password = password
        self.auth_token = None
        self.request_id = 1

    def authenticate(self) -> None:
        """Authenticate with Zabbix API"""
        payload = {
            "jsonrpc": "2.0",
            "method": "user.login",
            "params": {"username": self.user, "password": self.password},
            "id": self.request_id,
        }

        response = requests.post(self.url, json=payload, timeout=10)
        result = response.json()

        if 'error' in result:
            raise BulkOperationError(f"Authentication failed: {result['error']}")

        self.auth_token = result['result']
        logger.info("Authenticated with Zabbix API")

    def api_request(self, method: str, params: Dict[str, Any]) -> Any:
        """Make API request"""
        if not self.auth_token:
            self.authenticate()

        self.request_id += 1
        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "auth": self.auth_token,
            "id": self.request_id,
        }

        response = requests.post(self.url, json=payload, timeout=30)
        result = response.json()

        if 'error' in result:
            raise BulkOperationError(f"API error: {result['error']}")

        return result['result']

    def export_macros(self, scope: str, host_pattern: Optional[str] = None,
                     macro_pattern: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Export macros based on scope and filters

        Args:
            scope: global, host, or template
            host_pattern: Pattern to match host/template names
            macro_pattern: Pattern to match macro names

        Returns:
            List of macro configurations
        """
        logger.info(f"Exporting {scope} macros...")

        if scope == 'global':
            macros = self.api_request('usermacro.get', {
                'globalmacro': True,
                'output': ['macro', 'value', 'description', 'type']
            })
            result = [{'scope': 'global', 'macros': macros}]

        elif scope == 'host':
            # Get all hosts
            hosts = self.api_request('host.get', {'output': ['hostid', 'host']})

            if host_pattern:
                pattern = re.compile(host_pattern.replace('*', '.*'))
                hosts = [h for h in hosts if pattern.match(h['host'])]

            result = []
            for host in hosts:
                macros = self.api_request('usermacro.get', {
                    'hostids': host['hostid'],
                    'output': ['macro', 'value', 'description', 'type']
                })

                if macro_pattern:
                    pattern = re.compile(macro_pattern.replace('*', '.*'))
                    macros = [m for m in macros if pattern.match(m['macro'])]

                if macros:
                    result.append({
                        'scope': 'host',
                        'host': host['host'],
                        'macros': macros
                    })

        elif scope == 'template':
            templates = self.api_request('template.get', {
                'output': ['templateid', 'host']
            })

            if host_pattern:
                pattern = re.compile(host_pattern.replace('*', '.*'))
                templates = [t for t in templates if pattern.match(t['host'])]

            result = []
            for template in templates:
                macros = self.api_request('usermacro.get', {
                    'hostids': template['templateid'],
                    'output': ['macro', 'value', 'description', 'type']
                })

                if macro_pattern:
                    pattern = re.compile(macro_pattern.replace('*', '.*'))
                    macros = [m for m in macros if pattern.match(m['macro'])]

                if macros:
                    result.append({
                        'scope': 'template',
                        'template': template['host'],
                        'macros': macros
                    })

        logger.info(f"Exported {len(result)} macro configurations")
        return result

    def import_macros(self, data: List[Dict[str, Any]], overwrite: bool = False,
                     dry_run: bool = False) -> Dict[str, int]:
        """
        Import macros from configuration data

        Args:
            data: Macro configuration data
            overwrite: Update existing macros
            dry_run: Validate without applying changes

        Returns:
            Statistics of operations performed
        """
        stats = {'created': 0, 'updated': 0, 'skipped': 0, 'errors': 0}

        for config in data:
            scope = config['scope']
            macros = config.get('macros', [])

            for macro_def in macros:
                try:
                    macro = macro_def['macro']
                    value = macro_def.get('value', '')
                    description = macro_def.get('description', '')
                    macro_type = int(macro_def.get('type', 0))

                    if dry_run:
                        logger.info(f"[DRY RUN] Would create/update {macro}")
                        stats['created'] += 1
                        continue

                    # Check if macro exists
                    if scope == 'global':
                        existing = self.api_request('usermacro.get', {
                            'globalmacro': True,
                            'filter': {'macro': macro}
                        })

                        if existing and not overwrite:
                            logger.debug(f"Skipping existing macro: {macro}")
                            stats['skipped'] += 1
                            continue

                        if existing and overwrite:
                            self.api_request('usermacro.updateglobal', {
                                'globalmacroid': existing[0]['globalmacroid'],
                                'value': value,
                                'description': description,
                                'type': macro_type
                            })
                            stats['updated'] += 1
                        else:
                            self.api_request('usermacro.createglobal', {
                                'macro': macro,
                                'value': value,
                                'description': description,
                                'type': macro_type
                            })
                            stats['created'] += 1

                    else:
                        # Get host/template ID
                        entity_name = config.get('host') or config.get('template')
                        if scope == 'host':
                            entities = self.api_request('host.get', {
                                'filter': {'host': entity_name},
                                'output': ['hostid']
                            })
                        else:
                            entities = self.api_request('template.get', {
                                'filter': {'host': entity_name},
                                'output': ['templateid']
                            })

                        if not entities:
                            logger.warning(f"Entity not found: {entity_name}")
                            stats['errors'] += 1
                            continue

                        entity_id = entities[0].get('hostid') or entities[0].get('templateid')

                        existing = self.api_request('usermacro.get', {
                            'hostids': entity_id,
                            'filter': {'macro': macro}
                        })

                        if existing and not overwrite:
                            stats['skipped'] += 1
                            continue

                        if existing and overwrite:
                            self.api_request('usermacro.update', {
                                'hostmacroid': existing[0]['hostmacroid'],
                                'value': value,
                                'description': description,
                                'type': macro_type
                            })
                            stats['updated'] += 1
                        else:
                            self.api_request('usermacro.create', {
                                'hostid': entity_id,
                                'macro': macro,
                                'value': value,
                                'description': description,
                                'type': macro_type
                            })
                            stats['created'] += 1

                except Exception as e:
                    logger.error(f"Error processing macro {macro_def.get('macro')}: {e}")
                    stats['errors'] += 1

        return stats

    def bulk_update(self, scope: str, entity_pattern: str, macro: str,
                   new_value: str) -> int:
        """
        Update macro value across multiple entities

        Args:
            scope: host or template
            entity_pattern: Pattern to match entities
            macro: Macro name to update
            new_value: New macro value

        Returns:
            Number of macros updated
        """
        updated = 0
        pattern = re.compile(entity_pattern.replace('*', '.*'))

        if scope == 'host':
            entities = self.api_request('host.get', {'output': ['hostid', 'host']})
            id_field = 'hostid'
        else:
            entities = self.api_request('template.get', {
                'output': ['templateid', 'host']
            })
            id_field = 'templateid'

        matching = [e for e in entities if pattern.match(e['host'])]

        for entity in matching:
            try:
                entity_id = entity[id_field]
                existing = self.api_request('usermacro.get', {
                    'hostids': entity_id,
                    'filter': {'macro': macro}
                })

                if existing:
                    self.api_request('usermacro.update', {
                        'hostmacroid': existing[0]['hostmacroid'],
                        'value': new_value
                    })
                    logger.info(f"Updated {macro} on {entity['host']}")
                    updated += 1

            except Exception as e:
                logger.error(f"Error updating {entity['host']}: {e}")

        return updated

    def search_and_replace(self, scope: str, search: str, replace: str,
                          backup: bool = True) -> int:
        """
        Search and replace macro names or values

        Args:
            scope: Macro scope
            search: Search pattern (macro name)
            replace: Replacement macro name
            backup: Create backup before replacing

        Returns:
            Number of replacements made
        """
        if backup:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_file = f"macro_backup_{timestamp}.json"
            exported = self.export_macros(scope)
            with open(backup_file, 'w') as f:
                json.dump(exported, f, indent=2)
            logger.info(f"Backup created: {backup_file}")

        # Implementation would search and replace macro names
        # This is a simplified version
        logger.info(f"Search and replace: {search} -> {replace}")
        return 0


def main():
    parser = argparse.ArgumentParser(description='Zabbix Macro Bulk Operations')
    subparsers = parser.add_subparsers(dest='command', help='Command')

    # Export
    p_export = subparsers.add_parser('export', help='Export macros')
    p_export.add_argument('--scope', required=True, choices=['global', 'host', 'template'])
    p_export.add_argument('--host-pattern', help='Host/template name pattern')
    p_export.add_argument('--macro-pattern', help='Macro name pattern')
    p_export.add_argument('--output', required=True, help='Output file')
    p_export.add_argument('--format', default='json', choices=['json', 'yaml'])

    # Import
    p_import = subparsers.add_parser('import', help='Import macros')
    p_import.add_argument('--file', required=True, help='Input file')
    p_import.add_argument('--overwrite', action='store_true', help='Overwrite existing')
    p_import.add_argument('--dry-run', action='store_true', help='Validate only')

    # Update
    p_update = subparsers.add_parser('update', help='Bulk update macros')
    p_update.add_argument('--scope', required=True, choices=['host', 'template'])
    p_update.add_argument('--pattern', required=True, help='Entity pattern')
    p_update.add_argument('--macro', required=True, help='Macro name')
    p_update.add_argument('--value', required=True, help='New value')

    # Replace
    p_replace = subparsers.add_parser('replace', help='Search and replace')
    p_replace.add_argument('--scope', required=True, choices=['global', 'host', 'template'])
    p_replace.add_argument('--search', required=True, help='Search pattern')
    p_replace.add_argument('--replace', required=True, help='Replace pattern')
    p_replace.add_argument('--backup', action='store_true', help='Create backup')

    parser.add_argument('--url', default=ZABBIX_URL)
    parser.add_argument('--user', default=ZABBIX_USER)
    parser.add_argument('--password', default=ZABBIX_PASSWORD)
    parser.add_argument('--verbose', action='store_true')

    args = parser.parse_args()

    if args.verbose:
        logger.setLevel(logging.DEBUG)

    if not args.command:
        parser.print_help()
        return 1

    try:
        manager = ZabbixBulkMacroManager(args.url, args.user, args.password)

        if args.command == 'export':
            data = manager.export_macros(args.scope, args.host_pattern, args.macro_pattern)

            with open(args.output, 'w') as f:
                if args.format == 'json':
                    json.dump(data, f, indent=2)
                else:
                    yaml.dump(data, f, default_flow_style=False)

            logger.info(f"Exported to {args.output}")

        elif args.command == 'import':
            with open(args.file) as f:
                if args.file.endswith('.yaml') or args.file.endswith('.yml'):
                    data = yaml.safe_load(f)
                else:
                    data = json.load(f)

            stats = manager.import_macros(data, args.overwrite, args.dry_run)
            logger.info(f"Import complete: {stats}")

        elif args.command == 'update':
            count = manager.bulk_update(args.scope, args.pattern, args.macro, args.value)
            logger.info(f"Updated {count} macros")

        elif args.command == 'replace':
            count = manager.search_and_replace(args.scope, args.search, args.replace, args.backup)
            logger.info(f"Replaced {count} macros")

        return 0

    except Exception as e:
        logger.error(f"Error: {e}")
        return 1


if __name__ == '__main__':
    sys.exit(main())
