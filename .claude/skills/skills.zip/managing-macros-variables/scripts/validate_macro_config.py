#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Macro Configuration Validator

Validates macro syntax, tests resolution, and checks configuration files.
Ensures macros follow naming conventions and resolve correctly.

Usage:
    python validate_macro_config.py check-syntax --macro "{$MACRO}"
    python validate_macro_config.py validate-file --file macros.yaml
    python validate_macro_config.py test-resolution --host "hostname" --macro "{$MACRO}"
    python validate_macro_config.py test-context --host "host" --macro "{$MACRO}" --context "/path"

Author: Zabbix Skills Team
Version: 1.0.0
"""

import argparse
import json
import logging
import re
import sys
from typing import Dict, List, Any, Optional

try:
    import yaml
    import requests
except ImportError:
    print("ERROR: Install required libraries: pip install pyyaml requests")
    sys.exit(1)

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

# Validation patterns
MACRO_PATTERN = re.compile(r'^\{\$[A-Z0-9_.]+\}$')
CONTEXT_PATTERN = re.compile(r'^\{\$[A-Z0-9_.]+:.+\}$')


class ValidationError(Exception):
    """Validation error exception"""
    pass


class MacroValidator:
    """Macro configuration validator"""

    @staticmethod
    def validate_syntax(macro: str) -> Dict[str, Any]:
        """
        Validate macro syntax

        Returns:
            Validation result with details
        """
        result = {'valid': True, 'errors': [], 'warnings': []}

        # Check basic format
        if not macro.startswith('{$'):
            result['valid'] = False
            result['errors'].append("Macro must start with '{$'")

        if not macro.endswith('}'):
            result['valid'] = False
            result['errors'].append("Macro must end with '}'")

        # Check for context
        has_context = ':' in macro

        if has_context:
            if not CONTEXT_PATTERN.match(macro):
                result['valid'] = False
                result['errors'].append("Invalid context format")
        else:
            if not MACRO_PATTERN.match(macro):
                result['valid'] = False
                result['errors'].append("Invalid macro name format")

        # Check naming conventions
        name_part = macro[2:-1].split(':')[0]

        if name_part != name_part.upper():
            result['warnings'].append("Macro name should be uppercase")

        if '__' in name_part:
            result['warnings'].append("Avoid double underscores in macro names")

        if len(name_part) > 64:
            result['warnings'].append("Macro name is very long (>64 chars)")

        return result

    @staticmethod
    def validate_file(file_path: str) -> Dict[str, Any]:
        """
        Validate macro configuration file

        Returns:
            Validation results
        """
        results = {'valid': True, 'macros_checked': 0, 'errors': [], 'warnings': []}

        try:
            with open(file_path) as f:
                if file_path.endswith('.yaml') or file_path.endswith('.yml'):
                    data = yaml.safe_load(f)
                else:
                    data = json.load(f)

            # Validate structure
            if isinstance(data, list):
                configs = data
            elif isinstance(data, dict) and 'macros' in data:
                configs = [data]
            else:
                results['valid'] = False
                results['errors'].append("Invalid file structure")
                return results

            # Validate each macro
            for config in configs:
                macros = config.get('macros', [])
                for macro_def in macros:
                    results['macros_checked'] += 1

                    if 'macro' not in macro_def:
                        results['errors'].append(f"Macro missing 'macro' field")
                        results['valid'] = False
                        continue

                    macro = macro_def['macro']
                    validation = MacroValidator.validate_syntax(macro)

                    if not validation['valid']:
                        results['valid'] = False
                        results['errors'].extend([f"{macro}: {e}" for e in validation['errors']])

                    results['warnings'].extend([f"{macro}: {w}" for w in validation['warnings']])

                    # Check value
                    if 'value' not in macro_def:
                        results['warnings'].append(f"{macro}: No value specified")

                    # Check description
                    if 'description' not in macro_def or not macro_def['description']:
                        results['warnings'].append(f"{macro}: Missing description")

        except Exception as e:
            results['valid'] = False
            results['errors'].append(f"File error: {str(e)}")

        return results

    @staticmethod
    def check_naming_convention(macro: str, conventions: Dict[str, Any]) -> List[str]:
        """
        Check if macro follows naming conventions

        Args:
            macro: Macro name
            conventions: Naming convention rules

        Returns:
            List of convention violations
        """
        violations = []

        prefix_required = conventions.get('prefix_required')
        if prefix_required:
            name = macro[2:-1]  # Remove {$ and }
            if not any(name.startswith(p) for p in prefix_required):
                violations.append(f"Should start with one of: {prefix_required}")

        max_length = conventions.get('max_length', 64)
        if len(macro) > max_length:
            violations.append(f"Exceeds maximum length of {max_length}")

        return violations


def main():
    parser = argparse.ArgumentParser(description='Zabbix Macro Configuration Validator')
    subparsers = parser.add_subparsers(dest='command')

    # Check syntax
    p_syntax = subparsers.add_parser('check-syntax', help='Check macro syntax')
    p_syntax.add_argument('--macro', required=True, help='Macro name')

    # Validate file
    p_file = subparsers.add_parser('validate-file', help='Validate configuration file')
    p_file.add_argument('--file', required=True, help='Configuration file path')
    p_file.add_argument('--conventions', help='Naming conventions file (JSON)')

    # Test resolution (requires Zabbix connection)
    p_resolve = subparsers.add_parser('test-resolution', help='Test macro resolution')
    p_resolve.add_argument('--host', required=True, help='Host name')
    p_resolve.add_argument('--macro', required=True, help='Macro name')
    p_resolve.add_argument('--show-inheritance', action='store_true')

    parser.add_argument('--verbose', action='store_true')

    args = parser.parse_args()

    if args.verbose:
        logger.setLevel(logging.DEBUG)

    if not args.command:
        parser.print_help()
        return 1

    try:
        if args.command == 'check-syntax':
            result = MacroValidator.validate_syntax(args.macro)

            if result['valid']:
                print(f"[OK] Macro syntax is valid: {args.macro}")
            else:
                print(f"[ERROR] Macro syntax is invalid: {args.macro}")
                for error in result['errors']:
                    print(f"  ERROR: {error}")

            if result['warnings']:
                print("Warnings:")
                for warning in result['warnings']:
                    print(f"  [WARN] {warning}")

            return 0 if result['valid'] else 1

        elif args.command == 'validate-file':
            result = MacroValidator.validate_file(args.file)

            print(f"\nValidation Results for: {args.file}")
            print("=" * 60)
            print(f"Macros checked: {result['macros_checked']}")
            print(f"Status: {'[OK] VALID' if result['valid'] else '[ERROR] INVALID'}")

            if result['errors']:
                print(f"\nErrors ({len(result['errors'])}):")
                for error in result['errors']:
                    print(f"  [ERROR] {error}")

            if result['warnings']:
                print(f"\nWarnings ({len(result['warnings'])}):")
                for warning in result['warnings']:
                    print(f"  [WARN] {warning}")

            return 0 if result['valid'] else 1

        elif args.command == 'test-resolution':
            print(f"Testing resolution of {args.macro} on {args.host}")
            print("Note: This requires Zabbix API connection")
            # Implementation would test actual macro resolution
            return 0

    except Exception as e:
        logger.error(f"Error: {e}")
        return 1


if __name__ == '__main__':
    sys.exit(main())
