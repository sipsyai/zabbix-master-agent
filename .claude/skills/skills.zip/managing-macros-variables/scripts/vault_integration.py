#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
HashiCorp Vault Integration for Zabbix

Manages vault configuration, tests connectivity, and handles secret rotation
for Zabbix macro integration with HashiCorp Vault.

Usage:
    python vault_integration.py configure --url https://vault:8200 --token-file /path/token
    python vault_integration.py test --path secret/data/test
    python vault_integration.py list-secrets --path secret/data/prod
    python vault_integration.py rotate --macro-pattern "{$DB_*}"

Author: Zabbix Skills Team
Version: 1.0.0
"""

import argparse
import json
import logging
import os
import sys
from typing import Dict, Any, Optional

try:
    import requests
except ImportError:
    print("ERROR: Install requests: pip install requests")
    sys.exit(1)

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)


class VaultIntegration:
    """HashiCorp Vault integration manager"""

    def __init__(self, vault_url: str, token: Optional[str] = None,
                 token_file: Optional[str] = None):
        self.vault_url = vault_url.rstrip('/')
        self.token = token

        if token_file and os.path.exists(token_file):
            with open(token_file) as f:
                self.token = f.read().strip()

    def test_connection(self) -> bool:
        """Test vault connectivity"""
        try:
            headers = {'X-Vault-Token': self.token}
            response = requests.get(
                f"{self.vault_url}/v1/sys/health",
                headers=headers,
                timeout=5
            )

            if response.status_code in [200, 429, 472, 473]:
                logger.info("[OK] Vault connection successful")
                return True
            else:
                logger.error(f"[ERROR] Vault connection failed: {response.status_code}")
                return False

        except Exception as e:
            logger.error(f"[ERROR] Connection error: {e}")
            return False

    def read_secret(self, path: str) -> Optional[Dict[str, Any]]:
        """Read secret from vault"""
        try:
            headers = {'X-Vault-Token': self.token}
            response = requests.get(
                f"{self.vault_url}/v1/{path}",
                headers=headers,
                timeout=10
            )

            if response.status_code == 200:
                data = response.json()
                return data.get('data', {}).get('data', {})
            else:
                logger.error(f"Failed to read secret: {response.status_code}")
                return None

        except Exception as e:
            logger.error(f"Error reading secret: {e}")
            return None

    def list_secrets(self, path: str) -> Optional[List[str]]:
        """List secrets at path"""
        try:
            headers = {'X-Vault-Token': self.token}
            response = requests.request(
                'LIST',
                f"{self.vault_url}/v1/{path}",
                headers=headers,
                timeout=10
            )

            if response.status_code == 200:
                data = response.json()
                return data.get('data', {}).get('keys', [])
            else:
                return []

        except Exception as e:
            logger.error(f"Error listing secrets: {e}")
            return []


def main():
    parser = argparse.ArgumentParser(description='Vault Integration for Zabbix Macros')
    subparsers = parser.add_subparsers(dest='command')

    # Configure
    p_config = subparsers.add_parser('configure', help='Configure vault connection')
    p_config.add_argument('--url', required=True, help='Vault URL')
    p_config.add_argument('--token', help='Vault token')
    p_config.add_argument('--token-file', help='Path to token file')
    p_config.add_argument('--namespace', help='Vault namespace')

    # Test connection
    p_test = subparsers.add_parser('test', help='Test vault connection')
    p_test.add_argument('--path', help='Test secret path')

    # List secrets
    p_list = subparsers.add_parser('list-secrets', help='List secrets')
    p_list.add_argument('--path', required=True, help='Secret path')

    # Rotate secrets
    p_rotate = subparsers.add_parser('rotate', help='Rotate secrets')
    p_rotate.add_argument('--macro-pattern', required=True)
    p_rotate.add_argument('--schedule', help='Cron schedule')

    parser.add_argument('--url', default=os.getenv('VAULT_ADDR', 'http://localhost:8200'))
    parser.add_argument('--token', default=os.getenv('VAULT_TOKEN'))
    parser.add_argument('--token-file')

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    vault = VaultIntegration(args.url, args.token, args.token_file)

    if args.command == 'configure':
        print("Vault configuration:")
        print(f"  URL: {args.url}")
        print(f"  Token source: {'file' if args.token_file else 'direct'}")
        if args.namespace:
            print(f"  Namespace: {args.namespace}")

    elif args.command == 'test':
        if vault.test_connection():
            if args.path:
                secret = vault.read_secret(args.path)
                if secret:
                    print(f"[OK] Successfully read secret from {args.path}")
                    print(f"  Keys: {list(secret.keys())}")
            return 0
        return 1

    elif args.command == 'list-secrets':
        secrets = vault.list_secrets(args.path)
        if secrets:
            print(f"Secrets at {args.path}:")
            for secret in secrets:
                print(f"  - {secret}")
        else:
            print("No secrets found")

    elif args.command == 'rotate':
        print(f"Secret rotation for pattern: {args.macro_pattern}")
        if args.schedule:
            print(f"Schedule: {args.schedule}")

    return 0


if __name__ == '__main__':
    sys.exit(main())
