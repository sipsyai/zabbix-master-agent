#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Macro Manager

Comprehensive macro management tool for Zabbix supporting global, host, and template macros.
Handles creation, update, deletion, and retrieval of user macros with full validation.

Usage:
    python zabbix_macro_manager.py create-global --macro "{$MACRO}" --value "value"
    python zabbix_macro_manager.py create-host --host "hostname" --macro "{$MACRO}" --value "value"
    python zabbix_macro_manager.py create-template --template "template" --macro "{$MACRO}" --value "value"
    python zabbix_macro_manager.py update-global --macro "{$MACRO}" --value "new_value"
    python zabbix_macro_manager.py delete-global --macro "{$MACRO}"
    python zabbix_macro_manager.py list-all --scope global|host|template
    python zabbix_macro_manager.py get --macro "{$MACRO}" --host "hostname"

Author: Zabbix Skills Team
Version: 1.0.0
"""

import argparse
import json
import logging
import os
import re
import sys
from typing import Dict, List, Optional, Any
from urllib.parse import urljoin

try:
    import requests
    from requests.auth import HTTPBasicAuth
except ImportError:
    print("ERROR: 'requests' library is required. Install with: pip install requests")
    sys.exit(1)


# Configuration constants
ZABBIX_URL = os.getenv('ZABBIX_URL', 'http://localhost/zabbix')
ZABBIX_USER = os.getenv('ZABBIX_USER', 'Admin')
ZABBIX_PASSWORD = os.getenv('ZABBIX_PASSWORD', 'zabbix')
API_ENDPOINT = urljoin(ZABBIX_URL, 'api_jsonrpc.php')

# Macro validation regex
MACRO_NAME_PATTERN = re.compile(r'^\{\$[A-Z0-9_.]+\}$')
MACRO_CONTEXT_PATTERN = re.compile(r'^\{\$[A-Z0-9_.]+:[^\}]+\}$')

# Logging configuration
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ZabbixAPIError(Exception):
    """Custom exception for Zabbix API errors"""
    pass


class MacroValidationError(Exception):
    """Custom exception for macro validation errors"""
    pass


class ZabbixMacroManager:
    """Manager class for Zabbix macro operations"""

    def __init__(self, url: str, user: str, password: str):
        """
        Initialize Zabbix Macro Manager

        Args:
            url: Zabbix API URL
            user: Zabbix username
            password: Zabbix password
        """
        self.url = url
        self.user = user
        self.password = password
        self.auth_token = None
        self.request_id = 1

    def authenticate(self) -> None:
        """Authenticate with Zabbix API and obtain auth token"""
        payload = {
            "jsonrpc": "2.0",
            "method": "user.login",
            "params": {
                "username": self.user,
                "password": self.password
            },
            "id": self.request_id,
        }

        try:
            response = requests.post(self.url, json=payload, timeout=10)
            response.raise_for_status()
            result = response.json()

            if 'error' in result:
                raise ZabbixAPIError(f"Authentication failed: {result['error']['data']}")

            self.auth_token = result['result']
            logger.info("Successfully authenticated with Zabbix API")

        except requests.RequestException as e:
            raise ZabbixAPIError(f"Failed to connect to Zabbix API: {str(e)}")

    def api_request(self, method: str, params: Dict[str, Any]) -> Any:
        """
        Make API request to Zabbix

        Args:
            method: API method name
            params: Method parameters

        Returns:
            API response result
        """
        if not self.auth_token:
            self.authenticate()

        self.request_id += 1
        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "auth": self.auth_token,
            "id": self.request_id,
        }

        try:
            response = requests.post(self.url, json=payload, timeout=30)
            response.raise_for_status()
            result = response.json()

            if 'error' in result:
                error_msg = result['error'].get('data', result['error'].get('message', 'Unknown error'))
                raise ZabbixAPIError(f"API request failed: {error_msg}")

            return result['result']

        except requests.RequestException as e:
            raise ZabbixAPIError(f"API request failed: {str(e)}")

    @staticmethod
    def validate_macro_name(macro: str, allow_context: bool = False) -> None:
        """
        Validate macro name syntax

        Args:
            macro: Macro name to validate
            allow_context: Whether to allow context in macro name

        Raises:
            MacroValidationError: If macro name is invalid
        """
        if not macro:
            raise MacroValidationError("Macro name cannot be empty")

        # Check basic format
        if not macro.startswith('{$') or not macro.endswith('}'):
            raise MacroValidationError(
                f"Invalid macro format: '{macro}'. Must be wrapped in {{$ }}"
            )

        # Check if context exists
        has_context = ':' in macro

        if has_context and not allow_context:
            raise MacroValidationError(
                f"Macro '{macro}' contains context but context is not allowed in this operation"
            )

        # Validate based on pattern
        if has_context:
            if not MACRO_CONTEXT_PATTERN.match(macro):
                raise MacroValidationError(
                    f"Invalid macro with context: '{macro}'. Format: {{$NAME:context}}"
                )
        else:
            if not MACRO_NAME_PATTERN.match(macro):
                raise MacroValidationError(
                    f"Invalid macro name: '{macro}'. Allowed characters: A-Z, 0-9, _, ."
                )

    @staticmethod
    def validate_macro_value(value: str, max_length: int = 2048) -> None:
        """
        Validate macro value

        Args:
            value: Macro value to validate
            max_length: Maximum allowed length

        Raises:
            MacroValidationError: If value is invalid
        """
        if value is None:
            raise MacroValidationError("Macro value cannot be None")

        if len(value) > max_length:
            raise MacroValidationError(
                f"Macro value exceeds maximum length of {max_length} characters"
            )

    def get_host_id(self, host_name: str) -> str:
        """
        Get host ID by name

        Args:
            host_name: Host name

        Returns:
            Host ID
        """
        result = self.api_request('host.get', {
            'filter': {'host': host_name},
            'output': ['hostid']
        })

        if not result:
            raise ZabbixAPIError(f"Host not found: {host_name}")

        return result[0]['hostid']

    def get_template_id(self, template_name: str) -> str:
        """
        Get template ID by name

        Args:
            template_name: Template name

        Returns:
            Template ID
        """
        result = self.api_request('template.get', {
            'filter': {'host': template_name},
            'output': ['templateid']
        })

        if not result:
            raise ZabbixAPIError(f"Template not found: {template_name}")

        return result[0]['templateid']

    def create_global_macro(self, macro: str, value: str, description: str = "") -> str:
        """
        Create global macro

        Args:
            macro: Macro name (e.g., {$MACRO})
            value: Macro value
            description: Macro description

        Returns:
            Created macro ID
        """
        self.validate_macro_name(macro, allow_context=False)
        self.validate_macro_value(value)

        params = {
            'macro': macro,
            'value': value
        }

        if description:
            params['description'] = description

        result = self.api_request('usermacro.createglobal', params)

        macro_id = result['globalmacroids'][0]
        logger.info(f"Created global macro: {macro} (ID: {macro_id})")
        return macro_id

    def create_host_macro(self, host_name: str, macro: str, value: str,
                          description: str = "") -> str:
        """
        Create host-level macro

        Args:
            host_name: Host name
            macro: Macro name
            value: Macro value
            description: Macro description

        Returns:
            Created macro ID
        """
        self.validate_macro_name(macro, allow_context=False)
        self.validate_macro_value(value)

        host_id = self.get_host_id(host_name)

        params = {
            'hostid': host_id,
            'macro': macro,
            'value': value
        }

        if description:
            params['description'] = description

        result = self.api_request('usermacro.create', params)

        macro_id = result['hostmacroids'][0]
        logger.info(f"Created host macro: {macro} on {host_name} (ID: {macro_id})")
        return macro_id

    def create_template_macro(self, template_name: str, macro: str, value: str,
                             description: str = "") -> str:
        """
        Create template-level macro

        Args:
            template_name: Template name
            macro: Macro name
            value: Macro value
            description: Macro description

        Returns:
            Created macro ID
        """
        self.validate_macro_name(macro, allow_context=False)
        self.validate_macro_value(value)

        template_id = self.get_template_id(template_name)

        params = {
            'hostid': template_id,  # Templates use hostid parameter
            'macro': macro,
            'value': value
        }

        if description:
            params['description'] = description

        result = self.api_request('usermacro.create', params)

        macro_id = result['hostmacroids'][0]
        logger.info(f"Created template macro: {macro} on {template_name} (ID: {macro_id})")
        return macro_id

    def update_global_macro(self, macro: str, value: Optional[str] = None,
                           description: Optional[str] = None) -> str:
        """
        Update global macro

        Args:
            macro: Macro name
            value: New macro value (optional)
            description: New description (optional)

        Returns:
            Updated macro ID
        """
        # Get existing macro
        existing = self.api_request('usermacro.get', {
            'globalmacro': True,
            'filter': {'macro': macro},
            'output': ['globalmacroid']
        })

        if not existing:
            raise ZabbixAPIError(f"Global macro not found: {macro}")

        macro_id = existing[0]['globalmacroid']

        params = {'globalmacroid': macro_id}

        if value is not None:
            self.validate_macro_value(value)
            params['value'] = value

        if description is not None:
            params['description'] = description

        result = self.api_request('usermacro.updateglobal', params)

        logger.info(f"Updated global macro: {macro}")
        return macro_id

    def update_host_macro(self, host_name: str, macro: str, value: Optional[str] = None,
                         description: Optional[str] = None) -> str:
        """
        Update host-level macro

        Args:
            host_name: Host name
            macro: Macro name
            value: New macro value (optional)
            description: New description (optional)

        Returns:
            Updated macro ID
        """
        host_id = self.get_host_id(host_name)

        # Get existing macro
        existing = self.api_request('usermacro.get', {
            'hostids': host_id,
            'filter': {'macro': macro},
            'output': ['hostmacroid']
        })

        if not existing:
            raise ZabbixAPIError(f"Host macro not found: {macro} on {host_name}")

        macro_id = existing[0]['hostmacroid']

        params = {'hostmacroid': macro_id}

        if value is not None:
            self.validate_macro_value(value)
            params['value'] = value

        if description is not None:
            params['description'] = description

        result = self.api_request('usermacro.update', params)

        logger.info(f"Updated host macro: {macro} on {host_name}")
        return macro_id

    def delete_global_macro(self, macro: str) -> bool:
        """
        Delete global macro

        Args:
            macro: Macro name

        Returns:
            True if successful
        """
        # Get macro ID
        existing = self.api_request('usermacro.get', {
            'globalmacro': True,
            'filter': {'macro': macro},
            'output': ['globalmacroid']
        })

        if not existing:
            raise ZabbixAPIError(f"Global macro not found: {macro}")

        macro_id = existing[0]['globalmacroid']

        self.api_request('usermacro.deleteglobal', [macro_id])

        logger.info(f"Deleted global macro: {macro}")
        return True

    def delete_host_macro(self, host_name: str, macro: str) -> bool:
        """
        Delete host-level macro

        Args:
            host_name: Host name
            macro: Macro name

        Returns:
            True if successful
        """
        host_id = self.get_host_id(host_name)

        # Get macro ID
        existing = self.api_request('usermacro.get', {
            'hostids': host_id,
            'filter': {'macro': macro},
            'output': ['hostmacroid']
        })

        if not existing:
            raise ZabbixAPIError(f"Host macro not found: {macro} on {host_name}")

        macro_id = existing[0]['hostmacroid']

        self.api_request('usermacro.delete', [macro_id])

        logger.info(f"Deleted host macro: {macro} on {host_name}")
        return True

    def list_global_macros(self, output_format: str = 'table') -> List[Dict[str, Any]]:
        """
        List all global macros

        Args:
            output_format: Output format (table, json, yaml)

        Returns:
            List of global macros
        """
        macros = self.api_request('usermacro.get', {
            'globalmacro': True,
            'output': ['macro', 'value', 'description', 'type'],
            'sortfield': 'macro'
        })

        self._format_output(macros, output_format, "Global Macros")
        return macros

    def list_host_macros(self, host_name: str, output_format: str = 'table') -> List[Dict[str, Any]]:
        """
        List all macros for a host

        Args:
            host_name: Host name
            output_format: Output format

        Returns:
            List of host macros
        """
        host_id = self.get_host_id(host_name)

        macros = self.api_request('usermacro.get', {
            'hostids': host_id,
            'output': ['macro', 'value', 'description', 'type'],
            'sortfield': 'macro'
        })

        self._format_output(macros, output_format, f"Macros for host: {host_name}")
        return macros

    def get_macro_resolution(self, host_name: str, macro: str) -> Dict[str, Any]:
        """
        Get macro resolution details showing inheritance chain

        Args:
            host_name: Host name
            macro: Macro name

        Returns:
            Macro resolution details
        """
        host_id = self.get_host_id(host_name)

        # Get host macros
        host_macros = self.api_request('usermacro.get', {
            'hostids': host_id,
            'filter': {'macro': macro},
            'output': ['macro', 'value', 'description']
        })

        # Get templates for host
        templates = self.api_request('template.get', {
            'hostids': host_id,
            'output': ['templateid', 'host'],
            'sortfield': 'templateid'
        })

        # Get template macros
        template_macros = []
        for template in templates:
            tmpl_macros = self.api_request('usermacro.get', {
                'hostids': template['templateid'],
                'filter': {'macro': macro},
                'output': ['macro', 'value', 'description']
            })
            if tmpl_macros:
                template_macros.append({
                    'template': template['host'],
                    'template_id': template['templateid'],
                    'macro': tmpl_macros[0]
                })

        # Get global macros
        global_macros = self.api_request('usermacro.get', {
            'globalmacro': True,
            'filter': {'macro': macro},
            'output': ['macro', 'value', 'description']
        })

        return {
            'macro': macro,
            'host': host_name,
            'host_macro': host_macros[0] if host_macros else None,
            'template_macros': template_macros,
            'global_macro': global_macros[0] if global_macros else None,
            'resolved_value': (
                host_macros[0]['value'] if host_macros else
                template_macros[0]['macro']['value'] if template_macros else
                global_macros[0]['value'] if global_macros else
                None
            )
        }

    @staticmethod
    def _format_output(data: List[Dict[str, Any]], output_format: str, title: str) -> None:
        """Format and print output"""
        if output_format == 'json':
            print(json.dumps(data, indent=2))
        elif output_format == 'table':
            print(f"\n{title}")
            print("=" * 80)
            if not data:
                print("No macros found")
                return

            for macro in data:
                print(f"\nMacro: {macro['macro']}")
                value = macro.get('value', '')
                # Mask secret macros
                if macro.get('type') == '1':
                    value = '******'
                print(f"Value: {value}")
                if macro.get('description'):
                    print(f"Description: {macro['description']}")
                print("-" * 80)


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='Zabbix Macro Manager - Manage user macros in Zabbix',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    subparsers = parser.add_subparsers(dest='command', help='Command to execute')

    # Create global macro
    parser_create_global = subparsers.add_parser('create-global', help='Create global macro')
    parser_create_global.add_argument('--macro', required=True, help='Macro name')
    parser_create_global.add_argument('--value', required=True, help='Macro value')
    parser_create_global.add_argument('--description', default='', help='Macro description')

    # Create host macro
    parser_create_host = subparsers.add_parser('create-host', help='Create host macro')
    parser_create_host.add_argument('--host', required=True, help='Host name')
    parser_create_host.add_argument('--macro', required=True, help='Macro name')
    parser_create_host.add_argument('--value', required=True, help='Macro value')
    parser_create_host.add_argument('--description', default='', help='Macro description')

    # Create template macro
    parser_create_template = subparsers.add_parser('create-template', help='Create template macro')
    parser_create_template.add_argument('--template', required=True, help='Template name')
    parser_create_template.add_argument('--macro', required=True, help='Macro name')
    parser_create_template.add_argument('--value', required=True, help='Macro value')
    parser_create_template.add_argument('--description', default='', help='Macro description')

    # Update global macro
    parser_update_global = subparsers.add_parser('update-global', help='Update global macro')
    parser_update_global.add_argument('--macro', required=True, help='Macro name')
    parser_update_global.add_argument('--value', help='New macro value')
    parser_update_global.add_argument('--description', help='New description')

    # Update host macro
    parser_update_host = subparsers.add_parser('update-host', help='Update host macro')
    parser_update_host.add_argument('--host', required=True, help='Host name')
    parser_update_host.add_argument('--macro', required=True, help='Macro name')
    parser_update_host.add_argument('--value', help='New macro value')
    parser_update_host.add_argument('--description', help='New description')

    # Delete global macro
    parser_delete_global = subparsers.add_parser('delete-global', help='Delete global macro')
    parser_delete_global.add_argument('--macro', required=True, help='Macro name')

    # Delete host macro
    parser_delete_host = subparsers.add_parser('delete-host', help='Delete host macro')
    parser_delete_host.add_argument('--host', required=True, help='Host name')
    parser_delete_host.add_argument('--macro', required=True, help='Macro name')

    # List macros
    parser_list = subparsers.add_parser('list', help='List macros')
    parser_list.add_argument('--scope', required=True, choices=['global', 'host'],
                            help='Macro scope')
    parser_list.add_argument('--host', help='Host name (required for host scope)')
    parser_list.add_argument('--format', default='table', choices=['table', 'json'],
                            help='Output format')

    # Get macro resolution
    parser_resolve = subparsers.add_parser('resolve', help='Show macro resolution chain')
    parser_resolve.add_argument('--host', required=True, help='Host name')
    parser_resolve.add_argument('--macro', required=True, help='Macro name')

    # Common arguments
    parser.add_argument('--url', default=ZABBIX_URL, help='Zabbix URL')
    parser.add_argument('--user', default=ZABBIX_USER, help='Zabbix username')
    parser.add_argument('--password', default=ZABBIX_PASSWORD, help='Zabbix password')
    parser.add_argument('--verbose', action='store_true', help='Verbose output')

    args = parser.parse_args()

    if args.verbose:
        logger.setLevel(logging.DEBUG)

    if not args.command:
        parser.print_help()
        return 1

    try:
        manager = ZabbixMacroManager(args.url, args.user, args.password)

        if args.command == 'create-global':
            manager.create_global_macro(args.macro, args.value, args.description)

        elif args.command == 'create-host':
            manager.create_host_macro(args.host, args.macro, args.value, args.description)

        elif args.command == 'create-template':
            manager.create_template_macro(args.template, args.macro, args.value, args.description)

        elif args.command == 'update-global':
            manager.update_global_macro(args.macro, args.value, args.description)

        elif args.command == 'update-host':
            manager.update_host_macro(args.host, args.macro, args.value, args.description)

        elif args.command == 'delete-global':
            manager.delete_global_macro(args.macro)

        elif args.command == 'delete-host':
            manager.delete_host_macro(args.host, args.macro)

        elif args.command == 'list':
            if args.scope == 'global':
                manager.list_global_macros(args.format)
            elif args.scope == 'host':
                if not args.host:
                    print("ERROR: --host is required for host scope")
                    return 1
                manager.list_host_macros(args.host, args.format)

        elif args.command == 'resolve':
            resolution = manager.get_macro_resolution(args.host, args.macro)
            print(json.dumps(resolution, indent=2))

        return 0

    except (ZabbixAPIError, MacroValidationError) as e:
        logger.error(str(e))
        return 1
    except KeyboardInterrupt:
        logger.info("Operation cancelled by user")
        return 130
    except Exception as e:
        logger.exception(f"Unexpected error: {str(e)}")
        return 1


if __name__ == '__main__':
    sys.exit(main())
