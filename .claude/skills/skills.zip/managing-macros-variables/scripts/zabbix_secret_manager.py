#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Secret Macro Manager

Manages secret macros in Zabbix including secret text and vault secrets.
Supports HashiCorp Vault and CyberArk integration for secure credential storage.

Usage:
    python zabbix_secret_manager.py create-secret --host "hostname" --macro "{$MACRO}" --value "secret" --type secret_text
    python zabbix_secret_manager.py create-vault-secret --host "hostname" --macro "{$MACRO}" --vault-path "path"
    python zabbix_secret_manager.py convert-to-secret --host "hostname" --macro "{$MACRO}"
    python zabbix_secret_manager.py update-secret --host "hostname" --macro "{$MACRO}" --value "new_secret"
    python zabbix_secret_manager.py list-secrets --scope global|host

Author: Zabbix Skills Team
Version: 1.0.0
"""

import argparse
import json
import logging
import os
import sys
from enum import Enum
from typing import Dict, List, Optional, Any
from urllib.parse import urljoin

try:
    import requests
except ImportError:
    print("ERROR: 'requests' library is required. Install with: pip install requests")
    sys.exit(1)


# Configuration constants
ZABBIX_URL = os.getenv('ZABBIX_URL', 'http://localhost/zabbix')
ZABBIX_USER = os.getenv('ZABBIX_USER', 'Admin')
ZABBIX_PASSWORD = os.getenv('ZABBIX_PASSWORD', 'zabbix')
API_ENDPOINT = urljoin(ZABBIX_URL, 'api_jsonrpc.php')

# Macro types
class MacroType(Enum):
    """Macro value types"""
    TEXT = 0  # Plain text (default)
    SECRET = 1  # Secret text (masked)
    VAULT = 2  # Vault secret (external storage)

# Vault providers
class VaultProvider(Enum):
    """Supported vault providers"""
    HASHICORP = "hashicorp"
    CYBERARK = "cyberark"

# Logging configuration
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ZabbixAPIError(Exception):
    """Custom exception for Zabbix API errors"""
    pass


class SecretValidationError(Exception):
    """Custom exception for secret validation errors"""
    pass


class ZabbixSecretManager:
    """Manager class for Zabbix secret macro operations"""

    def __init__(self, url: str, user: str, password: str):
        """
        Initialize Zabbix Secret Manager

        Args:
            url: Zabbix API URL
            user: Zabbix username
            password: Zabbix password
        """
        self.url = url
        self.user = user
        self.password = password
        self.auth_token = None
        self.request_id = 1

    def authenticate(self) -> None:
        """Authenticate with Zabbix API and obtain auth token"""
        payload = {
            "jsonrpc": "2.0",
            "method": "user.login",
            "params": {
                "username": self.user,
                "password": self.password
            },
            "id": self.request_id,
        }

        try:
            response = requests.post(self.url, json=payload, timeout=10)
            response.raise_for_status()
            result = response.json()

            if 'error' in result:
                raise ZabbixAPIError(f"Authentication failed: {result['error']['data']}")

            self.auth_token = result['result']
            logger.info("Successfully authenticated with Zabbix API")

        except requests.RequestException as e:
            raise ZabbixAPIError(f"Failed to connect to Zabbix API: {str(e)}")

    def api_request(self, method: str, params: Dict[str, Any]) -> Any:
        """
        Make API request to Zabbix

        Args:
            method: API method name
            params: Method parameters

        Returns:
            API response result
        """
        if not self.auth_token:
            self.authenticate()

        self.request_id += 1
        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "auth": self.auth_token,
            "id": self.request_id,
        }

        try:
            response = requests.post(self.url, json=payload, timeout=30)
            response.raise_for_status()
            result = response.json()

            if 'error' in result:
                error_msg = result['error'].get('data', result['error'].get('message', 'Unknown error'))
                raise ZabbixAPIError(f"API request failed: {error_msg}")

            return result['result']

        except requests.RequestException as e:
            raise ZabbixAPIError(f"API request failed: {str(e)}")

    def get_host_id(self, host_name: str) -> str:
        """Get host ID by name"""
        result = self.api_request('host.get', {
            'filter': {'host': host_name},
            'output': ['hostid']
        })

        if not result:
            raise ZabbixAPIError(f"Host not found: {host_name}")

        return result[0]['hostid']

    def get_template_id(self, template_name: str) -> str:
        """Get template ID by name"""
        result = self.api_request('template.get', {
            'filter': {'host': template_name},
            'output': ['templateid']
        })

        if not result:
            raise ZabbixAPIError(f"Template not found: {template_name}")

        return result[0]['templateid']

    @staticmethod
    def validate_vault_path(vault_path: str, provider: VaultProvider) -> None:
        """
        Validate vault secret path format

        Args:
            vault_path: Vault secret path
            provider: Vault provider type

        Raises:
            SecretValidationError: If path format is invalid
        """
        if not vault_path:
            raise SecretValidationError("Vault path cannot be empty")

        if provider == VaultProvider.HASHICORP:
            # HashiCorp Vault format: secret/data/path:key
            if ':' not in vault_path:
                raise SecretValidationError(
                    "HashiCorp Vault path must include key (format: path:key)"
                )
            path, key = vault_path.rsplit(':', 1)
            if not path or not key:
                raise SecretValidationError(
                    "Invalid HashiCorp Vault path format (expected: path:key)"
                )

        elif provider == VaultProvider.CYBERARK:
            # CyberArk format: Safe=name;Object=name;Field=name
            required_fields = ['Safe=', 'Object=', 'Field=']
            for field in required_fields:
                if field not in vault_path:
                    raise SecretValidationError(
                        f"CyberArk path missing {field.rstrip('=')} (format: Safe=...;Object=...;Field=...)"
                    )

    def create_secret_text_macro(self, host_name: str, macro: str, value: str,
                                  description: str = "", scope: str = "host") -> str:
        """
        Create secret text macro (masked in UI)

        Args:
            host_name: Host or template name
            macro: Macro name
            value: Secret value
            description: Macro description
            scope: Macro scope (host, template, global)

        Returns:
            Created macro ID
        """
        if scope == "global":
            params = {
                'macro': macro,
                'value': value,
                'type': MacroType.SECRET.value
            }
            if description:
                params['description'] = description

            result = self.api_request('usermacro.createglobal', params)
            macro_id = result['globalmacroids'][0]
            logger.info(f"Created global secret macro: {macro}")

        else:
            # Get host or template ID
            if scope == "host":
                entity_id = self.get_host_id(host_name)
            else:  # template
                entity_id = self.get_template_id(host_name)

            params = {
                'hostid': entity_id,
                'macro': macro,
                'value': value,
                'type': MacroType.SECRET.value
            }
            if description:
                params['description'] = description

            result = self.api_request('usermacro.create', params)
            macro_id = result['hostmacroids'][0]
            logger.info(f"Created secret macro: {macro} on {host_name}")

        return macro_id

    def create_vault_secret_macro(self, host_name: str, macro: str, vault_path: str,
                                   provider: VaultProvider = VaultProvider.HASHICORP,
                                   description: str = "", scope: str = "host") -> str:
        """
        Create vault secret macro (stored in external vault)

        Args:
            host_name: Host or template name
            macro: Macro name
            vault_path: Path to secret in vault
            provider: Vault provider (hashicorp, cyberark)
            description: Macro description
            scope: Macro scope (host, template, global)

        Returns:
            Created macro ID
        """
        # Validate vault path format
        self.validate_vault_path(vault_path, provider)

        if scope == "global":
            params = {
                'macro': macro,
                'value': vault_path,
                'type': MacroType.VAULT.value
            }
            if description:
                params['description'] = description

            result = self.api_request('usermacro.createglobal', params)
            macro_id = result['globalmacroids'][0]
            logger.info(f"Created global vault secret macro: {macro} -> {vault_path}")

        else:
            # Get host or template ID
            if scope == "host":
                entity_id = self.get_host_id(host_name)
            else:  # template
                entity_id = self.get_template_id(host_name)

            params = {
                'hostid': entity_id,
                'macro': macro,
                'value': vault_path,
                'type': MacroType.VAULT.value
            }
            if description:
                params['description'] = description

            result = self.api_request('usermacro.create', params)
            macro_id = result['hostmacroids'][0]
            logger.info(f"Created vault secret macro: {macro} on {host_name} -> {vault_path}")

        return macro_id

    def convert_to_secret(self, host_name: str, macro: str, scope: str = "host",
                         secret_type: str = "secret_text") -> str:
        """
        Convert existing plain text macro to secret

        Args:
            host_name: Host or template name (not used for global)
            macro: Macro name
            scope: Macro scope (host, template, global)
            secret_type: Type of secret (secret_text, vault)

        Returns:
            Updated macro ID

        Note:
            For vault secrets, user must provide new vault path
        """
        if secret_type == "vault":
            raise SecretValidationError(
                "Converting to vault secret requires vault path. Use update-vault-secret instead."
            )

        # Get existing macro
        if scope == "global":
            existing = self.api_request('usermacro.get', {
                'globalmacro': True,
                'filter': {'macro': macro},
                'output': ['globalmacroid', 'macro', 'value', 'type']
            })

            if not existing:
                raise ZabbixAPIError(f"Global macro not found: {macro}")

            if existing[0]['type'] != str(MacroType.TEXT.value):
                raise SecretValidationError(f"Macro {macro} is already a secret")

            macro_id = existing[0]['globalmacroid']
            current_value = existing[0]['value']

            self.api_request('usermacro.updateglobal', {
                'globalmacroid': macro_id,
                'type': MacroType.SECRET.value
            })

            logger.info(f"Converted global macro {macro} to secret text")

        else:
            if scope == "host":
                entity_id = self.get_host_id(host_name)
            else:
                entity_id = self.get_template_id(host_name)

            existing = self.api_request('usermacro.get', {
                'hostids': entity_id,
                'filter': {'macro': macro},
                'output': ['hostmacroid', 'macro', 'value', 'type']
            })

            if not existing:
                raise ZabbixAPIError(f"Macro not found: {macro} on {host_name}")

            if existing[0]['type'] != str(MacroType.TEXT.value):
                raise SecretValidationError(f"Macro {macro} is already a secret")

            macro_id = existing[0]['hostmacroid']

            self.api_request('usermacro.update', {
                'hostmacroid': macro_id,
                'type': MacroType.SECRET.value
            })

            logger.info(f"Converted macro {macro} on {host_name} to secret text")

        logger.warning("IMPORTANT: Original value preserved but now masked. Cannot be viewed in UI.")
        return macro_id

    def update_secret_value(self, host_name: str, macro: str, new_value: str,
                           scope: str = "host") -> str:
        """
        Update secret macro value

        Args:
            host_name: Host or template name
            macro: Macro name
            new_value: New secret value (or vault path)
            scope: Macro scope

        Returns:
            Updated macro ID

        Note:
            This will overwrite the existing secret value
        """
        if scope == "global":
            existing = self.api_request('usermacro.get', {
                'globalmacro': True,
                'filter': {'macro': macro},
                'output': ['globalmacroid', 'type']
            })

            if not existing:
                raise ZabbixAPIError(f"Global macro not found: {macro}")

            macro_id = existing[0]['globalmacroid']

            self.api_request('usermacro.updateglobal', {
                'globalmacroid': macro_id,
                'value': new_value
            })

            logger.info(f"Updated global secret macro: {macro}")

        else:
            if scope == "host":
                entity_id = self.get_host_id(host_name)
            else:
                entity_id = self.get_template_id(host_name)

            existing = self.api_request('usermacro.get', {
                'hostids': entity_id,
                'filter': {'macro': macro},
                'output': ['hostmacroid', 'type']
            })

            if not existing:
                raise ZabbixAPIError(f"Macro not found: {macro} on {host_name}")

            macro_id = existing[0]['hostmacroid']

            self.api_request('usermacro.update', {
                'hostmacroid': macro_id,
                'value': new_value
            })

            logger.info(f"Updated secret macro: {macro} on {host_name}")

        return macro_id

    def list_secret_macros(self, scope: str = "global", host_name: Optional[str] = None,
                           output_format: str = "table") -> List[Dict[str, Any]]:
        """
        List all secret macros

        Args:
            scope: Macro scope (global, host, template)
            host_name: Host or template name (required for host/template scope)
            output_format: Output format (table, json)

        Returns:
            List of secret macros
        """
        if scope == "global":
            macros = self.api_request('usermacro.get', {
                'globalmacro': True,
                'output': ['macro', 'value', 'description', 'type'],
                'sortfield': 'macro'
            })
        else:
            if not host_name:
                raise ValueError(f"host_name is required for {scope} scope")

            if scope == "host":
                entity_id = self.get_host_id(host_name)
            else:
                entity_id = self.get_template_id(host_name)

            macros = self.api_request('usermacro.get', {
                'hostids': entity_id,
                'output': ['macro', 'value', 'description', 'type'],
                'sortfield': 'macro'
            })

        # Filter only secret macros (type 1 or 2)
        secret_macros = [
            m for m in macros
            if m['type'] in [str(MacroType.SECRET.value), str(MacroType.VAULT.value)]
        ]

        self._format_output(secret_macros, output_format, f"Secret Macros ({scope})")
        return secret_macros

    def get_secret_macro_info(self, host_name: str, macro: str,
                              scope: str = "host") -> Dict[str, Any]:
        """
        Get detailed information about a secret macro

        Args:
            host_name: Host or template name
            macro: Macro name
            scope: Macro scope

        Returns:
            Secret macro information
        """
        if scope == "global":
            macros = self.api_request('usermacro.get', {
                'globalmacro': True,
                'filter': {'macro': macro},
                'output': ['macro', 'value', 'description', 'type']
            })
        else:
            if scope == "host":
                entity_id = self.get_host_id(host_name)
            else:
                entity_id = self.get_template_id(host_name)

            macros = self.api_request('usermacro.get', {
                'hostids': entity_id,
                'filter': {'macro': macro},
                'output': ['macro', 'value', 'description', 'type']
            })

        if not macros:
            raise ZabbixAPIError(f"Macro not found: {macro}")

        macro_info = macros[0]

        # Determine secret type
        if macro_info['type'] == str(MacroType.SECRET.value):
            secret_type = "secret_text"
            value_display = "******"
        elif macro_info['type'] == str(MacroType.VAULT.value):
            secret_type = "vault_secret"
            value_display = macro_info['value']  # Vault path is shown
        else:
            secret_type = "plain_text"
            value_display = macro_info['value']

        return {
            'macro': macro_info['macro'],
            'type': secret_type,
            'value': value_display,
            'description': macro_info.get('description', ''),
            'scope': scope,
            'entity': host_name if scope != 'global' else 'global'
        }

    @staticmethod
    def _format_output(data: List[Dict[str, Any]], output_format: str, title: str) -> None:
        """Format and print output"""
        if output_format == 'json':
            print(json.dumps(data, indent=2))
        elif output_format == 'table':
            print(f"\n{title}")
            print("=" * 100)
            if not data:
                print("No secret macros found")
                return

            for macro in data:
                print(f"\nMacro: {macro['macro']}")

                # Display value based on type
                if macro['type'] == str(MacroType.SECRET.value):
                    print(f"Type: Secret Text")
                    print(f"Value: ******")
                elif macro['type'] == str(MacroType.VAULT.value):
                    print(f"Type: Vault Secret")
                    print(f"Vault Path: {macro['value']}")

                if macro.get('description'):
                    print(f"Description: {macro['description']}")
                print("-" * 100)


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='Zabbix Secret Macro Manager - Manage secret macros and vault integration',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    subparsers = parser.add_subparsers(dest='command', help='Command to execute')

    # Create secret text macro
    parser_create_secret = subparsers.add_parser('create-secret',
                                                   help='Create secret text macro')
    parser_create_secret.add_argument('--scope', default='host',
                                      choices=['global', 'host', 'template'],
                                      help='Macro scope')
    parser_create_secret.add_argument('--host', help='Host or template name')
    parser_create_secret.add_argument('--macro', required=True, help='Macro name')
    parser_create_secret.add_argument('--value', required=True, help='Secret value')
    parser_create_secret.add_argument('--description', default='', help='Description')

    # Create vault secret macro
    parser_create_vault = subparsers.add_parser('create-vault-secret',
                                                 help='Create vault secret macro')
    parser_create_vault.add_argument('--scope', default='host',
                                     choices=['global', 'host', 'template'],
                                     help='Macro scope')
    parser_create_vault.add_argument('--host', help='Host or template name')
    parser_create_vault.add_argument('--macro', required=True, help='Macro name')
    parser_create_vault.add_argument('--vault-path', required=True, help='Vault secret path')
    parser_create_vault.add_argument('--provider', default='hashicorp',
                                     choices=['hashicorp', 'cyberark'],
                                     help='Vault provider')
    parser_create_vault.add_argument('--description', default='', help='Description')

    # Convert to secret
    parser_convert = subparsers.add_parser('convert-to-secret',
                                           help='Convert plain text macro to secret')
    parser_convert.add_argument('--scope', default='host',
                               choices=['global', 'host', 'template'],
                               help='Macro scope')
    parser_convert.add_argument('--host', help='Host or template name')
    parser_convert.add_argument('--macro', required=True, help='Macro name')

    # Update secret value
    parser_update = subparsers.add_parser('update-secret',
                                          help='Update secret macro value')
    parser_update.add_argument('--scope', default='host',
                              choices=['global', 'host', 'template'],
                              help='Macro scope')
    parser_update.add_argument('--host', help='Host or template name')
    parser_update.add_argument('--macro', required=True, help='Macro name')
    parser_update.add_argument('--value', required=True, help='New secret value')

    # List secret macros
    parser_list = subparsers.add_parser('list-secrets', help='List all secret macros')
    parser_list.add_argument('--scope', default='global',
                            choices=['global', 'host', 'template'],
                            help='Macro scope')
    parser_list.add_argument('--host', help='Host or template name')
    parser_list.add_argument('--format', default='table', choices=['table', 'json'],
                            help='Output format')

    # Get secret info
    parser_info = subparsers.add_parser('info', help='Get secret macro information')
    parser_info.add_argument('--scope', default='host',
                            choices=['global', 'host', 'template'],
                            help='Macro scope')
    parser_info.add_argument('--host', help='Host or template name')
    parser_info.add_argument('--macro', required=True, help='Macro name')

    # Common arguments
    parser.add_argument('--url', default=ZABBIX_URL, help='Zabbix URL')
    parser.add_argument('--user', default=ZABBIX_USER, help='Zabbix username')
    parser.add_argument('--password', default=ZABBIX_PASSWORD, help='Zabbix password')
    parser.add_argument('--verbose', action='store_true', help='Verbose output')

    args = parser.parse_args()

    if args.verbose:
        logger.setLevel(logging.DEBUG)

    if not args.command:
        parser.print_help()
        return 1

    # Validate scope and host requirement
    if hasattr(args, 'scope') and args.scope in ['host', 'template'] and not args.host:
        print(f"ERROR: --host is required for {args.scope} scope")
        return 1

    try:
        manager = ZabbixSecretManager(args.url, args.user, args.password)

        if args.command == 'create-secret':
            manager.create_secret_text_macro(
                args.host, args.macro, args.value, args.description, args.scope
            )

        elif args.command == 'create-vault-secret':
            provider = VaultProvider(args.provider)
            manager.create_vault_secret_macro(
                args.host, args.macro, args.vault_path, provider, args.description, args.scope
            )

        elif args.command == 'convert-to-secret':
            manager.convert_to_secret(args.host, args.macro, args.scope)

        elif args.command == 'update-secret':
            manager.update_secret_value(args.host, args.macro, args.value, args.scope)

        elif args.command == 'list-secrets':
            manager.list_secret_macros(args.scope, args.host, args.format)

        elif args.command == 'info':
            info = manager.get_secret_macro_info(args.host, args.macro, args.scope)
            print(json.dumps(info, indent=2))

        return 0

    except (ZabbixAPIError, SecretValidationError, ValueError) as e:
        logger.error(str(e))
        return 1
    except KeyboardInterrupt:
        logger.info("Operation cancelled by user")
        return 130
    except Exception as e:
        logger.exception(f"Unexpected error: {str(e)}")
        return 1


if __name__ == '__main__':
    sys.exit(main())
