# Monitoring Problems & Events in Zabbix

Comprehensive Agent Skill for automating Zabbix problem and event monitoring, including active problem tracking, event analysis, acknowledgment workflows, metrics reporting, and integration with incident management systems.

## Quick Start

### Prerequisites

```bash
# Install required Python packages
pip install requests pyyaml

# Set environment variables
export ZABBIX_URL="https://zabbix.example.com"
export ZABBIX_TOKEN="your-api-token"
```

### Basic Usage

**Monitor Active Problems**
```bash
python scripts/zabbix_problem_monitor.py \
  --url $ZABBIX_URL \
  --token $ZABBIX_TOKEN \
  --severity critical,disaster \
  --status active
```

**Acknowledge a Problem**
```bash
python scripts/zabbix_problem_ack.py \
  --url $ZABBIX_URL \
  --token $ZABBIX_TOKEN \
  --problem-id 12345 \
  --message "Investigating database connection issue"
```

**Generate MTTR Report**
```bash
python scripts/zabbix_problem_reporter.py \
  --url $ZABBIX_URL \
  --token $ZABBIX_TOKEN \
  --report-type mttr \
  --time-range 7d
```

## Features

### Problem Monitoring
- Query active problems with complex filters (severity, host, tags, time)
- Real-time monitoring with configurable polling intervals
- Export problems in multiple formats (JSON, CSV, table)
- Filter by acknowledgment and suppression status
- Support for host patterns with wildcards

### Event Analysis
- Build event timelines and sequences
- Correlate related events and identify root causes
- Aggregate events by host, severity, or tags
- Detect cascade failures and dependencies
- Pattern recognition for recurring issues

### Problem Acknowledgment
- Single and bulk acknowledgment operations
- Templated messages for consistent documentation
- Action tracking and audit trail
- Problem closure with root cause analysis
- Suppression rules for false positives

### Metrics & Reporting
- MTTR (Mean Time To Resolution) calculation
- MTTA (Mean Time To Acknowledgment) tracking
- Problem frequency and trend analysis
- Top offenders identification
- SLA compliance reporting
- Custom report generation in multiple formats

### External Integrations
- **JIRA**: Automatic ticket creation and bidirectional sync
- **ServiceNow**: Incident creation and management
- **PagerDuty**: On-call notifications and escalation
- **Slack/Teams**: Real-time notifications
- Custom webhook integrations

## File Structure

```
monitoring-problems-events/
├── SKILL.md                          # Main skill documentation
├── README.md                         # This file
├── scripts/
│   ├── zabbix_problem_monitor.py    # Problem monitoring and querying
│   ├── zabbix_problem_ack.py        # Problem acknowledgment
│   ├── zabbix_event_analyzer.py     # Event analysis and correlation
│   ├── zabbix_problem_reporter.py   # Report generation
│   ├── validate_problem_config.py   # Configuration validation
│   └── integrations/
│       ├── jira_integration.py      # JIRA integration
│       ├── servicenow_integration.py # ServiceNow integration
│       └── pagerduty_integration.py # PagerDuty integration
└── examples/
    ├── problem_queries.json         # Problem query examples
    ├── acknowledgment_templates.yaml # Acknowledgment templates
    ├── correlation_rules.json       # Event correlation rules
    ├── report_configs.yaml          # Report configurations
    ├── integration_configs.json     # Integration settings
    ├── dashboard_configs.yaml       # Dashboard layouts
    └── bulk_operations.yaml         # Bulk operation patterns
```

## Common Workflows

### Incident Response Workflow

1. **Detect Critical Problem**
   ```bash
   python scripts/zabbix_problem_monitor.py \
     --url $ZABBIX_URL --token $ZABBIX_TOKEN \
     --severity disaster,high --status active
   ```

2. **Create JIRA Ticket**
   ```bash
   python scripts/integrations/jira_integration.py \
     --zabbix-url $ZABBIX_URL --zabbix-token $ZABBIX_TOKEN \
     --jira-url $JIRA_URL --jira-token $JIRA_TOKEN \
     --problem-id 12345 --project-key INFRA
   ```

3. **Acknowledge Problem**
   ```bash
   python scripts/zabbix_problem_ack.py \
     --url $ZABBIX_URL --token $ZABBIX_TOKEN \
     --problem-id 12345 --template incident_response \
     --var ticket=INFRA-1234 --var team="Database Team"
   ```

4. **Analyze Related Events**
   ```bash
   python scripts/zabbix_event_analyzer.py \
     --url $ZABBIX_URL --token $ZABBIX_TOKEN \
     --analyze-correlation --time-range 1h
   ```

5. **Close and Document**
   ```bash
   python scripts/zabbix_problem_ack.py \
     --url $ZABBIX_URL --token $ZABBIX_TOKEN \
     --problem-id 12345 --close --template resolved \
     --var resolution="Database restarted" \
     --var root_cause="Connection pool exhaustion"
   ```

### Real-Time Monitoring

**Monitor with Slack Alerts**
```bash
python scripts/zabbix_problem_monitor.py \
  --url $ZABBIX_URL --token $ZABBIX_TOKEN \
  --monitor --interval 60 \
  --severity disaster,high \
  --alert-webhook $SLACK_WEBHOOK_URL
```

### Bulk Operations

**Bulk Acknowledge Critical Problems**
```bash
python scripts/zabbix_problem_ack.py \
  --url $ZABBIX_URL --token $ZABBIX_TOKEN \
  --bulk --severity disaster,high \
  --message "Acknowledged during incident response" \
  --dry-run  # Remove for actual execution
```

### Reporting

**Weekly MTTR Report**
```bash
python scripts/zabbix_problem_reporter.py \
  --url $ZABBIX_URL --token $ZABBIX_TOKEN \
  --report-type mttr --time-range 7d \
  --group-by severity --format json \
  --output weekly_mttr.json
```

**Top Problematic Hosts**
```bash
python scripts/zabbix_problem_reporter.py \
  --url $ZABBIX_URL --token $ZABBIX_TOKEN \
  --report-type top-offenders --time-range 30d \
  --limit 20 --format text
```

## Configuration Examples

### Problem Query Configuration
See `examples/problem_queries.json` for comprehensive query patterns:
- Critical problems
- Database-specific issues
- Production environment problems
- Time-based queries
- Tag-based filtering

### Acknowledgment Templates
See `examples/acknowledgment_templates.yaml` for message templates:
- Incident response
- Maintenance windows
- False positives
- Escalations
- Resolution documentation

### Event Correlation Rules
See `examples/correlation_rules.json` for correlation patterns:
- Cascade failure detection
- Host-level correlation
- Application-level grouping
- Network outage detection
- Flapping detection

### Integration Configuration
See `examples/integration_configs.json` for integration setup:
- JIRA ticket creation
- ServiceNow incidents
- PagerDuty alerts
- Slack/Teams notifications
- Custom webhooks

## Validation

**Validate Configuration Files**
```bash
python scripts/validate_problem_config.py --all
```

**Validate Specific Config**
```bash
python scripts/validate_problem_config.py \
  --config examples/problem_queries.json
```

**Validate Templates**
```bash
python scripts/validate_problem_config.py \
  --template examples/acknowledgment_templates.yaml
```

## Environment Variables

```bash
# Zabbix
export ZABBIX_URL="https://zabbix.example.com"
export ZABBIX_TOKEN="your-api-token"

# JIRA
export JIRA_URL="https://jira.example.com"
export JIRA_TOKEN="your-jira-token"
export JIRA_EMAIL="your-email@example.com"

# ServiceNow
export SNOW_INSTANCE="your-instance"
export SNOW_USERNAME="your-username"
export SNOW_PASSWORD="your-password"

# PagerDuty
export PAGERDUTY_ROUTING_KEY="your-routing-key"

# Webhooks
export SLACK_WEBHOOK_URL="https://hooks.slack.com/services/YOUR/WEBHOOK/URL"
export TEAMS_WEBHOOK_URL="https://outlook.office.com/webhook/YOUR/WEBHOOK/URL"
```

## Best Practices

### Problem Monitoring
- Use appropriate severity filters to reduce noise
- Implement tag-based filtering for team-specific views
- Configure reasonable polling intervals (60-300 seconds)
- Archive historical problems regularly

### Acknowledgment
- Always include meaningful messages
- Document actions taken during incident response
- Use templates for consistent messaging
- Include ticket references for external systems

### Event Correlation
- Start with time-based correlation (5-10 minute windows)
- Use host dependencies for cascade detection
- Review and tune correlation rules regularly
- Document correlation patterns for team knowledge

### Integration
- Test integrations in non-production first
- Implement bidirectional sync when possible
- Handle integration failures gracefully
- Monitor integration health and performance

### Reporting
- Schedule reports during off-peak hours
- Use appropriate time ranges for metrics
- Customize reports for different audiences
- Archive reports for historical reference

## Troubleshooting

### No problems returned
- Verify API token permissions
- Check severity and status filters
- Confirm time range includes expected problems
- Validate host/tag filters

### Acknowledgment fails
- Verify problem ID exists and is valid
- Check API token has acknowledge permissions
- Ensure problem is not already closed
- Validate message format

### Integration not working
- Verify external system credentials
- Check network connectivity
- Review integration configuration syntax
- Confirm external system API is accessible

### Reports missing data
- Verify time range covers expected period
- Check data retention settings
- Confirm hosts/items are monitored
- Validate report configuration syntax

## Security

- Store API tokens securely (environment variables, secrets manager)
- Use HTTPS for all API communications
- Implement least-privilege access for API tokens
- Audit all problem operations for compliance
- Encrypt sensitive data in reports
- Rotate API tokens regularly

## Support

For detailed documentation, see `SKILL.md`.

For configuration examples, see files in the `examples/` directory.

For API documentation, refer to Zabbix API documentation.

## License

Part of the Zabbix Skills collection.
