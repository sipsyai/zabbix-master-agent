---
name: monitoring-problems-events
description: Automates Zabbix problem and event monitoring including querying active problems, analyzing event history, acknowledging problems, managing event correlation, creating custom dashboards, generating reports, and integrating with incident management systems through the Zabbix API. Use when monitoring Zabbix problems, analyzing events, acknowledging incidents, tracking resolution metrics, generating SLA reports, correlating events, integrating with ticketing systems, or automating incident response workflows.
version: 1.0.0
author: Zabbix Skills Team
degree_of_freedom: medium
---

# Monitoring Problems & Events in Zabbix

Comprehensive problem and event monitoring for Zabbix with automated acknowledgment, event analysis, reporting, and integration with incident management systems.

## Quick Start

### Monitor Active Problems
```bash
python scripts/zabbix_problem_monitor.py \
  --url https://zabbix.example.com \
  --token $ZABBIX_TOKEN \
  --severity critical,disaster \
  --status active \
  --output json
```

### Acknowledge Problem
```bash
python scripts/zabbix_problem_ack.py \
  --url https://zabbix.example.com \
  --token $ZABBIX_TOKEN \
  --problem-id 12345 \
  --message "Investigating database connection issue" \
  --action "Restarting database service"
```

### Analyze Event Timeline
```bash
python scripts/zabbix_event_analyzer.py \
  --url https://zabbix.example.com \
  --token $ZABBIX_TOKEN \
  --host "db-server-01" \
  --time-range "1h" \
  --analyze-correlation
```

### Generate Problem Report
```bash
python scripts/zabbix_problem_reporter.py \
  --url https://zabbix.example.com \
  --token $ZABBIX_TOKEN \
  --report-type mttr \
  --time-range "7d" \
  --format pdf \
  --output monthly_report.pdf
```

## Core Capabilities

### 1. Problem Monitoring
Query and filter active problems with comprehensive filtering options:
- **Severity Filtering**: disaster, critical, high, warning, information, not_classified
- **Status Filtering**: active, acknowledged, suppressed, resolved
- **Time-Based Filtering**: recent, last_hour, last_24h, last_7d, custom_range
- **Tag-Based Filtering**: Application tags, host groups, custom tags
- **Host Filtering**: By hostname, host group, or host pattern
- **Real-Time Monitoring**: Continuous polling with configurable intervals

**Examples**: See `examples/problem_queries.json` for comprehensive query patterns

### 2. Event Analysis
Analyze event history, correlate events, and identify root causes:
- **Timeline Reconstruction**: Build complete event sequences
- **Event Correlation**: Identify related events and cascading failures
- **Root Cause Analysis**: Determine primary event triggers
- **Event Aggregation**: Group similar events for noise reduction
- **Pattern Recognition**: Identify recurring event patterns
- **Causality Detection**: Determine event dependencies

**Examples**: See `examples/correlation_rules.json` for event correlation patterns

### 3. Problem Acknowledgment
Acknowledge problems with messages, actions, and automation:
- **Single Acknowledgment**: Acknowledge individual problems with detailed messages
- **Bulk Acknowledgment**: Process multiple problems simultaneously
- **Automated Acknowledgment**: Rule-based auto-acknowledgment
- **Action Documentation**: Record actions taken during incident response
- **Close with Cause**: Close problems with root cause documentation
- **Suppression**: Suppress false positives or maintenance-related problems

**Examples**: See `examples/acknowledgment_templates.yaml` for message templates

### 4. Metrics & Analytics
Calculate and track problem resolution metrics:
- **MTTR (Mean Time To Resolution)**: Average time from problem detection to resolution
- **MTTA (Mean Time To Acknowledgment)**: Average time from detection to first acknowledgment
- **Problem Frequency**: Count problems by host, severity, or tag
- **Top Offenders**: Identify most problematic hosts and items
- **Trend Analysis**: Detect increasing or decreasing problem rates
- **SLA Compliance**: Track service level agreement adherence

**Examples**: See `examples/report_configs.yaml` for metric configurations

### 5. Report Generation
Generate comprehensive problem reports in multiple formats:
- **Format Support**: CSV, JSON, PDF, HTML
- **Report Types**: Summary, detailed, trend, SLA, custom
- **Visualization**: Charts, graphs, heatmaps, timelines
- **Scheduled Reports**: Automated daily, weekly, monthly reports
- **Custom Dashboards**: Problem-specific dashboard configurations
- **Export Options**: API, email, file storage, webhook

**Examples**: See `examples/dashboard_configs.yaml` for dashboard templates

### 6. External Integrations
Integrate with incident management and communication platforms:
- **JIRA**: Automatic ticket creation from problems
- **ServiceNow**: Incident and change request creation
- **PagerDuty**: On-call notification and escalation
- **Slack/Teams**: Real-time problem notifications
- **Custom Webhooks**: Integration with any REST API
- **Bidirectional Sync**: Update Zabbix when external tickets close

**Examples**: See `examples/integration_configs.json` for integration setup

## Workflow Patterns

### Incident Response Workflow
1. **Detection**: Monitor for new problems matching severity criteria
2. **Notification**: Send alerts to appropriate teams (Slack, PagerDuty)
3. **Ticket Creation**: Automatically create JIRA/ServiceNow ticket
4. **Acknowledgment**: Acknowledge problem with ticket reference
5. **Investigation**: Analyze correlated events and root cause
6. **Resolution**: Document actions and close problem
7. **Reporting**: Update metrics and generate incident report

### Bulk Problem Management
1. **Identify**: Query problems matching specific criteria
2. **Validate**: Review problem list and verify bulk operation safety
3. **Execute**: Perform bulk acknowledgment or closure
4. **Verify**: Confirm operations completed successfully
5. **Audit**: Log all bulk operations for compliance

### Event Correlation Analysis
1. **Collection**: Gather events within specified time window
2. **Grouping**: Group events by host, application, or correlation tags
3. **Analysis**: Identify primary events and dependencies
4. **Visualization**: Generate timeline and dependency graphs
5. **Reporting**: Document findings and recommendations

## API Methods Used

### Problem Operations
- `problem.get`: Retrieve problems with filtering
  - Filter by severity, status, time, tags, hosts
  - Include acknowledgment details
  - Retrieve suppression information

- `event.acknowledge`: Acknowledge or close problems
  - Add acknowledgment message
  - Document actions taken
  - Close with cause information
  - Suppress false positives

### Event Operations
- `event.get`: Retrieve event history
  - Filter by source, object, value
  - Include related triggers and items
  - Retrieve correlation data

- `service.get`: Get SLA information
  - Calculate SLA compliance
  - Retrieve service dependencies

### Configuration
- `correlation.get`: Retrieve event correlation rules
- `action.get`: Get action configurations for automated responses

## Advanced Features

### Event Correlation
Configure rules to correlate related events and reduce noise:
- **Cascade Correlation**: Identify primary failure causing secondary problems
- **Time-Based Correlation**: Group events occurring within time windows
- **Tag-Based Correlation**: Correlate by application or service tags
- **Dependency Correlation**: Use host/service dependencies

### Problem Suppression
Manage false positives and maintenance windows:
- **Manual Suppression**: Suppress specific problems with documentation
- **Rule-Based Suppression**: Automatic suppression based on criteria
- **Maintenance Windows**: Schedule suppression during planned maintenance
- **Pattern Suppression**: Suppress recurring false positives

### Real-Time Monitoring
Continuous problem monitoring with alerting:
- **Polling Intervals**: Configurable check frequency (30s, 1m, 5m, etc.)
- **Change Detection**: Alert only on new or changed problems
- **Threshold Alerting**: Alert when problem counts exceed thresholds
- **Escalation**: Automatic escalation for unacknowledged problems

## Reference Documentation

For detailed information on specific topics:

- **Problem Queries**: `examples/problem_queries.json` - Comprehensive query examples
- **Acknowledgment Templates**: `examples/acknowledgment_templates.yaml` - Message templates
- **Correlation Rules**: `examples/correlation_rules.json` - Event correlation patterns
- **Report Configurations**: `examples/report_configs.yaml` - Report templates
- **Integration Configs**: `examples/integration_configs.json` - External system setup
- **Dashboard Templates**: `examples/dashboard_configs.yaml` - Problem dashboard examples
- **Bulk Operations**: `examples/bulk_operations.yaml` - Bulk operation patterns

## Script Reference

### Core Scripts
- **zabbix_problem_monitor.py**: Main problem monitoring and querying
  - Query problems with complex filters
  - Real-time monitoring mode
  - Export results in multiple formats

- **zabbix_problem_ack.py**: Problem acknowledgment automation
  - Single and bulk acknowledgment
  - Templated messages
  - Action documentation

- **zabbix_event_analyzer.py**: Event analysis and correlation
  - Timeline reconstruction
  - Root cause analysis
  - Event grouping and aggregation

- **zabbix_problem_reporter.py**: Report generation
  - MTTR/MTTA calculation
  - SLA compliance reports
  - Custom visualizations

### Integration Scripts
- **jira_integration.py**: JIRA ticket creation and sync
- **servicenow_integration.py**: ServiceNow incident management
- **pagerduty_integration.py**: PagerDuty on-call integration

### Validation
- **validate_problem_config.py**: Validate configuration files
  - Check query syntax
  - Validate acknowledgment templates
  - Test integration credentials

## Configuration Management

### Environment Variables
```bash
export ZABBIX_URL="https://zabbix.example.com"
export ZABBIX_TOKEN="your-api-token"
export JIRA_URL="https://jira.example.com"
export JIRA_TOKEN="your-jira-token"
export SERVICENOW_INSTANCE="your-instance"
export SERVICENOW_TOKEN="your-servicenow-token"
export PAGERDUTY_TOKEN="your-pagerduty-token"
```

### Configuration Files
All configuration examples are provided in the `examples/` directory:
- Problem query configurations
- Acknowledgment message templates
- Event correlation rules
- Report templates
- Integration configurations
- Dashboard layouts
- Bulk operation patterns

## Error Handling

Scripts include comprehensive error handling:
- **API Errors**: Retry logic with exponential backoff
- **Authentication**: Clear error messages for auth failures
- **Validation**: Input validation before API calls
- **Rate Limiting**: Respect Zabbix API rate limits
- **Network Errors**: Graceful handling of connection issues
- **Data Validation**: Verify response data integrity

## Best Practices

### Problem Monitoring
1. Use appropriate severity filters to reduce noise
2. Implement tag-based filtering for team-specific views
3. Configure reasonable polling intervals (avoid overloading API)
4. Use real-time monitoring only when necessary
5. Archive historical problems to maintain performance

### Acknowledgment
1. Always include meaningful messages
2. Document actions taken during incident response
3. Use templates for consistent messaging
4. Include ticket references for external systems
5. Close problems with root cause analysis

### Event Correlation
1. Start with time-based correlation windows
2. Use host dependencies for cascade detection
3. Implement tag-based correlation for microservices
4. Review and tune correlation rules regularly
5. Document correlation patterns for team knowledge

### Integration
1. Implement bidirectional sync when possible
2. Handle integration failures gracefully
3. Log all integration operations for audit
4. Test integrations in non-production first
5. Monitor integration health and performance

### Reporting
1. Schedule reports during off-peak hours
2. Use appropriate time ranges for metrics
3. Include context and trends in reports
4. Archive reports for historical reference
5. Customize reports for different audiences

## Security Considerations

- Store API tokens securely (environment variables, secrets manager)
- Use HTTPS for all API communications
- Implement least-privilege access for API tokens
- Audit all problem operations for compliance
- Encrypt sensitive data in reports
- Secure webhook endpoints with authentication
- Rotate API tokens regularly

## Troubleshooting

### Common Issues

**No problems returned from query**
- Verify API token has sufficient permissions
- Check severity and status filters
- Confirm time range includes expected problems
- Validate host/tag filters are correct

**Acknowledgment fails**
- Verify problem ID is valid and exists
- Check API token has acknowledge permissions
- Ensure message format is valid
- Confirm problem is not already closed

**Integration not working**
- Verify external system credentials
- Check network connectivity to external API
- Review integration configuration syntax
- Confirm external system API is accessible

**Reports missing data**
- Verify time range covers expected period
- Check data retention settings in Zabbix
- Confirm hosts/items are monitored
- Validate report configuration syntax

## Performance Optimization

- Use pagination for large result sets
- Filter at API level rather than client-side
- Batch bulk operations appropriately
- Cache frequently accessed data
- Use asynchronous operations for integrations
- Implement connection pooling for multiple requests
- Monitor script execution time and optimize queries

## Compliance & Audit

- Log all problem operations with timestamps
- Track acknowledgment history for audit
- Maintain problem closure documentation
- Generate compliance reports for SLA tracking
- Export audit logs for long-term retention
- Implement approval workflows for bulk operations
- Document all automation rules and configurations
