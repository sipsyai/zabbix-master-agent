#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DC01 Host Problem Analysis
Detailed problem analysis for host ID 10780
"""

import requests
import json
import sys
from datetime import datetime
from typing import Dict, List, Any

import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
# Set UTF-8 encoding for Windows console
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

class ZabbixAnalyzer:
    def __init__(self, url: str, username: str, password: str):
        self.url = url
        self.auth_token = None
        self.authenticate(username, password)

    def authenticate(self, username: str, password: str):
        """Authenticate with Zabbix API"""
        payload = {
            "jsonrpc": "2.0",
            "method": "user.login",
            "params": {
                "username": username,
                "password": password
            },
            "id": 1
        }

        response = requests.post(self.url, json=payload, headers={'Content-Type': 'application/json'})
        result = response.json()

        if 'error' in result:
            raise Exception(f"Authentication failed: {result['error']['message']}")

        self.auth_token = result['result']
        print(f"[OK] Successfully authenticated to Zabbix server")

    def api_call(self, method: str, params: Dict) -> Any:
        """Make Zabbix API call"""
        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "id": 1
        }

        # Use Authorization header for Zabbix 7.0+
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.auth_token}'
        }

        response = requests.post(self.url, json=payload, headers=headers)
        result = response.json()

        if 'error' in result:
            print(f"[DEBUG] API Error Details: {json.dumps(result['error'], indent=2)}")
            print(f"[DEBUG] Request Params: {json.dumps(params, indent=2)}")
            raise Exception(f"API Error: {result['error'].get('message', 'Unknown')} (Data: {result['error'].get('data', 'N/A')})")

        return result.get('result', [])

    def get_host_info(self, host_id: str) -> Dict:
        """Get host information"""
        hosts = self.api_call("host.get", {
            "hostids": [host_id],
            "output": "extend",
            "selectGroups": "extend",
            "selectInterfaces": "extend"
        })
        return hosts[0] if hosts else None

    def get_active_problems(self, host_id: str) -> List[Dict]:
        """Get active problems for host"""
        problems = self.api_call("problem.get", {
            "hostids": [host_id],
            "output": "extend",
            "selectAcknowledges": "extend",
            "selectTags": "extend",
            "selectSuppressionData": "extend",
            "recent": False,
            "sortfield": ["eventid"],
            "sortorder": "DESC"
        })
        return problems

    def get_resolved_problems(self, host_id: str, time_from: int) -> List[Dict]:
        """Get recently resolved problems"""
        events = self.api_call("event.get", {
            "hostids": [host_id],
            "source": 0,  # Trigger events
            "object": 0,  # Trigger object
            "value": 0,   # OK events (resolved)
            "time_from": time_from,
            "output": "extend",
            "selectTags": "extend",
            "sortfield": ["clock"],
            "sortorder": "DESC",
            "limit": 20
        })
        return events

    def get_trigger_details(self, trigger_ids: List[str]) -> Dict:
        """Get trigger details"""
        if not trigger_ids:
            return {}

        triggers = self.api_call("trigger.get", {
            "triggerids": trigger_ids,
            "output": "extend",
            "selectFunctions": "extend",
            "selectItems": ["itemid", "name", "key_", "lastvalue", "units"]
        })

        return {t['triggerid']: t for t in triggers}

    def get_latest_data(self, host_id: str) -> List[Dict]:
        """Get latest item values for host"""
        items = self.api_call("item.get", {
            "hostids": [host_id],
            "output": ["itemid", "name", "key_", "lastvalue", "lastclock", "units", "value_type"],
            "filter": {
                "status": 0  # Enabled items
            },
            "sortfield": "name",
            "limit": 30
        })
        return items

    def format_severity(self, severity: str) -> str:
        """Format severity with indicator"""
        severity_map = {
            '0': '[  ] Not classified',
            '1': '[ I] Information',
            '2': '[ W] Warning',
            '3': '[!A] Average',
            '4': '[!!] High',
            '5': '[XX] Disaster'
        }
        return severity_map.get(str(severity), f'Unknown ({severity})')

    def format_duration(self, start_time: int) -> str:
        """Format problem duration"""
        now = datetime.now().timestamp()
        duration = int(now - int(start_time))

        days = duration // 86400
        hours = (duration % 86400) // 3600
        minutes = (duration % 3600) // 60

        parts = []
        if days > 0:
            parts.append(f"{days}d")
        if hours > 0:
            parts.append(f"{hours}h")
        if minutes > 0 or not parts:
            parts.append(f"{minutes}m")

        return " ".join(parts)

    def format_timestamp(self, timestamp: int) -> str:
        """Format Unix timestamp to readable date"""
        return datetime.fromtimestamp(int(timestamp)).strftime('%Y-%m-%d %H:%M:%S')

    def analyze_host(self, host_id: str):
        """Perform comprehensive host analysis"""
        print("\n" + "="*80)
        print("DC01 HOST PROBLEM ANALYSIS")
        print("="*80)

        # Get host information
        print("\n[1] HOST INFORMATION")
        print("-" * 80)
        host = self.get_host_info(host_id)
        if not host:
            print(f"[ERROR] Host with ID {host_id} not found!")
            return

        status = "[+] Enabled" if host['status'] == '0' else "[-] Disabled"
        print(f"Host ID:      {host['hostid']}")
        print(f"Hostname:     {host['host']}")
        print(f"Display Name: {host['name']}")
        print(f"Status:       {status}")

        if host.get('groups'):
            print(f"Host Groups:  {', '.join([g['name'] for g in host['groups']])}")

        if host.get('interfaces'):
            for iface in host['interfaces']:
                iface_type = {'1': 'Agent', '2': 'SNMP', '3': 'IPMI', '4': 'JMX'}.get(iface['type'], 'Unknown')
                conn = iface.get('dns') or iface.get('ip', 'N/A')
                print(f"Interface:    {iface_type} - {conn}:{iface.get('port', 'N/A')}")

        # Get active problems
        print("\n[2] ACTIVE PROBLEMS")
        print("-" * 80)
        problems = self.get_active_problems(host_id)

        if not problems:
            print("[OK] No active problems found - host is healthy!")
        else:
            print(f"Found {len(problems)} active problem(s)\n")

            # Get trigger details for all problems
            trigger_ids = [p['objectid'] for p in problems]
            triggers = self.get_trigger_details(trigger_ids)

            for idx, problem in enumerate(problems, 1):
                trigger = triggers.get(problem['objectid'], {})

                print(f"\nProblem #{idx}:")
                print(f"  Event ID:     {problem['eventid']}")
                print(f"  Severity:     {self.format_severity(problem['severity'])}")
                print(f"  Name:         {problem['name']}")
                print(f"  Started:      {self.format_timestamp(problem['clock'])}")
                print(f"  Duration:     {self.format_duration(problem['clock'])}")

                # Acknowledgment status
                if problem.get('acknowledged') == '1':
                    ack_count = len(problem.get('acknowledges', []))
                    print(f"  Acknowledged: [YES] ({ack_count} acknowledgment(s))")

                    if problem.get('acknowledges'):
                        latest_ack = problem['acknowledges'][-1]
                        print(f"    Last ACK:   {self.format_timestamp(latest_ack['clock'])}")
                        if latest_ack.get('message'):
                            print(f"    Message:    {latest_ack['message']}")
                else:
                    print(f"  Acknowledged: [NO]")

                # Suppression status
                if problem.get('suppressed') == '1':
                    print(f"  Suppressed:   Yes")
                    if problem.get('suppression_data'):
                        for supp in problem['suppression_data']:
                            print(f"    Maintenance: {supp.get('maintenanceid', 'N/A')}")

                # Tags
                if problem.get('tags'):
                    tags_str = ', '.join([f"{t['tag']}: {t['value']}" if t.get('value') else t['tag']
                                         for t in problem['tags']])
                    print(f"  Tags:         {tags_str}")

                # Trigger details
                if trigger:
                    print(f"\n  Trigger Details:")
                    print(f"    Trigger ID:   {trigger['triggerid']}")
                    print(f"    Description:  {trigger.get('description', 'N/A')}")
                    print(f"    Expression:   {trigger.get('expression', 'N/A')}")
                    print(f"    Priority:     {self.format_severity(trigger.get('priority', '0'))}")
                    if trigger.get('comments'):
                        print(f"    Comments:     {trigger['comments']}")
                    if trigger.get('url'):
                        print(f"    URL:          {trigger['url']}")

                    # Related items
                    if trigger.get('items'):
                        print(f"    Related Items:")
                        for item in trigger['items']:
                            value = item.get('lastvalue', 'N/A')
                            units = item.get('units', '')
                            print(f"      - {item['name']}")
                            print(f"        Key: {item['key_']}")
                            print(f"        Last value: {value} {units}")

        # Get recently resolved problems (last 24 hours)
        print("\n[3] RECENTLY RESOLVED PROBLEMS (Last 24 hours)")
        print("-" * 80)
        time_from = int(datetime.now().timestamp() - 86400)
        resolved = self.get_resolved_problems(host_id, time_from)

        if not resolved:
            print("No problems resolved in the last 24 hours")
        else:
            print(f"Found {len(resolved)} resolved problem(s)\n")
            for idx, event in enumerate(resolved[:10], 1):  # Show max 10
                print(f"  {idx}. {event['name']}")
                print(f"     Resolved at: {self.format_timestamp(event['clock'])}")
                if event.get('severity'):
                    print(f"     Severity: {self.format_severity(event['severity'])}")

        # Get latest metrics
        print("\n[4] LATEST METRICS (Top 30 monitored items)")
        print("-" * 80)
        items = self.get_latest_data(host_id)

        if not items:
            print("No item data available")
        else:
            print(f"Showing {len(items)} monitored items:\n")
            for item in items:
                value = item.get('lastvalue', 'N/A')
                units = item.get('units', '')
                last_check = self.format_timestamp(item['lastclock']) if item.get('lastclock') else 'Never'

                # Format value based on type
                if value != 'N/A':
                    if item['value_type'] == '0':  # Numeric float
                        try:
                            value = f"{float(value):.2f}"
                        except:
                            pass
                    elif item['value_type'] == '3':  # Numeric unsigned
                        try:
                            value = f"{int(float(value))}"
                        except:
                            pass

                print(f"  - {item['name']}")
                print(f"    Value: {value} {units}")
                print(f"    Last check: {last_check}")
                print(f"    Key: {item['key_']}")
                print()

        # Summary
        print("\n[5] HEALTH SUMMARY")
        print("-" * 80)
        active_count = len(problems)
        resolved_count = len(resolved)

        if active_count == 0:
            print("[OK] HOST STATUS: HEALTHY")
            print(f"  - No active problems")
            print(f"  - {resolved_count} problems resolved in last 24h")
            print(f"  - {len(items)} items being monitored")
        else:
            critical_count = sum(1 for p in problems if int(p['severity']) >= 4)
            ack_count = sum(1 for p in problems if p.get('acknowledged') == '1')

            print("[!!] HOST STATUS: HAS PROBLEMS")
            print(f"  - {active_count} active problem(s)")
            print(f"  - {critical_count} critical/disaster severity")
            print(f"  - {ack_count} acknowledged")
            print(f"  - {active_count - ack_count} unacknowledged")
            print(f"  - {resolved_count} problems resolved in last 24h")

        print("\n" + "="*80)
        print("ANALYSIS COMPLETE")
        print("="*80 + "\n")


if __name__ == "__main__":
    # Load credentials from environment
    ZABBIX_URL = "http://192.168.213.141/api_jsonrpc.php"
    ZABBIX_USERNAME = "Admin"
    ZABBIX_PASSWORD = "zabbix"
    HOST_ID = "10780"

    try:
        analyzer = ZabbixAnalyzer(ZABBIX_URL, ZABBIX_USERNAME, ZABBIX_PASSWORD)
        analyzer.analyze_host(HOST_ID)
    except Exception as e:
        print(f"\n[ERROR] {str(e)}")
        import traceback
        traceback.print_exc()
