#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
JIRA Integration for Zabbix Problems

Creates and manages JIRA tickets from Zabbix problems with bidirectional sync.

Usage:
    python jira_integration.py --zabbix-url https://zabbix.example.com \\
        --zabbix-token $ZABBIX_TOKEN --jira-url https://jira.example.com \\
        --jira-token $JIRA_TOKEN --problem-id 12345 --project-key INFRA

    python jira_integration.py --zabbix-url https://zabbix.example.com \\
        --zabbix-token $ZABBIX_TOKEN --jira-url https://jira.example.com \\
        --jira-token $JIRA_TOKEN --auto-create --severity disaster,high
"""

import argparse
import json
import sys
from typing import Dict, Any, Optional
import requests
from datetime import datetime


class JiraClient:
    """JIRA REST API client."""

    def __init__(self, url: str, token: str, email: Optional[str] = None):
        self.url = url.rstrip('/')
        self.token = token
        self.email = email
        self.session = requests.Session()

        # Setup authentication
        if email:
            # Use email + token for cloud
            self.session.auth = (email, token)
        else:
            # Use bearer token
            self.session.headers.update({
                'Authorization': f'Bearer {token}'
            })

        self.session.headers.update({
            'Content-Type': 'application/json'
        })

    def create_issue(
        self,
        project_key: str,
        summary: str,
        description: str,
        issue_type: str = 'Bug',
        priority: Optional[str] = None,
        labels: Optional[list] = None,
        custom_fields: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Create JIRA issue."""
        payload = {
            'fields': {
                'project': {'key': project_key},
                'summary': summary,
                'description': description,
                'issuetype': {'name': issue_type}
            }
        }

        if priority:
            payload['fields']['priority'] = {'name': priority}

        if labels:
            payload['fields']['labels'] = labels

        if custom_fields:
            payload['fields'].update(custom_fields)

        response = self.session.post(
            f'{self.url}/rest/api/3/issue',
            json=payload,
            timeout=30
        )
        response.raise_for_status()

        return response.json()

    def update_issue(self, issue_key: str, fields: Dict[str, Any]) -> Dict[str, Any]:
        """Update JIRA issue."""
        payload = {'fields': fields}

        response = self.session.put(
            f'{self.url}/rest/api/3/issue/{issue_key}',
            json=payload,
            timeout=30
        )
        response.raise_for_status()

        return response.json() if response.content else {}

    def add_comment(self, issue_key: str, comment: str) -> Dict[str, Any]:
        """Add comment to JIRA issue."""
        payload = {
            'body': {
                'type': 'doc',
                'version': 1,
                'content': [
                    {
                        'type': 'paragraph',
                        'content': [
                            {
                                'type': 'text',
                                'text': comment
                            }
                        ]
                    }
                ]
            }
        }

        response = self.session.post(
            f'{self.url}/rest/api/3/issue/{issue_key}/comment',
            json=payload,
            timeout=30
        )
        response.raise_for_status()

        return response.json()

    def get_issue(self, issue_key: str) -> Dict[str, Any]:
        """Get JIRA issue details."""
        response = self.session.get(
            f'{self.url}/rest/api/3/issue/{issue_key}',
            timeout=30
        )
        response.raise_for_status()

        return response.json()

    def transition_issue(self, issue_key: str, transition_name: str) -> Dict[str, Any]:
        """Transition JIRA issue to new status."""
        # Get available transitions
        response = self.session.get(
            f'{self.url}/rest/api/3/issue/{issue_key}/transitions',
            timeout=30
        )
        response.raise_for_status()
        transitions = response.json()['transitions']

        # Find transition ID
        transition_id = None
        for t in transitions:
            if t['name'].lower() == transition_name.lower():
                transition_id = t['id']
                break

        if not transition_id:
            raise ValueError(f"Transition '{transition_name}' not found")

        # Perform transition
        payload = {'transition': {'id': transition_id}}
        response = self.session.post(
            f'{self.url}/rest/api/3/issue/{issue_key}/transitions',
            json=payload,
            timeout=30
        )
        response.raise_for_status()

        return response.json() if response.content else {}


class ZabbixJiraIntegration:
    """Integration between Zabbix problems and JIRA tickets."""

    SEVERITY_TO_PRIORITY = {
        '5': 'Highest',  # Disaster
        '4': 'High',     # High
        '3': 'Medium',   # Average
        '2': 'Low',      # Warning
        '1': 'Lowest',   # Information
        '0': 'Low'       # Not classified
    }

    def __init__(self, zabbix_api, jira_client: JiraClient):
        self.zabbix_api = zabbix_api
        self.jira_client = jira_client

    def create_ticket_from_problem(
        self,
        problem: Dict[str, Any],
        project_key: str,
        issue_type: str = 'Bug',
        labels: Optional[list] = None
    ) -> Dict[str, Any]:
        """Create JIRA ticket from Zabbix problem."""
        # Build summary
        summary = f"[Zabbix] {problem.get('name', 'Unknown Problem')}"

        # Build description
        severity = problem.get('severity', '0')
        severity_name = self._get_severity_name(severity)
        timestamp = datetime.fromtimestamp(int(problem.get('clock', 0))).strftime('%Y-%m-%d %H:%M:%S')

        description = f"""
*Zabbix Problem Report*

*Problem Details:*
- Event ID: {problem.get('eventid', 'N/A')}
- Severity: {severity_name}
- Detected: {timestamp}
- Status: {'Active' if problem.get('r_eventid', '0') == '0' else 'Resolved'}

*Problem Description:*
{problem.get('name', 'No description available')}

*Tags:*
{self._format_tags(problem.get('tags', []))}

*Link to Zabbix:*
Event ID: {problem.get('eventid')}

---
_This ticket was automatically created from a Zabbix problem._
        """.strip()

        # Get priority from severity
        priority = self.SEVERITY_TO_PRIORITY.get(severity, 'Medium')

        # Add default labels
        default_labels = ['zabbix', 'monitoring', f'severity-{severity_name.lower()}']
        if labels:
            default_labels.extend(labels)

        # Create issue
        issue = self.jira_client.create_issue(
            project_key=project_key,
            summary=summary,
            description=description,
            issue_type=issue_type,
            priority=priority,
            labels=default_labels
        )

        # Acknowledge problem in Zabbix with JIRA ticket reference
        issue_key = issue['key']
        self._acknowledge_with_ticket(problem['eventid'], issue_key)

        return {
            'jira_issue': issue,
            'problem_eventid': problem['eventid']
        }

    def sync_resolution(self, issue_key: str, event_id: str) -> Dict[str, Any]:
        """Sync resolution from JIRA to Zabbix."""
        # Get JIRA issue status
        issue = self.jira_client.get_issue(issue_key)
        status = issue['fields']['status']['name'].lower()

        # If issue is resolved/closed, close problem in Zabbix
        if status in ['resolved', 'closed', 'done']:
            resolution = issue['fields'].get('resolution', {})
            resolution_name = resolution.get('name', 'Unknown') if resolution else 'Unknown'

            message = f"Problem resolved via JIRA ticket {issue_key}. Resolution: {resolution_name}"

            # Close problem in Zabbix
            self.zabbix_api.call('event.acknowledge', {
                'eventids': [event_id],
                'action': 3,  # Close problem
                'message': message
            })

            return {
                'status': 'synced',
                'action': 'closed',
                'jira_issue': issue_key,
                'zabbix_event': event_id
            }

        return {
            'status': 'no_action',
            'jira_status': status
        }

    def update_ticket_from_problem(self, issue_key: str, problem: Dict[str, Any]):
        """Update JIRA ticket with problem updates."""
        # Check if problem is resolved
        if problem.get('r_eventid', '0') != '0':
            recovery_time = datetime.fromtimestamp(int(problem.get('r_clock', 0))).strftime('%Y-%m-%d %H:%M:%S')

            comment = f"Problem resolved in Zabbix at {recovery_time}"
            self.jira_client.add_comment(issue_key, comment)

            # Try to transition to resolved
            try:
                self.jira_client.transition_issue(issue_key, 'Resolve')
            except:
                pass  # Transition might not be available

    def _acknowledge_with_ticket(self, event_id: str, ticket_key: str):
        """Acknowledge Zabbix problem with JIRA ticket reference."""
        message = f"JIRA ticket created: {ticket_key}"

        self.zabbix_api.call('event.acknowledge', {
            'eventids': [event_id],
            'action': 2,  # Acknowledge
            'message': message
        })

    @staticmethod
    def _get_severity_name(severity: str) -> str:
        """Get severity name from code."""
        severity_map = {
            '0': 'Not classified',
            '1': 'Information',
            '2': 'Warning',
            '3': 'Average',
            '4': 'High',
            '5': 'Disaster'
        }
        return severity_map.get(severity, 'Unknown')

    @staticmethod
    def _format_tags(tags: list) -> str:
        """Format tags for JIRA description."""
        if not tags:
            return 'No tags'

        tag_strs = [f"- {t['tag']}: {t['value']}" for t in tags]
        return '\n'.join(tag_strs)


def main():
    parser = argparse.ArgumentParser(
        description='JIRA integration for Zabbix problems',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    # Zabbix options
    parser.add_argument('--zabbix-url', required=True, help='Zabbix server URL')
    parser.add_argument('--zabbix-token', required=True, help='Zabbix API token')

    # JIRA options
    parser.add_argument('--jira-url', required=True, help='JIRA server URL')
    parser.add_argument('--jira-token', required=True, help='JIRA API token')
    parser.add_argument('--jira-email', help='JIRA email (for cloud authentication)')

    # Operation options
    parser.add_argument('--problem-id', help='Zabbix problem event ID to create ticket for')
    parser.add_argument('--project-key', required=True, help='JIRA project key')
    parser.add_argument('--issue-type', default='Bug', help='JIRA issue type (default: Bug)')
    parser.add_argument('--labels', help='Additional JIRA labels (comma-separated)')

    # Auto-create options
    parser.add_argument('--auto-create', action='store_true', help='Automatically create tickets for active problems')
    parser.add_argument('--severity', help='Severity filter for auto-create (comma-separated)')

    # Sync options
    parser.add_argument('--sync-resolution', help='Sync resolution from JIRA ticket (format: ISSUE-123:event_id)')

    args = parser.parse_args()

    try:
        # Initialize clients
        from zabbix_problem_monitor import ZabbixAPI

        zabbix_api = ZabbixAPI(args.zabbix_url, args.zabbix_token)
        jira_client = JiraClient(args.jira_url, args.jira_token, args.jira_email)
        integration = ZabbixJiraIntegration(zabbix_api, jira_client)

        # Parse labels
        labels = None
        if args.labels:
            labels = [l.strip() for l in args.labels.split(',')]

        # Sync resolution
        if args.sync_resolution:
            issue_key, event_id = args.sync_resolution.split(':')
            result = integration.sync_resolution(issue_key, event_id)
            print(json.dumps(result, indent=2))
            sys.exit(0)

        # Create ticket for single problem
        if args.problem_id:
            # Get problem details
            problems = zabbix_api.call('problem.get', {
                'eventids': [args.problem_id],
                'output': 'extend',
                'selectTags': 'extend'
            })

            if not problems:
                print(f"Error: Problem {args.problem_id} not found", file=sys.stderr)
                sys.exit(1)

            problem = problems[0]
            result = integration.create_ticket_from_problem(
                problem,
                args.project_key,
                args.issue_type,
                labels
            )

            print(f"Created JIRA ticket: {result['jira_issue']['key']}")
            print(f"JIRA URL: {args.jira_url}/browse/{result['jira_issue']['key']}")
            sys.exit(0)

        # Auto-create tickets
        if args.auto_create:
            # Get active problems
            params = {
                'output': 'extend',
                'selectTags': 'extend',
                'recent': True,
                'acknowledged': False
            }

            if args.severity:
                severity_map = {
                    'not_classified': '0',
                    'information': '1',
                    'warning': '2',
                    'average': '3',
                    'high': '4',
                    'disaster': '5'
                }
                severities = [severity_map.get(s.strip().lower(), s.strip()) for s in args.severity.split(',')]
                params['severities'] = severities

            problems = zabbix_api.call('problem.get', params)

            print(f"Found {len(problems)} unacknowledged problem(s)")

            created_count = 0
            for problem in problems:
                try:
                    result = integration.create_ticket_from_problem(
                        problem,
                        args.project_key,
                        args.issue_type,
                        labels
                    )
                    print(f"Created ticket {result['jira_issue']['key']} for problem {problem['eventid']}")
                    created_count += 1
                except Exception as e:
                    print(f"Error creating ticket for problem {problem['eventid']}: {e}", file=sys.stderr)

            print(f"\nCreated {created_count} JIRA ticket(s)")
            sys.exit(0)

        parser.print_help()
        sys.exit(1)

    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
