#!/usr/bin/env python3
"""
PagerDuty Integration for Zabbix Problems

Triggers PagerDuty incidents from Zabbix problems with escalation and acknowledgment sync.

Usage:
    python pagerduty_integration.py --zabbix-url https://zabbix.example.com \\
        --zabbix-token $ZABBIX_TOKEN --pagerduty-token $PD_TOKEN \\
        --routing-key $ROUTING_KEY --problem-id 12345
"""

import argparse
import json
import sys
from typing import Dict, Any, Optional
import requests
from datetime import datetime


import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
class PagerDutyClient:
    """PagerDuty Events API v2 client."""

    SEVERITY_MAP = {
        '5': 'critical',  # Disaster
        '4': 'error',     # High
        '3': 'warning',   # Average
        '2': 'warning',   # Warning
        '1': 'info',      # Information
        '0': 'info'       # Not classified
    }

    def __init__(self, routing_key: str):
        self.routing_key = routing_key
        self.events_url = 'https://events.pagerduty.com/v2/enqueue'

    def trigger_alert(
        self,
        summary: str,
        source: str,
        severity: str,
        custom_details: Optional[Dict] = None,
        dedup_key: Optional[str] = None
    ) -> Dict[str, Any]:
        """Trigger PagerDuty alert."""
        payload = {
            'routing_key': self.routing_key,
            'event_action': 'trigger',
            'payload': {
                'summary': summary,
                'source': source,
                'severity': severity
            }
        }

        if custom_details:
            payload['payload']['custom_details'] = custom_details

        if dedup_key:
            payload['dedup_key'] = dedup_key

        response = requests.post(
            self.events_url,
            json=payload,
            timeout=30
        )
        response.raise_for_status()

        return response.json()

    def acknowledge_alert(self, dedup_key: str) -> Dict[str, Any]:
        """Acknowledge PagerDuty alert."""
        payload = {
            'routing_key': self.routing_key,
            'event_action': 'acknowledge',
            'dedup_key': dedup_key
        }

        response = requests.post(
            self.events_url,
            json=payload,
            timeout=30
        )
        response.raise_for_status()

        return response.json()

    def resolve_alert(self, dedup_key: str) -> Dict[str, Any]:
        """Resolve PagerDuty alert."""
        payload = {
            'routing_key': self.routing_key,
            'event_action': 'resolve',
            'dedup_key': dedup_key
        }

        response = requests.post(
            self.events_url,
            json=payload,
            timeout=30
        )
        response.raise_for_status()

        return response.json()


class ZabbixPagerDutyIntegration:
    """Integration between Zabbix and PagerDuty."""

    def __init__(self, zabbix_api, pd_client: PagerDutyClient):
        self.zabbix_api = zabbix_api
        self.pd_client = pd_client

    def trigger_from_problem(
        self,
        problem: Dict[str, Any],
        source: str = 'Zabbix'
    ) -> Dict[str, Any]:
        """Trigger PagerDuty alert from Zabbix problem."""
        # Build summary
        summary = problem.get('name', 'Unknown Problem')

        # Get severity
        severity_code = problem.get('severity', '0')
        severity = self.pd_client.SEVERITY_MAP.get(severity_code, 'info')

        # Build custom details
        severity_name = self._get_severity_name(severity_code)
        timestamp = datetime.fromtimestamp(int(problem.get('clock', 0))).isoformat()

        tags = problem.get('tags', [])
        tags_dict = {t['tag']: t['value'] for t in tags}

        custom_details = {
            'event_id': problem.get('eventid'),
            'severity': severity_name,
            'detected_at': timestamp,
            'tags': tags_dict,
            'status': 'Active' if problem.get('r_eventid', '0') == '0' else 'Resolved'
        }

        # Use event ID as dedup key
        dedup_key = f"zabbix-{problem['eventid']}"

        # Trigger alert
        response = self.pd_client.trigger_alert(
            summary=summary,
            source=source,
            severity=severity,
            custom_details=custom_details,
            dedup_key=dedup_key
        )

        # Acknowledge problem in Zabbix
        self._acknowledge_with_pagerduty(problem['eventid'], response.get('dedup_key'))

        return {
            'pagerduty_response': response,
            'problem_eventid': problem['eventid'],
            'dedup_key': dedup_key
        }

    def acknowledge_from_zabbix(self, event_id: str) -> Dict[str, Any]:
        """Acknowledge PagerDuty alert when Zabbix problem is acknowledged."""
        dedup_key = f"zabbix-{event_id}"

        response = self.pd_client.acknowledge_alert(dedup_key)

        return {
            'status': 'acknowledged',
            'dedup_key': dedup_key,
            'pagerduty_response': response
        }

    def resolve_from_zabbix(self, event_id: str) -> Dict[str, Any]:
        """Resolve PagerDuty alert when Zabbix problem is resolved."""
        dedup_key = f"zabbix-{event_id}"

        response = self.pd_client.resolve_alert(dedup_key)

        return {
            'status': 'resolved',
            'dedup_key': dedup_key,
            'pagerduty_response': response
        }

    def sync_resolved_problems(self, time_from: int, time_till: int) -> Dict[str, Any]:
        """Sync resolved problems to PagerDuty."""
        # Get recently resolved problems
        problems = self.zabbix_api.call('problem.get', {
            'output': 'extend',
            'time_from': time_from,
            'time_till': time_till,
            'recent': False
        })

        resolved_count = 0
        errors = []

        for problem in problems:
            if problem.get('r_eventid', '0') != '0':  # Problem is resolved
                try:
                    self.resolve_from_zabbix(problem['eventid'])
                    resolved_count += 1
                except Exception as e:
                    errors.append({
                        'event_id': problem['eventid'],
                        'error': str(e)
                    })

        return {
            'total_problems': len(problems),
            'resolved_in_pagerduty': resolved_count,
            'errors': errors
        }

    def _acknowledge_with_pagerduty(self, event_id: str, dedup_key: str):
        """Acknowledge Zabbix problem with PagerDuty reference."""
        message = f"PagerDuty alert triggered: {dedup_key}"

        self.zabbix_api.call('event.acknowledge', {
            'eventids': [event_id],
            'action': 2,  # Acknowledge
            'message': message
        })

    @staticmethod
    def _get_severity_name(severity: str) -> str:
        """Get severity name from code."""
        severity_map = {
            '0': 'Not classified',
            '1': 'Information',
            '2': 'Warning',
            '3': 'Average',
            '4': 'High',
            '5': 'Disaster'
        }
        return severity_map.get(severity, 'Unknown')


def main():
    parser = argparse.ArgumentParser(description='PagerDuty integration for Zabbix problems')

    # Zabbix options
    parser.add_argument('--zabbix-url', required=True, help='Zabbix server URL')
    parser.add_argument('--zabbix-token', required=True, help='Zabbix API token')

    # PagerDuty options
    parser.add_argument('--routing-key', required=True, help='PagerDuty routing key (integration key)')

    # Operation options
    parser.add_argument('--problem-id', help='Zabbix problem event ID to trigger alert')
    parser.add_argument('--acknowledge', help='Acknowledge PagerDuty alert for event ID')
    parser.add_argument('--resolve', help='Resolve PagerDuty alert for event ID')
    parser.add_argument('--sync-resolved', action='store_true', help='Sync recently resolved problems')
    parser.add_argument('--time-range', default='1h', help='Time range for sync (default: 1h)')

    args = parser.parse_args()

    try:
        # Initialize clients
        from zabbix_problem_monitor import ZabbixAPI

        zabbix_api = ZabbixAPI(args.zabbix_url, args.zabbix_token)
        pd_client = PagerDutyClient(args.routing_key)
        integration = ZabbixPagerDutyIntegration(zabbix_api, pd_client)

        # Trigger alert from problem
        if args.problem_id:
            problems = zabbix_api.call('problem.get', {
                'eventids': [args.problem_id],
                'output': 'extend',
                'selectTags': 'extend'
            })

            if not problems:
                print(f"Error: Problem {args.problem_id} not found", file=sys.stderr)
                sys.exit(1)

            problem = problems[0]
            result = integration.trigger_from_problem(problem)

            print(f"Triggered PagerDuty alert: {result['dedup_key']}")
            print(json.dumps(result['pagerduty_response'], indent=2))
            sys.exit(0)

        # Acknowledge alert
        if args.acknowledge:
            result = integration.acknowledge_from_zabbix(args.acknowledge)
            print(f"Acknowledged PagerDuty alert: {result['dedup_key']}")
            sys.exit(0)

        # Resolve alert
        if args.resolve:
            result = integration.resolve_from_zabbix(args.resolve)
            print(f"Resolved PagerDuty alert: {result['dedup_key']}")
            sys.exit(0)

        # Sync resolved problems
        if args.sync_resolved:
            from datetime import datetime, timedelta

            # Parse time range
            if args.time_range.endswith('h'):
                hours = int(args.time_range[:-1])
                time_from = datetime.now() - timedelta(hours=hours)
            elif args.time_range.endswith('d'):
                days = int(args.time_range[:-1])
                time_from = datetime.now() - timedelta(days=days)
            else:
                raise ValueError(f"Invalid time range: {args.time_range}")

            time_till = datetime.now()

            result = integration.sync_resolved_problems(
                int(time_from.timestamp()),
                int(time_till.timestamp())
            )

            print(f"Synced {result['resolved_in_pagerduty']}/{result['total_problems']} problems")
            if result['errors']:
                print(f"\nErrors: {len(result['errors'])}")
                for error in result['errors']:
                    print(f"  Event {error['event_id']}: {error['error']}")
            sys.exit(0)

        parser.print_help()
        sys.exit(1)

    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
