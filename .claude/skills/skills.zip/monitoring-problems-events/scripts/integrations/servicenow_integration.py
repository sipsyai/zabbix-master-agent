#!/usr/bin/env python3
"""
ServiceNow Integration for Zabbix Problems

Creates and manages ServiceNow incidents from Zabbix problems.

Usage:
    python servicenow_integration.py --zabbix-url https://zabbix.example.com \\
        --zabbix-token $ZABBIX_TOKEN --snow-instance your-instance \\
        --snow-token $SNOW_TOKEN --problem-id 12345
"""

import argparse
import json
import sys
from typing import Dict, Any, Optional
import requests
from datetime import datetime


import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
class ServiceNowClient:
    """ServiceNow REST API client."""

    SEVERITY_TO_IMPACT = {
        '5': '1',  # Disaster -> High
        '4': '2',  # High -> Medium
        '3': '2',  # Average -> Medium
        '2': '3',  # Warning -> Low
        '1': '3',  # Information -> Low
        '0': '3'   # Not classified -> Low
    }

    SEVERITY_TO_URGENCY = {
        '5': '1',  # Disaster -> High
        '4': '1',  # High -> High
        '3': '2',  # Average -> Medium
        '2': '3',  # Warning -> Low
        '1': '3',  # Information -> Low
        '0': '3'   # Not classified -> Low
    }

    def __init__(self, instance: str, username: str, password: str):
        self.base_url = f'https://{instance}.service-now.com'
        self.session = requests.Session()
        self.session.auth = (username, password)
        self.session.headers.update({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        })

    def create_incident(
        self,
        short_description: str,
        description: str,
        impact: str = '3',
        urgency: str = '3',
        category: str = 'Monitoring',
        assignment_group: Optional[str] = None
    ) -> Dict[str, Any]:
        """Create ServiceNow incident."""
        payload = {
            'short_description': short_description,
            'description': description,
            'impact': impact,
            'urgency': urgency,
            'category': category
        }

        if assignment_group:
            payload['assignment_group'] = assignment_group

        response = self.session.post(
            f'{self.base_url}/api/now/table/incident',
            json=payload,
            timeout=30
        )
        response.raise_for_status()

        return response.json()['result']

    def update_incident(self, sys_id: str, fields: Dict[str, Any]) -> Dict[str, Any]:
        """Update ServiceNow incident."""
        response = self.session.patch(
            f'{self.base_url}/api/now/table/incident/{sys_id}',
            json=fields,
            timeout=30
        )
        response.raise_for_status()

        return response.json()['result']

    def add_work_note(self, sys_id: str, note: str) -> Dict[str, Any]:
        """Add work note to incident."""
        return self.update_incident(sys_id, {'work_notes': note})

    def resolve_incident(
        self,
        sys_id: str,
        resolution_code: str = 'Solved Remotely',
        resolution_notes: str = ''
    ) -> Dict[str, Any]:
        """Resolve ServiceNow incident."""
        fields = {
            'state': '6',  # Resolved
            'close_code': resolution_code,
            'close_notes': resolution_notes
        }
        return self.update_incident(sys_id, fields)

    def get_incident(self, sys_id: str) -> Dict[str, Any]:
        """Get incident details."""
        response = self.session.get(
            f'{self.base_url}/api/now/table/incident/{sys_id}',
            timeout=30
        )
        response.raise_for_status()

        return response.json()['result']


class ZabbixServiceNowIntegration:
    """Integration between Zabbix and ServiceNow."""

    def __init__(self, zabbix_api, snow_client: ServiceNowClient):
        self.zabbix_api = zabbix_api
        self.snow_client = snow_client

    def create_incident_from_problem(
        self,
        problem: Dict[str, Any],
        assignment_group: Optional[str] = None
    ) -> Dict[str, Any]:
        """Create ServiceNow incident from Zabbix problem."""
        # Build short description
        short_description = f"[Zabbix] {problem.get('name', 'Unknown Problem')[:120]}"

        # Build description
        severity = problem.get('severity', '0')
        severity_name = self._get_severity_name(severity)
        timestamp = datetime.fromtimestamp(int(problem.get('clock', 0))).strftime('%Y-%m-%d %H:%M:%S')

        tags = problem.get('tags', [])
        tags_str = '\n'.join([f"  - {t['tag']}: {t['value']}" for t in tags]) if tags else '  None'

        description = f"""Zabbix Problem Report

Event ID: {problem.get('eventid', 'N/A')}
Severity: {severity_name}
Detected: {timestamp}
Status: {'Active' if problem.get('r_eventid', '0') == '0' else 'Resolved'}

Problem Description:
{problem.get('name', 'No description available')}

Tags:
{tags_str}

This incident was automatically created from a Zabbix monitoring alert.
"""

        # Determine impact and urgency from severity
        impact = self.snow_client.SEVERITY_TO_IMPACT.get(severity, '3')
        urgency = self.snow_client.SEVERITY_TO_URGENCY.get(severity, '3')

        # Create incident
        incident = self.snow_client.create_incident(
            short_description=short_description,
            description=description,
            impact=impact,
            urgency=urgency,
            assignment_group=assignment_group
        )

        # Acknowledge problem in Zabbix with ServiceNow reference
        incident_number = incident['number']
        self._acknowledge_with_incident(problem['eventid'], incident_number)

        return {
            'incident': incident,
            'problem_eventid': problem['eventid']
        }

    def sync_resolution(self, sys_id: str, event_id: str) -> Dict[str, Any]:
        """Sync resolution from ServiceNow to Zabbix."""
        incident = self.snow_client.get_incident(sys_id)
        state = incident['state']

        # If incident is resolved/closed
        if state in ['6', '7']:  # Resolved or Closed
            close_notes = incident.get('close_notes', 'Resolved in ServiceNow')

            message = f"Problem resolved via ServiceNow incident {incident['number']}. Notes: {close_notes}"

            # Close problem in Zabbix
            self.zabbix_api.call('event.acknowledge', {
                'eventids': [event_id],
                'action': 3,  # Close problem
                'message': message
            })

            return {
                'status': 'synced',
                'action': 'closed',
                'incident_number': incident['number'],
                'zabbix_event': event_id
            }

        return {
            'status': 'no_action',
            'incident_state': state
        }

    def _acknowledge_with_incident(self, event_id: str, incident_number: str):
        """Acknowledge Zabbix problem with ServiceNow incident reference."""
        message = f"ServiceNow incident created: {incident_number}"

        self.zabbix_api.call('event.acknowledge', {
            'eventids': [event_id],
            'action': 2,  # Acknowledge
            'message': message
        })

    @staticmethod
    def _get_severity_name(severity: str) -> str:
        """Get severity name from code."""
        severity_map = {
            '0': 'Not classified',
            '1': 'Information',
            '2': 'Warning',
            '3': 'Average',
            '4': 'High',
            '5': 'Disaster'
        }
        return severity_map.get(severity, 'Unknown')


def main():
    parser = argparse.ArgumentParser(description='ServiceNow integration for Zabbix problems')

    # Zabbix options
    parser.add_argument('--zabbix-url', required=True, help='Zabbix server URL')
    parser.add_argument('--zabbix-token', required=True, help='Zabbix API token')

    # ServiceNow options
    parser.add_argument('--snow-instance', required=True, help='ServiceNow instance name')
    parser.add_argument('--snow-username', required=True, help='ServiceNow username')
    parser.add_argument('--snow-password', required=True, help='ServiceNow password')

    # Operation options
    parser.add_argument('--problem-id', help='Zabbix problem event ID')
    parser.add_argument('--assignment-group', help='ServiceNow assignment group')

    args = parser.parse_args()

    try:
        # Initialize clients
        from zabbix_problem_monitor import ZabbixAPI

        zabbix_api = ZabbixAPI(args.zabbix_url, args.zabbix_token)
        snow_client = ServiceNowClient(args.snow_instance, args.snow_username, args.snow_password)
        integration = ZabbixServiceNowIntegration(zabbix_api, snow_client)

        if args.problem_id:
            # Get problem details
            problems = zabbix_api.call('problem.get', {
                'eventids': [args.problem_id],
                'output': 'extend',
                'selectTags': 'extend'
            })

            if not problems:
                print(f"Error: Problem {args.problem_id} not found", file=sys.stderr)
                sys.exit(1)

            problem = problems[0]
            result = integration.create_incident_from_problem(problem, args.assignment_group)

            print(f"Created ServiceNow incident: {result['incident']['number']}")
            print(f"Incident SysID: {result['incident']['sys_id']}")
            sys.exit(0)

        parser.print_help()
        sys.exit(1)

    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
