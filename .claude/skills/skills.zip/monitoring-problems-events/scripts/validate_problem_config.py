#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Validate Problem Configuration

Validates problem monitoring configurations, query syntax, acknowledgment templates,
and integration settings.

Usage:
    python validate_problem_config.py --config examples/problem_queries.json
    python validate_problem_config.py --template examples/acknowledgment_templates.yaml
    python validate_problem_config.py --all
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List, Any, Tuple


class ConfigValidator:
    """Configuration validation engine."""

    VALID_SEVERITIES = ['not_classified', 'information', 'warning', 'average', 'high', 'disaster']
    VALID_STATUSES = ['active', 'resolved']
    VALID_REPORT_TYPES = ['summary', 'mttr', 'mtta', 'top-offenders', 'trend']
    VALID_FORMATS = ['json', 'csv', 'pdf', 'html']

    def __init__(self):
        self.errors = []
        self.warnings = []

    def validate_problem_query(self, query: Dict[str, Any], query_name: str = 'query') -> bool:
        """Validate problem query configuration."""
        is_valid = True

        # Check severity
        if 'severity' in query:
            severities = query['severity'] if isinstance(query['severity'], list) else [query['severity']]
            for sev in severities:
                if sev.lower() not in self.VALID_SEVERITIES:
                    self.errors.append(f"{query_name}: Invalid severity '{sev}'")
                    is_valid = False

        # Check status
        if 'status' in query:
            if query['status'].lower() not in self.VALID_STATUSES:
                self.errors.append(f"{query_name}: Invalid status '{query['status']}'")
                is_valid = False

        # Check time_range format
        if 'time_range' in query:
            if not self._validate_time_range(query['time_range']):
                self.errors.append(f"{query_name}: Invalid time_range format '{query['time_range']}'")
                is_valid = False

        # Check tags format
        if 'tags' in query:
            if not isinstance(query['tags'], list):
                self.errors.append(f"{query_name}: 'tags' must be a list")
                is_valid = False
            else:
                for tag in query['tags']:
                    if not isinstance(tag, dict) or 'tag' not in tag:
                        self.errors.append(f"{query_name}: Invalid tag format")
                        is_valid = False

        # Check output format
        if 'output_format' in query:
            if query['output_format'].lower() not in self.VALID_FORMATS:
                self.errors.append(f"{query_name}: Invalid output_format '{query['output_format']}'")
                is_valid = False

        return is_valid

    def validate_acknowledgment_template(self, template: Dict[str, Any], template_name: str) -> bool:
        """Validate acknowledgment template."""
        is_valid = True

        # Check required fields
        if 'message' not in template and 'template' not in template:
            self.errors.append(f"{template_name}: Missing 'message' or 'template' field")
            is_valid = False

        # Check variables
        if 'variables' in template:
            if not isinstance(template['variables'], (list, dict)):
                self.errors.append(f"{template_name}: 'variables' must be list or dict")
                is_valid = False

        # Check actions
        if 'actions' in template:
            valid_actions = ['acknowledge', 'close', 'suppress', 'change_severity']
            actions = template['actions'] if isinstance(template['actions'], list) else [template['actions']]
            for action in actions:
                if action.lower() not in valid_actions:
                    self.warnings.append(f"{template_name}: Unknown action '{action}'")

        return is_valid

    def validate_correlation_rule(self, rule: Dict[str, Any], rule_name: str) -> bool:
        """Validate event correlation rule."""
        is_valid = True

        # Check required fields
        required_fields = ['name', 'conditions']
        for field in required_fields:
            if field not in rule:
                self.errors.append(f"{rule_name}: Missing required field '{field}'")
                is_valid = False

        # Check time_window
        if 'time_window' in rule:
            if not isinstance(rule['time_window'], int) or rule['time_window'] <= 0:
                self.errors.append(f"{rule_name}: 'time_window' must be positive integer")
                is_valid = False

        # Check conditions
        if 'conditions' in rule:
            if not isinstance(rule['conditions'], list):
                self.errors.append(f"{rule_name}: 'conditions' must be a list")
                is_valid = False

        return is_valid

    def validate_report_config(self, config: Dict[str, Any], config_name: str) -> bool:
        """Validate report configuration."""
        is_valid = True

        # Check report type
        if 'report_type' in config:
            if config['report_type'] not in self.VALID_REPORT_TYPES:
                self.errors.append(f"{config_name}: Invalid report_type '{config['report_type']}'")
                is_valid = False

        # Check time_range
        if 'time_range' in config:
            if not self._validate_time_range(config['time_range']):
                self.errors.append(f"{config_name}: Invalid time_range '{config['time_range']}'")
                is_valid = False

        # Check format
        if 'format' in config:
            if config['format'].lower() not in self.VALID_FORMATS:
                self.errors.append(f"{config_name}: Invalid format '{config['format']}'")
                is_valid = False

        return is_valid

    def validate_integration_config(self, config: Dict[str, Any], config_name: str) -> bool:
        """Validate integration configuration."""
        is_valid = True

        # Check required fields based on integration type
        integration_type = config.get('type', '').lower()

        if integration_type == 'jira':
            required_fields = ['url', 'project_key']
            for field in required_fields:
                if field not in config:
                    self.errors.append(f"{config_name}: Missing required field '{field}' for JIRA integration")
                    is_valid = False

        elif integration_type == 'servicenow':
            required_fields = ['instance', 'table']
            for field in required_fields:
                if field not in config:
                    self.errors.append(f"{config_name}: Missing required field '{field}' for ServiceNow integration")
                    is_valid = False

        elif integration_type == 'pagerduty':
            required_fields = ['routing_key']
            for field in required_fields:
                if field not in config:
                    self.errors.append(f"{config_name}: Missing required field '{field}' for PagerDuty integration")
                    is_valid = False

        elif integration_type == 'webhook':
            if 'url' not in config:
                self.errors.append(f"{config_name}: Missing 'url' field for webhook integration")
                is_valid = False
            elif not config['url'].startswith(('http://', 'https://')):
                self.errors.append(f"{config_name}: Invalid webhook URL")
                is_valid = False

        # Check authentication
        if 'auth' in config:
            auth_type = config['auth'].get('type', '').lower()
            if auth_type not in ['token', 'basic', 'oauth', 'none']:
                self.warnings.append(f"{config_name}: Unknown auth type '{auth_type}'")

        return is_valid

    def validate_dashboard_config(self, config: Dict[str, Any], config_name: str) -> bool:
        """Validate dashboard configuration."""
        is_valid = True

        # Check widgets
        if 'widgets' in config:
            if not isinstance(config['widgets'], list):
                self.errors.append(f"{config_name}: 'widgets' must be a list")
                is_valid = False
            else:
                for idx, widget in enumerate(config['widgets']):
                    if 'type' not in widget:
                        self.errors.append(f"{config_name}: Widget {idx} missing 'type' field")
                        is_valid = False

        return is_valid

    def validate_bulk_operation(self, operation: Dict[str, Any], operation_name: str) -> bool:
        """Validate bulk operation configuration."""
        is_valid = True

        # Check required fields
        if 'action' not in operation:
            self.errors.append(f"{operation_name}: Missing 'action' field")
            is_valid = False

        # Check filters
        if 'filters' in operation:
            is_valid &= self.validate_problem_query(operation['filters'], f"{operation_name}.filters")

        # Check safety limits
        if 'max_problems' in operation:
            if not isinstance(operation['max_problems'], int) or operation['max_problems'] <= 0:
                self.errors.append(f"{operation_name}: 'max_problems' must be positive integer")
                is_valid = False

        # Warn about bulk operations without filters
        if 'filters' not in operation:
            self.warnings.append(f"{operation_name}: No filters specified for bulk operation")

        return is_valid

    @staticmethod
    def _validate_time_range(time_range: str) -> bool:
        """Validate time range format."""
        import re
        pattern = r'^\d+[mhd]$'
        return bool(re.match(pattern, time_range))

    def get_results(self) -> Tuple[bool, List[str], List[str]]:
        """Get validation results."""
        is_valid = len(self.errors) == 0
        return is_valid, self.errors, self.warnings


def validate_json_file(file_path: Path, validator: ConfigValidator) -> bool:
    """Validate JSON configuration file."""
    try:
        with open(file_path, 'r') as f:
            data = json.load(f)

        file_name = file_path.name

        if 'problem_queries' in file_name or 'queries' in file_name:
            if isinstance(data, dict):
                for name, query in data.items():
                    validator.validate_problem_query(query, name)
            elif isinstance(data, list):
                for idx, query in enumerate(data):
                    validator.validate_problem_query(query, f"query_{idx}")

        elif 'correlation' in file_name:
            if isinstance(data, dict):
                for name, rule in data.items():
                    validator.validate_correlation_rule(rule, name)
            elif isinstance(data, list):
                for idx, rule in enumerate(data):
                    validator.validate_correlation_rule(rule, f"rule_{idx}")

        elif 'integration' in file_name:
            if isinstance(data, dict):
                for name, config in data.items():
                    validator.validate_integration_config(config, name)
            elif isinstance(data, list):
                for idx, config in enumerate(data):
                    validator.validate_integration_config(config, f"integration_{idx}")

        elif 'bulk' in file_name:
            if isinstance(data, dict):
                for name, operation in data.items():
                    validator.validate_bulk_operation(operation, name)
            elif isinstance(data, list):
                for idx, operation in enumerate(data):
                    validator.validate_bulk_operation(operation, f"operation_{idx}")

        return True

    except json.JSONDecodeError as e:
        validator.errors.append(f"{file_path}: JSON parse error - {str(e)}")
        return False
    except Exception as e:
        validator.errors.append(f"{file_path}: {str(e)}")
        return False


def validate_yaml_file(file_path: Path, validator: ConfigValidator) -> bool:
    """Validate YAML configuration file."""
    try:
        import yaml
    except ImportError:
        validator.warnings.append("PyYAML not installed, skipping YAML validation")
        return True

    try:
        with open(file_path, 'r') as f:
            data = yaml.safe_load(f)

        file_name = file_path.name

        if 'acknowledgment' in file_name or 'template' in file_name:
            if isinstance(data, dict):
                for name, template in data.items():
                    validator.validate_acknowledgment_template(template, name)

        elif 'report' in file_name:
            if isinstance(data, dict):
                for name, config in data.items():
                    validator.validate_report_config(config, name)

        elif 'dashboard' in file_name:
            if isinstance(data, dict):
                for name, config in data.items():
                    validator.validate_dashboard_config(config, name)

        elif 'bulk' in file_name:
            if isinstance(data, dict):
                for name, operation in data.items():
                    validator.validate_bulk_operation(operation, name)

        return True

    except yaml.YAMLError as e:
        validator.errors.append(f"{file_path}: YAML parse error - {str(e)}")
        return False
    except Exception as e:
        validator.errors.append(f"{file_path}: {str(e)}")
        return False


def main():
    parser = argparse.ArgumentParser(
        description='Validate problem monitoring configurations',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument('--config', help='Configuration file to validate')
    parser.add_argument('--template', help='Template file to validate')
    parser.add_argument('--all', action='store_true', help='Validate all configuration files in examples/')
    parser.add_argument('--verbose', action='store_true', help='Show detailed validation results')

    args = parser.parse_args()

    validator = ConfigValidator()
    files_validated = 0

    if args.all:
        # Validate all files in examples directory
        examples_dir = Path(__file__).parent.parent / 'examples'
        if not examples_dir.exists():
            print(f"Error: Examples directory not found: {examples_dir}", file=sys.stderr)
            sys.exit(1)

        for file_path in examples_dir.glob('*'):
            if file_path.suffix in ['.json', '.yaml', '.yml']:
                print(f"Validating {file_path.name}...", end=' ')
                if file_path.suffix == '.json':
                    validate_json_file(file_path, validator)
                else:
                    validate_yaml_file(file_path, validator)
                files_validated += 1
                print("Done")

    elif args.config:
        file_path = Path(args.config)
        if not file_path.exists():
            print(f"Error: File not found: {file_path}", file=sys.stderr)
            sys.exit(1)

        if file_path.suffix == '.json':
            validate_json_file(file_path, validator)
        else:
            validate_yaml_file(file_path, validator)
        files_validated = 1

    elif args.template:
        file_path = Path(args.template)
        if not file_path.exists():
            print(f"Error: File not found: {file_path}", file=sys.stderr)
            sys.exit(1)

        validate_yaml_file(file_path, validator)
        files_validated = 1

    else:
        parser.print_help()
        sys.exit(1)

    # Get results
    is_valid, errors, warnings = validator.get_results()

    # Print results
    print(f"\nValidation Results:")
    print(f"  Files validated: {files_validated}")
    print(f"  Errors: {len(errors)}")
    print(f"  Warnings: {len(warnings)}")

    if errors:
        print("\nErrors:")
        for error in errors:
            print(f"  [ERROR] {error}")

    if warnings:
        print("\nWarnings:")
        for warning in warnings:
            print(f"  [WARN] {warning}")

    if is_valid:
        print("\n[OK] All validations passed!")
        sys.exit(0)
    else:
        print("\n[ERROR] Validation failed!")
        sys.exit(1)


if __name__ == '__main__':
    main()
