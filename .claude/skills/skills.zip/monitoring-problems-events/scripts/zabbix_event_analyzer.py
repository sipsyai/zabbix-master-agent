#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Event Analyzer

Analyzes event history, performs correlation analysis, and identifies root causes.

Usage:
    python zabbix_event_analyzer.py --url https://zabbix.example.com \\
        --token $ZABBIX_TOKEN --host "db-server-01" --time-range 1h

    python zabbix_event_analyzer.py --url https://zabbix.example.com \\
        --token $ZABBIX_TOKEN --analyze-correlation --time-range 30m

    python zabbix_event_analyzer.py --url https://zabbix.example.com \\
        --token $ZABBIX_TOKEN --timeline --host "web-*" --output timeline.json
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from collections import defaultdict
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


class ZabbixAPI:
    """Zabbix API client with retry logic."""

    def __init__(self, url: str, token: str):
        self.url = url.rstrip('/') + '/api_jsonrpc.php'
        self.token = token
        self.session = self._create_session()

    def _create_session(self) -> requests.Session:
        """Create session with retry logic."""
        session = requests.Session()
        retry = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[500, 502, 503, 504]
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        return session

    def call(self, method: str, params: Dict[str, Any]) -> Any:
        """Make API call with error handling."""
        payload = {
            'jsonrpc': '2.0',
            'method': method,
            'params': params,
            'auth': self.token,
            'id': 1
        }

        try:
            response = self.session.post(
                self.url,
                json=payload,
                headers={'Content-Type': 'application/json'},
                timeout=30
            )
            response.raise_for_status()

            result = response.json()

            if 'error' in result:
                raise Exception(f"API Error: {result['error']['message']} (Code: {result['error']['code']})")

            return result.get('result', [])

        except requests.exceptions.RequestException as e:
            raise Exception(f"Network error: {str(e)}")


class EventAnalyzer:
    """Event analysis and correlation engine."""

    SEVERITY_NAMES = {
        '0': 'Not classified',
        '1': 'Information',
        '2': 'Warning',
        '3': 'Average',
        '4': 'High',
        '5': 'Disaster'
    }

    def __init__(self, api: ZabbixAPI):
        self.api = api

    def get_events(
        self,
        time_from: int,
        time_till: int,
        hosts: Optional[List[str]] = None,
        severities: Optional[List[str]] = None,
        source: int = 0,  # 0 = trigger events
        value: Optional[int] = None  # 1 = PROBLEM, 0 = OK
    ) -> List[Dict[str, Any]]:
        """
        Retrieve events within time range.

        Args:
            time_from: Start time (Unix timestamp)
            time_till: End time (Unix timestamp)
            hosts: Host filter patterns
            severities: Severity filter
            source: Event source (0=trigger, 3=internal)
            value: Event value (1=PROBLEM, 0=OK)

        Returns:
            List of events
        """
        params = {
            'output': 'extend',
            'selectHosts': ['hostid', 'host', 'name'],
            'selectRelatedObject': 'extend',
            'selectTags': 'extend',
            'source': source,
            'time_from': time_from,
            'time_till': time_till,
            'sortfield': ['clock'],
            'sortorder': 'ASC'
        }

        if value is not None:
            params['value'] = value

        if severities:
            params['severities'] = severities

        events = self.api.call('event.get', params)

        # Filter by host patterns if specified
        if hosts:
            events = self._filter_by_hosts(events, hosts)

        return events

    def _filter_by_hosts(self, events: List[Dict], host_patterns: List[str]) -> List[Dict]:
        """Filter events by host patterns."""
        filtered_events = []

        for event in events:
            event_hosts = event.get('hosts', [])
            for host in event_hosts:
                host_name = host.get('host', '')

                for pattern in host_patterns:
                    if self._match_pattern(host_name, pattern):
                        filtered_events.append(event)
                        break

        return filtered_events

    @staticmethod
    def _match_pattern(text: str, pattern: str) -> bool:
        """Simple pattern matching with wildcards."""
        import re
        regex_pattern = pattern.replace('*', '.*').replace('?', '.')
        return bool(re.match(f'^{regex_pattern}$', text, re.IGNORECASE))

    def build_timeline(self, events: List[Dict]) -> List[Dict[str, Any]]:
        """
        Build event timeline with enhanced information.

        Args:
            events: List of events

        Returns:
            Sorted timeline of events
        """
        timeline = []

        for event in events:
            clock = int(event.get('clock', 0))
            timestamp = datetime.fromtimestamp(clock)

            hosts = event.get('hosts', [])
            host_names = [h.get('host', 'Unknown') for h in hosts]

            related_obj = event.get('relatedObject', {})
            trigger_name = related_obj.get('description', event.get('name', 'Unknown'))

            severity = event.get('severity', '0')
            severity_name = self.SEVERITY_NAMES.get(severity, 'Unknown')

            value = event.get('value', '0')
            event_type = 'PROBLEM' if value == '1' else 'RESOLVED'

            tags = event.get('tags', [])

            timeline_entry = {
                'eventid': event.get('eventid'),
                'timestamp': timestamp.isoformat(),
                'timestamp_unix': clock,
                'hosts': host_names,
                'type': event_type,
                'severity': severity_name,
                'severity_code': severity,
                'name': trigger_name,
                'tags': tags
            }

            timeline.append(timeline_entry)

        return sorted(timeline, key=lambda x: x['timestamp_unix'])

    def correlate_events(
        self,
        events: List[Dict],
        time_window: int = 300  # 5 minutes
    ) -> Dict[str, Any]:
        """
        Correlate events to identify related problems.

        Args:
            events: List of events to analyze
            time_window: Time window in seconds for correlation

        Returns:
            Correlation analysis results
        """
        # Group events by host
        events_by_host = defaultdict(list)
        for event in events:
            hosts = event.get('hosts', [])
            for host in hosts:
                host_name = host.get('host', 'Unknown')
                events_by_host[host_name].append(event)

        # Find correlated event groups
        correlated_groups = []

        # Sort events by time
        sorted_events = sorted(events, key=lambda e: int(e.get('clock', 0)))

        for i, primary_event in enumerate(sorted_events):
            if primary_event.get('value') != '1':  # Skip non-PROBLEM events
                continue

            primary_time = int(primary_event.get('clock', 0))
            primary_hosts = [h.get('host') for h in primary_event.get('hosts', [])]

            # Find events within time window
            related_events = []

            for j, other_event in enumerate(sorted_events[i+1:], start=i+1):
                other_time = int(other_event.get('clock', 0))

                # Check if within time window
                if other_time - primary_time > time_window:
                    break

                if other_event.get('value') == '1':  # PROBLEM events
                    related_events.append({
                        'eventid': other_event.get('eventid'),
                        'time_offset': other_time - primary_time,
                        'hosts': [h.get('host') for h in other_event.get('hosts', [])],
                        'name': other_event.get('relatedObject', {}).get('description', 'Unknown'),
                        'severity': other_event.get('severity')
                    })

            if related_events:
                correlated_groups.append({
                    'primary_event': {
                        'eventid': primary_event.get('eventid'),
                        'timestamp': datetime.fromtimestamp(primary_time).isoformat(),
                        'hosts': primary_hosts,
                        'name': primary_event.get('relatedObject', {}).get('description', 'Unknown'),
                        'severity': primary_event.get('severity')
                    },
                    'related_events': related_events,
                    'correlation_window': time_window
                })

        # Identify potential root causes
        root_causes = self._identify_root_causes(correlated_groups)

        return {
            'total_events': len(events),
            'problem_events': len([e for e in events if e.get('value') == '1']),
            'correlated_groups': correlated_groups,
            'potential_root_causes': root_causes
        }

    def _identify_root_causes(self, correlated_groups: List[Dict]) -> List[Dict]:
        """
        Identify potential root causes from correlated event groups.

        Args:
            correlated_groups: List of correlated event groups

        Returns:
            List of potential root causes
        """
        root_causes = []

        for group in correlated_groups:
            primary = group['primary_event']
            related = group['related_events']

            # Primary event triggered multiple subsequent events
            if len(related) >= 2:
                root_causes.append({
                    'type': 'cascade_failure',
                    'root_event': primary,
                    'affected_count': len(related),
                    'confidence': 'high' if len(related) >= 3 else 'medium',
                    'description': f"Primary event likely caused {len(related)} subsequent problems"
                })

            # Check for host-level correlation
            primary_hosts = set(primary['hosts'])
            affected_hosts = set()
            for rel in related:
                affected_hosts.update(rel['hosts'])

            if affected_hosts and primary_hosts.intersection(affected_hosts):
                root_causes.append({
                    'type': 'host_level_issue',
                    'root_event': primary,
                    'affected_hosts': list(affected_hosts),
                    'confidence': 'high',
                    'description': f"Host-level issue affecting {len(affected_hosts)} host(s)"
                })

        return root_causes

    def aggregate_events(
        self,
        events: List[Dict],
        group_by: str = 'host'
    ) -> Dict[str, Any]:
        """
        Aggregate events by various dimensions.

        Args:
            events: List of events
            group_by: Aggregation dimension (host, severity, tag)

        Returns:
            Aggregated statistics
        """
        if group_by == 'host':
            return self._aggregate_by_host(events)
        elif group_by == 'severity':
            return self._aggregate_by_severity(events)
        elif group_by == 'tag':
            return self._aggregate_by_tag(events)
        else:
            raise ValueError(f"Invalid group_by: {group_by}")

    def _aggregate_by_host(self, events: List[Dict]) -> Dict[str, Any]:
        """Aggregate events by host."""
        host_stats = defaultdict(lambda: {'problem_count': 0, 'events': []})

        for event in events:
            if event.get('value') != '1':  # Skip non-PROBLEM events
                continue

            hosts = event.get('hosts', [])
            for host in hosts:
                host_name = host.get('host', 'Unknown')
                host_stats[host_name]['problem_count'] += 1
                host_stats[host_name]['events'].append({
                    'eventid': event.get('eventid'),
                    'name': event.get('relatedObject', {}).get('description', 'Unknown'),
                    'severity': event.get('severity'),
                    'timestamp': datetime.fromtimestamp(int(event.get('clock', 0))).isoformat()
                })

        # Sort by problem count
        sorted_hosts = sorted(
            host_stats.items(),
            key=lambda x: x[1]['problem_count'],
            reverse=True
        )

        return {
            'group_by': 'host',
            'total_hosts': len(sorted_hosts),
            'hosts': [
                {
                    'host': host,
                    'problem_count': stats['problem_count'],
                    'events': stats['events']
                }
                for host, stats in sorted_hosts
            ]
        }

    def _aggregate_by_severity(self, events: List[Dict]) -> Dict[str, Any]:
        """Aggregate events by severity."""
        severity_stats = defaultdict(lambda: {'problem_count': 0, 'events': []})

        for event in events:
            if event.get('value') != '1':
                continue

            severity = event.get('severity', '0')
            severity_name = self.SEVERITY_NAMES.get(severity, 'Unknown')

            severity_stats[severity_name]['problem_count'] += 1
            severity_stats[severity_name]['events'].append({
                'eventid': event.get('eventid'),
                'name': event.get('relatedObject', {}).get('description', 'Unknown'),
                'hosts': [h.get('host') for h in event.get('hosts', [])],
                'timestamp': datetime.fromtimestamp(int(event.get('clock', 0))).isoformat()
            })

        return {
            'group_by': 'severity',
            'severities': [
                {
                    'severity': severity,
                    'problem_count': stats['problem_count'],
                    'events': stats['events']
                }
                for severity, stats in severity_stats.items()
            ]
        }

    def _aggregate_by_tag(self, events: List[Dict]) -> Dict[str, Any]:
        """Aggregate events by tags."""
        tag_stats = defaultdict(lambda: {'problem_count': 0, 'events': []})

        for event in events:
            if event.get('value') != '1':
                continue

            tags = event.get('tags', [])
            for tag in tags:
                tag_str = f"{tag.get('tag')}:{tag.get('value')}"
                tag_stats[tag_str]['problem_count'] += 1
                tag_stats[tag_str]['events'].append({
                    'eventid': event.get('eventid'),
                    'name': event.get('relatedObject', {}).get('description', 'Unknown'),
                    'hosts': [h.get('host') for h in event.get('hosts', [])],
                    'timestamp': datetime.fromtimestamp(int(event.get('clock', 0))).isoformat()
                })

        # Sort by problem count
        sorted_tags = sorted(
            tag_stats.items(),
            key=lambda x: x[1]['problem_count'],
            reverse=True
        )

        return {
            'group_by': 'tag',
            'total_tags': len(sorted_tags),
            'tags': [
                {
                    'tag': tag,
                    'problem_count': stats['problem_count'],
                    'events': stats['events']
                }
                for tag, stats in sorted_tags
            ]
        }


def parse_time_range(time_range: str) -> Tuple[int, int]:
    """Parse time range string to Unix timestamps."""
    now = datetime.now()

    if time_range.endswith('h'):
        hours = int(time_range[:-1])
        time_from = now - timedelta(hours=hours)
    elif time_range.endswith('d'):
        days = int(time_range[:-1])
        time_from = now - timedelta(days=days)
    elif time_range.endswith('m'):
        minutes = int(time_range[:-1])
        time_from = now - timedelta(minutes=minutes)
    else:
        raise ValueError(f"Invalid time range format: {time_range}")

    return int(time_from.timestamp()), int(now.timestamp())


def main():
    parser = argparse.ArgumentParser(
        description='Analyze Zabbix events and correlate problems',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Analyze events for specific host
  %(prog)s --url https://zabbix.example.com --token TOKEN \\
           --host "db-server-01" --time-range 1h

  # Build event timeline
  %(prog)s --url https://zabbix.example.com --token TOKEN \\
           --timeline --time-range 30m --output timeline.json

  # Correlate events within 5-minute windows
  %(prog)s --url https://zabbix.example.com --token TOKEN \\
           --analyze-correlation --time-range 1h --correlation-window 300

  # Aggregate events by host
  %(prog)s --url https://zabbix.example.com --token TOKEN \\
           --aggregate host --time-range 24h

  # Aggregate by severity
  %(prog)s --url https://zabbix.example.com --token TOKEN \\
           --aggregate severity --time-range 7d
        """
    )

    parser.add_argument('--url', required=True, help='Zabbix server URL')
    parser.add_argument('--token', required=True, help='Zabbix API token')

    # Filters
    parser.add_argument('--time-range', required=True, help='Time range (e.g., 1h, 24h, 7d)')
    parser.add_argument('--host', help='Host filter (comma-separated patterns, supports wildcards)')
    parser.add_argument('--severity', help='Severity filter (comma-separated)')
    parser.add_argument('--problems-only', action='store_true', help='Show only PROBLEM events')

    # Analysis options
    parser.add_argument('--timeline', action='store_true', help='Build event timeline')
    parser.add_argument('--analyze-correlation', action='store_true', help='Perform correlation analysis')
    parser.add_argument('--correlation-window', type=int, default=300, help='Correlation time window in seconds (default: 300)')
    parser.add_argument('--aggregate', choices=['host', 'severity', 'tag'], help='Aggregate events by dimension')

    # Output
    parser.add_argument('--output', help='Output file path (JSON format)')
    parser.add_argument('--pretty', action='store_true', help='Pretty print JSON output')

    args = parser.parse_args()

    try:
        # Initialize API
        api = ZabbixAPI(args.url, args.token)
        analyzer = EventAnalyzer(api)

        # Parse time range
        time_from, time_till = parse_time_range(args.time_range)

        # Parse filters
        hosts = None
        if args.host:
            hosts = [h.strip() for h in args.host.split(',')]

        severities = None
        if args.severity:
            severities = [s.strip() for s in args.severity.split(',')]

        value = 1 if args.problems_only else None

        # Get events
        print(f"Retrieving events from {datetime.fromtimestamp(time_from)} to {datetime.fromtimestamp(time_till)}...",
              file=sys.stderr)

        events = analyzer.get_events(
            time_from=time_from,
            time_till=time_till,
            hosts=hosts,
            severities=severities,
            value=value
        )

        print(f"Retrieved {len(events)} events", file=sys.stderr)

        # Perform analysis
        result = {}

        if args.timeline:
            result['timeline'] = analyzer.build_timeline(events)

        if args.analyze_correlation:
            result['correlation'] = analyzer.correlate_events(events, args.correlation_window)

        if args.aggregate:
            result['aggregation'] = analyzer.aggregate_events(events, args.aggregate)

        if not result:
            # Default: show timeline
            result['timeline'] = analyzer.build_timeline(events)

        # Output results
        output_json = json.dumps(result, indent=2 if args.pretty else None)

        if args.output:
            with open(args.output, 'w') as f:
                f.write(output_json)
            print(f"Results written to {args.output}", file=sys.stderr)
        else:
            print(output_json)

        sys.exit(0)

    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
