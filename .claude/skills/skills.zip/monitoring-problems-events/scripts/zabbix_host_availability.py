#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Zabbix Host Availability Checker
Checks host availability, interface status, agent connectivity, and recent data collection
"""

import argparse
import json
import sys
import os
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import requests
from dotenv import load_dotenv

import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
# Set UTF-8 encoding for Windows console
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

class ZabbixHostChecker:
    """Zabbix Host Availability Checker"""

    def __init__(self, url: str, username: str = None, password: str = None, token: str = None):
        """Initialize Zabbix API client"""
        self.url = url
        self.token = token
        self.auth_token = None
        self.request_id = 1

        # Authenticate if using username/password
        if username and password:
            self.authenticate(username, password)
        elif token:
            self.auth_token = token
        else:
            raise ValueError("Either provide username/password or API token")

    def authenticate(self, username: str, password: str) -> None:
        """Authenticate with username and password"""
        payload = {
            "jsonrpc": "2.0",
            "method": "user.login",
            "params": {
                "username": username,
                "password": password
            },
            "id": self.request_id,
        }

        try:
            response = requests.post(self.url, json=payload, headers={'Content-Type': 'application/json'}, timeout=30)
            response.raise_for_status()
            result = response.json()

            if 'error' in result:
                raise Exception(f"Authentication failed: {result['error'].get('message', result['error'].get('data', 'Unknown'))}")

            self.auth_token = result['result']
            self.request_id += 1
        except Exception as e:
            raise Exception(f"Authentication error: {str(e)}")

    def _make_request(self, method: str, params: Dict = None) -> Any:
        """Make API request"""
        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params or {},
            "id": self.request_id,
        }

        # Use Authorization header for Zabbix 7.0+
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.auth_token}'
        }

        try:
            response = requests.post(self.url, json=payload, headers=headers, timeout=30)
            response.raise_for_status()
            result = response.json()

            if 'error' in result:
                raise Exception(f"API Error: {result['error'].get('message', 'Unknown')} - {result['error'].get('data', '')}")

            self.request_id += 1
            return result['result']
        except Exception as e:
            raise Exception(f"API request failed: {str(e)}")

    def get_host_details(self, host_id: str) -> Optional[Dict]:
        """Get comprehensive host details"""
        params = {
            "output": "extend",
            "hostids": [host_id],
            "selectInterfaces": "extend",
            "selectInventory": "extend",
            "selectGroups": "extend",
            "selectTags": "extend"
        }

        result = self._make_request("host.get", params)
        return result[0] if result else None

    def get_host_problems(self, host_id: str, recent_only: bool = False) -> List[Dict]:
        """Get problems for the host"""
        params = {
            "output": "extend",
            "hostids": [host_id],
            "selectAcknowledges": "extend",
            "selectTags": "extend",
            "recent": recent_only,
            "sortfield": ["eventid"],
            "sortorder": "DESC"
        }

        return self._make_request("problem.get", params)

    def get_latest_items(self, host_id: str, limit: int = 10) -> List[Dict]:
        """Get latest item data for the host"""
        # First get items
        item_params = {
            "output": ["itemid", "name", "key_", "lastvalue", "lastclock", "status", "error"],
            "hostids": [host_id],
            "monitored": True,
            "limit": limit
        }

        items = self._make_request("item.get", item_params)

        # Format timestamps
        for item in items:
            if item.get('lastclock', '0') != '0' and item.get('lastclock'):
                try:
                    item['lastvalue_time'] = datetime.fromtimestamp(int(item['lastclock'])).strftime('%Y-%m-%d %H:%M:%S')
                except:
                    item['lastvalue_time'] = 'Never'
            else:
                item['lastvalue_time'] = 'Never'

        return items

    def get_agent_info_items(self, host_id: str) -> List[Dict]:
        """Get agent version and system information items"""
        item_params = {
            "output": ["itemid", "name", "key_", "lastvalue", "lastclock"],
            "hostids": [host_id],
            "search": {
                "key_": "agent"
            },
            "searchWildcardsEnabled": True
        }

        items = self._make_request("item.get", item_params)

        # Also search for system.uname
        system_params = {
            "output": ["itemid", "name", "key_", "lastvalue", "lastclock"],
            "hostids": [host_id],
            "search": {
                "key_": "system.uname"
            }
        }
        system_items = self._make_request("item.get", system_params)
        items.extend(system_items)

        for item in items:
            if item.get('lastclock', '0') != '0' and item.get('lastclock'):
                try:
                    item['lastvalue_time'] = datetime.fromtimestamp(int(item['lastclock'])).strftime('%Y-%m-%d %H:%M:%S')
                except:
                    item['lastvalue_time'] = 'Never'
            else:
                item['lastvalue_time'] = 'Never'

        return items

    def check_host_availability(self, host_id: str) -> Dict[str, Any]:
        """Comprehensive host availability check"""
        print(f"\n{'='*80}")
        print(f"HOST AVAILABILITY CHECK - ID: {host_id}")
        print(f"{'='*80}\n")

        # Get host details
        print("[1/6] Retrieving host details...")
        host = self.get_host_details(host_id)

        if not host:
            return {"error": f"Host with ID {host_id} not found"}

        print(f"      Host: {host['host']} (Name: {host['name']})")
        print(f"      Status: {'Enabled' if host['status'] == '0' else 'Disabled'}")

        # Host availability status
        print(f"\n[2/6] Checking host availability status...")
        availability = self._parse_availability(host)

        # Interfaces
        print(f"\n[3/6] Checking interfaces...")
        interfaces = self._parse_interfaces(host.get('interfaces', []))

        # Problems
        print(f"\n[4/6] Checking for problems...")
        problems = self.get_host_problems(host_id)
        print(f"      Found {len(problems)} active problem(s)")

        # Agent info
        print(f"\n[5/6] Checking agent information...")
        agent_items = self.get_agent_info_items(host_id)

        # Latest items
        print(f"\n[6/6] Checking latest item data...")
        latest_items = self.get_latest_items(host_id, limit=10)
        print(f"      Retrieved {len(latest_items)} latest items")

        # Build comprehensive report
        report = {
            "host_info": {
                "hostid": host['hostid'],
                "host": host['host'],
                "name": host['name'],
                "status": "Enabled" if host['status'] == '0' else "Disabled",
                "groups": [g['name'] for g in host.get('groups', [])],
                "tags": [{"tag": t['tag'], "value": t['value']} for t in host.get('tags', [])]
            },
            "availability": availability,
            "interfaces": interfaces,
            "problems": self._format_problems(problems),
            "agent_info": self._format_agent_info(agent_items),
            "latest_data": self._format_latest_items(latest_items),
            "inventory": host.get('inventory', {})
        }

        return report

    def _parse_availability(self, host: Dict) -> Dict[str, Any]:
        """Parse host availability status"""
        availability_status = {
            "0": "Unknown",
            "1": "Available",
            "2": "Unavailable"
        }

        result = {
            "zabbix_agent": {
                "status": availability_status.get(host.get('available', '0'), "Unknown"),
                "error": host.get('error', ''),
                "error_from": datetime.fromtimestamp(int(host.get('errors_from', '0'))).strftime('%Y-%m-%d %H:%M:%S') if host.get('errors_from', '0') != '0' else 'N/A'
            },
            "snmp": {
                "status": availability_status.get(host.get('snmp_available', '0'), "Unknown"),
                "error": host.get('snmp_error', ''),
                "error_from": datetime.fromtimestamp(int(host.get('snmp_errors_from', '0'))).strftime('%Y-%m-%d %H:%M:%S') if host.get('snmp_errors_from', '0') != '0' else 'N/A'
            },
            "ipmi": {
                "status": availability_status.get(host.get('ipmi_available', '0'), "Unknown"),
                "error": host.get('ipmi_error', ''),
                "error_from": datetime.fromtimestamp(int(host.get('ipmi_errors_from', '0'))).strftime('%Y-%m-%d %H:%M:%S') if host.get('ipmi_errors_from', '0') != '0' else 'N/A'
            },
            "jmx": {
                "status": availability_status.get(host.get('jmx_available', '0'), "Unknown"),
                "error": host.get('jmx_error', ''),
                "error_from": datetime.fromtimestamp(int(host.get('jmx_errors_from', '0'))).strftime('%Y-%m-%d %H:%M:%S') if host.get('jmx_errors_from', '0') != '0' else 'N/A'
            }
        }

        # Print availability summary
        print(f"      Zabbix Agent: {result['zabbix_agent']['status']}")
        if result['zabbix_agent']['error']:
            print(f"        Error: {result['zabbix_agent']['error']}")
            print(f"        Error Since: {result['zabbix_agent']['error_from']}")

        return result

    def _parse_interfaces(self, interfaces: List[Dict]) -> List[Dict]:
        """Parse interface information"""
        interface_types = {
            "1": "Zabbix Agent",
            "2": "SNMP",
            "3": "IPMI",
            "4": "JMX"
        }

        result = []
        for iface in interfaces:
            interface_info = {
                "type": interface_types.get(iface['type'], "Unknown"),
                "ip": iface['ip'],
                "dns": iface['dns'],
                "port": iface['port'],
                "useip": "IP" if iface['useip'] == '1' else "DNS",
                "main": "Yes" if iface['main'] == '1' else "No",
                "available": iface.get('available', 'Unknown'),
                "error": iface.get('error', '')
            }
            result.append(interface_info)

            # Print interface info
            print(f"      - {interface_info['type']}: {interface_info['ip']}:{interface_info['port']} (Main: {interface_info['main']})")
            if interface_info['error']:
                print(f"        Error: {interface_info['error']}")

        return result

    def _format_problems(self, problems: List[Dict]) -> List[Dict]:
        """Format problem information"""
        severity_names = {
            "0": "Not classified",
            "1": "Information",
            "2": "Warning",
            "3": "Average",
            "4": "High",
            "5": "Disaster"
        }

        result = []
        for problem in problems:
            problem_info = {
                "eventid": problem['eventid'],
                "name": problem['name'],
                "severity": severity_names.get(problem['severity'], "Unknown"),
                "time": datetime.fromtimestamp(int(problem['clock'])).strftime('%Y-%m-%d %H:%M:%S'),
                "acknowledged": "Yes" if problem['acknowledged'] == '1' else "No",
                "suppressed": "Yes" if problem.get('suppressed', '0') == '1' else "No"
            }
            result.append(problem_info)

            # Print problem summary
            if len(result) <= 5:  # Only print first 5
                print(f"      - [{problem_info['severity']}] {problem_info['name']} ({problem_info['time']})")

        if len(problems) > 5:
            print(f"      ... and {len(problems) - 5} more problem(s)")

        return result

    def _format_agent_info(self, items: List[Dict]) -> Dict[str, Any]:
        """Format agent information"""
        agent_info = {
            "version": None,
            "hostname": None,
            "system": None,
            "ping_status": None
        }

        for item in items:
            key = item.get('key_', '')
            value = item.get('lastvalue', 'N/A')

            if 'agent.version' in key:
                agent_info['version'] = value
                print(f"      Agent Version: {value}")
            elif 'system.uname' in key:
                agent_info['system'] = value
                print(f"      System: {value}")
            elif 'agent.hostname' in key:
                agent_info['hostname'] = value
                print(f"      Agent Hostname: {value}")
            elif 'agent.ping' in key:
                agent_info['ping_status'] = value
                print(f"      Agent Ping: {value}")

        if not any(agent_info.values()):
            print(f"      No agent information items found")

        return agent_info

    def _format_latest_items(self, items: List[Dict]) -> List[Dict]:
        """Format latest item data"""
        result = []
        for item in items:
            item_info = {
                "name": item['name'],
                "key": item['key_'],
                "last_value": item.get('lastvalue', 'N/A'),
                "last_time": item.get('lastvalue_time', 'Never'),
                "status": "Enabled" if item['status'] == '0' else "Disabled",
                "error": item.get('error', '')
            }
            result.append(item_info)

            # Print item summary
            if len(result) <= 5:
                status_indicator = "[OK]" if item['status'] == '0' and item.get('lastclock', '0') != '0' else "[ERROR]"
                print(f"      {status_indicator} {item_info['name']}: {item_info['last_value']} ({item_info['last_time']})")
                if item_info['error']:
                    print(f"        Error: {item_info['error']}")

        if len(items) > 5:
            print(f"      ... and {len(items) - 5} more item(s)")

        return result

    def print_summary(self, report: Dict) -> None:
        """Print a summary of findings"""
        print(f"\n{'='*80}")
        print("SUMMARY")
        print(f"{'='*80}\n")

        # Overall status
        agent_available = report['availability']['zabbix_agent']['status'] == 'Available'
        has_problems = len(report['problems']) > 0
        has_recent_data = any(item['last_time'] != 'Never' for item in report['latest_data'])

        print(f"Host Status: {report['host_info']['status']}")
        print(f"Agent Status: {report['availability']['zabbix_agent']['status']}")
        print(f"Active Problems: {len(report['problems'])}")
        print(f"Recent Data Collection: {'Yes' if has_recent_data else 'No'}")

        # Overall health
        if agent_available and not has_problems and has_recent_data:
            print(f"\nOverall Health: [OK] HEALTHY")
        elif agent_available and has_recent_data:
            print(f"\nOverall Health: [WARN] WARNING (Has active problems)")
        else:
            print(f"\nOverall Health: [ERROR] CRITICAL (Agent unavailable or no recent data)")

        # Recommendations
        print(f"\nRecommendations:")
        if not agent_available:
            print(f"  - Check Zabbix agent service on the host")
            if report['interfaces']:
                print(f"  - Verify network connectivity to {report['interfaces'][0]['ip']}:{report['interfaces'][0]['port']}")
            print(f"  - Check firewall rules")

        if report['availability']['zabbix_agent']['error']:
            print(f"  - Investigate agent error: {report['availability']['zabbix_agent']['error']}")

        if not has_recent_data:
            print(f"  - No recent data collected - agent may be down or not sending data")

        if has_problems:
            print(f"  - Review and acknowledge {len(report['problems'])} active problem(s)")

        print()


def main():
    parser = argparse.ArgumentParser(
        description="Check Zabbix host availability and connectivity status"
    )
    parser.add_argument(
        "--host-id",
        required=True,
        help="Host ID to check"
    )
    parser.add_argument(
        "--url",
        help="Zabbix API URL (default: from .env)"
    )
    parser.add_argument(
        "--username",
        help="Zabbix username (default: from .env)"
    )
    parser.add_argument(
        "--password",
        help="Zabbix password (default: from .env)"
    )
    parser.add_argument(
        "--token",
        help="Zabbix API token (default: from .env)"
    )
    parser.add_argument(
        "--output",
        choices=["json", "summary"],
        default="summary",
        help="Output format"
    )
    parser.add_argument(
        "--output-file",
        help="Save output to file"
    )

    args = parser.parse_args()

    # Load environment variables
    load_dotenv()

    # Get credentials from args or environment
    url = args.url or os.getenv('ZABBIX_API_URL')
    username = args.username or os.getenv('ZABBIX_USERNAME')
    password = args.password or os.getenv('ZABBIX_PASSWORD')
    token = args.token or os.getenv('ZABBIX_API_TOKEN')

    if not url:
        print("Error: Zabbix API URL not provided", file=sys.stderr)
        sys.exit(1)

    try:
        # Initialize checker
        checker = ZabbixHostChecker(url, username, password, token)

        # Perform availability check
        report = checker.check_host_availability(args.host_id)

        if "error" in report:
            print(f"\nError: {report['error']}", file=sys.stderr)
            sys.exit(1)

        # Print summary
        checker.print_summary(report)

        # Output results
        if args.output == "json":
            output = json.dumps(report, indent=2, ensure_ascii=False)
            if args.output_file:
                with open(args.output_file, 'w', encoding='utf-8') as f:
                    f.write(output)
                print(f"\nJSON report saved to: {args.output_file}")
            else:
                print(f"\n{'='*80}")
                print("JSON OUTPUT")
                print(f"{'='*80}\n")
                print(output)
        elif args.output_file:
            # For summary output to file, we would need to capture the printed output
            print(f"Summary output file writing not implemented for summary format")

    except Exception as e:
        print(f"\nError: {str(e)}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
