#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Problem Acknowledgment

Automates problem acknowledgment with support for single/bulk operations,
templated messages, and action documentation.

Usage:
    python zabbix_problem_ack.py --url https://zabbix.example.com \\
        --token $ZABBIX_TOKEN --problem-id 12345 \\
        --message "Investigating database issue"

    python zabbix_problem_ack.py --url https://zabbix.example.com \\
        --token $ZABBIX_TOKEN --problem-id 12345 \\
        --template incident_response --ticket JIRA-1234

    python zabbix_problem_ack.py --url https://zabbix.example.com \\
        --token $ZABBIX_TOKEN --bulk --severity disaster,high \\
        --message "Mass acknowledgment during incident response"
"""

import argparse
import json
import sys
from datetime import datetime
from typing import Dict, List, Any, Optional
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


class ZabbixAPI:
    """Zabbix API client with retry logic."""

    def __init__(self, url: str, token: str):
        self.url = url.rstrip('/') + '/api_jsonrpc.php'
        self.token = token
        self.session = self._create_session()

    def _create_session(self) -> requests.Session:
        """Create session with retry logic."""
        session = requests.Session()
        retry = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[500, 502, 503, 504]
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        return session

    def call(self, method: str, params: Dict[str, Any]) -> Any:
        """Make API call with error handling."""
        payload = {
            'jsonrpc': '2.0',
            'method': method,
            'params': params,
            'auth': self.token,
            'id': 1
        }

        try:
            response = self.session.post(
                self.url,
                json=payload,
                headers={'Content-Type': 'application/json'},
                timeout=30
            )
            response.raise_for_status()

            result = response.json()

            if 'error' in result:
                raise Exception(f"API Error: {result['error']['message']} (Code: {result['error']['code']})")

            return result.get('result', [])

        except requests.exceptions.RequestException as e:
            raise Exception(f"Network error: {str(e)}")


class ProblemAcknowledger:
    """Problem acknowledgment handler."""

    SEVERITY_MAP = {
        'not_classified': '0',
        'information': '1',
        'warning': '2',
        'average': '3',
        'high': '4',
        'disaster': '5'
    }

    # Action flags for acknowledgment
    ACTION_CLOSE = 1
    ACTION_ACK = 2
    ACTION_CHANGE_SEVERITY = 4
    ACTION_MESSAGE = 8
    ACTION_SUPPRESS = 16

    def __init__(self, api: ZabbixAPI):
        self.api = api

    def acknowledge_problem(
        self,
        event_ids: List[str],
        message: str,
        action: int = None,
        close: bool = False,
        suppress_until: Optional[int] = None,
        new_severity: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Acknowledge one or more problems.

        Args:
            event_ids: List of event IDs to acknowledge
            message: Acknowledgment message
            action: Action flags (use ACTION_* constants)
            close: Close the problems
            suppress_until: Unix timestamp to suppress until (0 for unlimited)
            new_severity: New severity level (0-5)

        Returns:
            API response with acknowledgment results
        """
        # Build action flags
        if action is None:
            action = self.ACTION_ACK | self.ACTION_MESSAGE

        if close:
            action |= self.ACTION_CLOSE

        if suppress_until is not None:
            action |= self.ACTION_SUPPRESS

        if new_severity is not None:
            action |= self.ACTION_CHANGE_SEVERITY

        # Build params
        params = {
            'eventids': event_ids,
            'action': action,
            'message': message
        }

        if suppress_until is not None:
            params['suppress_until'] = suppress_until

        if new_severity is not None:
            params['severity'] = new_severity

        return self.api.call('event.acknowledge', params)

    def get_unacknowledged_problems(
        self,
        severities: Optional[List[str]] = None,
        hosts: Optional[List[str]] = None,
        tags: Optional[List[Dict[str, str]]] = None
    ) -> List[Dict[str, Any]]:
        """Get list of unacknowledged problems."""
        params = {
            'output': 'extend',
            'selectTags': 'extend',
            'recent': True,
            'acknowledged': False,
            'sortfield': ['eventid'],
            'sortorder': 'DESC'
        }

        if severities:
            severity_codes = []
            for sev in severities:
                if sev.lower() in self.SEVERITY_MAP:
                    severity_codes.append(self.SEVERITY_MAP[sev.lower()])
            if severity_codes:
                params['severities'] = severity_codes

        if tags:
            params['tags'] = tags

        return self.api.call('problem.get', params)

    def bulk_acknowledge(
        self,
        message: str,
        severities: Optional[List[str]] = None,
        hosts: Optional[List[str]] = None,
        tags: Optional[List[Dict[str, str]]] = None,
        dry_run: bool = False,
        max_problems: int = 100
    ) -> Dict[str, Any]:
        """
        Acknowledge multiple problems matching criteria.

        Args:
            message: Acknowledgment message for all problems
            severities: Filter by severity levels
            hosts: Filter by host patterns
            tags: Filter by tags
            dry_run: If True, only show what would be acknowledged
            max_problems: Maximum number of problems to acknowledge

        Returns:
            Dictionary with operation results
        """
        # Get unacknowledged problems
        problems = self.get_unacknowledged_problems(severities, hosts, tags)

        if not problems:
            return {
                'status': 'success',
                'acknowledged': 0,
                'message': 'No unacknowledged problems found'
            }

        # Limit number of problems
        if len(problems) > max_problems:
            problems = problems[:max_problems]
            print(f"Warning: Limited to first {max_problems} problems", file=sys.stderr)

        event_ids = [p['eventid'] for p in problems]

        if dry_run:
            return {
                'status': 'dry_run',
                'would_acknowledge': len(event_ids),
                'problems': problems
            }

        # Acknowledge problems
        result = self.acknowledge_problem(event_ids, message)

        return {
            'status': 'success',
            'acknowledged': len(event_ids),
            'event_ids': event_ids,
            'api_response': result
        }


class MessageTemplateEngine:
    """Template engine for acknowledgment messages."""

    DEFAULT_TEMPLATES = {
        'incident_response': """
[Incident Response]
Ticket: {ticket}
Status: Investigating
Team: {team}
Next Update: {next_update}

Initial assessment: {assessment}
        """.strip(),

        'maintenance': """
[Planned Maintenance]
Window: {window}
Duration: {duration}
Impact: {impact}

This issue is expected during planned maintenance.
        """.strip(),

        'false_positive': """
[False Positive]
Reason: {reason}
Reviewed by: {reviewer}
Date: {date}

This alert has been reviewed and determined to be a false positive.
Monitoring configuration will be adjusted to prevent recurrence.
        """.strip(),

        'escalation': """
[Escalated to {level}]
Ticket: {ticket}
Escalated by: {escalated_by}
Reason: {reason}

Escalating to {level} for further investigation.
        """.strip(),

        'resolved': """
[Resolved]
Resolution: {resolution}
Root Cause: {root_cause}
Actions Taken: {actions}

Problem has been resolved. Monitoring for recurrence.
        """.strip(),

        'acknowledged': """
[Acknowledged]
Acknowledged by: {acknowledged_by}
Time: {time}

Problem has been acknowledged and is under investigation.
        """.strip()
    }

    def __init__(self, custom_templates: Optional[Dict[str, str]] = None):
        self.templates = self.DEFAULT_TEMPLATES.copy()
        if custom_templates:
            self.templates.update(custom_templates)

    def render(self, template_name: str, **variables) -> str:
        """
        Render template with variables.

        Args:
            template_name: Name of template to use
            **variables: Variables to substitute in template

        Returns:
            Rendered message
        """
        if template_name not in self.templates:
            raise ValueError(f"Unknown template: {template_name}")

        template = self.templates[template_name]

        # Add default variables
        if 'date' not in variables:
            variables['date'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        if 'time' not in variables:
            variables['time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        try:
            return template.format(**variables)
        except KeyError as e:
            raise ValueError(f"Missing required variable for template '{template_name}': {e}")

    def list_templates(self) -> List[str]:
        """List available template names."""
        return list(self.templates.keys())


def load_templates_from_file(file_path: str) -> Dict[str, str]:
    """Load custom templates from YAML file."""
    try:
        import yaml
        with open(file_path, 'r') as f:
            return yaml.safe_load(f)
    except ImportError:
        print("Warning: PyYAML not installed. Cannot load custom templates.", file=sys.stderr)
        return {}
    except Exception as e:
        print(f"Warning: Failed to load templates from {file_path}: {e}", file=sys.stderr)
        return {}


def parse_tags(tag_strings: List[str]) -> List[Dict[str, str]]:
    """Parse tag strings to tag filter format."""
    tags = []
    for tag_str in tag_strings:
        if ':' in tag_str:
            tag, value = tag_str.split(':', 1)
            tags.append({'tag': tag, 'value': value})
        else:
            tags.append({'tag': tag_str})
    return tags


def main():
    parser = argparse.ArgumentParser(
        description='Acknowledge Zabbix problems with templated messages',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Acknowledge single problem with message
  %(prog)s --url https://zabbix.example.com --token TOKEN \\
           --problem-id 12345 --message "Investigating database issue"

  # Acknowledge with template
  %(prog)s --url https://zabbix.example.com --token TOKEN \\
           --problem-id 12345 --template incident_response \\
           --var ticket=JIRA-1234 --var team="Database Team"

  # Bulk acknowledge critical problems
  %(prog)s --url https://zabbix.example.com --token TOKEN \\
           --bulk --severity disaster,high \\
           --message "Acknowledged during incident response"

  # Close problem with resolution
  %(prog)s --url https://zabbix.example.com --token TOKEN \\
           --problem-id 12345 --close \\
           --template resolved --var resolution="Database restarted" \\
           --var root_cause="Connection pool exhaustion"

  # Suppress problem
  %(prog)s --url https://zabbix.example.com --token TOKEN \\
           --problem-id 12345 --suppress-hours 24 \\
           --message "Suppressing during maintenance window"

  # Dry run for bulk operation
  %(prog)s --url https://zabbix.example.com --token TOKEN \\
           --bulk --severity disaster --dry-run
        """
    )

    parser.add_argument('--url', required=True, help='Zabbix server URL')
    parser.add_argument('--token', required=True, help='Zabbix API token')

    # Problem identification
    parser.add_argument('--problem-id', help='Single problem event ID to acknowledge')
    parser.add_argument('--problem-ids', help='Comma-separated list of event IDs')
    parser.add_argument('--bulk', action='store_true', help='Bulk acknowledge multiple problems')

    # Bulk filters
    parser.add_argument('--severity', help='Severity filter for bulk operations (comma-separated)')
    parser.add_argument('--host', help='Host filter for bulk operations (comma-separated patterns)')
    parser.add_argument('--tag', action='append', help='Tag filter (format: tag:value)')

    # Message options
    parser.add_argument('--message', help='Acknowledgment message (required if not using template)')
    parser.add_argument('--template', help='Message template name')
    parser.add_argument('--var', action='append', help='Template variable (format: key=value)')
    parser.add_argument('--template-file', help='Load custom templates from YAML file')
    parser.add_argument('--list-templates', action='store_true', help='List available templates')

    # Actions
    parser.add_argument('--close', action='store_true', help='Close the problem(s)')
    parser.add_argument('--suppress-hours', type=int, help='Suppress problem for N hours')
    parser.add_argument('--suppress-unlimited', action='store_true', help='Suppress problem indefinitely')

    # Options
    parser.add_argument('--dry-run', action='store_true', help='Show what would be done without making changes')
    parser.add_argument('--max-problems', type=int, default=100, help='Maximum problems for bulk operations (default: 100)')

    args = parser.parse_args()

    try:
        # Load templates
        custom_templates = {}
        if args.template_file:
            custom_templates = load_templates_from_file(args.template_file)

        template_engine = MessageTemplateEngine(custom_templates)

        # List templates if requested
        if args.list_templates:
            print("Available templates:")
            for name in template_engine.list_templates():
                print(f"  - {name}")
            sys.exit(0)

        # Initialize API client
        api = ZabbixAPI(args.url, args.token)
        acknowledger = ProblemAcknowledger(api)

        # Build message
        message = None
        if args.template:
            # Parse template variables
            variables = {}
            if args.var:
                for var in args.var:
                    if '=' not in var:
                        print(f"Error: Invalid variable format '{var}'. Use key=value", file=sys.stderr)
                        sys.exit(1)
                    key, value = var.split('=', 1)
                    variables[key] = value

            message = template_engine.render(args.template, **variables)
        elif args.message:
            message = args.message
        else:
            print("Error: Either --message or --template is required", file=sys.stderr)
            sys.exit(1)

        # Calculate suppress_until if needed
        suppress_until = None
        if args.suppress_hours:
            from datetime import datetime, timedelta
            future = datetime.now() + timedelta(hours=args.suppress_hours)
            suppress_until = int(future.timestamp())
        elif args.suppress_unlimited:
            suppress_until = 0

        # Handle bulk acknowledgment
        if args.bulk:
            severities = None
            if args.severity:
                severities = [s.strip() for s in args.severity.split(',')]

            hosts = None
            if args.host:
                hosts = [h.strip() for h in args.host.split(',')]

            tags = None
            if args.tag:
                tags = parse_tags(args.tag)

            result = acknowledger.bulk_acknowledge(
                message=message,
                severities=severities,
                hosts=hosts,
                tags=tags,
                dry_run=args.dry_run,
                max_problems=args.max_problems
            )

            if args.dry_run:
                print(f"\nDRY RUN: Would acknowledge {result['would_acknowledge']} problem(s)\n")
                print("Problems that would be acknowledged:")
                for p in result['problems']:
                    print(f"  - Event ID: {p['eventid']}, Name: {p['name']}")
            else:
                print(f"Successfully acknowledged {result['acknowledged']} problem(s)")

            sys.exit(0)

        # Handle single/multiple problem acknowledgment
        event_ids = []
        if args.problem_id:
            event_ids = [args.problem_id]
        elif args.problem_ids:
            event_ids = [e.strip() for e in args.problem_ids.split(',')]
        else:
            print("Error: Specify --problem-id, --problem-ids, or --bulk", file=sys.stderr)
            sys.exit(1)

        if args.dry_run:
            print(f"\nDRY RUN: Would acknowledge {len(event_ids)} problem(s)")
            print(f"Event IDs: {', '.join(event_ids)}")
            print(f"\nMessage:\n{message}")
            if args.close:
                print("\nWould also close the problem(s)")
            if suppress_until is not None:
                print(f"\nWould suppress until: {suppress_until}")
            sys.exit(0)

        # Acknowledge problems
        result = acknowledger.acknowledge_problem(
            event_ids=event_ids,
            message=message,
            close=args.close,
            suppress_until=suppress_until
        )

        print(f"Successfully acknowledged {len(event_ids)} problem(s)")
        print(f"Event IDs: {', '.join(event_ids)}")

        sys.exit(0)

    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
