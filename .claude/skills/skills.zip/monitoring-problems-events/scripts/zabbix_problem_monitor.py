#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Problem Monitor

Monitors and queries active problems in Zabbix with comprehensive filtering,
real-time monitoring, and export capabilities.

Usage:
    python zabbix_problem_monitor.py --url https://zabbix.example.com \\
        --token $ZABBIX_TOKEN --severity critical,disaster --status active

    python zabbix_problem_monitor.py --url https://zabbix.example.com \\
        --token $ZABBIX_TOKEN --host "db-*" --tag "Application:Database" \\
        --time-range 1h --output json

    python zabbix_problem_monitor.py --url https://zabbix.example.com \\
        --token $ZABBIX_TOKEN --monitor --interval 60 --alert-webhook https://hooks.slack.com/...
"""

import argparse
import json
import sys
import time
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


class ZabbixAPI:
    """Zabbix API client with retry logic and error handling."""

    def __init__(self, url: str, token: str):
        self.url = url.rstrip('/') + '/api_jsonrpc.php'
        self.token = token
        self.session = self._create_session()

    def _create_session(self) -> requests.Session:
        """Create session with retry logic."""
        session = requests.Session()
        retry = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[500, 502, 503, 504]
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        return session

    def call(self, method: str, params: Dict[str, Any]) -> Any:
        """Make API call with error handling."""
        payload = {
            'jsonrpc': '2.0',
            'method': method,
            'params': params,
            'auth': self.token,
            'id': 1
        }

        try:
            response = self.session.post(
                self.url,
                json=payload,
                headers={'Content-Type': 'application/json'},
                timeout=30
            )
            response.raise_for_status()

            result = response.json()

            if 'error' in result:
                raise Exception(f"API Error: {result['error']['message']} (Code: {result['error']['code']})")

            return result.get('result', [])

        except requests.exceptions.RequestException as e:
            raise Exception(f"Network error: {str(e)}")


class ProblemMonitor:
    """Main problem monitoring class."""

    SEVERITY_MAP = {
        'not_classified': '0',
        'information': '1',
        'warning': '2',
        'average': '3',
        'high': '4',
        'disaster': '5'
    }

    SEVERITY_NAMES = {
        '0': 'Not classified',
        '1': 'Information',
        '2': 'Warning',
        '3': 'Average',
        '4': 'High',
        '5': 'Disaster'
    }

    def __init__(self, api: ZabbixAPI):
        self.api = api
        self.last_problems = set()

    def get_problems(
        self,
        severities: Optional[List[str]] = None,
        status: Optional[str] = None,
        hosts: Optional[List[str]] = None,
        tags: Optional[List[Dict[str, str]]] = None,
        time_from: Optional[int] = None,
        time_till: Optional[int] = None,
        acknowledged: Optional[bool] = None,
        suppressed: Optional[bool] = None
    ) -> List[Dict[str, Any]]:
        """
        Query problems with comprehensive filtering.

        Args:
            severities: List of severity names (e.g., ['critical', 'disaster'])
            status: Problem status - 'active' or 'resolved'
            hosts: List of host name patterns
            tags: List of tag filters [{'tag': 'Application', 'value': 'Database'}]
            time_from: Unix timestamp for start time
            time_till: Unix timestamp for end time
            acknowledged: Filter by acknowledgment status
            suppressed: Filter by suppression status

        Returns:
            List of problems with full details
        """
        params = {
            'output': 'extend',
            'selectAcknowledges': 'extend',
            'selectTags': 'extend',
            'selectSuppressionData': 'extend',
            'recent': True,
            'sortfield': ['eventid'],
            'sortorder': 'DESC'
        }

        # Severity filter
        if severities:
            severity_codes = []
            for sev in severities:
                sev_lower = sev.lower()
                if sev_lower in self.SEVERITY_MAP:
                    severity_codes.append(self.SEVERITY_MAP[sev_lower])
            if severity_codes:
                params['severities'] = severity_codes

        # Status filter
        if status:
            if status.lower() == 'active':
                params['recent'] = True
            elif status.lower() == 'resolved':
                params['recent'] = False

        # Time filters
        if time_from:
            params['time_from'] = time_from
        if time_till:
            params['time_till'] = time_till

        # Acknowledgment filter
        if acknowledged is not None:
            params['acknowledged'] = acknowledged

        # Suppression filter
        if suppressed is not None:
            params['suppressed'] = suppressed

        # Tag filters
        if tags:
            params['tags'] = tags
            params['evaltype'] = 0  # AND/OR evaluation

        problems = self.api.call('problem.get', params)

        # Filter by host patterns if specified
        if hosts:
            problems = self._filter_by_hosts(problems, hosts)

        return problems

    def _filter_by_hosts(self, problems: List[Dict], host_patterns: List[str]) -> List[Dict]:
        """Filter problems by host name patterns."""
        if not problems:
            return problems

        # Get unique host IDs from problems
        host_ids = set()
        for problem in problems:
            if 'objectid' in problem:
                host_ids.add(problem['objectid'])

        if not host_ids:
            return problems

        # Get host information
        hosts = self.api.call('host.get', {
            'hostids': list(host_ids),
            'output': ['hostid', 'host', 'name']
        })

        # Create host ID to name mapping
        host_map = {h['hostid']: h['host'] for h in hosts}

        # Filter problems by host patterns
        filtered_problems = []
        for problem in problems:
            host_id = problem.get('objectid')
            if not host_id:
                continue

            host_name = host_map.get(host_id, '')

            # Check if host matches any pattern
            for pattern in host_patterns:
                if self._match_pattern(host_name, pattern):
                    filtered_problems.append(problem)
                    break

        return filtered_problems

    @staticmethod
    def _match_pattern(text: str, pattern: str) -> bool:
        """Simple pattern matching with wildcards."""
        import re
        regex_pattern = pattern.replace('*', '.*').replace('?', '.')
        return bool(re.match(f'^{regex_pattern}$', text, re.IGNORECASE))

    def format_problems(
        self,
        problems: List[Dict],
        format_type: str = 'table'
    ) -> str:
        """
        Format problems for output.

        Args:
            problems: List of problems
            format_type: Output format - 'table', 'json', 'csv'

        Returns:
            Formatted string
        """
        if format_type == 'json':
            return json.dumps(problems, indent=2)

        elif format_type == 'csv':
            import csv
            from io import StringIO

            output = StringIO()
            if not problems:
                return ''

            # Get all unique keys
            keys = set()
            for p in problems:
                keys.update(p.keys())
            keys = sorted(keys)

            writer = csv.DictWriter(output, fieldnames=keys)
            writer.writeheader()

            for problem in problems:
                # Flatten nested structures
                flat_problem = self._flatten_dict(problem)
                writer.writerow(flat_problem)

            return output.getvalue()

        else:  # table format
            if not problems:
                return "No problems found."

            lines = []
            lines.append(f"\nFound {len(problems)} problem(s):\n")
            lines.append("=" * 100)

            for idx, problem in enumerate(problems, 1):
                severity = self.SEVERITY_NAMES.get(problem.get('severity', '0'), 'Unknown')
                event_id = problem.get('eventid', 'N/A')
                name = problem.get('name', 'N/A')
                clock = problem.get('clock', 0)
                timestamp = datetime.fromtimestamp(int(clock)).strftime('%Y-%m-%d %H:%M:%S')

                acknowledged = len(problem.get('acknowledges', [])) > 0
                ack_status = 'Yes' if acknowledged else 'No'

                suppressed = problem.get('suppressed', '0') == '1'
                supp_status = 'Yes' if suppressed else 'No'

                lines.append(f"\n{idx}. Event ID: {event_id}")
                lines.append(f"   Name: {name}")
                lines.append(f"   Severity: {severity}")
                lines.append(f"   Time: {timestamp}")
                lines.append(f"   Acknowledged: {ack_status}")
                lines.append(f"   Suppressed: {supp_status}")

                # Show tags
                tags = problem.get('tags', [])
                if tags:
                    tag_strs = [f"{t['tag']}:{t['value']}" for t in tags]
                    lines.append(f"   Tags: {', '.join(tag_strs)}")

                # Show acknowledgments
                if acknowledged:
                    lines.append(f"   Acknowledgments:")
                    for ack in problem.get('acknowledges', []):
                        ack_time = datetime.fromtimestamp(int(ack.get('clock', 0))).strftime('%Y-%m-%d %H:%M:%S')
                        message = ack.get('message', 'No message')
                        lines.append(f"     - [{ack_time}] {message}")

                lines.append("-" * 100)

            return '\n'.join(lines)

    @staticmethod
    def _flatten_dict(d: Dict, parent_key: str = '', sep: str = '_') -> Dict:
        """Flatten nested dictionary for CSV export."""
        items = []
        for k, v in d.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            if isinstance(v, dict):
                items.extend(ProblemMonitor._flatten_dict(v, new_key, sep=sep).items())
            elif isinstance(v, list):
                items.append((new_key, json.dumps(v)))
            else:
                items.append((new_key, v))
        return dict(items)

    def monitor_problems(
        self,
        interval: int,
        callback: Optional[callable] = None,
        **filter_args
    ):
        """
        Monitor problems in real-time.

        Args:
            interval: Check interval in seconds
            callback: Function to call when new problems detected
            **filter_args: Problem filter arguments
        """
        print(f"Starting real-time monitoring (checking every {interval}s)...")
        print("Press Ctrl+C to stop.\n")

        try:
            while True:
                problems = self.get_problems(**filter_args)
                current_problem_ids = {p['eventid'] for p in problems}

                # Find new problems
                new_problem_ids = current_problem_ids - self.last_problems

                if new_problem_ids:
                    new_problems = [p for p in problems if p['eventid'] in new_problem_ids]

                    print(f"\n[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] "
                          f"Found {len(new_problems)} new problem(s)!")

                    print(self.format_problems(new_problems, 'table'))

                    if callback:
                        callback(new_problems)

                self.last_problems = current_problem_ids
                time.sleep(interval)

        except KeyboardInterrupt:
            print("\n\nMonitoring stopped by user.")


def send_webhook_alert(webhook_url: str, problems: List[Dict]):
    """Send alert to webhook (e.g., Slack, Teams)."""
    try:
        severity_names = ProblemMonitor.SEVERITY_NAMES

        message = f"*New Zabbix Problems Detected ({len(problems)})*\n\n"

        for problem in problems:
            severity = severity_names.get(problem.get('severity', '0'), 'Unknown')
            name = problem.get('name', 'N/A')
            event_id = problem.get('eventid', 'N/A')

            message += f"* [{severity}] {name} (ID: {event_id})\n"

        payload = {'text': message}

        response = requests.post(webhook_url, json=payload, timeout=10)
        response.raise_for_status()

    except Exception as e:
        print(f"Warning: Failed to send webhook alert: {e}", file=sys.stderr)


def parse_time_range(time_range: str) -> tuple:
    """Parse time range string to Unix timestamps."""
    now = datetime.now()

    # Parse format like "1h", "24h", "7d", "30d"
    if time_range.endswith('h'):
        hours = int(time_range[:-1])
        time_from = now - timedelta(hours=hours)
    elif time_range.endswith('d'):
        days = int(time_range[:-1])
        time_from = now - timedelta(days=days)
    elif time_range.endswith('m'):
        minutes = int(time_range[:-1])
        time_from = now - timedelta(minutes=minutes)
    else:
        raise ValueError(f"Invalid time range format: {time_range}")

    return int(time_from.timestamp()), int(now.timestamp())


def parse_tags(tag_strings: List[str]) -> List[Dict[str, str]]:
    """Parse tag strings to tag filter format."""
    tags = []
    for tag_str in tag_strings:
        if ':' in tag_str:
            tag, value = tag_str.split(':', 1)
            tags.append({'tag': tag, 'value': value})
        else:
            tags.append({'tag': tag_str})
    return tags


def main():
    parser = argparse.ArgumentParser(
        description='Monitor and query Zabbix problems',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Query critical and disaster problems
  %(prog)s --url https://zabbix.example.com --token TOKEN --severity disaster,high

  # Query problems for specific hosts
  %(prog)s --url https://zabbix.example.com --token TOKEN --host "db-*,web-*"

  # Query problems with tags
  %(prog)s --url https://zabbix.example.com --token TOKEN --tag "Application:Database"

  # Query problems from last hour
  %(prog)s --url https://zabbix.example.com --token TOKEN --time-range 1h

  # Real-time monitoring with webhook alerts
  %(prog)s --url https://zabbix.example.com --token TOKEN --monitor --interval 60 \\
           --alert-webhook https://hooks.slack.com/services/YOUR/WEBHOOK/URL

  # Export to JSON
  %(prog)s --url https://zabbix.example.com --token TOKEN --output json > problems.json

  # Export to CSV
  %(prog)s --url https://zabbix.example.com --token TOKEN --output csv > problems.csv
        """
    )

    parser.add_argument('--url', required=True, help='Zabbix server URL')
    parser.add_argument('--token', required=True, help='Zabbix API token')

    # Filter options
    parser.add_argument('--severity', help='Comma-separated severity levels (disaster,high,average,warning,information,not_classified)')
    parser.add_argument('--status', choices=['active', 'resolved'], help='Problem status')
    parser.add_argument('--host', help='Comma-separated host name patterns (supports wildcards)')
    parser.add_argument('--tag', action='append', help='Tag filter (format: tag:value or tag). Can be specified multiple times.')
    parser.add_argument('--time-range', help='Time range (e.g., 1h, 24h, 7d)')
    parser.add_argument('--acknowledged', action='store_true', help='Show only acknowledged problems')
    parser.add_argument('--unacknowledged', action='store_true', help='Show only unacknowledged problems')
    parser.add_argument('--suppressed', action='store_true', help='Show only suppressed problems')
    parser.add_argument('--not-suppressed', action='store_true', help='Show only non-suppressed problems')

    # Output options
    parser.add_argument('--output', choices=['table', 'json', 'csv'], default='table', help='Output format')
    parser.add_argument('--output-file', help='Output file path (default: stdout)')

    # Monitoring options
    parser.add_argument('--monitor', action='store_true', help='Enable real-time monitoring mode')
    parser.add_argument('--interval', type=int, default=60, help='Monitoring interval in seconds (default: 60)')
    parser.add_argument('--alert-webhook', help='Webhook URL for new problem alerts (Slack, Teams, etc.)')

    args = parser.parse_args()

    try:
        # Initialize API client
        api = ZabbixAPI(args.url, args.token)
        monitor = ProblemMonitor(api)

        # Build filter arguments
        filter_args = {}

        if args.severity:
            filter_args['severities'] = [s.strip() for s in args.severity.split(',')]

        if args.status:
            filter_args['status'] = args.status

        if args.host:
            filter_args['hosts'] = [h.strip() for h in args.host.split(',')]

        if args.tag:
            filter_args['tags'] = parse_tags(args.tag)

        if args.time_range:
            time_from, time_till = parse_time_range(args.time_range)
            filter_args['time_from'] = time_from
            filter_args['time_till'] = time_till

        if args.acknowledged:
            filter_args['acknowledged'] = True
        elif args.unacknowledged:
            filter_args['acknowledged'] = False

        if args.suppressed:
            filter_args['suppressed'] = True
        elif args.not_suppressed:
            filter_args['suppressed'] = False

        # Real-time monitoring mode
        if args.monitor:
            callback = None
            if args.alert_webhook:
                callback = lambda problems: send_webhook_alert(args.alert_webhook, problems)

            monitor.monitor_problems(args.interval, callback, **filter_args)
        else:
            # One-time query
            problems = monitor.get_problems(**filter_args)

            # Format output
            output = monitor.format_problems(problems, args.output)

            # Write output
            if args.output_file:
                with open(args.output_file, 'w') as f:
                    f.write(output)
                print(f"Results written to {args.output_file}")
            else:
                print(output)

        sys.exit(0)

    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
