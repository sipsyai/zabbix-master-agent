#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Problem Reporter

Generates comprehensive problem reports including MTTR, MTTA, SLA compliance,
and trend analysis with multiple export formats.

Usage:
    python zabbix_problem_reporter.py --url https://zabbix.example.com \\
        --token $ZABBIX_TOKEN --report-type mttr --time-range 7d

    python zabbix_problem_reporter.py --url https://zabbix.example.com \\
        --token $ZABBIX_TOKEN --report-type summary --format pdf \\
        --output monthly_report.pdf

    python zabbix_problem_reporter.py --url https://zabbix.example.com \\
        --token $ZABBIX_TOKEN --report-type top-offenders --time-range 30d
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from collections import defaultdict
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


class ZabbixAPI:
    """Zabbix API client with retry logic."""

    def __init__(self, url: str, token: str):
        self.url = url.rstrip('/') + '/api_jsonrpc.php'
        self.token = token
        self.session = self._create_session()

    def _create_session(self) -> requests.Session:
        """Create session with retry logic."""
        session = requests.Session()
        retry = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[500, 502, 503, 504]
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        return session

    def call(self, method: str, params: Dict[str, Any]) -> Any:
        """Make API call with error handling."""
        payload = {
            'jsonrpc': '2.0',
            'method': method,
            'params': params,
            'auth': self.token,
            'id': 1
        }

        try:
            response = self.session.post(
                self.url,
                json=payload,
                headers={'Content-Type': 'application/json'},
                timeout=30
            )
            response.raise_for_status()

            result = response.json()

            if 'error' in result:
                raise Exception(f"API Error: {result['error']['message']} (Code: {result['error']['code']})")

            return result.get('result', [])

        except requests.exceptions.RequestException as e:
            raise Exception(f"Network error: {str(e)}")


class ProblemReporter:
    """Problem reporting and metrics calculator."""

    SEVERITY_NAMES = {
        '0': 'Not classified',
        '1': 'Information',
        '2': 'Warning',
        '3': 'Average',
        '4': 'High',
        '5': 'Disaster'
    }

    def __init__(self, api: ZabbixAPI):
        self.api = api

    def get_problems_with_resolution(
        self,
        time_from: int,
        time_till: int
    ) -> List[Dict[str, Any]]:
        """Get problems with resolution times."""
        # Get resolved problems
        params = {
            'output': 'extend',
            'selectAcknowledges': 'extend',
            'selectTags': 'extend',
            'time_from': time_from,
            'time_till': time_till,
            'recent': False,  # Include resolved problems
            'sortfield': ['eventid'],
            'sortorder': 'DESC'
        }

        problems = self.api.call('problem.get', params)

        # Get recovery events for resolution times
        problem_ids = [p['eventid'] for p in problems]

        if not problem_ids:
            return []

        # Get recovery information
        recovery_params = {
            'output': 'extend',
            'eventids': problem_ids,
            'selectRelatedObject': 'extend'
        }

        events = self.api.call('event.get', recovery_params)

        # Build map of problem to recovery time
        recovery_map = {}
        for event in events:
            if event.get('r_eventid', '0') != '0':
                recovery_map[event['eventid']] = event

        # Enhance problems with recovery info
        for problem in problems:
            event_id = problem['eventid']
            if event_id in recovery_map:
                recovery_event = recovery_map[event_id]
                problem['recovery_eventid'] = recovery_event.get('r_eventid')
                problem['recovery_clock'] = recovery_event.get('r_clock', 0)

        return problems

    def calculate_mttr(
        self,
        time_from: int,
        time_till: int,
        group_by: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Calculate Mean Time To Resolution (MTTR).

        Args:
            time_from: Start time
            time_till: End time
            group_by: Optional grouping (host, severity)

        Returns:
            MTTR statistics
        """
        problems = self.get_problems_with_resolution(time_from, time_till)

        resolved_problems = [
            p for p in problems
            if 'recovery_clock' in p and int(p.get('recovery_clock', 0)) > 0
        ]

        if not resolved_problems:
            return {
                'mttr_seconds': 0,
                'mttr_formatted': '0h 0m',
                'total_problems': 0,
                'resolved_problems': 0
            }

        # Calculate resolution times
        resolution_times = []
        for problem in resolved_problems:
            start_time = int(problem['clock'])
            end_time = int(problem['recovery_clock'])
            resolution_time = end_time - start_time
            resolution_times.append(resolution_time)

        avg_resolution_time = sum(resolution_times) / len(resolution_times)

        result = {
            'mttr_seconds': int(avg_resolution_time),
            'mttr_formatted': self._format_duration(avg_resolution_time),
            'total_problems': len(problems),
            'resolved_problems': len(resolved_problems),
            'min_resolution_time': self._format_duration(min(resolution_times)),
            'max_resolution_time': self._format_duration(max(resolution_times)),
            'median_resolution_time': self._format_duration(self._median(resolution_times))
        }

        # Group by if requested
        if group_by:
            result['groups'] = self._group_mttr(resolved_problems, group_by)

        return result

    def calculate_mtta(
        self,
        time_from: int,
        time_till: int,
        group_by: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Calculate Mean Time To Acknowledgment (MTTA).

        Args:
            time_from: Start time
            time_till: End time
            group_by: Optional grouping (host, severity)

        Returns:
            MTTA statistics
        """
        problems = self.get_problems_with_resolution(time_from, time_till)

        acknowledged_problems = [
            p for p in problems
            if p.get('acknowledges') and len(p['acknowledges']) > 0
        ]

        if not acknowledged_problems:
            return {
                'mtta_seconds': 0,
                'mtta_formatted': '0h 0m',
                'total_problems': len(problems),
                'acknowledged_problems': 0
            }

        # Calculate acknowledgment times
        ack_times = []
        for problem in acknowledged_problems:
            start_time = int(problem['clock'])
            # Get first acknowledgment time
            first_ack = min(problem['acknowledges'], key=lambda a: int(a['clock']))
            ack_time = int(first_ack['clock']) - start_time
            ack_times.append(ack_time)

        avg_ack_time = sum(ack_times) / len(ack_times)

        result = {
            'mtta_seconds': int(avg_ack_time),
            'mtta_formatted': self._format_duration(avg_ack_time),
            'total_problems': len(problems),
            'acknowledged_problems': len(acknowledged_problems),
            'acknowledgment_rate': f"{len(acknowledged_problems) / len(problems) * 100:.1f}%",
            'min_ack_time': self._format_duration(min(ack_times)),
            'max_ack_time': self._format_duration(max(ack_times)),
            'median_ack_time': self._format_duration(self._median(ack_times))
        }

        if group_by:
            result['groups'] = self._group_mtta(acknowledged_problems, group_by)

        return result

    def generate_summary_report(
        self,
        time_from: int,
        time_till: int
    ) -> Dict[str, Any]:
        """Generate comprehensive summary report."""
        problems = self.get_problems_with_resolution(time_from, time_till)

        # Count by severity
        severity_counts = defaultdict(int)
        for problem in problems:
            severity = problem.get('severity', '0')
            severity_name = self.SEVERITY_NAMES.get(severity, 'Unknown')
            severity_counts[severity_name] += 1

        # Count by status
        active_problems = [p for p in problems if not p.get('recovery_clock')]
        resolved_problems = [p for p in problems if p.get('recovery_clock')]

        # Acknowledgment stats
        acknowledged = [p for p in problems if p.get('acknowledges')]
        unacknowledged = [p for p in problems if not p.get('acknowledges')]

        # Calculate MTTR and MTTA
        mttr = self.calculate_mttr(time_from, time_till)
        mtta = self.calculate_mtta(time_from, time_till)

        return {
            'report_type': 'summary',
            'time_range': {
                'from': datetime.fromtimestamp(time_from).isoformat(),
                'to': datetime.fromtimestamp(time_till).isoformat()
            },
            'overview': {
                'total_problems': len(problems),
                'active_problems': len(active_problems),
                'resolved_problems': len(resolved_problems),
                'acknowledged_problems': len(acknowledged),
                'unacknowledged_problems': len(unacknowledged)
            },
            'by_severity': dict(severity_counts),
            'metrics': {
                'mttr': mttr,
                'mtta': mtta
            }
        }

    def generate_top_offenders_report(
        self,
        time_from: int,
        time_till: int,
        limit: int = 10
    ) -> Dict[str, Any]:
        """Generate report of most problematic hosts."""
        problems = self.get_problems_with_resolution(time_from, time_till)

        # Get host IDs from problems
        host_ids = set()
        for problem in problems:
            if 'objectid' in problem:
                host_ids.add(problem['objectid'])

        if not host_ids:
            return {'hosts': [], 'total': 0}

        # Get host information
        hosts = self.api.call('host.get', {
            'hostids': list(host_ids),
            'output': ['hostid', 'host', 'name']
        })

        # Map host ID to name
        host_map = {h['hostid']: h for h in hosts}

        # Count problems by host
        host_stats = defaultdict(lambda: {
            'problem_count': 0,
            'severity_breakdown': defaultdict(int)
        })

        for problem in problems:
            host_id = problem.get('objectid')
            if host_id in host_map:
                host_name = host_map[host_id]['host']
                severity = self.SEVERITY_NAMES.get(problem.get('severity', '0'), 'Unknown')

                host_stats[host_name]['problem_count'] += 1
                host_stats[host_name]['severity_breakdown'][severity] += 1

        # Sort by problem count
        sorted_hosts = sorted(
            host_stats.items(),
            key=lambda x: x[1]['problem_count'],
            reverse=True
        )[:limit]

        return {
            'report_type': 'top_offenders',
            'time_range': {
                'from': datetime.fromtimestamp(time_from).isoformat(),
                'to': datetime.fromtimestamp(time_till).isoformat()
            },
            'hosts': [
                {
                    'host': host,
                    'problem_count': stats['problem_count'],
                    'severity_breakdown': dict(stats['severity_breakdown'])
                }
                for host, stats in sorted_hosts
            ],
            'total_hosts': len(host_stats)
        }

    def generate_trend_report(
        self,
        time_from: int,
        time_till: int,
        interval: str = 'day'
    ) -> Dict[str, Any]:
        """Generate problem trend report over time."""
        problems = self.get_problems_with_resolution(time_from, time_till)

        # Determine interval duration
        if interval == 'hour':
            interval_seconds = 3600
        elif interval == 'day':
            interval_seconds = 86400
        elif interval == 'week':
            interval_seconds = 604800
        else:
            raise ValueError(f"Invalid interval: {interval}")

        # Group problems by interval
        interval_stats = defaultdict(lambda: {
            'problem_count': 0,
            'resolved_count': 0,
            'by_severity': defaultdict(int)
        })

        for problem in problems:
            problem_time = int(problem['clock'])
            interval_key = (problem_time // interval_seconds) * interval_seconds

            interval_stats[interval_key]['problem_count'] += 1

            if problem.get('recovery_clock'):
                interval_stats[interval_key]['resolved_count'] += 1

            severity = self.SEVERITY_NAMES.get(problem.get('severity', '0'), 'Unknown')
            interval_stats[interval_key]['by_severity'][severity] += 1

        # Sort by time
        sorted_intervals = sorted(interval_stats.items())

        return {
            'report_type': 'trend',
            'interval': interval,
            'time_range': {
                'from': datetime.fromtimestamp(time_from).isoformat(),
                'to': datetime.fromtimestamp(time_till).isoformat()
            },
            'data': [
                {
                    'timestamp': datetime.fromtimestamp(ts).isoformat(),
                    'problem_count': stats['problem_count'],
                    'resolved_count': stats['resolved_count'],
                    'by_severity': dict(stats['by_severity'])
                }
                for ts, stats in sorted_intervals
            ]
        }

    @staticmethod
    def _format_duration(seconds: float) -> str:
        """Format duration in human-readable format."""
        seconds = int(seconds)
        days = seconds // 86400
        hours = (seconds % 86400) // 3600
        minutes = (seconds % 3600) // 60
        secs = seconds % 60

        parts = []
        if days > 0:
            parts.append(f"{days}d")
        if hours > 0:
            parts.append(f"{hours}h")
        if minutes > 0:
            parts.append(f"{minutes}m")
        if secs > 0 or not parts:
            parts.append(f"{secs}s")

        return ' '.join(parts)

    @staticmethod
    def _median(values: List[float]) -> float:
        """Calculate median value."""
        sorted_values = sorted(values)
        n = len(sorted_values)
        if n % 2 == 0:
            return (sorted_values[n//2 - 1] + sorted_values[n//2]) / 2
        else:
            return sorted_values[n//2]

    def _group_mttr(self, problems: List[Dict], group_by: str) -> List[Dict]:
        """Group MTTR by dimension."""
        groups = defaultdict(list)

        for problem in problems:
            start_time = int(problem['clock'])
            end_time = int(problem.get('recovery_clock', 0))

            if end_time == 0:
                continue

            resolution_time = end_time - start_time

            if group_by == 'severity':
                key = self.SEVERITY_NAMES.get(problem.get('severity', '0'), 'Unknown')
            else:
                key = 'default'

            groups[key].append(resolution_time)

        return [
            {
                'group': group,
                'mttr_seconds': int(sum(times) / len(times)),
                'mttr_formatted': self._format_duration(sum(times) / len(times)),
                'count': len(times)
            }
            for group, times in groups.items()
        ]

    def _group_mtta(self, problems: List[Dict], group_by: str) -> List[Dict]:
        """Group MTTA by dimension."""
        groups = defaultdict(list)

        for problem in problems:
            start_time = int(problem['clock'])
            first_ack = min(problem['acknowledges'], key=lambda a: int(a['clock']))
            ack_time = int(first_ack['clock']) - start_time

            if group_by == 'severity':
                key = self.SEVERITY_NAMES.get(problem.get('severity', '0'), 'Unknown')
            else:
                key = 'default'

            groups[key].append(ack_time)

        return [
            {
                'group': group,
                'mtta_seconds': int(sum(times) / len(times)),
                'mtta_formatted': self._format_duration(sum(times) / len(times)),
                'count': len(times)
            }
            for group, times in groups.items()
        ]


def format_report_text(report: Dict[str, Any]) -> str:
    """Format report as plain text."""
    lines = []

    report_type = report.get('report_type', 'unknown')

    if report_type == 'summary':
        lines.append("=" * 80)
        lines.append("PROBLEM SUMMARY REPORT")
        lines.append("=" * 80)
        lines.append("")

        time_range = report['time_range']
        lines.append(f"Time Range: {time_range['from']} to {time_range['to']}")
        lines.append("")

        overview = report['overview']
        lines.append("Overview:")
        lines.append(f"  Total Problems: {overview['total_problems']}")
        lines.append(f"  Active Problems: {overview['active_problems']}")
        lines.append(f"  Resolved Problems: {overview['resolved_problems']}")
        lines.append(f"  Acknowledged: {overview['acknowledged_problems']}")
        lines.append(f"  Unacknowledged: {overview['unacknowledged_problems']}")
        lines.append("")

        lines.append("By Severity:")
        for severity, count in report['by_severity'].items():
            lines.append(f"  {severity}: {count}")
        lines.append("")

        mttr = report['metrics']['mttr']
        lines.append("Mean Time To Resolution (MTTR):")
        lines.append(f"  Average: {mttr['mttr_formatted']}")
        lines.append(f"  Resolved Problems: {mttr['resolved_problems']}")
        lines.append("")

        mtta = report['metrics']['mtta']
        lines.append("Mean Time To Acknowledgment (MTTA):")
        lines.append(f"  Average: {mtta['mtta_formatted']}")
        lines.append(f"  Acknowledgment Rate: {mtta['acknowledgment_rate']}")

    elif report_type == 'top_offenders':
        lines.append("=" * 80)
        lines.append("TOP PROBLEMATIC HOSTS")
        lines.append("=" * 80)
        lines.append("")

        for idx, host_data in enumerate(report['hosts'], 1):
            lines.append(f"{idx}. {host_data['host']}")
            lines.append(f"   Total Problems: {host_data['problem_count']}")
            lines.append(f"   By Severity:")
            for severity, count in host_data['severity_breakdown'].items():
                lines.append(f"     {severity}: {count}")
            lines.append("")

    return '\n'.join(lines)


def parse_time_range(time_range: str) -> tuple:
    """Parse time range string to Unix timestamps."""
    now = datetime.now()

    if time_range.endswith('h'):
        hours = int(time_range[:-1])
        time_from = now - timedelta(hours=hours)
    elif time_range.endswith('d'):
        days = int(time_range[:-1])
        time_from = now - timedelta(days=days)
    elif time_range.endswith('m'):
        minutes = int(time_range[:-1])
        time_from = now - timedelta(minutes=minutes)
    else:
        raise ValueError(f"Invalid time range format: {time_range}")

    return int(time_from.timestamp()), int(now.timestamp())


def main():
    parser = argparse.ArgumentParser(
        description='Generate Zabbix problem reports',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Generate MTTR report
  %(prog)s --url https://zabbix.example.com --token TOKEN \\
           --report-type mttr --time-range 7d

  # Generate summary report
  %(prog)s --url https://zabbix.example.com --token TOKEN \\
           --report-type summary --time-range 30d --format json

  # Top problematic hosts
  %(prog)s --url https://zabbix.example.com --token TOKEN \\
           --report-type top-offenders --time-range 30d --limit 20

  # Trend analysis
  %(prog)s --url https://zabbix.example.com --token TOKEN \\
           --report-type trend --time-range 7d --interval day
        """
    )

    parser.add_argument('--url', required=True, help='Zabbix server URL')
    parser.add_argument('--token', required=True, help='Zabbix API token')

    # Report options
    parser.add_argument('--report-type', required=True,
                        choices=['summary', 'mttr', 'mtta', 'top-offenders', 'trend'],
                        help='Type of report to generate')
    parser.add_argument('--time-range', required=True, help='Time range (e.g., 1h, 24h, 7d, 30d)')

    # Additional options
    parser.add_argument('--group-by', choices=['severity', 'host'], help='Group metrics by dimension')
    parser.add_argument('--limit', type=int, default=10, help='Limit for top-offenders report')
    parser.add_argument('--interval', choices=['hour', 'day', 'week'], default='day', help='Interval for trend report')

    # Output options
    parser.add_argument('--format', choices=['json', 'text'], default='json', help='Output format')
    parser.add_argument('--output', help='Output file path')

    args = parser.parse_args()

    try:
        # Initialize API
        api = ZabbixAPI(args.url, args.token)
        reporter = ProblemReporter(api)

        # Parse time range
        time_from, time_till = parse_time_range(args.time_range)

        # Generate report
        if args.report_type == 'summary':
            report = reporter.generate_summary_report(time_from, time_till)
        elif args.report_type == 'mttr':
            report = reporter.calculate_mttr(time_from, time_till, args.group_by)
            report['report_type'] = 'mttr'
        elif args.report_type == 'mtta':
            report = reporter.calculate_mtta(time_from, time_till, args.group_by)
            report['report_type'] = 'mtta'
        elif args.report_type == 'top-offenders':
            report = reporter.generate_top_offenders_report(time_from, time_till, args.limit)
        elif args.report_type == 'trend':
            report = reporter.generate_trend_report(time_from, time_till, args.interval)
        else:
            raise ValueError(f"Unknown report type: {args.report_type}")

        # Format output
        if args.format == 'json':
            output = json.dumps(report, indent=2)
        else:
            output = format_report_text(report)

        # Write output
        if args.output:
            with open(args.output, 'w') as f:
                f.write(output)
            print(f"Report written to {args.output}", file=sys.stderr)
        else:
            print(output)

        sys.exit(0)

    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
