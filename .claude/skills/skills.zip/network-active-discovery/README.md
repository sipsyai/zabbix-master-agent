# Network & Active Discovery in Zabbix

Automate Zabbix network discovery and active agent registration to automatically detect and onboard network devices, servers, and services.

## Quick Start

### 1. Install Dependencies

```bash
pip install pyzabbix requests ipaddress pysnmp
```

For cloud discovery:
```bash
pip install boto3 azure-identity azure-mgmt-compute google-cloud-compute
```

For Docker discovery:
```bash
pip install docker
```

### 2. Basic Network Discovery

Create a simple discovery rule:

```bash
python scripts/zabbix_discovery_manager.py \
    --url https://zabbix.example.com \
    --token your-api-token \
    --action create \
    --rule-name "Office Network Discovery" \
    --iprange "192.168.1.1-254" \
    --delay "1h"
```

### 3. Set Up Auto-Registration

Configure active agent auto-registration:

```bash
python scripts/zabbix_autoregistration_manager.py \
    --url https://zabbix.example.com \
    --token your-api-token \
    --action create \
    --action-name "Linux Servers Auto-Registration" \
    --metadata-pattern "Linux" \
    --host-groups "Linux servers" "Discovered hosts" \
    --templates "Linux by Zabbix agent"
```

### 4. Monitor Discovery Status

Check discovery results:

```bash
python scripts/zabbix_discovery_monitor.py \
    --url https://zabbix.example.com \
    --token your-api-token \
    --rule-name "Office Network Discovery"
```

## Key Features

### Network Discovery
- ICMP ping scanning
- SNMP device discovery (v1/v2c/v3)
- Zabbix agent detection
- HTTP/HTTPS service checks
- Port scanning (TCP/UDP)
- Multiple protocol support

### Active Agent Auto-Registration
- Metadata-based matching
- Hostname pattern matching
- Automatic template assignment
- Group assignment rules
- IP range restrictions

### SNMP Discovery
- Multi-version support (v1, v2c, v3)
- Device categorization
- OID-based identification
- Automatic template linking
- Security options (authentication, privacy)

### Cloud Integration
- AWS EC2 instance discovery
- Azure VM discovery
- GCP Compute Engine discovery
- Automatic cloud host registration

### Container Discovery
- Docker container discovery
- Kubernetes node detection
- Automatic containerized app monitoring

## Common Use Cases

### Multi-Subnet Discovery

```bash
python scripts/zabbix_discovery_manager.py \
    --url https://zabbix.example.com \
    --token your-api-token \
    --action create \
    --config examples/bulk_discovery.yaml
```

### SNMP Device Discovery

```bash
python scripts/custom_checks/snmp_discovery.py \
    --url https://zabbix.example.com \
    --token your-api-token \
    --iprange "10.0.0.0/24" \
    --community public \
    --auto-add
```

### AWS Cloud Discovery

```bash
python scripts/custom_checks/cloud_discovery.py \
    --url https://zabbix.example.com \
    --token your-api-token \
    --provider aws \
    --region us-east-1 \
    --auto-register
```

### Docker Container Discovery

```bash
python scripts/custom_checks/docker_discovery.py \
    --url https://zabbix.example.com \
    --token your-api-token \
    --docker-host docker-host-01 docker-host-02 \
    --auto-register
```

### Validate Configuration

```bash
python scripts/validate_discovery_config.py \
    --config examples/network_discovery.json \
    --url https://zabbix.example.com \
    --token your-api-token \
    --validate-all \
    --check-connectivity
```

### Generate Analysis Report

```bash
python scripts/discovery_result_analyzer.py \
    --url https://zabbix.example.com \
    --token your-api-token \
    --rule-name "Office Network Discovery" \
    --days 7 \
    --format html \
    --report discovery_report.html
```

## Scripts Overview

| Script | Purpose |
|--------|---------|
| `zabbix_discovery_manager.py` | Manage network discovery rules |
| `zabbix_autoregistration_manager.py` | Configure auto-registration actions |
| `zabbix_discovery_monitor.py` | Monitor discovery status and results |
| `validate_discovery_config.py` | Validate configurations before deployment |
| `discovery_result_analyzer.py` | Analyze and report on discovery results |
| `custom_checks/snmp_discovery.py` | SNMP device discovery with categorization |
| `custom_checks/cloud_discovery.py` | Cloud instance discovery (AWS/Azure/GCP) |
| `custom_checks/docker_discovery.py` | Docker container discovery |

## Configuration Examples

All examples are in the `examples/` directory:

- `network_discovery.json` - Basic network discovery configurations
- `snmp_discovery.yaml` - SNMP discovery with v1/v2c/v3
- `autoregistration_config.json` - Auto-registration action examples
- `cloud_discovery.yaml` - Cloud provider configurations
- `service_discovery.json` - Service and port discovery
- `discovery_actions.yaml` - Discovery action configurations
- `bulk_discovery.yaml` - Bulk operations
- `subnet_configs.json` - IP range and subnet examples

## Agent Configuration for Auto-Registration

Configure Zabbix agent for auto-registration:

```ini
# /etc/zabbix/zabbix_agentd.conf

Server=zabbix-server.example.com
ServerActive=zabbix-server.example.com:10051
Hostname=server-01

# Enable auto-registration
HostMetadata=Linux,production,webserver
# or use a script:
# HostMetadataItem=system.run[/usr/local/bin/get_metadata.sh]
```

## Discovery Check Types

### ICMP
```json
{"type": "ICMP"}
```

### SNMPv2
```json
{
  "type": "SNMPv2",
  "snmp_community": "public",
  "key_": "sysDescr.0"
}
```

### SNMPv3 with Authentication and Privacy
```json
{
  "type": "SNMPv3",
  "snmpv3_securitylevel": "authPriv",
  "snmpv3_securityname": "admin",
  "snmpv3_authprotocol": "SHA256",
  "snmpv3_authpassphrase": "auth_password",
  "snmpv3_privprotocol": "AES256",
  "snmpv3_privpassphrase": "priv_password",
  "key_": "sysDescr.0"
}
```

### Zabbix Agent
```json
{
  "type": "Zabbix agent",
  "key_": "agent.ping",
  "ports": "10050"
}
```

### HTTP/HTTPS
```json
{"type": "HTTP", "ports": "80,8080,8000"}
{"type": "HTTPS", "ports": "443,8443"}
```

## IP Range Formats

Supported IP range formats:

- Single IP: `192.168.1.100`
- Range (partial): `192.168.1.1-254`
- Range (full): `192.168.1.1-192.168.1.254`
- CIDR: `192.168.1.0/24`, `10.0.0.0/16`
- Multiple: `192.168.1.0/24,10.0.1.0/24,172.16.0.1-100`

## Best Practices

1. **Start Small**: Test discovery on small IP ranges before scaling
2. **Use Proxies**: Distribute discovery across Zabbix proxies for large networks
3. **Optimize Intervals**: Balance discovery frequency with network impact
4. **Validate First**: Always validate configurations before deployment
5. **Monitor Performance**: Track discovery execution times and adjust
6. **Security**: Use SNMPv3 with authentication when possible
7. **Document Metadata**: Standardize host metadata conventions
8. **Clean Up**: Remove stale discovered hosts regularly

## Troubleshooting

### No Devices Discovered
1. Verify IP ranges are correct and reachable
2. Check firewall rules allow discovery traffic
3. Confirm SNMP community strings or credentials
4. Test connectivity manually with ping/snmpwalk
5. Check Zabbix server/proxy logs

### Auto-Registration Not Working
1. Verify agent ServerActive points to Zabbix server
2. Check HostMetadata in agent configuration
3. Confirm auto-registration action is enabled
4. Review action condition patterns
5. Check network connectivity from agent to server

### Discovery Performance Issues
1. Reduce IP range scope
2. Increase discovery interval
3. Use Zabbix proxies for distributed discovery
4. Limit number of discovery checks per rule
5. Monitor Zabbix server resource usage

## API Methods Used

- `drule.create` - Create discovery rules
- `drule.update` - Update discovery rules
- `drule.delete` - Delete discovery rules
- `drule.get` - Retrieve discovery rules
- `dhost.get` - Get discovered hosts
- `dservice.get` - Get discovered services
- `action.create` - Create discovery/auto-registration actions
- `action.update` - Update actions
- `action.get` - Retrieve actions

## Documentation

For complete documentation, see `SKILL.md`.

For Zabbix documentation, refer to:
- Network Discovery: `zabbix-docs-masters/zabbix-docs/15_Discovery/1_network_discovery.md`
- Auto-Registration: `zabbix-docs-masters/zabbix-docs/15_Discovery/2_auto_registration.md`
- API Documentation: `zabbix-docs-masters/zabbix-docs/20_API/88_drule.md`

## Support

For issues or questions:
1. Check `SKILL.md` for detailed usage
2. Review example configurations in `examples/`
3. Run validation scripts to identify issues
4. Check Zabbix server logs for errors

## License

This skill follows your organization's licensing terms for Zabbix automation tools.
