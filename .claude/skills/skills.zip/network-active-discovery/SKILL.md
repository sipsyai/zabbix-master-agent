---
name: Network & Active Discovery in Zabbix
description: Automate Zabbix network discovery and active agent registration to automatically detect and onboard network devices, servers, and services. Configure discovery rules, manage discovery actions, handle auto-registration, and implement custom discovery checks through the Zabbix API. Use when automating infrastructure discovery, implementing auto-scaling monitoring, or managing dynamic network environments.
keywords: zabbix, network discovery, auto-registration, active agent, SNMP discovery, device discovery, auto-scaling, cloud discovery, service discovery, discovery rules, discovery actions, host auto-registration
dependencies: pyzabbix, requests, ipaddress, snmp
version: 1.0.0
---

# Network & Active Discovery in Zabbix

Automate Zabbix network discovery and active agent auto-registration for dynamic infrastructure monitoring. This skill enables you to automatically detect, onboard, and configure network devices, servers, and services using discovery rules, SNMP queries, active agent registration, and custom discovery checks.

## Quick Start

### Basic Network Discovery
Create a simple network discovery rule to scan a subnet:

```python
from scripts.zabbix_discovery_manager import ZabbixDiscoveryManager

manager = ZabbixDiscoveryManager(
    url="https://zabbix.example.com",
    token="your-api-token"
)

# Create basic network discovery rule
discovery_rule = manager.create_discovery_rule(
    name="Office Network Discovery",
    iprange="192.168.1.1-254",
    delay="1h",
    checks=[
        {"type": "ICMP", "ports": ""},
        {"type": "SNMPv2", "snmp_community": "public", "key_": "sysDescr.0"}
    ]
)
```

### Active Agent Auto-Registration
Configure auto-registration for new Zabbix agents:

```python
from scripts.zabbix_autoregistration_manager import AutoRegistrationManager

reg_manager = AutoRegistrationManager(
    url="https://zabbix.example.com",
    token="your-api-token"
)

# Create auto-registration action
action = reg_manager.create_autoregistration_action(
    name="Linux Servers Auto-Registration",
    metadata_pattern="Linux",
    host_groups=["Linux servers", "Discovered hosts"],
    templates=["Linux by Zabbix agent"]
)
```

### Monitor Discovery Results
Check what has been discovered:

```bash
python scripts/zabbix_discovery_monitor.py \
    --url https://zabbix.example.com \
    --token your-api-token \
    --rule-name "Office Network Discovery" \
    --status active
```

## Core Capabilities

### 1. Network Discovery Rules

Create and manage network discovery rules that scan IP ranges for devices:

- **IP Range Configuration**: Define single IPs, ranges, or CIDR notation
- **Multiple Check Types**: ICMP, SNMP (v1/v2c/v3), Zabbix agent, HTTP/HTTPS, FTP, SSH, Telnet, LDAP
- **Discovery Frequency**: Set scan intervals from minutes to weeks
- **Proxy Support**: Use Zabbix proxies for distributed discovery
- **Uniqueness Criteria**: Define how to identify unique devices

**Available Discovery Checks:**
- ICMP ping (network availability)
- SNMPv1/v2c/v3 (device identification, OID queries)
- Zabbix agent (agent availability, key checks)
- HTTP/HTTPS (web service availability, status codes)
- TCP/UDP port checks (service detection)
- SSH, FTP, Telnet, LDAP (protocol-specific checks)

See [reference/discovery_checks.md](reference/discovery_checks.md) for detailed check configurations.

### 2. Discovery Actions

Automatically act on discovered devices:

- **Host Creation**: Add discovered devices as monitored hosts
- **Template Linking**: Automatically assign monitoring templates
- **Group Assignment**: Place hosts in appropriate host groups
- **Host Enablement**: Enable or disable monitoring automatically
- **Notifications**: Alert when new devices are discovered
- **Remote Commands**: Execute scripts on discovery events
- **Custom Operations**: Run external scripts or webhooks

See [reference/discovery_actions.md](reference/discovery_actions.md) for action configuration details.

### 3. Active Agent Auto-Registration

Enable Zabbix agents to register themselves automatically:

- **Metadata Matching**: Match agents based on host metadata
- **Pattern-Based Rules**: Use regular expressions for flexible matching
- **Template Assignment**: Link templates based on metadata
- **Group Assignment**: Assign to groups automatically
- **Macro Configuration**: Set host macros during registration
- **IP Range Restrictions**: Limit registration to specific networks
- **Hostname Patterns**: Match by hostname conventions

See [reference/autoregistration.md](reference/autoregistration.md) for auto-registration setup.

### 4. SNMP Discovery

Specialized SNMP device discovery:

- **Multi-Version Support**: SNMPv1, v2c, and v3
- **OID-Based Identification**: Identify devices by system OIDs
- **Community Strings**: Configure public/private communities
- **SNMPv3 Security**: Username, auth protocol, privacy settings
- **Bulk Operations**: Discover multiple SNMP devices efficiently
- **Custom OID Queries**: Use any OID for device detection

See [reference/snmp_discovery.md](reference/snmp_discovery.md) for SNMP configuration.

### 5. Cloud & Container Discovery

Discover cloud instances and containers automatically:

- **AWS Discovery**: EC2 instances, ECS containers, Lambda functions
- **Azure Discovery**: Virtual machines, container instances
- **GCP Discovery**: Compute Engine instances, GKE containers
- **Docker Discovery**: Running containers, services, stacks
- **Kubernetes Discovery**: Pods, services, nodes
- **VMware Discovery**: Virtual machines, ESXi hosts

See [reference/cloud_discovery.md](reference/cloud_discovery.md) for cloud integration.

### 6. Service Discovery

Detect services and open ports:

- **Port Scanning**: TCP/UDP port availability checks
- **Service Identification**: Detect common services (HTTP, SSH, MySQL, etc.)
- **Version Detection**: Identify service versions through banners
- **Custom Port Ranges**: Scan specific port ranges
- **Protocol Validation**: Verify service protocols

See [reference/service_discovery.md](reference/service_discovery.md) for service discovery patterns.

### 7. Discovery Monitoring & Analysis

Monitor and analyze discovery results:

- **Discovery Status**: Track active/disabled discovery rules
- **Discovered Devices**: View all discovered hosts and services
- **Discovery Performance**: Monitor scan times and efficiency
- **Device Changes**: Track newly discovered and lost devices
- **Result Analysis**: Analyze discovery patterns and trends
- **Validation Reports**: Verify discovery configurations

See [reference/monitoring.md](reference/monitoring.md) for monitoring capabilities.

## Usage Patterns

### Pattern 1: Multi-Subnet Network Discovery

Discover devices across multiple subnets with different configurations:

```python
# Create discovery rule for multiple subnets
manager.create_discovery_rule(
    name="Multi-Site Discovery",
    iprange="10.0.1.0/24,10.0.2.0/24,10.0.3.1-254,192.168.1.100",
    delay="30m",
    checks=[
        {"type": "ICMP"},
        {"type": "SNMPv2", "snmp_community": "public", "key_": "sysDescr.0"},
        {"type": "Zabbix agent", "key_": "agent.ping"}
    ],
    discovery_actions=[
        {
            "condition": "Discovery status equals Up",
            "operations": [
                {"type": "add_host"},
                {"type": "link_template", "template": "Template Net Network Generic Device SNMP"},
                {"type": "add_to_group", "group": "Discovered hosts"}
            ]
        }
    ]
)
```

### Pattern 2: SNMP Device Discovery with Auto-Categorization

Discover SNMP devices and categorize them automatically:

```python
from scripts.custom_checks.snmp_discovery import SNMPDiscovery

snmp_disc = SNMPDiscovery(url="https://zabbix.example.com", token="token")

# Discover and categorize SNMP devices
devices = snmp_disc.discover_and_categorize(
    iprange="10.0.0.0/16",
    community="public",
    categorization_rules={
        "switches": {"oid": "1.3.6.1.2.1.1.1.0", "pattern": "switch|catalyst"},
        "routers": {"oid": "1.3.6.1.2.1.1.1.0", "pattern": "router|cisco.*ios"},
        "printers": {"oid": "1.3.6.1.2.1.25.3.2.1.2.1", "pattern": "printer"}
    }
)
```

### Pattern 3: Cloud Instance Auto-Registration

Set up auto-registration for cloud instances:

```python
# AWS EC2 auto-registration
reg_manager.create_autoregistration_action(
    name="AWS EC2 Auto-Registration",
    metadata_pattern="aws-ec2",
    conditions=[
        {"type": "host_metadata", "operator": "contains", "value": "aws-ec2"},
        {"type": "host_metadata", "operator": "contains", "value": "production"}
    ],
    operations=[
        {"type": "add_host"},
        {"type": "link_template", "templates": ["Linux by Zabbix agent", "AWS EC2 by HTTP"]},
        {"type": "add_to_group", "groups": ["AWS EC2", "Production"]},
        {"type": "set_host_inventory", "mode": "automatic"}
    ]
)
```

### Pattern 4: Docker Container Discovery

Discover running Docker containers:

```python
from scripts.custom_checks.docker_discovery import DockerDiscovery

docker_disc = DockerDiscovery(url="https://zabbix.example.com", token="token")

# Discover Docker containers
containers = docker_disc.discover_containers(
    docker_hosts=["docker-host-01", "docker-host-02"],
    filters={
        "status": "running",
        "labels": {"env": "production"}
    },
    auto_register=True,
    template="Docker by Zabbix agent 2"
)
```

### Pattern 5: Service-Based Discovery

Discover hosts by detecting specific services:

```python
# Discover web servers by HTTP service
manager.create_discovery_rule(
    name="Web Server Discovery",
    iprange="10.0.0.0/8",
    delay="1h",
    checks=[
        {"type": "HTTP", "ports": "80,443,8080,8443"},
        {"type": "Zabbix agent", "key_": "web.server.type"}
    ],
    discovery_actions=[
        {
            "condition": "Service port equals 80",
            "operations": [
                {"type": "add_host"},
                {"type": "link_template", "template": "Apache by Zabbix agent"},
                {"type": "add_to_group", "group": "Web servers"}
            ]
        },
        {
            "condition": "Service port equals 443",
            "operations": [
                {"type": "add_host"},
                {"type": "link_template", "template": "Nginx by Zabbix agent"},
                {"type": "add_to_group", "group": "Web servers"}
            ]
        }
    ]
)
```

### Pattern 6: Bulk Discovery Management

Manage multiple discovery rules at scale:

```bash
# Create discovery rules from configuration file
python scripts/zabbix_discovery_manager.py \
    --url https://zabbix.example.com \
    --token your-api-token \
    --config examples/bulk_discovery.yaml \
    --mode create

# Update all discovery rules
python scripts/zabbix_discovery_manager.py \
    --url https://zabbix.example.com \
    --token your-api-token \
    --config examples/bulk_discovery.yaml \
    --mode update

# Validate discovery configurations
python scripts/validate_discovery_config.py \
    --config examples/bulk_discovery.yaml \
    --check-connectivity \
    --validate-ip-ranges
```

## Validation & Troubleshooting

### Validate Discovery Configuration

Validate discovery rules before deployment:

```bash
python scripts/validate_discovery_config.py \
    --url https://zabbix.example.com \
    --token your-api-token \
    --rule-name "Office Network Discovery" \
    --validate-ip-ranges \
    --check-snmp-access \
    --test-discovery-checks
```

### Analyze Discovery Results

Analyze what has been discovered:

```bash
python scripts/discovery_result_analyzer.py \
    --url https://zabbix.example.com \
    --token your-api-token \
    --rule-name "Office Network Discovery" \
    --report discovery_report.json \
    --format json
```

### Common Issues

**Issue: No devices discovered**
- Verify IP ranges are correct and reachable
- Check firewall rules allow ICMP/SNMP/agent traffic
- Confirm SNMP community strings are correct
- Verify discovery checks are properly configured
- Check Zabbix proxy connectivity (if used)

**Issue: Discovered devices not added**
- Review discovery action conditions
- Verify templates exist and are linkable
- Check host groups are created
- Review action operation order
- Check Zabbix server logs for errors

**Issue: Auto-registration not working**
- Verify agent configuration includes ServerActive
- Check HostMetadata in agent configuration
- Confirm auto-registration actions are enabled
- Review action condition patterns
- Verify network connectivity from agent to server

See [reference/troubleshooting.md](reference/troubleshooting.md) for detailed troubleshooting steps.

## Examples

Comprehensive examples are provided:

- [examples/network_discovery.json](examples/network_discovery.json) - Network discovery rule examples
- [examples/snmp_discovery.yaml](examples/snmp_discovery.yaml) - SNMP-based discovery configurations
- [examples/autoregistration_config.json](examples/autoregistration_config.json) - Auto-registration action examples
- [examples/cloud_discovery.yaml](examples/cloud_discovery.yaml) - Cloud provider discovery examples
- [examples/service_discovery.json](examples/service_discovery.json) - Service/port discovery examples
- [examples/discovery_actions.yaml](examples/discovery_actions.yaml) - Discovery action configurations
- [examples/bulk_discovery.yaml](examples/bulk_discovery.yaml) - Bulk discovery operations
- [examples/subnet_configs.json](examples/subnet_configs.json) - IP range and subnet examples

## Scripts

All scripts support `--help` for detailed usage:

- **zabbix_discovery_manager.py** - Create, update, delete, manage discovery rules
- **zabbix_autoregistration_manager.py** - Configure auto-registration actions
- **zabbix_discovery_monitor.py** - Monitor discovery status and results
- **validate_discovery_config.py** - Validate discovery configurations
- **discovery_result_analyzer.py** - Analyze and report discovery results
- **custom_checks/snmp_discovery.py** - SNMP device discovery with categorization
- **custom_checks/cloud_discovery.py** - Cloud instance discovery (AWS, Azure, GCP)
- **custom_checks/docker_discovery.py** - Docker container discovery

## Reference Documentation

- [reference/discovery_checks.md](reference/discovery_checks.md) - All discovery check types and configurations
- [reference/discovery_actions.md](reference/discovery_actions.md) - Discovery action operations and conditions
- [reference/autoregistration.md](reference/autoregistration.md) - Active agent auto-registration setup
- [reference/snmp_discovery.md](reference/snmp_discovery.md) - SNMP discovery configuration (v1/v2c/v3)
- [reference/cloud_discovery.md](reference/cloud_discovery.md) - Cloud provider integration patterns
- [reference/service_discovery.md](reference/service_discovery.md) - Service and port discovery
- [reference/monitoring.md](reference/monitoring.md) - Discovery monitoring and analysis
- [reference/api_reference.md](reference/api_reference.md) - Zabbix API methods for discovery
- [reference/troubleshooting.md](reference/troubleshooting.md) - Common issues and solutions
- [reference/best_practices.md](reference/best_practices.md) - Discovery implementation best practices

## Zabbix Documentation

Core Zabbix documentation references:
- Network Discovery: `zabbix-docs-masters/zabbix-docs/15_Discovery/1_network_discovery.md`
- Auto-Registration: `zabbix-docs-masters/zabbix-docs/15_Discovery/2_auto_registration.md`
- API - drule: `zabbix-docs-masters/zabbix-docs/20_API/88_drule.md`
- API - autoregistration: `zabbix-docs-masters/zabbix-docs/20_API/20_autoregistration.md`

## API Methods Used

Primary Zabbix API methods:
- `drule.create` - Create network discovery rules
- `drule.update` - Update discovery rules
- `drule.delete` - Delete discovery rules
- `drule.get` - Retrieve discovery rules
- `dhost.get` - Get discovered hosts
- `dservice.get` - Get discovered services
- `action.create` - Create discovery/auto-registration actions
- `action.update` - Update actions
- `action.get` - Retrieve actions
- `proxy.get` - Get proxy information for distributed discovery

## Best Practices

1. **Start Small**: Test discovery rules on small IP ranges before scaling
2. **Use Proxies**: Distribute discovery load across Zabbix proxies
3. **Optimize Intervals**: Balance discovery frequency with network load
4. **Validate Configurations**: Always validate IP ranges and credentials
5. **Monitor Discovery**: Track discovery performance and results
6. **Use Uniqueness Criteria**: Define clear device identification rules
7. **Implement Actions Carefully**: Test discovery actions before production
8. **Document Metadata**: Standardize host metadata for auto-registration
9. **Security**: Use SNMPv3 with authentication and encryption
10. **Clean Up**: Remove outdated discovered hosts regularly

## Security Considerations

- Store SNMP community strings and credentials securely
- Use SNMPv3 with authentication when possible
- Restrict auto-registration by IP range
- Validate host metadata patterns carefully
- Use Zabbix proxy for network segmentation
- Audit discovery actions regularly
- Limit discovery check privileges
- Monitor for unauthorized device registration
