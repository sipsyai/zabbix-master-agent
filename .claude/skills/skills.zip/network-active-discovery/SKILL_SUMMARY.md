# Network & Active Discovery Skill - Complete Summary

## Overview

A comprehensive Agent Skill for automating Zabbix network discovery and active agent registration. This skill enables automatic detection, categorization, and onboarding of network devices, servers, cloud instances, and containers.

**Location**: `C:\Users\Ali\Documents\Projects\skill-creator-agent\zabbix-skills-priority2\network-active-discovery\`

**Total Lines of Code**: 4,352 lines across 18 files

## Core Capabilities

### 1. Network Discovery Management
- Create and manage discovery rules via Zabbix API
- Support all discovery check types (ICMP, SNMP v1/v2c/v3, HTTP/HTTPS, SSH, FTP, etc.)
- Configure IP ranges (single IPs, ranges, CIDR notation)
- Set discovery intervals and uniqueness criteria
- Enable/disable discovery rules dynamically
- Bulk operations from configuration files

### 2. Active Agent Auto-Registration
- Metadata-based host registration
- Hostname pattern matching
- Automatic template assignment
- Group assignment rules
- Custom macro configuration
- IP range restrictions

### 3. SNMP Device Discovery
- Multi-version SNMP support (v1, v2c, v3)
- Automatic device categorization (Cisco, HP, Linux, Windows, Printers, UPS)
- OID-based device identification
- Automatic template linking based on device type
- SNMPv3 security (authentication, privacy protocols)

### 4. Cloud Integration
- AWS EC2 instance discovery
- Azure VM discovery
- GCP Compute Engine discovery
- Automatic cloud host registration with appropriate templates
- Tag and metadata-based filtering

### 5. Container Discovery
- Docker container discovery across multiple hosts
- Container status and metadata collection
- Automatic registration with Docker monitoring templates
- Label-based filtering

### 6. Discovery Monitoring
- Real-time discovery status tracking
- Discovered host and service reports
- Discovery performance metrics
- Change tracking over time
- Health scoring

### 7. Configuration Validation
- Pre-deployment validation
- IP range format checking
- SNMP configuration validation
- Network connectivity testing
- Template and host group existence checks

### 8. Result Analysis
- Comprehensive discovery analytics
- Network topology mapping
- Service distribution analysis
- Device type detection
- Trend analysis
- HTML/JSON report generation

## File Structure

```
network-active-discovery/
├── SKILL.md                              (462 lines) - Complete skill documentation
├── README.md                             (328 lines) - Quick start guide
├── SKILL_SUMMARY.md                      (This file) - Comprehensive summary
│
├── scripts/
│   ├── zabbix_discovery_manager.py      (539 lines) - Discovery rule management
│   ├── zabbix_autoregistration_manager.py (547 lines) - Auto-registration actions
│   ├── zabbix_discovery_monitor.py      (490 lines) - Discovery monitoring
│   ├── validate_discovery_config.py     (541 lines) - Configuration validation
│   ├── discovery_result_analyzer.py     (520 lines) - Discovery analytics
│   │
│   └── custom_checks/
│       ├── snmp_discovery.py            (355 lines) - SNMP device discovery
│       ├── cloud_discovery.py           (372 lines) - Cloud instance discovery
│       └── docker_discovery.py          (198 lines) - Docker container discovery
│
└── examples/
    ├── network_discovery.json           - Basic network discovery examples
    ├── snmp_discovery.yaml              - SNMP v1/v2c/v3 configurations
    ├── autoregistration_config.json     - Auto-registration actions
    ├── cloud_discovery.yaml             - AWS/Azure/GCP configurations
    ├── service_discovery.json           - Service/port discovery
    ├── discovery_actions.yaml           - Discovery action configurations
    ├── bulk_discovery.yaml              - Bulk operations
    └── subnet_configs.json              - IP range examples and best practices
```

## Key Scripts

### 1. zabbix_discovery_manager.py
**Purpose**: Create, update, delete, and manage network discovery rules

**Key Features**:
- Full CRUD operations for discovery rules
- Support for all check types (ICMP, SNMP, HTTP, SSH, etc.)
- IP range validation
- Bulk operations from YAML/JSON configs
- Proxy-based discovery support

**Usage Examples**:
```bash
# Create discovery rule
python zabbix_discovery_manager.py --url URL --token TOKEN \
    --action create --rule-name "Office Network" --iprange "192.168.1.0/24"

# List all rules
python zabbix_discovery_manager.py --url URL --token TOKEN --action list

# Bulk create from config
python zabbix_discovery_manager.py --url URL --token TOKEN \
    --action bulk-create --config examples/bulk_discovery.yaml
```

### 2. zabbix_autoregistration_manager.py
**Purpose**: Configure active agent auto-registration actions

**Key Features**:
- Metadata pattern matching
- Hostname pattern matching
- Template and group assignment
- Inventory mode configuration
- Advanced condition/operation setup

**Usage Examples**:
```bash
# Create auto-registration action
python zabbix_autoregistration_manager.py --url URL --token TOKEN \
    --action create --action-name "Linux Servers" \
    --metadata-pattern "Linux" --host-groups "Linux servers" \
    --templates "Linux by Zabbix agent"

# Bulk create from config
python zabbix_autoregistration_manager.py --url URL --token TOKEN \
    --action bulk-create --config examples/autoregistration_config.json
```

### 3. zabbix_discovery_monitor.py
**Purpose**: Monitor discovery operations and results

**Key Features**:
- Real-time discovery status
- Discovered hosts and services listing
- Discovery statistics
- Change tracking
- JSON/text output formats

**Usage Examples**:
```bash
# Monitor specific rule
python zabbix_discovery_monitor.py --url URL --token TOKEN \
    --rule-name "Office Network"

# Get changes in last 24 hours
python zabbix_discovery_monitor.py --url URL --token TOKEN \
    --rule-name "Office Network" --changes 24

# Export to JSON
python zabbix_discovery_monitor.py --url URL --token TOKEN \
    --format json --output discovery_status.json
```

### 4. validate_discovery_config.py
**Purpose**: Validate discovery configurations before deployment

**Key Features**:
- Configuration file validation (YAML/JSON)
- IP range format checking
- SNMP parameter validation
- Network connectivity testing
- Template/group existence verification

**Usage Examples**:
```bash
# Validate configuration file
python validate_discovery_config.py \
    --config examples/network_discovery.json --validate-all

# Validate with connectivity checks
python validate_discovery_config.py \
    --config examples/network_discovery.json \
    --url URL --token TOKEN --check-connectivity

# Generate validation report
python validate_discovery_config.py \
    --config examples/network_discovery.json \
    --output validation_report.json
```

### 5. discovery_result_analyzer.py
**Purpose**: Analyze discovery results and generate reports

**Key Features**:
- Comprehensive discovery analytics
- Network topology mapping
- Service distribution analysis
- Device type detection
- Trend analysis
- HTML/JSON report generation
- Health scoring

**Usage Examples**:
```bash
# Generate JSON analysis report
python discovery_result_analyzer.py --url URL --token TOKEN \
    --rule-name "Office Network" --days 7 \
    --format json --report analysis.json

# Generate HTML report
python discovery_result_analyzer.py --url URL --token TOKEN \
    --days 30 --format html --report report.html
```

### 6. snmp_discovery.py
**Purpose**: Advanced SNMP device discovery with automatic categorization

**Key Features**:
- Multi-version SNMP support (v1, v2c)
- Automatic device categorization (Cisco, HP, Linux, Windows, Printers, UPS)
- OID-based device identification
- Automatic template linking
- Custom categorization rules

**Usage Examples**:
```bash
# Discover and categorize SNMP devices
python snmp_discovery.py --url URL --token TOKEN \
    --iprange "10.0.0.0/24" --community public --auto-add

# Custom SNMP version and timeout
python snmp_discovery.py --url URL --token TOKEN \
    --iprange "192.168.1.0/24" --community private \
    --version 2 --timeout 10 --output results.json
```

### 7. cloud_discovery.py
**Purpose**: Discover cloud instances from AWS, Azure, and GCP

**Key Features**:
- AWS EC2 instance discovery
- Azure VM discovery
- GCP Compute Engine discovery
- Tag/label-based filtering
- Automatic host registration

**Usage Examples**:
```bash
# Discover AWS EC2 instances
python cloud_discovery.py --url URL --token TOKEN \
    --provider aws --region us-east-1 --auto-register

# Discover Azure VMs
python cloud_discovery.py --url URL --token TOKEN \
    --provider azure --subscription-id SUB_ID \
    --resource-group prod-rg --auto-register

# Discover GCP instances
python cloud_discovery.py --url URL --token TOKEN \
    --provider gcp --project-id my-project --auto-register
```

### 8. docker_discovery.py
**Purpose**: Discover running Docker containers

**Key Features**:
- Multi-host Docker discovery
- Container status filtering
- Label-based filtering
- Automatic registration with Docker templates

**Usage Examples**:
```bash
# Discover containers on multiple Docker hosts
python docker_discovery.py --url URL --token TOKEN \
    --docker-host docker-01 docker-02 --auto-register

# Filter by container status
python docker_discovery.py --url URL --token TOKEN \
    --docker-host docker-01 --status running \
    --output containers.json
```

## Configuration Examples

### Network Discovery (network_discovery.json)
- Office network discovery (192.168.1.0/24)
- Multi-site discovery (multiple subnets)
- Data center discovery (172.16.0.0/16)
- Web server discovery (HTTP/HTTPS)
- Database server discovery (MySQL, PostgreSQL, MongoDB ports)

### SNMP Discovery (snmp_discovery.yaml)
- SNMPv2 with public community
- SNMPv3 with authentication only
- SNMPv3 with authentication and privacy
- Cisco device discovery
- Network switch discovery
- Printer discovery
- UPS discovery
- Multi-vendor discovery

### Auto-Registration (autoregistration_config.json)
- Linux servers
- Windows servers
- Production/Development environments
- AWS EC2 instances
- Azure VMs
- Docker containers
- Kubernetes nodes
- Web servers
- Database servers

### Cloud Discovery (cloud_discovery.yaml)
- AWS EC2 by region and tags
- Azure VMs by subscription and resource group
- GCP instances by project and zone

### Service Discovery (service_discovery.json)
- Web services (HTTP/HTTPS)
- Database services (MySQL, PostgreSQL, MSSQL, MongoDB, Redis)
- SSH services
- FTP services
- Mail services (SMTP, POP3, IMAP)
- Monitoring agents (Zabbix, Prometheus)

### Bulk Discovery (bulk_discovery.yaml)
- Multiple network ranges
- Auto-registration actions
- Complete infrastructure setup

### Subnet Configurations (subnet_configs.json)
- IP range format examples
- CIDR notation examples
- Best practices
- Common subnet sizes

## Discovery Check Types Supported

1. **ICMP** - Network availability
2. **SNMPv1** - Legacy SNMP devices
3. **SNMPv2c** - Common SNMP version
4. **SNMPv3** - Secure SNMP with auth/privacy
5. **Zabbix agent** - Agent availability checks
6. **HTTP** - Web service detection
7. **HTTPS** - Secure web service detection
8. **FTP** - FTP service detection
9. **SSH** - SSH service detection
10. **Telnet** - Telnet service detection
11. **TCP** - Generic TCP port checks
12. **LDAP** - LDAP service detection

## Auto-Registration Conditions

1. **Host Metadata** - Match host metadata patterns
2. **Hostname Pattern** - Match hostname with regex
3. **Proxy** - Filter by Zabbix proxy

## Discovery Actions

1. **Add Host** - Create new monitored host
2. **Add to Group** - Assign to host groups
3. **Link Template** - Attach monitoring templates
4. **Enable/Disable Host** - Control monitoring state
5. **Set Inventory Mode** - Configure inventory collection
6. **Send Message** - Notifications
7. **Execute Remote Command** - Custom scripts

## IP Range Formats

- **Single IP**: `192.168.1.100`
- **Partial Range**: `192.168.1.1-254`
- **Full Range**: `192.168.1.1-192.168.1.254`
- **CIDR Notation**: `192.168.1.0/24`, `10.0.0.0/16`
- **Multiple Ranges**: `192.168.1.0/24,10.0.1.0/24,172.16.0.1-100`

## Dependencies

### Required
- `pyzabbix` - Zabbix API client
- `requests` - HTTP library
- `ipaddress` - IP address manipulation
- `PyYAML` - YAML configuration parsing

### Optional
- `pysnmp` - For SNMP discovery
- `boto3` - For AWS discovery
- `azure-identity`, `azure-mgmt-compute` - For Azure discovery
- `google-cloud-compute` - For GCP discovery
- `docker` - For Docker discovery

## API Methods Used

### Discovery Rules
- `drule.create` - Create discovery rules
- `drule.update` - Update discovery rules
- `drule.delete` - Delete discovery rules
- `drule.get` - Retrieve discovery rules

### Discovered Items
- `dhost.get` - Get discovered hosts
- `dservice.get` - Get discovered services

### Actions
- `action.create` - Create discovery/auto-registration actions
- `action.update` - Update actions
- `action.get` - Retrieve actions

### Supporting
- `proxy.get` - Get proxy information
- `hostgroup.get`, `hostgroup.create` - Manage host groups
- `template.get` - Get template information
- `host.create` - Create hosts

## Use Cases

### 1. Automated Network Discovery
Automatically discover all devices on corporate networks using ICMP and SNMP checks, categorize them, and assign appropriate monitoring templates.

### 2. Auto-Scaling Cloud Monitoring
Enable cloud instances to automatically register with Zabbix when launched, with templates assigned based on instance metadata.

### 3. Container Infrastructure Monitoring
Discover Docker containers and Kubernetes nodes automatically, enabling monitoring of dynamic containerized environments.

### 4. Multi-Site Network Management
Discover devices across multiple branch offices, data centers, and cloud regions with centralized configuration.

### 5. Service-Based Discovery
Discover hosts by detecting specific services (web servers, databases, etc.) and assign appropriate monitoring templates.

### 6. BYOD and Guest Networks
Automatically discover and monitor devices on guest/BYOD networks with appropriate security and monitoring policies.

### 7. IoT Device Discovery
Discover and categorize IoT devices using SNMP or custom discovery methods.

## Best Practices

1. **Start Small** - Test on small IP ranges before scaling
2. **Use Validation** - Always validate configs before deployment
3. **Leverage Proxies** - Distribute discovery load across proxies
4. **Optimize Intervals** - Balance frequency with network impact
5. **Monitor Performance** - Track discovery execution times
6. **Security First** - Use SNMPv3 with authentication when possible
7. **Document Metadata** - Standardize metadata conventions
8. **Regular Cleanup** - Remove stale discovered hosts
9. **Test Auto-Registration** - Verify patterns before production
10. **Generate Reports** - Regular analysis for insights

## Security Considerations

- Store SNMP community strings securely (use Zabbix macros)
- Use SNMPv3 with authentication and privacy when possible
- Restrict auto-registration by IP range
- Validate host metadata patterns carefully
- Use Zabbix proxies for network segmentation
- Audit discovery actions regularly
- Monitor for unauthorized device registration
- Implement least-privilege access for discovery operations

## Troubleshooting Guide

### No Devices Discovered
1. Verify IP ranges are reachable
2. Check firewall rules
3. Confirm SNMP credentials
4. Test manually with ping/snmpwalk
5. Review Zabbix server logs

### Auto-Registration Not Working
1. Check agent ServerActive configuration
2. Verify HostMetadata matches action patterns
3. Confirm action is enabled
4. Review network connectivity
5. Check action conditions

### Performance Issues
1. Reduce IP range scope
2. Increase discovery intervals
3. Use Zabbix proxies
4. Limit checks per rule
5. Monitor server resources

### SNMP Discovery Issues
1. Verify SNMP version match
2. Check community strings/credentials
3. Test with snmpwalk command
4. Verify firewall allows UDP 161
5. Check SNMPv3 security settings

## Integration Points

### With Other Zabbix Skills
- **Host Management**: Discovered hosts become managed hosts
- **Template Management**: Auto-assign templates during discovery
- **Problem Management**: Monitor discovered infrastructure
- **Alerting**: Notify on discovery events
- **Reporting**: Include discovery metrics

### With External Systems
- **Cloud Providers**: AWS, Azure, GCP APIs
- **Container Platforms**: Docker, Kubernetes
- **CMDB**: Export discovery data
- **Network Tools**: Integration with network scanners
- **IPAM**: Sync with IP address management

## Future Enhancements

Potential additions:
- VMware vSphere discovery
- Network topology visualization
- Automatic network diagram generation
- Machine learning for device categorization
- Custom discovery protocols
- Integration with network flow analysis
- Automatic baseline establishment
- Predictive discovery (AI-based patterns)

## Testing

### Unit Testing
Each script includes input validation and error handling that can be tested independently.

### Integration Testing
Use the validation script to test configurations before deployment.

### Performance Testing
Monitor discovery execution times and adjust intervals accordingly.

## Documentation References

### Internal
- `SKILL.md` - Complete skill documentation with progressive disclosure
- `README.md` - Quick start guide
- Example files - Practical configuration examples

### External (Zabbix Documentation)
- `zabbix-docs-masters/zabbix-docs/15_Discovery/1_network_discovery.md`
- `zabbix-docs-masters/zabbix-docs/15_Discovery/2_auto_registration.md`
- `zabbix-docs-masters/zabbix-docs/20_API/88_drule.md`
- `zabbix-docs-masters/zabbix-docs/20_API/20_autoregistration.md`

## Success Metrics

Track these metrics to measure skill effectiveness:
- Number of devices discovered automatically
- Time saved vs manual host creation
- Discovery accuracy rate
- Auto-registration success rate
- Network coverage percentage
- Discovery execution time
- False positive rate
- Time to production for new hosts

## Skill Metadata

- **Skill Name**: Network & Active Discovery in Zabbix
- **Version**: 1.0.0
- **Category**: Zabbix Automation - Discovery
- **Priority**: Priority 2
- **Complexity**: Advanced
- **Lines of Code**: 4,352
- **Number of Scripts**: 8
- **Number of Examples**: 8
- **Dependencies**: pyzabbix, requests, ipaddress, PyYAML
- **Optional Dependencies**: pysnmp, boto3, azure-sdk, google-cloud-sdk, docker

## Conclusion

This comprehensive skill provides production-ready automation for Zabbix network discovery and active agent registration. It supports all major discovery scenarios including network scanning, SNMP device discovery, cloud integration, and container monitoring. The included validation, monitoring, and analysis tools ensure reliable and maintainable discovery operations at scale.

All scripts include proper error handling, logging, and documentation. The extensive example configurations demonstrate real-world usage patterns and best practices. The skill follows Zabbix API conventions and implements security best practices throughout.
