#!/usr/bin/env python3
"""
Cloud Instance Discovery

Discover cloud instances from AWS, Azure, and GCP for automatic Zabbix registration.

Usage:
    python cloud_discovery.py --url https://zabbix.example.com --token TOKEN --provider aws --region us-east-1
"""

import argparse
import json
import sys
from typing import Dict, List, Optional, Any
from pyzabbix import ZabbixAPI


import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
class CloudDiscovery:
    """Discover cloud instances from multiple providers."""

    def __init__(self, url: str, token: str):
        """Initialize Cloud Discovery."""
        self.zapi = ZabbixAPI(url)
        self.zapi.login(api_token=token)

    def discover_aws_instances(
        self,
        region: str,
        access_key: Optional[str] = None,
        secret_key: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None,
        auto_register: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Discover AWS EC2 instances.

        Args:
            region: AWS region
            access_key: AWS access key (or use env AWS_ACCESS_KEY_ID)
            secret_key: AWS secret key (or use env AWS_SECRET_ACCESS_KEY)
            filters: EC2 filters (e.g., {'tag:Environment': 'production'})
            auto_register: Automatically register instances

        Returns:
            List of discovered instances
        """
        try:
            import boto3
        except ImportError:
            print("Error: boto3 not installed. Install with: pip install boto3")
            sys.exit(1)

        print(f"Discovering AWS EC2 instances in region: {region}")

        # Create EC2 client
        ec2_config = {'region_name': region}
        if access_key and secret_key:
            ec2_config['aws_access_key_id'] = access_key
            ec2_config['aws_secret_access_key'] = secret_key

        ec2 = boto3.client('ec2', **ec2_config)

        # Describe instances
        describe_params = {}
        if filters:
            describe_params['Filters'] = [
                {'Name': k, 'Values': [v]} for k, v in filters.items()
            ]

        response = ec2.describe_instances(**describe_params)

        instances = []

        for reservation in response['Reservations']:
            for instance in reservation['Instances']:
                if instance['State']['Name'] != 'running':
                    continue

                inst_data = {
                    'instance_id': instance['InstanceId'],
                    'instance_type': instance['InstanceType'],
                    'private_ip': instance.get('PrivateIpAddress'),
                    'public_ip': instance.get('PublicIpAddress'),
                    'availability_zone': instance['Placement']['AvailabilityZone'],
                    'tags': {tag['Key']: tag['Value'] for tag in instance.get('Tags', [])},
                    'provider': 'aws',
                    'region': region
                }

                instances.append(inst_data)
                print(f"  [OK] Found: {inst_data['instance_id']} ({inst_data['private_ip']})")

                if auto_register:
                    self._register_instance(inst_data)

        print(f"\nTotal AWS instances discovered: {len(instances)}")
        return instances

    def discover_azure_instances(
        self,
        subscription_id: str,
        resource_group: Optional[str] = None,
        auto_register: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Discover Azure VM instances.

        Args:
            subscription_id: Azure subscription ID
            resource_group: Resource group filter
            auto_register: Automatically register instances

        Returns:
            List of discovered instances
        """
        try:
            from azure.identity import DefaultAzureCredential
            from azure.mgmt.compute import ComputeManagementClient
        except ImportError:
            print("Error: Azure SDK not installed. Install with: pip install azure-identity azure-mgmt-compute")
            sys.exit(1)

        print(f"Discovering Azure VMs in subscription: {subscription_id}")

        credential = DefaultAzureCredential()
        compute_client = ComputeManagementClient(credential, subscription_id)

        instances = []

        if resource_group:
            vms = compute_client.virtual_machines.list(resource_group)
        else:
            vms = compute_client.virtual_machines.list_all()

        for vm in vms:
            inst_data = {
                'name': vm.name,
                'vm_id': vm.vm_id,
                'location': vm.location,
                'vm_size': vm.hardware_profile.vm_size,
                'resource_group': vm.id.split('/')[4],
                'tags': vm.tags or {},
                'provider': 'azure'
            }

            instances.append(inst_data)
            print(f"  [OK] Found: {inst_data['name']} ({inst_data['location']})")

            if auto_register:
                self._register_instance(inst_data)

        print(f"\nTotal Azure instances discovered: {len(instances)}")
        return instances

    def discover_gcp_instances(
        self,
        project_id: str,
        zone: Optional[str] = None,
        auto_register: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Discover GCP Compute Engine instances.

        Args:
            project_id: GCP project ID
            zone: GCP zone filter
            auto_register: Automatically register instances

        Returns:
            List of discovered instances
        """
        try:
            from google.cloud import compute_v1
        except ImportError:
            print("Error: Google Cloud SDK not installed. Install with: pip install google-cloud-compute")
            sys.exit(1)

        print(f"Discovering GCP instances in project: {project_id}")

        instances_client = compute_v1.InstancesClient()
        instances = []

        if zone:
            request = compute_v1.ListInstancesRequest(project=project_id, zone=zone)
            instance_list = instances_client.list(request=request)
        else:
            # List from all zones
            zones_client = compute_v1.ZonesClient()
            zones_request = compute_v1.ListZonesRequest(project=project_id)
            zones = zones_client.list(request=zones_request)

            instance_list = []
            for z in zones:
                request = compute_v1.ListInstancesRequest(project=project_id, zone=z.name)
                instance_list.extend(instances_client.list(request=request))

        for instance in instance_list:
            inst_data = {
                'name': instance.name,
                'instance_id': str(instance.id),
                'machine_type': instance.machine_type.split('/')[-1],
                'zone': instance.zone.split('/')[-1],
                'status': instance.status,
                'labels': dict(instance.labels or {}),
                'provider': 'gcp',
                'project': project_id
            }

            # Get network interfaces
            if instance.network_interfaces:
                inst_data['internal_ip'] = instance.network_interfaces[0].network_i_p
                if instance.network_interfaces[0].access_configs:
                    inst_data['external_ip'] = instance.network_interfaces[0].access_configs[0].nat_i_p

            instances.append(inst_data)
            print(f"  [OK] Found: {inst_data['name']} ({inst_data['zone']})")

            if auto_register:
                self._register_instance(inst_data)

        print(f"\nTotal GCP instances discovered: {len(instances)}")
        return instances

    def _register_instance(self, instance: Dict[str, Any]):
        """Register cloud instance in Zabbix."""
        provider = instance.get('provider', 'cloud')

        # Determine hostname and IP
        if provider == 'aws':
            hostname = instance.get('tags', {}).get('Name', instance['instance_id'])
            ip = instance.get('private_ip') or instance.get('public_ip')
        elif provider == 'azure':
            hostname = instance['name']
            ip = instance.get('private_ip', '')
        elif provider == 'gcp':
            hostname = instance['name']
            ip = instance.get('internal_ip', '')
        else:
            hostname = instance.get('name', 'unknown')
            ip = instance.get('ip', '')

        if not ip:
            print(f"  ! Cannot register {hostname}: No IP address")
            return

        try:
            # Check if host already exists
            existing = self.zapi.host.get(
                output=['hostid'],
                filter={'host': hostname}
            )

            if existing:
                print(f"  ! Host {hostname} already exists")
                return

            # Create host
            host = self.zapi.host.create(
                host=hostname,
                interfaces=[{
                    'type': 1,  # Agent
                    'main': 1,
                    'useip': 1,
                    'ip': ip,
                    'dns': '',
                    'port': '10050'
                }],
                groups=[{'groupid': self._get_or_create_group(f'{provider.upper()} Instances')}],
                templates=[{'templateid': self._get_cloud_template(provider)}]
            )

            print(f"  [OK] Registered in Zabbix: {hostname} (ID: {host['hostids'][0]})")

        except Exception as e:
            print(f"  ! Failed to register {hostname}: {e}")

    def _get_or_create_group(self, group_name: str) -> str:
        """Get or create host group."""
        groups = self.zapi.hostgroup.get(
            output=['groupid'],
            filter={'name': group_name}
        )

        if groups:
            return groups[0]['groupid']

        result = self.zapi.hostgroup.create(name=group_name)
        return result['groupids'][0]

    def _get_cloud_template(self, provider: str) -> str:
        """Get template ID for cloud provider."""
        template_names = {
            'aws': 'Linux by Zabbix agent',
            'azure': 'Linux by Zabbix agent',
            'gcp': 'Linux by Zabbix agent'
        }

        template_name = template_names.get(provider, 'Linux by Zabbix agent')

        templates = self.zapi.template.get(
            output=['templateid'],
            filter={'host': template_name}
        )

        if templates:
            return templates[0]['templateid']

        # Return empty string if not found
        return ''


def main():
    parser = argparse.ArgumentParser(description='Cloud instance discovery')
    parser.add_argument('--url', required=True, help='Zabbix server URL')
    parser.add_argument('--token', required=True, help='API authentication token')
    parser.add_argument('--provider', required=True, choices=['aws', 'azure', 'gcp'], help='Cloud provider')
    parser.add_argument('--region', help='AWS region or Azure location')
    parser.add_argument('--zone', help='GCP zone')
    parser.add_argument('--project-id', help='GCP project ID')
    parser.add_argument('--subscription-id', help='Azure subscription ID')
    parser.add_argument('--resource-group', help='Azure resource group')
    parser.add_argument('--auto-register', action='store_true', help='Auto-register instances')
    parser.add_argument('--output', help='Output file for results')

    args = parser.parse_args()

    try:
        discovery = CloudDiscovery(args.url, args.token)

        instances = []

        if args.provider == 'aws':
            if not args.region:
                print("Error: --region required for AWS")
                sys.exit(1)
            instances = discovery.discover_aws_instances(
                region=args.region,
                auto_register=args.auto_register
            )

        elif args.provider == 'azure':
            if not args.subscription_id:
                print("Error: --subscription-id required for Azure")
                sys.exit(1)
            instances = discovery.discover_azure_instances(
                subscription_id=args.subscription_id,
                resource_group=args.resource_group,
                auto_register=args.auto_register
            )

        elif args.provider == 'gcp':
            if not args.project_id:
                print("Error: --project-id required for GCP")
                sys.exit(1)
            instances = discovery.discover_gcp_instances(
                project_id=args.project_id,
                zone=args.zone,
                auto_register=args.auto_register
            )

        if args.output:
            with open(args.output, 'w') as f:
                json.dump(instances, f, indent=2)
            print(f"\n[OK] Results saved to: {args.output}")

    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
