#!/usr/bin/env python3
"""
Docker Container Discovery

Discover running Docker containers for automatic Zabbix monitoring.

Usage:
    python docker_discovery.py --url https://zabbix.example.com --token TOKEN --docker-host docker-server-01
"""

import argparse
import json
import sys
from typing import Dict, List, Optional, Any
from pyzabbix import ZabbixAPI


import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
class DockerDiscovery:
    """Discover Docker containers for monitoring."""

    def __init__(self, url: str, token: str):
        """Initialize Docker Discovery."""
        self.zapi = ZabbixAPI(url)
        self.zapi.login(api_token=token)

    def discover_containers(
        self,
        docker_hosts: List[str],
        filters: Optional[Dict[str, Any]] = None,
        auto_register: bool = False,
        template: str = 'Docker by Zabbix agent 2'
    ) -> List[Dict[str, Any]]:
        """
        Discover Docker containers on specified hosts.

        Args:
            docker_hosts: List of Docker host IPs/hostnames
            filters: Docker filters (status, labels, etc.)
            auto_register: Automatically register containers
            template: Zabbix template to use

        Returns:
            List of discovered containers
        """
        try:
            import docker
        except ImportError:
            print("Error: docker library not installed. Install with: pip install docker")
            sys.exit(1)

        all_containers = []

        for docker_host in docker_hosts:
            print(f"\nDiscovering containers on: {docker_host}")

            try:
                # Connect to Docker
                client = docker.DockerClient(base_url=f"tcp://{docker_host}:2375")

                # List containers
                container_filters = filters or {}
                if 'status' not in container_filters:
                    container_filters['status'] = 'running'

                containers = client.containers.list(filters=container_filters)

                for container in containers:
                    container_data = {
                        'id': container.id[:12],
                        'name': container.name,
                        'image': container.image.tags[0] if container.image.tags else container.image.id[:12],
                        'status': container.status,
                        'docker_host': docker_host,
                        'labels': container.labels,
                        'ports': container.ports,
                        'networks': list(container.attrs['NetworkSettings']['Networks'].keys())
                    }

                    # Get IP address
                    networks = container.attrs['NetworkSettings']['Networks']
                    if networks:
                        first_network = list(networks.values())[0]
                        container_data['ip_address'] = first_network.get('IPAddress', '')

                    all_containers.append(container_data)
                    print(f"  [OK] Found: {container_data['name']} ({container_data['image']})")

                    if auto_register:
                        self._register_container(container_data, template)

                client.close()

            except Exception as e:
                print(f"  [ERROR] Error connecting to {docker_host}: {e}")

        print(f"\nTotal containers discovered: {len(all_containers)}")
        return all_containers

    def _register_container(self, container: Dict[str, Any], template_name: str):
        """Register Docker container in Zabbix."""
        hostname = f"{container['docker_host']}-{container['name']}"

        try:
            # Check if host already exists
            existing = self.zapi.host.get(
                output=['hostid'],
                filter={'host': hostname}
            )

            if existing:
                print(f"  ! Container {hostname} already registered")
                return

            # Get template
            templates = self.zapi.template.get(
                output=['templateid'],
                filter={'host': template_name}
            )

            if not templates:
                print(f"  ! Template '{template_name}' not found")
                return

            # Create host
            host = self.zapi.host.create(
                host=hostname,
                interfaces=[{
                    'type': 1,  # Agent
                    'main': 1,
                    'useip': 1,
                    'ip': container.get('ip_address', container['docker_host']),
                    'dns': '',
                    'port': '10050'
                }],
                groups=[{'groupid': self._get_or_create_group('Docker Containers')}],
                templates=[{'templateid': templates[0]['templateid']}],
                inventory_mode=1,
                inventory={
                    'tag': container['id'],
                    'notes': f"Docker container: {container['image']}"
                }
            )

            print(f"  [OK] Registered: {hostname} (ID: {host['hostids'][0]})")

        except Exception as e:
            print(f"  ! Failed to register {hostname}: {e}")

    def _get_or_create_group(self, group_name: str) -> str:
        """Get or create host group."""
        groups = self.zapi.hostgroup.get(
            output=['groupid'],
            filter={'name': group_name}
        )

        if groups:
            return groups[0]['groupid']

        result = self.zapi.hostgroup.create(name=group_name)
        return result['groupids'][0]


def main():
    parser = argparse.ArgumentParser(description='Docker container discovery')
    parser.add_argument('--url', required=True, help='Zabbix server URL')
    parser.add_argument('--token', required=True, help='API authentication token')
    parser.add_argument('--docker-host', required=True, nargs='+', help='Docker host(s) to scan')
    parser.add_argument('--status', default='running', help='Container status filter')
    parser.add_argument('--auto-register', action='store_true', help='Auto-register containers')
    parser.add_argument('--template', default='Docker by Zabbix agent 2', help='Zabbix template')
    parser.add_argument('--output', help='Output file for results')

    args = parser.parse_args()

    try:
        discovery = DockerDiscovery(args.url, args.token)

        filters = {'status': args.status} if args.status else None

        containers = discovery.discover_containers(
            docker_hosts=args.docker_host,
            filters=filters,
            auto_register=args.auto_register,
            template=args.template
        )

        if args.output:
            with open(args.output, 'w') as f:
                json.dump(containers, f, indent=2)
            print(f"\n[OK] Results saved to: {args.output}")

    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
