#!/usr/bin/env python3
"""
SNMP Discovery Script

Advanced SNMP device discovery with automatic categorization and template assignment.

Usage:
    python snmp_discovery.py --url https://zabbix.example.com --token TOKEN --iprange "10.0.0.0/24" --community public
"""

import argparse
import sys
from typing import Dict, List, Optional, Any
from pyzabbix import ZabbixAPI
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
try:
    from pysnmp.hlapi import *
except ImportError:
    print("Warning: pysnmp not installed. Install with: pip install pysnmp")


class SNMPDiscovery:
    """Advanced SNMP device discovery with categorization."""

    # Common SNMP OIDs
    OIDS = {
        'sysDescr': '1.3.6.1.2.1.1.1.0',
        'sysObjectID': '1.3.6.1.2.1.1.2.0',
        'sysUpTime': '1.3.6.1.2.1.1.3.0',
        'sysContact': '1.3.6.1.2.1.1.4.0',
        'sysName': '1.3.6.1.2.1.1.5.0',
        'sysLocation': '1.3.6.1.2.1.1.6.0',
        'ifNumber': '1.3.6.1.2.1.2.1.0',
        'hrDeviceDescr': '1.3.6.1.2.1.25.3.2.1.3.1'
    }

    # Device categorization patterns
    DEVICE_PATTERNS = {
        'Cisco Switch': {
            'oid': 'sysDescr',
            'pattern': 'cisco.*switch|catalyst',
            'template': 'Cisco IOS Switch SNMP'
        },
        'Cisco Router': {
            'oid': 'sysDescr',
            'pattern': 'cisco.*router|ios.*router',
            'template': 'Cisco IOS Router SNMP'
        },
        'HP Switch': {
            'oid': 'sysDescr',
            'pattern': 'hp.*switch|procurve',
            'template': 'HP Switch SNMP'
        },
        'Linux Server': {
            'oid': 'sysDescr',
            'pattern': 'linux|ubuntu|debian|centos|redhat',
            'template': 'Linux by SNMP'
        },
        'Windows Server': {
            'oid': 'sysDescr',
            'pattern': 'windows.*server|microsoft',
            'template': 'Windows by SNMP'
        },
        'Printer': {
            'oid': 'hrDeviceDescr',
            'pattern': 'printer|hp laserjet',
            'template': 'Generic Printer SNMP'
        },
        'UPS': {
            'oid': 'sysDescr',
            'pattern': 'ups|power|apc',
            'template': 'Generic UPS SNMP'
        }
    }

    def __init__(self, url: str, token: str):
        """Initialize SNMP Discovery."""
        self.zapi = ZabbixAPI(url)
        self.zapi.login(api_token=token)

    def discover_and_categorize(
        self,
        iprange: str,
        community: str = 'public',
        version: int = 2,
        timeout: int = 5,
        auto_add: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Discover SNMP devices and categorize them.

        Args:
            iprange: IP range to scan
            community: SNMP community string
            version: SNMP version (1 or 2)
            timeout: SNMP timeout in seconds
            auto_add: Automatically add discovered devices to Zabbix

        Returns:
            List of discovered and categorized devices
        """
        print(f"Discovering SNMP devices in range: {iprange}")

        devices = []
        ips = self._expand_ip_range(iprange)

        for ip in ips:
            device = self._discover_device(ip, community, version, timeout)
            if device:
                device['category'] = self._categorize_device(device)
                devices.append(device)
                print(f"  [OK] Discovered: {ip} ({device['category']})")

                if auto_add:
                    self._add_device_to_zabbix(device)

        print(f"\nTotal devices discovered: {len(devices)}")
        return devices

    def _discover_device(
        self,
        ip: str,
        community: str,
        version: int,
        timeout: int
    ) -> Optional[Dict[str, Any]]:
        """
        Discover a single SNMP device.

        Args:
            ip: IP address
            community: SNMP community
            version: SNMP version
            timeout: Timeout in seconds

        Returns:
            Device information dictionary or None
        """
        try:
            device = {'ip': ip, 'snmp_data': {}}

            # Query common OIDs
            for name, oid in self.OIDS.items():
                value = self._snmp_get(ip, community, oid, version, timeout)
                if value:
                    device['snmp_data'][name] = value

            # Return device only if we got some data
            if device['snmp_data']:
                return device

        except Exception:
            pass

        return None

    def _snmp_get(
        self,
        ip: str,
        community: str,
        oid: str,
        version: int,
        timeout: int
    ) -> Optional[str]:
        """Perform SNMP GET request."""
        try:
            mp_model = 0 if version == 1 else 1

            iterator = getCmd(
                SnmpEngine(),
                CommunityData(community, mpModel=mp_model),
                UdpTransportTarget((ip, 161), timeout=timeout),
                ContextData(),
                ObjectType(ObjectIdentity(oid))
            )

            errorIndication, errorStatus, errorIndex, varBinds = next(iterator)

            if errorIndication or errorStatus:
                return None

            for varBind in varBinds:
                return str(varBind[1])

        except Exception:
            pass

        return None

    def _categorize_device(self, device: Dict[str, Any]) -> str:
        """
        Categorize device based on SNMP data.

        Args:
            device: Device information

        Returns:
            Device category
        """
        import re

        snmp_data = device.get('snmp_data', {})

        for category, pattern_info in self.DEVICE_PATTERNS.items():
            oid_name = pattern_info['oid']
            pattern = pattern_info['pattern']

            if oid_name in snmp_data:
                value = snmp_data[oid_name].lower()
                if re.search(pattern, value, re.IGNORECASE):
                    return category

        return 'Unknown Device'

    def _add_device_to_zabbix(self, device: Dict[str, Any]):
        """Add discovered device to Zabbix."""
        category = device.get('category', 'Unknown Device')
        template_name = None

        # Find template for category
        for cat, pattern_info in self.DEVICE_PATTERNS.items():
            if cat == category:
                template_name = pattern_info.get('template')
                break

        if not template_name:
            print(f"  ! No template found for category: {category}")
            return

        # Get template ID
        templates = self.zapi.template.get(
            output=['templateid'],
            filter={'host': template_name}
        )

        if not templates:
            print(f"  ! Template '{template_name}' not found")
            return

        # Create host
        try:
            hostname = device['snmp_data'].get('sysName', device['ip'])

            host = self.zapi.host.create(
                host=hostname,
                interfaces=[{
                    'type': 2,  # SNMP
                    'main': 1,
                    'useip': 1,
                    'ip': device['ip'],
                    'dns': '',
                    'port': '161',
                    'details': {
                        'version': 2,
                        'community': '{$SNMP_COMMUNITY}'
                    }
                }],
                groups=[{'groupid': self._get_or_create_group('Discovered hosts')}],
                templates=[{'templateid': templates[0]['templateid']}]
            )

            print(f"  [OK] Added to Zabbix: {hostname} (ID: {host['hostids'][0]})")

        except Exception as e:
            print(f"  ! Failed to add device: {e}")

    def _get_or_create_group(self, group_name: str) -> str:
        """Get or create host group."""
        groups = self.zapi.hostgroup.get(
            output=['groupid'],
            filter={'name': group_name}
        )

        if groups:
            return groups[0]['groupid']

        # Create group
        result = self.zapi.hostgroup.create(name=group_name)
        return result['groupids'][0]

    def _expand_ip_range(self, iprange: str, limit: int = 254) -> List[str]:
        """Expand IP range to list of IPs."""
        import ipaddress

        ips = []
        ranges = iprange.split(',')

        for ip_range in ranges:
            ip_range = ip_range.strip()

            try:
                if '/' in ip_range:
                    network = ipaddress.ip_network(ip_range, strict=False)
                    for ip in network.hosts():
                        ips.append(str(ip))
                        if len(ips) >= limit:
                            return ips
                elif '-' in ip_range:
                    parts = ip_range.split('-')
                    if '.' in parts[1]:
                        start = ipaddress.ip_address(parts[0])
                        end = ipaddress.ip_address(parts[1])
                    else:
                        base_parts = parts[0].rsplit('.', 1)
                        start = ipaddress.ip_address(parts[0])
                        end = ipaddress.ip_address(f"{base_parts[0]}.{parts[1]}")

                    current = start
                    while current <= end and len(ips) < limit:
                        ips.append(str(current))
                        current = ipaddress.ip_address(int(current) + 1)
                else:
                    ips.append(ip_range)
            except Exception:
                pass

        return ips


def main():
    parser = argparse.ArgumentParser(description='SNMP device discovery')
    parser.add_argument('--url', required=True, help='Zabbix server URL')
    parser.add_argument('--token', required=True, help='API authentication token')
    parser.add_argument('--iprange', required=True, help='IP range to scan')
    parser.add_argument('--community', default='public', help='SNMP community string')
    parser.add_argument('--version', type=int, choices=[1, 2], default=2, help='SNMP version')
    parser.add_argument('--timeout', type=int, default=5, help='SNMP timeout in seconds')
    parser.add_argument('--auto-add', action='store_true', help='Automatically add devices to Zabbix')
    parser.add_argument('--output', help='Output file for results')

    args = parser.parse_args()

    try:
        discovery = SNMPDiscovery(args.url, args.token)

        devices = discovery.discover_and_categorize(
            iprange=args.iprange,
            community=args.community,
            version=args.version,
            timeout=args.timeout,
            auto_add=args.auto_add
        )

        if args.output:
            import json
            with open(args.output, 'w') as f:
                json.dump(devices, f, indent=2)
            print(f"\n[OK] Results saved to: {args.output}")

    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
