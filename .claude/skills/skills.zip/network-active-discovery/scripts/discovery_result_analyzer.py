#!/usr/bin/env python3
"""
Discovery Result Analyzer

Analyzes Zabbix discovery results, generates reports, identifies patterns,
and provides insights into discovered infrastructure.

Usage:
    python discovery_result_analyzer.py --url https://zabbix.example.com --token TOKEN --rule-name "Office Network" --report report.json
    python discovery_result_analyzer.py --url https://zabbix.example.com --token TOKEN --analyze-all --format html
"""

import argparse
import json
import sys
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from collections import defaultdict
from pyzabbix import ZabbixAPI


import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
class DiscoveryResultAnalyzer:
    """Analyzes Zabbix discovery results and generates reports."""

    def __init__(self, url: str, token: str):
        """
        Initialize analyzer.

        Args:
            url: Zabbix server URL
            token: API authentication token
        """
        self.zapi = ZabbixAPI(url)
        self.zapi.login(api_token=token)

    def analyze_discovery_results(
        self,
        rule_name: Optional[str] = None,
        days: int = 7
    ) -> Dict[str, Any]:
        """
        Analyze discovery results and generate comprehensive report.

        Args:
            rule_name: Filter by discovery rule name
            days: Number of days to analyze

        Returns:
            Analysis report dictionary
        """
        print(f"Analyzing discovery results for last {days} days...")

        # Get discovery rules
        rule_filter = {'filter': {'name': rule_name}} if rule_name else {}
        rules = self.zapi.drule.get(
            output='extend',
            selectDChecks='extend',
            selectDHosts='extend',
            **rule_filter
        )

        report = {
            'generated_at': datetime.now().isoformat(),
            'analysis_period_days': days,
            'summary': {},
            'rules': [],
            'network_topology': {},
            'service_distribution': {},
            'device_types': {},
            'trends': {},
            'recommendations': []
        }

        # Analyze each rule
        for rule in rules:
            rule_analysis = self._analyze_rule(rule, days)
            report['rules'].append(rule_analysis)

        # Generate summary
        report['summary'] = self._generate_summary(report['rules'])

        # Analyze network topology
        report['network_topology'] = self._analyze_network_topology(rules)

        # Analyze service distribution
        report['service_distribution'] = self._analyze_service_distribution()

        # Detect device types
        report['device_types'] = self._detect_device_types()

        # Analyze trends
        report['trends'] = self._analyze_trends(rules, days)

        # Generate recommendations
        report['recommendations'] = self._generate_recommendations(report)

        return report

    def _analyze_rule(self, rule: Dict[str, Any], days: int) -> Dict[str, Any]:
        """
        Analyze a single discovery rule.

        Args:
            rule: Discovery rule data
            days: Number of days to analyze

        Returns:
            Rule analysis dictionary
        """
        dhosts = rule.get('dhosts', [])
        dchecks = rule.get('dchecks', [])

        # Get discovered services
        dservices = self.zapi.dservice.get(
            output='extend',
            druleids=rule['druleid']
        )

        # Calculate uptime statistics
        cutoff_time = int((datetime.now() - timedelta(days=days)).timestamp())
        recent_dhosts = [h for h in dhosts if int(h.get('lastup', 0)) > cutoff_time]

        analysis = {
            'rule_id': rule['druleid'],
            'rule_name': rule['name'],
            'ip_range': rule['iprange'],
            'status': 'Enabled' if rule['status'] == '0' else 'Disabled',
            'check_types': [c['type'] for c in dchecks],
            'total_checks': len(dchecks),
            'discovered_hosts': {
                'total': len(dhosts),
                'up': sum(1 for h in dhosts if h['status'] == '0'),
                'down': sum(1 for h in dhosts if h['status'] == '1'),
                'recent': len(recent_dhosts)
            },
            'discovered_services': {
                'total': len(dservices),
                'by_port': self._group_services_by_port(dservices)
            },
            'coverage': self._calculate_coverage(rule['iprange'], len(dhosts)),
            'health_score': self._calculate_health_score(dhosts, dservices)
        }

        return analysis

    def _group_services_by_port(self, dservices: List[Dict[str, Any]]) -> Dict[int, int]:
        """Group discovered services by port."""
        port_counts = defaultdict(int)
        for service in dservices:
            port = int(service.get('port', 0))
            if port > 0:
                port_counts[port] += 1
        return dict(sorted(port_counts.items()))

    def _calculate_coverage(self, iprange: str, discovered_count: int) -> float:
        """
        Calculate discovery coverage percentage.

        Args:
            iprange: IP range string
            discovered_count: Number of discovered hosts

        Returns:
            Coverage percentage (0-100)
        """
        # Estimate total possible hosts in range
        total_ips = self._estimate_ip_count(iprange)

        if total_ips == 0:
            return 0.0

        coverage = (discovered_count / total_ips) * 100
        return min(coverage, 100.0)

    def _estimate_ip_count(self, iprange: str) -> int:
        """Estimate number of IPs in range."""
        import ipaddress

        count = 0
        ranges = iprange.split(',')

        for ip_range in ranges:
            ip_range = ip_range.strip()

            try:
                if '/' in ip_range:
                    network = ipaddress.ip_network(ip_range, strict=False)
                    count += network.num_addresses - 2  # Exclude network and broadcast
                elif '-' in ip_range:
                    parts = ip_range.split('-')
                    if '.' in parts[1]:
                        start = ipaddress.ip_address(parts[0])
                        end = ipaddress.ip_address(parts[1])
                        count += int(end) - int(start) + 1
                    else:
                        count += int(parts[1]) - int(parts[0].split('.')[-1]) + 1
                else:
                    count += 1
            except Exception:
                pass

        return count

    def _calculate_health_score(
        self,
        dhosts: List[Dict[str, Any]],
        dservices: List[Dict[str, Any]]
    ) -> float:
        """
        Calculate overall health score (0-100).

        Args:
            dhosts: Discovered hosts
            dservices: Discovered services

        Returns:
            Health score
        """
        if not dhosts:
            return 0.0

        # Factors: uptime, service availability
        up_hosts = sum(1 for h in dhosts if h['status'] == '0')
        up_services = sum(1 for s in dservices if s['status'] == '0')

        host_score = (up_hosts / len(dhosts)) * 60 if dhosts else 0
        service_score = (up_services / len(dservices)) * 40 if dservices else 20

        return round(host_score + service_score, 2)

    def _generate_summary(self, rules: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate overall summary from rule analyses."""
        total_hosts = sum(r['discovered_hosts']['total'] for r in rules)
        total_services = sum(r['discovered_services']['total'] for r in rules)
        up_hosts = sum(r['discovered_hosts']['up'] for r in rules)

        return {
            'total_rules': len(rules),
            'active_rules': sum(1 for r in rules if r['status'] == 'Enabled'),
            'total_discovered_hosts': total_hosts,
            'total_up_hosts': up_hosts,
            'total_discovered_services': total_services,
            'average_health_score': round(sum(r['health_score'] for r in rules) / len(rules), 2) if rules else 0
        }

    def _analyze_network_topology(self, rules: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze network topology from discovered hosts."""
        subnets = defaultdict(int)

        for rule in rules:
            for dhost in rule.get('dhosts', []):
                ip = dhost.get('ip', '')
                # Extract subnet (first 3 octets)
                if '.' in ip:
                    subnet = '.'.join(ip.split('.')[:3]) + '.0/24'
                    subnets[subnet] += 1

        return {
            'total_subnets': len(subnets),
            'subnets': dict(sorted(subnets.items(), key=lambda x: x[1], reverse=True))
        }

    def _analyze_service_distribution(self) -> Dict[str, Any]:
        """Analyze distribution of discovered services."""
        dservices = self.zapi.dservice.get(output='extend')

        # Common service ports
        service_names = {
            21: 'FTP', 22: 'SSH', 23: 'Telnet', 25: 'SMTP',
            53: 'DNS', 80: 'HTTP', 110: 'POP3', 143: 'IMAP',
            443: 'HTTPS', 3306: 'MySQL', 5432: 'PostgreSQL',
            6379: 'Redis', 27017: 'MongoDB', 10050: 'Zabbix Agent'
        }

        service_counts = defaultdict(int)

        for service in dservices:
            port = int(service.get('port', 0))
            if port > 0:
                name = service_names.get(port, f"Port {port}")
                service_counts[name] += 1

        return dict(sorted(service_counts.items(), key=lambda x: x[1], reverse=True))

    def _detect_device_types(self) -> Dict[str, Any]:
        """Detect device types based on discovered services."""
        dservices = self.zapi.dservice.get(
            output='extend',
            selectHosts=['hostid', 'host']
        )

        device_types = defaultdict(set)

        # Group services by host
        host_services = defaultdict(set)
        for service in dservices:
            ip = service.get('ip', '')
            port = int(service.get('port', 0))
            host_services[ip].add(port)

        # Classify devices
        for ip, ports in host_services.items():
            if 80 in ports or 443 in ports:
                device_types['Web Servers'].add(ip)
            if 22 in ports:
                device_types['Linux/Unix Servers'].add(ip)
            if 3389 in ports:
                device_types['Windows Servers'].add(ip)
            if 3306 in ports or 5432 in ports:
                device_types['Database Servers'].add(ip)
            if 161 in ports:
                device_types['SNMP Devices'].add(ip)
            if 10050 in ports or 10051 in ports:
                device_types['Zabbix Monitored'].add(ip)

        return {k: len(v) for k, v in device_types.items()}

    def _analyze_trends(self, rules: List[Dict[str, Any]], days: int) -> Dict[str, Any]:
        """Analyze discovery trends over time."""
        # Get historical data points
        now = int(datetime.now().timestamp())
        intervals = 5  # Analyze 5 time intervals

        trend_data = []

        for i in range(intervals):
            interval_start = now - ((intervals - i) * days * 86400 // intervals)

            # Count hosts discovered in this interval
            hosts_in_interval = 0
            for rule in rules:
                for dhost in rule.get('dhosts', []):
                    lastup = int(dhost.get('lastup', 0))
                    if lastup >= interval_start:
                        hosts_in_interval += 1

            trend_data.append({
                'interval': i + 1,
                'timestamp': interval_start,
                'discovered_hosts': hosts_in_interval
            })

        return {
            'intervals': trend_data,
            'trend': self._calculate_trend_direction(trend_data)
        }

    def _calculate_trend_direction(self, trend_data: List[Dict[str, Any]]) -> str:
        """Calculate overall trend direction."""
        if len(trend_data) < 2:
            return 'stable'

        first_half = sum(t['discovered_hosts'] for t in trend_data[:len(trend_data)//2])
        second_half = sum(t['discovered_hosts'] for t in trend_data[len(trend_data)//2:])

        if second_half > first_half * 1.1:
            return 'increasing'
        elif second_half < first_half * 0.9:
            return 'decreasing'
        else:
            return 'stable'

    def _generate_recommendations(self, report: Dict[str, Any]) -> List[str]:
        """Generate recommendations based on analysis."""
        recommendations = []

        summary = report['summary']

        # Check coverage
        for rule in report['rules']:
            if rule['coverage'] < 10:
                recommendations.append(
                    f"Low discovery coverage ({rule['coverage']:.1f}%) in rule '{rule['rule_name']}'. "
                    "Consider verifying IP ranges or checking network connectivity."
                )

            if rule['health_score'] < 70:
                recommendations.append(
                    f"Health score ({rule['health_score']}) below threshold in rule '{rule['rule_name']}'. "
                    "Investigate down hosts and services."
                )

        # Check service diversity
        service_dist = report['service_distribution']
        if len(service_dist) < 3:
            recommendations.append(
                "Limited service discovery detected. Consider adding more discovery checks "
                "(HTTP, SSH, SNMP, etc.) to improve device identification."
            )

        # Check trends
        if report['trends']['trend'] == 'decreasing':
            recommendations.append(
                "Discovery trend is decreasing. Check if devices are being removed or "
                "if there are network connectivity issues."
            )

        return recommendations

    def generate_html_report(self, report: Dict[str, Any]) -> str:
        """Generate HTML report from analysis."""
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Zabbix Discovery Analysis Report</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                h1 {{ color: #2c3e50; }}
                h2 {{ color: #34495e; margin-top: 30px; }}
                table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
                th, td {{ border: 1px solid #ddd; padding: 12px; text-align: left; }}
                th {{ background-color: #3498db; color: white; }}
                .summary-box {{ background: #ecf0f1; padding: 15px; margin: 20px 0; border-radius: 5px; }}
                .health-good {{ color: #27ae60; }}
                .health-warning {{ color: #f39c12; }}
                .health-bad {{ color: #e74c3c; }}
                .recommendation {{ background: #fff3cd; padding: 10px; margin: 10px 0; border-left: 4px solid #ffc107; }}
            </style>
        </head>
        <body>
            <h1>Zabbix Discovery Analysis Report</h1>
            <p>Generated: {report['generated_at']}</p>
            <p>Analysis Period: {report['analysis_period_days']} days</p>

            <h2>Summary</h2>
            <div class="summary-box">
                <p><strong>Total Discovery Rules:</strong> {report['summary']['total_rules']}</p>
                <p><strong>Active Rules:</strong> {report['summary']['active_rules']}</p>
                <p><strong>Total Discovered Hosts:</strong> {report['summary']['total_discovered_hosts']}</p>
                <p><strong>Hosts Up:</strong> {report['summary']['total_up_hosts']}</p>
                <p><strong>Total Services:</strong> {report['summary']['total_discovered_services']}</p>
                <p><strong>Average Health Score:</strong> {report['summary']['average_health_score']}</p>
            </div>

            <h2>Service Distribution</h2>
            <table>
                <tr><th>Service</th><th>Count</th></tr>
        """

        for service, count in list(report['service_distribution'].items())[:10]:
            html += f"<tr><td>{service}</td><td>{count}</td></tr>"

        html += """
            </table>

            <h2>Device Types</h2>
            <table>
                <tr><th>Type</th><th>Count</th></tr>
        """

        for device_type, count in report['device_types'].items():
            html += f"<tr><td>{device_type}</td><td>{count}</td></tr>"

        html += """
            </table>

            <h2>Recommendations</h2>
        """

        for rec in report['recommendations']:
            html += f'<div class="recommendation">{rec}</div>'

        html += """
        </body>
        </html>
        """

        return html


def main():
    parser = argparse.ArgumentParser(description='Analyze Zabbix discovery results')
    parser.add_argument('--url', required=True, help='Zabbix server URL')
    parser.add_argument('--token', required=True, help='API authentication token')
    parser.add_argument('--rule-name', help='Discovery rule name to analyze')
    parser.add_argument('--days', type=int, default=7, help='Number of days to analyze (default: 7)')
    parser.add_argument('--format', choices=['json', 'html'], default='json', help='Output format')
    parser.add_argument('--report', required=True, help='Output report file')

    args = parser.parse_args()

    try:
        analyzer = DiscoveryResultAnalyzer(args.url, args.token)

        # Generate analysis
        report = analyzer.analyze_discovery_results(
            rule_name=args.rule_name,
            days=args.days
        )

        # Save report
        if args.format == 'json':
            with open(args.report, 'w') as f:
                json.dump(report, f, indent=2)
            print(f"[OK] JSON report saved to: {args.report}")

        elif args.format == 'html':
            html_report = analyzer.generate_html_report(report)
            with open(args.report, 'w') as f:
                f.write(html_report)
            print(f"[OK] HTML report saved to: {args.report}")

        # Print summary
        print("\nAnalysis Summary:")
        print(f"  Total Rules: {report['summary']['total_rules']}")
        print(f"  Discovered Hosts: {report['summary']['total_discovered_hosts']}")
        print(f"  Discovered Services: {report['summary']['total_discovered_services']}")
        print(f"  Average Health Score: {report['summary']['average_health_score']}")

        if report['recommendations']:
            print(f"\n{len(report['recommendations'])} recommendation(s) generated")

    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
