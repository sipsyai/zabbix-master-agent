#!/usr/bin/env python3
"""
Discovery Configuration Validator

Validates Zabbix discovery configurations including IP ranges, SNMP settings,
check parameters, and connectivity before deployment.

Usage:
    python validate_discovery_config.py --config discovery_config.yaml --validate-all
    python validate_discovery_config.py --config discovery_config.yaml --check-connectivity --validate-ip-ranges
"""

import argparse
import json
import sys
import yaml
import ipaddress
import socket
import subprocess
from typing import Dict, List, Optional, Any, Tuple
from pyzabbix import ZabbixAPI


import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
class DiscoveryConfigValidator:
    """Validates discovery configurations before deployment."""

    def __init__(self, url: Optional[str] = None, token: Optional[str] = None):
        """
        Initialize validator.

        Args:
            url: Zabbix server URL (optional)
            token: API authentication token (optional)
        """
        self.zapi = None
        if url and token:
            self.zapi = ZabbixAPI(url)
            self.zapi.login(api_token=token)

        self.errors = []
        self.warnings = []
        self.info = []

    def validate_configuration_file(self, config_file: str) -> bool:
        """
        Validate a discovery configuration file.

        Args:
            config_file: Path to configuration file (YAML or JSON)

        Returns:
            True if validation passes, False otherwise
        """
        print(f"\n{'='*80}")
        print(f"VALIDATING DISCOVERY CONFIGURATION: {config_file}")
        print(f"{'='*80}\n")

        # Load configuration
        try:
            with open(config_file, 'r') as f:
                if config_file.endswith('.yaml') or config_file.endswith('.yml'):
                    config = yaml.safe_load(f)
                else:
                    config = json.load(f)
        except Exception as e:
            self.errors.append(f"Failed to load configuration file: {e}")
            return False

        # Validate discovery rules
        if 'discovery_rules' in config:
            for rule in config['discovery_rules']:
                self._validate_discovery_rule(rule)

        # Validate auto-registration actions
        if 'autoregistration_actions' in config:
            for action in config['autoregistration_actions']:
                self._validate_autoregistration_action(action)

        # Print results
        self._print_validation_results()

        return len(self.errors) == 0

    def _validate_discovery_rule(self, rule: Dict[str, Any]):
        """
        Validate a single discovery rule configuration.

        Args:
            rule: Discovery rule configuration
        """
        rule_name = rule.get('name', 'Unnamed')
        print(f"Validating discovery rule: {rule_name}")

        # Validate required fields
        if 'name' not in rule:
            self.errors.append(f"Discovery rule missing required field: name")

        if 'iprange' not in rule:
            self.errors.append(f"Rule '{rule_name}': Missing required field: iprange")
        else:
            # Validate IP ranges
            if not self._validate_ip_ranges(rule['iprange']):
                self.errors.append(f"Rule '{rule_name}': Invalid IP range format: {rule['iprange']}")

        # Validate delay
        if 'delay' in rule:
            if not self._validate_delay(rule['delay']):
                self.warnings.append(f"Rule '{rule_name}': Unusual delay value: {rule['delay']}")

        # Validate checks
        if 'checks' in rule:
            for idx, check in enumerate(rule['checks']):
                self._validate_discovery_check(check, rule_name, idx)

        # Validate proxy if specified
        if 'proxy_id' in rule and self.zapi:
            if not self._validate_proxy_exists(rule['proxy_id']):
                self.errors.append(f"Rule '{rule_name}': Proxy ID {rule['proxy_id']} does not exist")

    def _validate_discovery_check(self, check: Dict[str, Any], rule_name: str, check_idx: int):
        """
        Validate a discovery check configuration.

        Args:
            check: Check configuration
            rule_name: Parent rule name
            check_idx: Check index
        """
        check_type = check.get('type', 'Unknown')

        # Validate check type
        valid_types = ['ICMP', 'SNMPv1', 'SNMPv2', 'SNMPv3', 'Zabbix agent',
                      'HTTP', 'HTTPS', 'FTP', 'SSH', 'Telnet', 'LDAP', 'TCP']

        if check_type not in valid_types:
            self.errors.append(
                f"Rule '{rule_name}', Check #{check_idx}: Invalid check type: {check_type}"
            )

        # Validate SNMP checks
        if check_type in ['SNMPv1', 'SNMPv2']:
            if 'snmp_community' not in check:
                self.warnings.append(
                    f"Rule '{rule_name}', Check #{check_idx}: SNMP community not specified, using default"
                )

        if check_type == 'SNMPv3':
            self._validate_snmpv3_check(check, rule_name, check_idx)

        # Validate ports for service checks
        if check_type in ['HTTP', 'HTTPS', 'FTP', 'SSH', 'Telnet', 'TCP']:
            if 'ports' not in check or not check['ports']:
                self.warnings.append(
                    f"Rule '{rule_name}', Check #{check_idx}: No ports specified for {check_type} check"
                )

    def _validate_snmpv3_check(self, check: Dict[str, Any], rule_name: str, check_idx: int):
        """
        Validate SNMPv3 check configuration.

        Args:
            check: Check configuration
            rule_name: Parent rule name
            check_idx: Check index
        """
        security_level = check.get('snmpv3_securitylevel', 'noAuthNoPriv')

        valid_security_levels = ['noAuthNoPriv', 'authNoPriv', 'authPriv']
        if security_level not in valid_security_levels:
            self.errors.append(
                f"Rule '{rule_name}', Check #{check_idx}: Invalid SNMPv3 security level: {security_level}"
            )

        # Validate authentication parameters
        if security_level in ['authNoPriv', 'authPriv']:
            if 'snmpv3_authprotocol' not in check:
                self.errors.append(
                    f"Rule '{rule_name}', Check #{check_idx}: SNMPv3 auth protocol required for {security_level}"
                )

            if 'snmpv3_authpassphrase' not in check:
                self.errors.append(
                    f"Rule '{rule_name}', Check #{check_idx}: SNMPv3 auth passphrase required for {security_level}"
                )

        # Validate privacy parameters
        if security_level == 'authPriv':
            if 'snmpv3_privprotocol' not in check:
                self.errors.append(
                    f"Rule '{rule_name}', Check #{check_idx}: SNMPv3 privacy protocol required for authPriv"
                )

            if 'snmpv3_privpassphrase' not in check:
                self.errors.append(
                    f"Rule '{rule_name}', Check #{check_idx}: SNMPv3 privacy passphrase required for authPriv"
                )

    def _validate_autoregistration_action(self, action: Dict[str, Any]):
        """
        Validate an auto-registration action configuration.

        Args:
            action: Action configuration
        """
        action_name = action.get('name', 'Unnamed')
        print(f"Validating auto-registration action: {action_name}")

        # Validate required fields
        if 'name' not in action:
            self.errors.append(f"Auto-registration action missing required field: name")

        # Check for at least one condition
        has_condition = any([
            action.get('metadata_pattern'),
            action.get('hostname_pattern'),
            action.get('proxy_name')
        ])

        if not has_condition:
            self.warnings.append(
                f"Action '{action_name}': No conditions specified, will match all auto-registrations"
            )

        # Validate host groups if specified
        if 'host_groups' in action and self.zapi:
            for group in action['host_groups']:
                if not self._validate_hostgroup_exists(group):
                    self.errors.append(f"Action '{action_name}': Host group '{group}' does not exist")

        # Validate templates if specified
        if 'templates' in action and self.zapi:
            for template in action['templates']:
                if not self._validate_template_exists(template):
                    self.errors.append(f"Action '{action_name}': Template '{template}' does not exist")

    def _validate_ip_ranges(self, iprange: str) -> bool:
        """
        Validate IP range format.

        Args:
            iprange: IP range string

        Returns:
            True if valid, False otherwise
        """
        ranges = iprange.split(',')

        for ip_range in ranges:
            ip_range = ip_range.strip()

            try:
                # Check for CIDR notation
                if '/' in ip_range:
                    ipaddress.ip_network(ip_range, strict=False)
                # Check for IP range
                elif '-' in ip_range:
                    parts = ip_range.split('-')
                    if len(parts) != 2:
                        return False

                    # Full range or partial range
                    if '.' in parts[1]:
                        ipaddress.ip_address(parts[0])
                        ipaddress.ip_address(parts[1])
                    else:
                        ipaddress.ip_address(parts[0])
                        int(parts[1])
                # Single IP
                else:
                    ipaddress.ip_address(ip_range)
            except (ValueError, ipaddress.AddressValueError):
                return False

        return True

    def _validate_delay(self, delay: str) -> bool:
        """
        Validate delay format.

        Args:
            delay: Delay string (e.g., "1h", "30m", "3600")

        Returns:
            True if valid, False otherwise
        """
        # Allow simple intervals and flexible intervals
        if delay.isdigit():
            return int(delay) > 0

        # Check for time suffix
        valid_suffixes = ['s', 'm', 'h', 'd', 'w']
        if delay[-1] in valid_suffixes:
            try:
                value = int(delay[:-1])
                return value > 0
            except ValueError:
                return False

        return False

    def _validate_proxy_exists(self, proxy_id: int) -> bool:
        """Check if proxy exists."""
        if not self.zapi:
            return True  # Can't validate without API

        proxies = self.zapi.proxy.get(
            output=['proxyid'],
            proxyids=proxy_id
        )
        return len(proxies) > 0

    def _validate_hostgroup_exists(self, group_name: str) -> bool:
        """Check if host group exists."""
        if not self.zapi:
            return True  # Can't validate without API

        groups = self.zapi.hostgroup.get(
            output=['groupid'],
            filter={'name': group_name}
        )
        return len(groups) > 0

    def _validate_template_exists(self, template_name: str) -> bool:
        """Check if template exists."""
        if not self.zapi:
            return True  # Can't validate without API

        templates = self.zapi.template.get(
            output=['templateid'],
            filter={'host': template_name}
        )
        return len(templates) > 0

    def check_network_connectivity(self, iprange: str) -> Dict[str, Any]:
        """
        Check network connectivity to IP ranges.

        Args:
            iprange: IP range to check

        Returns:
            Connectivity results
        """
        print(f"\nChecking network connectivity to: {iprange}")

        results = {
            'total_ips': 0,
            'reachable': 0,
            'unreachable': 0,
            'reachable_ips': [],
            'unreachable_ips': []
        }

        # Expand IP ranges to individual IPs (limit to first 10 for testing)
        ips = self._expand_ip_range(iprange, limit=10)

        results['total_ips'] = len(ips)

        for ip in ips:
            if self._ping_host(ip):
                results['reachable'] += 1
                results['reachable_ips'].append(ip)
                self.info.append(f"[OK] Host {ip} is reachable")
            else:
                results['unreachable'] += 1
                results['unreachable_ips'].append(ip)
                self.warnings.append(f"[ERROR] Host {ip} is not reachable")

        return results

    def _expand_ip_range(self, iprange: str, limit: int = 10) -> List[str]:
        """
        Expand IP range to list of individual IPs.

        Args:
            iprange: IP range string
            limit: Maximum number of IPs to return

        Returns:
            List of IP addresses
        """
        ips = []
        ranges = iprange.split(',')

        for ip_range in ranges:
            ip_range = ip_range.strip()

            try:
                # CIDR notation
                if '/' in ip_range:
                    network = ipaddress.ip_network(ip_range, strict=False)
                    for ip in network.hosts():
                        ips.append(str(ip))
                        if len(ips) >= limit:
                            return ips

                # Range notation
                elif '-' in ip_range:
                    parts = ip_range.split('-')
                    if '.' in parts[1]:
                        # Full range: 192.168.1.1-192.168.1.254
                        start = ipaddress.ip_address(parts[0])
                        end = ipaddress.ip_address(parts[1])
                    else:
                        # Partial range: 192.168.1.1-254
                        base_parts = parts[0].rsplit('.', 1)
                        start = ipaddress.ip_address(parts[0])
                        end = ipaddress.ip_address(f"{base_parts[0]}.{parts[1]}")

                    current = start
                    while current <= end:
                        ips.append(str(current))
                        if len(ips) >= limit:
                            return ips
                        current = ipaddress.ip_address(int(current) + 1)

                # Single IP
                else:
                    ips.append(ip_range)

            except (ValueError, ipaddress.AddressValueError):
                pass

        return ips[:limit]

    def _ping_host(self, host: str, timeout: int = 2) -> bool:
        """
        Ping a host to check connectivity.

        Args:
            host: Hostname or IP address
            timeout: Timeout in seconds

        Returns:
            True if host is reachable, False otherwise
        """
        param = '-n' if sys.platform.lower() == 'win32' else '-c'
        timeout_param = '-w' if sys.platform.lower() == 'win32' else '-W'

        command = ['ping', param, '1', timeout_param, str(timeout), host]

        try:
            result = subprocess.run(
                command,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=timeout + 1
            )
            return result.returncode == 0
        except (subprocess.TimeoutExpired, Exception):
            return False

    def _print_validation_results(self):
        """Print validation results."""
        print(f"\n{'='*80}")
        print("VALIDATION RESULTS")
        print(f"{'='*80}\n")

        if self.errors:
            print(f"ERRORS ({len(self.errors)}):")
            for error in self.errors:
                print(f"  [ERROR] {error}")
            print()

        if self.warnings:
            print(f"WARNINGS ({len(self.warnings)}):")
            for warning in self.warnings:
                print(f"  [WARN] {warning}")
            print()

        if self.info:
            print(f"INFORMATION ({len(self.info)}):")
            for info in self.info:
                print(f"  ℹ {info}")
            print()

        if not self.errors and not self.warnings:
            print("[OK] Validation passed with no errors or warnings")
        elif not self.errors:
            print(f"[OK] Validation passed with {len(self.warnings)} warning(s)")
        else:
            print(f"[ERROR] Validation failed with {len(self.errors)} error(s)")

        print(f"\n{'='*80}\n")


def main():
    parser = argparse.ArgumentParser(description='Validate Zabbix discovery configuration')
    parser.add_argument('--config', required=True, help='Configuration file to validate')
    parser.add_argument('--url', help='Zabbix server URL (for API validation)')
    parser.add_argument('--token', help='API authentication token')
    parser.add_argument('--validate-all', action='store_true', help='Perform all validations')
    parser.add_argument('--check-connectivity', action='store_true', help='Check network connectivity')
    parser.add_argument('--validate-ip-ranges', action='store_true', help='Validate IP range formats')
    parser.add_argument('--output', help='Output file for validation report')

    args = parser.parse_args()

    try:
        validator = DiscoveryConfigValidator(args.url, args.token)

        # Perform configuration validation
        success = validator.validate_configuration_file(args.config)

        # Additional connectivity checks if requested
        if args.check_connectivity or args.validate_all:
            # Load config to get IP ranges
            with open(args.config, 'r') as f:
                if args.config.endswith('.yaml') or args.config.endswith('.yml'):
                    config = yaml.safe_load(f)
                else:
                    config = json.load(f)

            if 'discovery_rules' in config:
                for rule in config['discovery_rules']:
                    if 'iprange' in rule:
                        validator.check_network_connectivity(rule['iprange'])

        # Save validation report if requested
        if args.output:
            report = {
                'errors': validator.errors,
                'warnings': validator.warnings,
                'info': validator.info,
                'success': success
            }

            with open(args.output, 'w') as f:
                json.dump(report, f, indent=2)

            print(f"Validation report saved to: {args.output}")

        sys.exit(0 if success else 1)

    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
