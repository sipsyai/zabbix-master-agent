#!/usr/bin/env python3
"""
Zabbix Auto-Registration Manager

Manages Zabbix active agent auto-registration actions, enabling automatic
host registration based on host metadata patterns.

Usage:
    python zabbix_autoregistration_manager.py --url https://zabbix.example.com --token TOKEN --action create --config config.json
    python zabbix_autoregistration_manager.py --url https://zabbix.example.com --token TOKEN --action list --type autoregistration
"""

import argparse
import json
import sys
import yaml
from typing import Dict, List, Optional, Any
from pyzabbix import ZabbixAPI


import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
class AutoRegistrationManager:
    """Manages Zabbix active agent auto-registration actions."""

    # Event source types
    EVENT_SOURCE_AUTOREGISTRATION = 2

    # Condition types for auto-registration
    CONDITION_TYPES = {
        'host_name': 24,
        'host_metadata': 24,
        'proxy': 20
    }

    # Condition operators
    CONDITION_OPERATORS = {
        'equals': 0,
        'not_equals': 1,
        'contains': 2,
        'not_contains': 3,
        'matches': 8,
        'not_matches': 9
    }

    # Operation types
    OPERATION_TYPES = {
        'add_host': 2,
        'add_to_group': 4,
        'link_template': 6,
        'enable_host': 7,
        'disable_host': 8,
        'set_host_inventory_mode': 10
    }

    # Inventory modes
    INVENTORY_MODES = {
        'disabled': -1,
        'manual': 0,
        'automatic': 1
    }

    def __init__(self, url: str, token: str):
        """
        Initialize Auto-Registration Manager.

        Args:
            url: Zabbix server URL
            token: API authentication token
        """
        self.zapi = ZabbixAPI(url)
        self.zapi.login(api_token=token)

    def create_autoregistration_action(
        self,
        name: str,
        metadata_pattern: Optional[str] = None,
        hostname_pattern: Optional[str] = None,
        proxy_name: Optional[str] = None,
        host_groups: Optional[List[str]] = None,
        templates: Optional[List[str]] = None,
        inventory_mode: str = 'automatic',
        enabled: bool = True
    ) -> Dict[str, Any]:
        """
        Create an auto-registration action.

        Args:
            name: Action name
            metadata_pattern: Host metadata pattern to match
            hostname_pattern: Hostname pattern to match
            proxy_name: Proxy name to match
            host_groups: List of host group names to add host to
            templates: List of template names to link
            inventory_mode: Inventory mode (disabled, manual, automatic)
            enabled: Whether action is enabled

        Returns:
            Created action details
        """
        # Prepare action parameters
        params = {
            'name': name,
            'eventsource': self.EVENT_SOURCE_AUTOREGISTRATION,
            'status': 0 if enabled else 1,
            'esc_period': '1h',
            'operations': []
        }

        # Build conditions
        conditions = []

        if metadata_pattern:
            conditions.append({
                'conditiontype': self.CONDITION_TYPES['host_metadata'],
                'operator': self.CONDITION_OPERATORS['contains'],
                'value': metadata_pattern
            })

        if hostname_pattern:
            conditions.append({
                'conditiontype': self.CONDITION_TYPES['host_name'],
                'operator': self.CONDITION_OPERATORS['matches'],
                'value': hostname_pattern
            })

        if proxy_name:
            # Get proxy ID
            proxies = self.zapi.proxy.get(
                output=['proxyid', 'host'],
                filter={'host': proxy_name}
            )
            if proxies:
                conditions.append({
                    'conditiontype': self.CONDITION_TYPES['proxy'],
                    'operator': self.CONDITION_OPERATORS['equals'],
                    'value': proxies[0]['proxyid']
                })

        if conditions:
            params['filter'] = {
                'evaltype': 0,  # AND/OR
                'conditions': conditions
            }

        # Build operations
        operation_id = 0

        # Add host operation (always included)
        params['operations'].append({
            'operationtype': self.OPERATION_TYPES['add_host'],
            'opseverity': 0
        })
        operation_id += 1

        # Add to host groups
        if host_groups:
            group_ids = self._get_hostgroup_ids(host_groups)
            if group_ids:
                params['operations'].append({
                    'operationtype': self.OPERATION_TYPES['add_to_group'],
                    'opgroup': [{'groupid': gid} for gid in group_ids]
                })
                operation_id += 1

        # Link templates
        if templates:
            template_ids = self._get_template_ids(templates)
            if template_ids:
                params['operations'].append({
                    'operationtype': self.OPERATION_TYPES['link_template'],
                    'optemplate': [{'templateid': tid} for tid in template_ids]
                })
                operation_id += 1

        # Set inventory mode
        if inventory_mode in self.INVENTORY_MODES:
            params['operations'].append({
                'operationtype': self.OPERATION_TYPES['set_host_inventory_mode'],
                'opinventory': {'inventory_mode': self.INVENTORY_MODES[inventory_mode]}
            })
            operation_id += 1

        # Create action
        result = self.zapi.action.create(params)

        print(f"[OK] Created auto-registration action: {name} (ID: {result['actionids'][0]})")
        return result

    def _get_hostgroup_ids(self, group_names: List[str]) -> List[str]:
        """
        Get host group IDs by names.

        Args:
            group_names: List of host group names

        Returns:
            List of host group IDs
        """
        groups = self.zapi.hostgroup.get(
            output=['groupid'],
            filter={'name': group_names}
        )
        return [g['groupid'] for g in groups]

    def _get_template_ids(self, template_names: List[str]) -> List[str]:
        """
        Get template IDs by names.

        Args:
            template_names: List of template names

        Returns:
            List of template IDs
        """
        templates = self.zapi.template.get(
            output=['templateid'],
            filter={'host': template_names}
        )
        return [t['templateid'] for t in templates]

    def update_autoregistration_action(
        self,
        action_id: int,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Update an auto-registration action.

        Args:
            action_id: Action ID
            **kwargs: Parameters to update

        Returns:
            Update result
        """
        params = {'actionid': action_id}
        params.update(kwargs)

        result = self.zapi.action.update(params)
        print(f"[OK] Updated auto-registration action ID: {action_id}")
        return result

    def delete_autoregistration_action(self, action_id: int) -> Dict[str, Any]:
        """
        Delete an auto-registration action.

        Args:
            action_id: Action ID

        Returns:
            Deletion result
        """
        result = self.zapi.action.delete([action_id])
        print(f"[OK] Deleted auto-registration action ID: {action_id}")
        return result

    def get_autoregistration_actions(
        self,
        name: Optional[str] = None,
        action_ids: Optional[List[int]] = None
    ) -> List[Dict[str, Any]]:
        """
        Get auto-registration actions.

        Args:
            name: Filter by action name
            action_ids: Filter by action IDs

        Returns:
            List of auto-registration actions
        """
        params = {
            'output': 'extend',
            'selectOperations': 'extend',
            'selectFilter': 'extend',
            'filter': {
                'eventsource': self.EVENT_SOURCE_AUTOREGISTRATION
            }
        }

        if name:
            params['search'] = {'name': name}

        if action_ids:
            params['actionids'] = action_ids

        return self.zapi.action.get(params)

    def enable_action(self, action_id: int) -> Dict[str, Any]:
        """Enable an auto-registration action."""
        return self.update_autoregistration_action(action_id, status=0)

    def disable_action(self, action_id: int) -> Dict[str, Any]:
        """Disable an auto-registration action."""
        return self.update_autoregistration_action(action_id, status=1)

    def bulk_create_from_config(self, config_file: str) -> List[Dict[str, Any]]:
        """
        Create multiple auto-registration actions from a configuration file.

        Args:
            config_file: Path to YAML or JSON configuration file

        Returns:
            List of created actions
        """
        # Load configuration
        with open(config_file, 'r') as f:
            if config_file.endswith('.yaml') or config_file.endswith('.yml'):
                config = yaml.safe_load(f)
            else:
                config = json.load(f)

        results = []

        for action_config in config.get('autoregistration_actions', []):
            try:
                result = self.create_autoregistration_action(**action_config)
                results.append(result)
            except Exception as e:
                print(f"[ERROR] Error creating action '{action_config.get('name')}': {e}")

        return results

    def create_advanced_action(
        self,
        name: str,
        conditions: List[Dict[str, Any]],
        operations: List[Dict[str, Any]],
        enabled: bool = True
    ) -> Dict[str, Any]:
        """
        Create an advanced auto-registration action with custom conditions and operations.

        Args:
            name: Action name
            conditions: List of condition dictionaries
            operations: List of operation dictionaries
            enabled: Whether action is enabled

        Returns:
            Created action details
        """
        params = {
            'name': name,
            'eventsource': self.EVENT_SOURCE_AUTOREGISTRATION,
            'status': 0 if enabled else 1,
            'esc_period': '1h',
            'filter': {
                'evaltype': 0,
                'conditions': self._prepare_conditions(conditions)
            },
            'operations': self._prepare_operations(operations)
        }

        result = self.zapi.action.create(params)
        print(f"[OK] Created advanced auto-registration action: {name} (ID: {result['actionids'][0]})")
        return result

    def _prepare_conditions(self, conditions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Prepare action conditions.

        Args:
            conditions: List of condition configurations

        Returns:
            List of formatted conditions
        """
        formatted_conditions = []

        for condition in conditions:
            cond_type = condition.get('type')
            operator = condition.get('operator', 'contains')
            value = condition.get('value', '')

            formatted_cond = {
                'conditiontype': self.CONDITION_TYPES.get(cond_type, self.CONDITION_TYPES['host_metadata']),
                'operator': self.CONDITION_OPERATORS.get(operator, self.CONDITION_OPERATORS['contains']),
                'value': value
            }

            formatted_conditions.append(formatted_cond)

        return formatted_conditions

    def _prepare_operations(self, operations: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Prepare action operations.

        Args:
            operations: List of operation configurations

        Returns:
            List of formatted operations
        """
        formatted_operations = []

        for operation in operations:
            op_type = operation.get('type')

            if op_type not in self.OPERATION_TYPES:
                continue

            formatted_op = {
                'operationtype': self.OPERATION_TYPES[op_type]
            }

            # Add type-specific parameters
            if op_type == 'add_to_group':
                group_names = operation.get('groups', [])
                group_ids = self._get_hostgroup_ids(group_names)
                formatted_op['opgroup'] = [{'groupid': gid} for gid in group_ids]

            elif op_type == 'link_template':
                template_names = operation.get('templates', [])
                template_ids = self._get_template_ids(template_names)
                formatted_op['optemplate'] = [{'templateid': tid} for tid in template_ids]

            elif op_type == 'set_host_inventory_mode':
                mode = operation.get('mode', 'automatic')
                formatted_op['opinventory'] = {
                    'inventory_mode': self.INVENTORY_MODES.get(mode, self.INVENTORY_MODES['automatic'])
                }

            formatted_operations.append(formatted_op)

        return formatted_operations


def main():
    parser = argparse.ArgumentParser(description='Manage Zabbix auto-registration actions')
    parser.add_argument('--url', required=True, help='Zabbix server URL')
    parser.add_argument('--token', required=True, help='API authentication token')
    parser.add_argument('--action', required=True,
                       choices=['create', 'update', 'delete', 'list', 'enable', 'disable', 'bulk-create'],
                       help='Action to perform')
    parser.add_argument('--config', help='Configuration file (JSON or YAML)')
    parser.add_argument('--action-id', type=int, help='Action ID')
    parser.add_argument('--action-name', help='Action name')
    parser.add_argument('--metadata-pattern', help='Host metadata pattern to match')
    parser.add_argument('--hostname-pattern', help='Hostname pattern to match')
    parser.add_argument('--host-groups', nargs='+', help='Host groups to add host to')
    parser.add_argument('--templates', nargs='+', help='Templates to link')
    parser.add_argument('--inventory-mode', choices=['disabled', 'manual', 'automatic'],
                       default='automatic', help='Inventory mode')
    parser.add_argument('--enabled', action='store_true', default=True, help='Enable action')
    parser.add_argument('--output', help='Output file for results')

    args = parser.parse_args()

    try:
        manager = AutoRegistrationManager(args.url, args.token)

        if args.action == 'create':
            if not args.config and not args.action_name:
                print("Error: Either --config or --action-name is required")
                sys.exit(1)

            if args.config:
                results = manager.bulk_create_from_config(args.config)
            else:
                result = manager.create_autoregistration_action(
                    name=args.action_name,
                    metadata_pattern=args.metadata_pattern,
                    hostname_pattern=args.hostname_pattern,
                    host_groups=args.host_groups,
                    templates=args.templates,
                    inventory_mode=args.inventory_mode,
                    enabled=args.enabled
                )
                results = [result]

            if args.output:
                with open(args.output, 'w') as f:
                    json.dump(results, f, indent=2)

        elif args.action == 'update':
            if not args.action_id:
                print("Error: --action-id is required for update")
                sys.exit(1)

            update_params = {}
            if args.action_name:
                update_params['name'] = args.action_name

            manager.update_autoregistration_action(args.action_id, **update_params)

        elif args.action == 'delete':
            if not args.action_id:
                print("Error: --action-id is required for delete")
                sys.exit(1)

            manager.delete_autoregistration_action(args.action_id)

        elif args.action == 'list':
            actions = manager.get_autoregistration_actions(
                name=args.action_name,
                action_ids=[args.action_id] if args.action_id else None
            )

            if args.output:
                with open(args.output, 'w') as f:
                    json.dump(actions, f, indent=2)
            else:
                for action in actions:
                    print(f"\nAuto-Registration Action: {action['name']} (ID: {action['actionid']})")
                    print(f"  Status: {'Enabled' if action['status'] == '0' else 'Disabled'}")
                    print(f"  Operations: {len(action.get('operations', []))}")

                    # Display conditions
                    if 'filter' in action and 'conditions' in action['filter']:
                        print(f"  Conditions: {len(action['filter']['conditions'])}")
                        for cond in action['filter']['conditions']:
                            print(f"    - Type: {cond.get('conditiontype')}, Value: {cond.get('value')}")

        elif args.action == 'enable':
            if not args.action_id:
                print("Error: --action-id is required for enable")
                sys.exit(1)

            manager.enable_action(args.action_id)

        elif args.action == 'disable':
            if not args.action_id:
                print("Error: --action-id is required for disable")
                sys.exit(1)

            manager.disable_action(args.action_id)

        elif args.action == 'bulk-create':
            if not args.config:
                print("Error: --config is required for bulk-create")
                sys.exit(1)

            results = manager.bulk_create_from_config(args.config)

            if args.output:
                with open(args.output, 'w') as f:
                    json.dump(results, f, indent=2)

    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
