#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Discovery Manager

Manages Zabbix network discovery rules including creation, update, deletion,
and retrieval. Supports all discovery check types and configurations.

Usage:
    python zabbix_discovery_manager.py --url https://zabbix.example.com --token TOKEN --action create --config config.json
    python zabbix_discovery_manager.py --url https://zabbix.example.com --token TOKEN --action list
    python zabbix_discovery_manager.py --url https://zabbix.example.com --token TOKEN --action delete --rule-id 10
"""

import argparse
import json
import sys
import yaml
from typing import Dict, List, Optional, Any
from pyzabbix import ZabbixAPI
import ipaddress


class ZabbixDiscoveryManager:
    """Manages Zabbix network discovery rules."""

    # Discovery check types
    CHECK_TYPES = {
        'ICMP': 0,
        'SNMPv1': 1,
        'Zabbix agent': 2,
        'SNMPv2': 4,
        'SNMPv3': 6,
        'FTP': 7,
        'HTTP': 8,
        'POP': 9,
        'NNTP': 10,
        'IMAP': 11,
        'TCP': 12,
        'Telnet': 13,
        'SSH': 14,
        'HTTPS': 15,
        'LDAP': 16
    }

    # SNMPv3 security levels
    SNMPV3_SECURITY_LEVELS = {
        'noAuthNoPriv': 0,
        'authNoPriv': 1,
        'authPriv': 2
    }

    # SNMPv3 authentication protocols
    SNMPV3_AUTH_PROTOCOLS = {
        'MD5': 0,
        'SHA1': 1,
        'SHA224': 2,
        'SHA256': 3,
        'SHA384': 4,
        'SHA512': 5
    }

    # SNMPv3 privacy protocols
    SNMPV3_PRIV_PROTOCOLS = {
        'DES': 0,
        'AES128': 1,
        'AES192': 2,
        'AES256': 3
    }

    def __init__(self, url: str, token: str):
        """
        Initialize Zabbix Discovery Manager.

        Args:
            url: Zabbix server URL
            token: API authentication token
        """
        self.zapi = ZabbixAPI(url)
        self.zapi.login(api_token=token)

    def validate_ip_range(self, iprange: str) -> bool:
        """
        Validate IP range format.

        Args:
            iprange: IP range string (e.g., "192.168.1.1-254", "10.0.0.0/24")

        Returns:
            True if valid, False otherwise
        """
        ranges = iprange.split(',')

        for ip_range in ranges:
            ip_range = ip_range.strip()

            try:
                # Check for CIDR notation
                if '/' in ip_range:
                    ipaddress.ip_network(ip_range, strict=False)
                # Check for IP range (e.g., 192.168.1.1-254)
                elif '-' in ip_range:
                    parts = ip_range.split('-')
                    if len(parts) != 2:
                        return False

                    # Check if it's a full range (192.168.1.1-192.168.1.254)
                    if '.' in parts[1]:
                        ipaddress.ip_address(parts[0])
                        ipaddress.ip_address(parts[1])
                    else:
                        # Check if it's a partial range (192.168.1.1-254)
                        base_ip = parts[0]
                        ipaddress.ip_address(base_ip)
                        # Validate the last octet is a number
                        int(parts[1])
                # Check for single IP
                else:
                    ipaddress.ip_address(ip_range)
            except (ValueError, ipaddress.AddressValueError):
                return False

        return True

    def create_discovery_rule(
        self,
        name: str,
        iprange: str,
        delay: str = "1h",
        checks: Optional[List[Dict[str, Any]]] = None,
        proxy_id: Optional[int] = None,
        status: int = 0,
        uniqueness_criteria: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Create a network discovery rule.

        Args:
            name: Discovery rule name
            iprange: IP range to scan (e.g., "192.168.1.1-254", "10.0.0.0/24")
            delay: Discovery check interval (default: "1h")
            checks: List of discovery checks
            proxy_id: Zabbix proxy ID for distributed discovery
            status: Rule status (0=enabled, 1=disabled)
            uniqueness_criteria: Criteria to identify unique devices

        Returns:
            Created discovery rule details

        Raises:
            ValueError: If IP range is invalid
        """
        # Validate IP range
        if not self.validate_ip_range(iprange):
            raise ValueError(f"Invalid IP range format: {iprange}")

        # Prepare discovery rule parameters
        params = {
            'name': name,
            'iprange': iprange,
            'delay': delay,
            'status': status
        }

        # Add proxy if specified
        if proxy_id is not None:
            params['proxy_hostid'] = proxy_id

        # Prepare discovery checks
        if checks:
            dchecks = []
            for check in checks:
                dcheck = self._prepare_discovery_check(check, uniqueness_criteria)
                dchecks.append(dcheck)
            params['dchecks'] = dchecks

        # Create discovery rule
        result = self.zapi.drule.create(params)

        print(f"[OK] Created discovery rule: {name} (ID: {result['druleids'][0]})")
        return result

    def _prepare_discovery_check(
        self,
        check: Dict[str, Any],
        uniqueness_criteria: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Prepare discovery check parameters.

        Args:
            check: Check configuration
            uniqueness_criteria: Uniqueness criteria for this check

        Returns:
            Formatted discovery check parameters
        """
        check_type = check.get('type', 'ICMP')

        if check_type not in self.CHECK_TYPES:
            raise ValueError(f"Invalid check type: {check_type}")

        dcheck = {
            'type': self.CHECK_TYPES[check_type]
        }

        # Add common parameters
        if 'ports' in check:
            dcheck['ports'] = check['ports']

        if 'key_' in check:
            dcheck['key_'] = check['key_']

        # Add SNMP-specific parameters
        if check_type in ['SNMPv1', 'SNMPv2']:
            if 'snmp_community' in check:
                dcheck['snmp_community'] = check['snmp_community']

        if check_type == 'SNMPv3':
            # SNMPv3 security level
            if 'snmpv3_securitylevel' in check:
                level = check['snmpv3_securitylevel']
                if level in self.SNMPV3_SECURITY_LEVELS:
                    dcheck['snmpv3_securitylevel'] = self.SNMPV3_SECURITY_LEVELS[level]

            # SNMPv3 context
            if 'snmpv3_contextname' in check:
                dcheck['snmpv3_contextname'] = check['snmpv3_contextname']

            # SNMPv3 username
            if 'snmpv3_securityname' in check:
                dcheck['snmpv3_securityname'] = check['snmpv3_securityname']

            # SNMPv3 authentication
            if 'snmpv3_authprotocol' in check:
                proto = check['snmpv3_authprotocol']
                if proto in self.SNMPV3_AUTH_PROTOCOLS:
                    dcheck['snmpv3_authprotocol'] = self.SNMPV3_AUTH_PROTOCOLS[proto]

            if 'snmpv3_authpassphrase' in check:
                dcheck['snmpv3_authpassphrase'] = check['snmpv3_authpassphrase']

            # SNMPv3 privacy
            if 'snmpv3_privprotocol' in check:
                proto = check['snmpv3_privprotocol']
                if proto in self.SNMPV3_PRIV_PROTOCOLS:
                    dcheck['snmpv3_privprotocol'] = self.SNMPV3_PRIV_PROTOCOLS[proto]

            if 'snmpv3_privpassphrase' in check:
                dcheck['snmpv3_privpassphrase'] = check['snmpv3_privpassphrase']

        # Add uniqueness criteria
        if uniqueness_criteria and uniqueness_criteria.get('check_type') == check_type:
            dcheck['uniq'] = 1
        else:
            dcheck['uniq'] = 0

        return dcheck

    def update_discovery_rule(
        self,
        drule_id: int,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Update an existing discovery rule.

        Args:
            drule_id: Discovery rule ID
            **kwargs: Parameters to update

        Returns:
            Update result
        """
        params = {'druleid': drule_id}
        params.update(kwargs)

        result = self.zapi.drule.update(params)
        print(f"[OK] Updated discovery rule ID: {drule_id}")
        return result

    def delete_discovery_rule(self, drule_id: int) -> Dict[str, Any]:
        """
        Delete a discovery rule.

        Args:
            drule_id: Discovery rule ID

        Returns:
            Deletion result
        """
        result = self.zapi.drule.delete([drule_id])
        print(f"[OK] Deleted discovery rule ID: {drule_id}")
        return result

    def get_discovery_rules(
        self,
        name: Optional[str] = None,
        drule_ids: Optional[List[int]] = None,
        proxy_id: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Get discovery rules.

        Args:
            name: Filter by rule name
            drule_ids: Filter by rule IDs
            proxy_id: Filter by proxy ID

        Returns:
            List of discovery rules
        """
        params = {
            'output': 'extend',
            'selectDChecks': 'extend',
            'selectDHosts': ['dhostid', 'status', 'lastup', 'lastdown']
        }

        if name:
            params['filter'] = {'name': name}

        if drule_ids:
            params['druleids'] = drule_ids

        if proxy_id is not None:
            params['proxy_hostid'] = proxy_id

        return self.zapi.drule.get(params)

    def get_discovered_hosts(
        self,
        drule_id: Optional[int] = None,
        status: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Get discovered hosts.

        Args:
            drule_id: Filter by discovery rule ID
            status: Filter by status (0=host up, 1=host down)

        Returns:
            List of discovered hosts
        """
        params = {
            'output': 'extend',
            'selectDServices': 'extend'
        }

        if drule_id is not None:
            params['druleids'] = drule_id

        if status is not None:
            params['filter'] = {'status': status}

        return self.zapi.dhost.get(params)

    def get_discovered_services(
        self,
        drule_id: Optional[int] = None,
        dhost_id: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Get discovered services.

        Args:
            drule_id: Filter by discovery rule ID
            dhost_id: Filter by discovered host ID

        Returns:
            List of discovered services
        """
        params = {
            'output': 'extend',
            'selectHosts': ['hostid', 'host']
        }

        if drule_id is not None:
            params['druleids'] = drule_id

        if dhost_id is not None:
            params['dhostids'] = dhost_id

        return self.zapi.dservice.get(params)

    def enable_discovery_rule(self, drule_id: int) -> Dict[str, Any]:
        """Enable a discovery rule."""
        return self.update_discovery_rule(drule_id, status=0)

    def disable_discovery_rule(self, drule_id: int) -> Dict[str, Any]:
        """Disable a discovery rule."""
        return self.update_discovery_rule(drule_id, status=1)

    def bulk_create_from_config(self, config_file: str) -> List[Dict[str, Any]]:
        """
        Create multiple discovery rules from a configuration file.

        Args:
            config_file: Path to YAML or JSON configuration file

        Returns:
            List of created discovery rules
        """
        # Load configuration
        with open(config_file, 'r') as f:
            if config_file.endswith('.yaml') or config_file.endswith('.yml'):
                config = yaml.safe_load(f)
            else:
                config = json.load(f)

        results = []

        for rule_config in config.get('discovery_rules', []):
            try:
                result = self.create_discovery_rule(**rule_config)
                results.append(result)
            except Exception as e:
                print(f"[ERROR] Error creating rule '{rule_config.get('name')}': {e}")

        return results


def main():
    parser = argparse.ArgumentParser(description='Manage Zabbix network discovery rules')
    parser.add_argument('--url', required=True, help='Zabbix server URL')
    parser.add_argument('--token', required=True, help='API authentication token')
    parser.add_argument('--action', required=True,
                       choices=['create', 'update', 'delete', 'list', 'enable', 'disable', 'bulk-create'],
                       help='Action to perform')
    parser.add_argument('--config', help='Configuration file (JSON or YAML)')
    parser.add_argument('--rule-id', type=int, help='Discovery rule ID')
    parser.add_argument('--rule-name', help='Discovery rule name')
    parser.add_argument('--iprange', help='IP range to scan')
    parser.add_argument('--delay', default='1h', help='Discovery interval (default: 1h)')
    parser.add_argument('--proxy-id', type=int, help='Zabbix proxy ID')
    parser.add_argument('--status', type=int, choices=[0, 1], help='Rule status (0=enabled, 1=disabled)')
    parser.add_argument('--output', help='Output file for results')

    args = parser.parse_args()

    try:
        manager = ZabbixDiscoveryManager(args.url, args.token)

        if args.action == 'create':
            if not args.config and not (args.rule_name and args.iprange):
                print("Error: Either --config or both --rule-name and --iprange are required")
                sys.exit(1)

            if args.config:
                results = manager.bulk_create_from_config(args.config)
            else:
                result = manager.create_discovery_rule(
                    name=args.rule_name,
                    iprange=args.iprange,
                    delay=args.delay,
                    proxy_id=args.proxy_id,
                    status=args.status or 0
                )
                results = [result]

            if args.output:
                with open(args.output, 'w') as f:
                    json.dump(results, f, indent=2)

        elif args.action == 'update':
            if not args.rule_id:
                print("Error: --rule-id is required for update")
                sys.exit(1)

            update_params = {}
            if args.rule_name:
                update_params['name'] = args.rule_name
            if args.iprange:
                update_params['iprange'] = args.iprange
            if args.delay:
                update_params['delay'] = args.delay
            if args.proxy_id is not None:
                update_params['proxy_hostid'] = args.proxy_id
            if args.status is not None:
                update_params['status'] = args.status

            manager.update_discovery_rule(args.rule_id, **update_params)

        elif args.action == 'delete':
            if not args.rule_id:
                print("Error: --rule-id is required for delete")
                sys.exit(1)

            manager.delete_discovery_rule(args.rule_id)

        elif args.action == 'list':
            rules = manager.get_discovery_rules(
                name=args.rule_name,
                drule_ids=[args.rule_id] if args.rule_id else None,
                proxy_id=args.proxy_id
            )

            if args.output:
                with open(args.output, 'w') as f:
                    json.dump(rules, f, indent=2)
            else:
                for rule in rules:
                    print(f"\nDiscovery Rule: {rule['name']} (ID: {rule['druleid']})")
                    print(f"  IP Range: {rule['iprange']}")
                    print(f"  Delay: {rule['delay']}")
                    print(f"  Status: {'Enabled' if rule['status'] == '0' else 'Disabled'}")
                    print(f"  Checks: {len(rule.get('dchecks', []))}")

        elif args.action == 'enable':
            if not args.rule_id:
                print("Error: --rule-id is required for enable")
                sys.exit(1)

            manager.enable_discovery_rule(args.rule_id)

        elif args.action == 'disable':
            if not args.rule_id:
                print("Error: --rule-id is required for disable")
                sys.exit(1)

            manager.disable_discovery_rule(args.rule_id)

        elif args.action == 'bulk-create':
            if not args.config:
                print("Error: --config is required for bulk-create")
                sys.exit(1)

            results = manager.bulk_create_from_config(args.config)

            if args.output:
                with open(args.output, 'w') as f:
                    json.dump(results, f, indent=2)

    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
