#!/usr/bin/env python3
"""
Zabbix Discovery Monitor

Monitors Zabbix network discovery status, discovered hosts, and services.
Provides real-time visibility into discovery operations.

Usage:
    python zabbix_discovery_monitor.py --url https://zabbix.example.com --token TOKEN --rule-name "Office Network"
    python zabbix_discovery_monitor.py --url https://zabbix.example.com --token TOKEN --status up --format json
"""

import argparse
import json
import sys
from typing import Dict, List, Optional, Any
from datetime import datetime
from pyzabbix import ZabbixAPI


import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
class DiscoveryMonitor:
    """Monitors Zabbix network discovery operations."""

    # Discovery host status
    HOST_STATUS = {
        0: 'Up',
        1: 'Down'
    }

    # Discovery service status
    SERVICE_STATUS = {
        0: 'Up',
        1: 'Down'
    }

    def __init__(self, url: str, token: str):
        """
        Initialize Discovery Monitor.

        Args:
            url: Zabbix server URL
            token: API authentication token
        """
        self.zapi = ZabbixAPI(url)
        self.zapi.login(api_token=token)

    def get_discovery_rule_status(
        self,
        rule_name: Optional[str] = None,
        rule_id: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Get discovery rule status and statistics.

        Args:
            rule_name: Discovery rule name
            rule_id: Discovery rule ID

        Returns:
            List of discovery rule status information
        """
        params = {
            'output': 'extend',
            'selectDChecks': 'extend',
            'selectDHosts': ['dhostid', 'status', 'lastup', 'lastdown']
        }

        if rule_name:
            params['filter'] = {'name': rule_name}

        if rule_id:
            params['druleids'] = rule_id

        rules = self.zapi.drule.get(params)

        status_info = []

        for rule in rules:
            info = {
                'rule_id': rule['druleid'],
                'rule_name': rule['name'],
                'ip_range': rule['iprange'],
                'delay': rule['delay'],
                'status': 'Enabled' if rule['status'] == '0' else 'Disabled',
                'next_check': rule.get('nextcheck', 'N/A'),
                'checks': len(rule.get('dchecks', [])),
                'discovered_hosts': len(rule.get('dhosts', []))
            }

            # Count hosts by status
            dhosts = rule.get('dhosts', [])
            up_hosts = sum(1 for h in dhosts if h['status'] == '0')
            down_hosts = sum(1 for h in dhosts if h['status'] == '1')

            info['hosts_up'] = up_hosts
            info['hosts_down'] = down_hosts

            status_info.append(info)

        return status_info

    def get_discovered_hosts(
        self,
        rule_name: Optional[str] = None,
        rule_id: Optional[int] = None,
        status: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Get discovered hosts with details.

        Args:
            rule_name: Filter by discovery rule name
            rule_id: Filter by discovery rule ID
            status: Filter by status (up/down)

        Returns:
            List of discovered hosts
        """
        params = {
            'output': 'extend',
            'selectDServices': 'extend'
        }

        # Get rule ID if rule name provided
        if rule_name:
            rules = self.zapi.drule.get(
                output=['druleid'],
                filter={'name': rule_name}
            )
            if rules:
                rule_id = rules[0]['druleid']

        if rule_id:
            params['druleids'] = rule_id

        if status:
            status_code = 0 if status.lower() == 'up' else 1
            params['filter'] = {'status': status_code}

        dhosts = self.zapi.dhost.get(params)

        discovered_hosts = []

        for dhost in dhosts:
            host_info = {
                'dhost_id': dhost['dhostid'],
                'ip': dhost['ip'],
                'status': self.HOST_STATUS.get(int(dhost['status']), 'Unknown'),
                'last_up': self._format_timestamp(dhost.get('lastup', '0')),
                'last_down': self._format_timestamp(dhost.get('lastdown', '0')),
                'services': []
            }

            # Add service information
            for service in dhost.get('dservices', []):
                service_info = {
                    'dservice_id': service['dserviceid'],
                    'type': service['type'],
                    'port': service['port'],
                    'status': self.SERVICE_STATUS.get(int(service['status']), 'Unknown'),
                    'key': service.get('key_', ''),
                    'value': service.get('value', '')
                }
                host_info['services'].append(service_info)

            discovered_hosts.append(host_info)

        return discovered_hosts

    def get_discovered_services(
        self,
        rule_name: Optional[str] = None,
        rule_id: Optional[int] = None,
        port: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Get discovered services.

        Args:
            rule_name: Filter by discovery rule name
            rule_id: Filter by discovery rule ID
            port: Filter by port number

        Returns:
            List of discovered services
        """
        params = {
            'output': 'extend',
            'selectHosts': ['hostid', 'host']
        }

        # Get rule ID if rule name provided
        if rule_name:
            rules = self.zapi.drule.get(
                output=['druleid'],
                filter={'name': rule_name}
            )
            if rules:
                rule_id = rules[0]['druleid']

        if rule_id:
            params['druleids'] = rule_id

        dservices = self.zapi.dservice.get(params)

        discovered_services = []

        for service in dservices:
            # Filter by port if specified
            if port and int(service.get('port', 0)) != port:
                continue

            service_info = {
                'dservice_id': service['dserviceid'],
                'ip': service['ip'],
                'type': service['type'],
                'port': service['port'],
                'status': self.SERVICE_STATUS.get(int(service['status']), 'Unknown'),
                'key': service.get('key_', ''),
                'value': service.get('value', ''),
                'last_up': self._format_timestamp(service.get('lastup', '0')),
                'last_down': self._format_timestamp(service.get('lastdown', '0'))
            }

            # Add linked host information
            if 'hosts' in service and service['hosts']:
                service_info['linked_hosts'] = [
                    {'hostid': h['hostid'], 'hostname': h['host']}
                    for h in service['hosts']
                ]

            discovered_services.append(service_info)

        return discovered_services

    def get_discovery_statistics(
        self,
        rule_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get overall discovery statistics.

        Args:
            rule_name: Filter by discovery rule name

        Returns:
            Discovery statistics dictionary
        """
        rule_status = self.get_discovery_rule_status(rule_name=rule_name)
        discovered_hosts = self.get_discovered_hosts(rule_name=rule_name)
        discovered_services = self.get_discovered_services(rule_name=rule_name)

        stats = {
            'total_rules': len(rule_status),
            'enabled_rules': sum(1 for r in rule_status if r['status'] == 'Enabled'),
            'disabled_rules': sum(1 for r in rule_status if r['status'] == 'Disabled'),
            'total_discovered_hosts': len(discovered_hosts),
            'hosts_up': sum(1 for h in discovered_hosts if h['status'] == 'Up'),
            'hosts_down': sum(1 for h in discovered_hosts if h['status'] == 'Down'),
            'total_discovered_services': len(discovered_services),
            'services_up': sum(1 for s in discovered_services if s['status'] == 'Up'),
            'services_down': sum(1 for s in discovered_services if s['status'] == 'Down')
        }

        # Service breakdown by port
        service_ports = {}
        for service in discovered_services:
            port = service['port']
            if port not in service_ports:
                service_ports[port] = 0
            service_ports[port] += 1

        stats['services_by_port'] = service_ports

        return stats

    def get_discovery_changes(
        self,
        rule_name: Optional[str] = None,
        hours: int = 24
    ) -> Dict[str, Any]:
        """
        Get discovery changes in the last N hours.

        Args:
            rule_name: Filter by discovery rule name
            hours: Number of hours to look back

        Returns:
            Dictionary of discovery changes
        """
        current_time = int(datetime.now().timestamp())
        cutoff_time = current_time - (hours * 3600)

        discovered_hosts = self.get_discovered_hosts(rule_name=rule_name)

        changes = {
            'timeframe_hours': hours,
            'newly_discovered': [],
            'recently_up': [],
            'recently_down': []
        }

        for host in discovered_hosts:
            last_up = int(host.get('last_up', '0'))
            last_down = int(host.get('last_down', '0'))

            # Check if newly discovered (first seen recently)
            if last_up > cutoff_time and last_down == 0:
                changes['newly_discovered'].append(host)

            # Check if recently came up
            elif last_up > cutoff_time and last_up > last_down:
                changes['recently_up'].append(host)

            # Check if recently went down
            elif last_down > cutoff_time and last_down > last_up:
                changes['recently_down'].append(host)

        return changes

    def _format_timestamp(self, timestamp: str) -> str:
        """
        Format Unix timestamp to human-readable string.

        Args:
            timestamp: Unix timestamp as string

        Returns:
            Formatted datetime string
        """
        try:
            ts = int(timestamp)
            if ts == 0:
                return 'Never'
            return datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
        except (ValueError, OSError):
            return 'Invalid'

    def print_discovery_summary(self, rule_name: Optional[str] = None):
        """
        Print a formatted discovery summary.

        Args:
            rule_name: Filter by discovery rule name
        """
        print("\n" + "="*80)
        print("ZABBIX DISCOVERY SUMMARY")
        print("="*80 + "\n")

        # Get statistics
        stats = self.get_discovery_statistics(rule_name=rule_name)

        print(f"Discovery Rules:")
        print(f"  Total: {stats['total_rules']}")
        print(f"  Enabled: {stats['enabled_rules']}")
        print(f"  Disabled: {stats['disabled_rules']}")
        print()

        print(f"Discovered Hosts:")
        print(f"  Total: {stats['total_discovered_hosts']}")
        print(f"  Up: {stats['hosts_up']}")
        print(f"  Down: {stats['hosts_down']}")
        print()

        print(f"Discovered Services:")
        print(f"  Total: {stats['total_discovered_services']}")
        print(f"  Up: {stats['services_up']}")
        print(f"  Down: {stats['services_down']}")
        print()

        # Service breakdown
        if stats['services_by_port']:
            print("Services by Port:")
            for port, count in sorted(stats['services_by_port'].items()):
                print(f"  Port {port}: {count} services")
            print()

        # Get rule details
        rule_status = self.get_discovery_rule_status(rule_name=rule_name)
        if rule_status:
            print("Discovery Rules Details:")
            for rule in rule_status:
                print(f"\n  Rule: {rule['rule_name']} (ID: {rule['rule_id']})")
                print(f"    IP Range: {rule['ip_range']}")
                print(f"    Delay: {rule['delay']}")
                print(f"    Status: {rule['status']}")
                print(f"    Checks: {rule['checks']}")
                print(f"    Discovered Hosts: {rule['discovered_hosts']} ({rule['hosts_up']} up, {rule['hosts_down']} down)")

        print("\n" + "="*80 + "\n")


def main():
    parser = argparse.ArgumentParser(description='Monitor Zabbix network discovery')
    parser.add_argument('--url', required=True, help='Zabbix server URL')
    parser.add_argument('--token', required=True, help='API authentication token')
    parser.add_argument('--rule-name', help='Discovery rule name to monitor')
    parser.add_argument('--rule-id', type=int, help='Discovery rule ID to monitor')
    parser.add_argument('--status', choices=['up', 'down'], help='Filter hosts by status')
    parser.add_argument('--port', type=int, help='Filter services by port')
    parser.add_argument('--changes', type=int, help='Show changes in last N hours')
    parser.add_argument('--format', choices=['text', 'json'], default='text', help='Output format')
    parser.add_argument('--output', help='Output file for results')

    args = parser.parse_args()

    try:
        monitor = DiscoveryMonitor(args.url, args.token)

        if args.changes:
            # Show discovery changes
            changes = monitor.get_discovery_changes(
                rule_name=args.rule_name,
                hours=args.changes
            )

            if args.format == 'json':
                output = json.dumps(changes, indent=2)
            else:
                output = f"\nDiscovery Changes (Last {args.changes} hours):\n"
                output += f"  Newly Discovered: {len(changes['newly_discovered'])}\n"
                output += f"  Recently Up: {len(changes['recently_up'])}\n"
                output += f"  Recently Down: {len(changes['recently_down'])}\n"

            if args.output:
                with open(args.output, 'w') as f:
                    f.write(output)
            else:
                print(output)

        elif args.format == 'json':
            # JSON output
            data = {
                'rule_status': monitor.get_discovery_rule_status(
                    rule_name=args.rule_name,
                    rule_id=args.rule_id
                ),
                'discovered_hosts': monitor.get_discovered_hosts(
                    rule_name=args.rule_name,
                    rule_id=args.rule_id,
                    status=args.status
                ),
                'discovered_services': monitor.get_discovered_services(
                    rule_name=args.rule_name,
                    rule_id=args.rule_id,
                    port=args.port
                ),
                'statistics': monitor.get_discovery_statistics(rule_name=args.rule_name)
            }

            output = json.dumps(data, indent=2)

            if args.output:
                with open(args.output, 'w') as f:
                    f.write(output)
            else:
                print(output)

        else:
            # Text output
            monitor.print_discovery_summary(rule_name=args.rule_name)

            # Print detailed host information if filtered
            if args.rule_name or args.rule_id or args.status:
                hosts = monitor.get_discovered_hosts(
                    rule_name=args.rule_name,
                    rule_id=args.rule_id,
                    status=args.status
                )

                if hosts:
                    print("Discovered Hosts:")
                    for host in hosts:
                        print(f"\n  IP: {host['ip']} (ID: {host['dhost_id']})")
                        print(f"    Status: {host['status']}")
                        print(f"    Last Up: {host['last_up']}")
                        print(f"    Last Down: {host['last_down']}")
                        print(f"    Services: {len(host['services'])}")

                        for service in host['services']:
                            print(f"      - Port {service['port']}: {service['status']}")

    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
