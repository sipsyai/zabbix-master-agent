# Web & API Monitoring in Zabbix

Complete solution for monitoring websites, web applications, RESTful APIs, and synthetic user journeys in Zabbix.

## Quick Start

### 1. Simple Website Check

Monitor website availability in 30 seconds:

```bash
python scripts/zabbix_web_scenario_manager.py create \
  --name "Website Health" \
  --url "https://example.com" \
  --host-id 10001
```

### 2. API Endpoint Monitoring

Set up REST API monitoring:

```bash
python scripts/zabbix_api_monitor_setup.py \
  --name "API Health Check" \
  --url "https://api.example.com/health" \
  --host-id 10001 \
  --expected-status 200
```

### 3. SSL Certificate Monitoring

Monitor SSL certificate expiration:

```bash
python scripts/ssl_cert_monitor.py setup \
  --url "https://example.com" \
  --host-id 10001 \
  --warning 30 \
  --critical 7
```

## What's Included

### Scripts

All scripts support `--help` for detailed usage information.

| Script | Purpose |
|--------|---------|
| `zabbix_web_scenario_manager.py` | Create and manage web scenarios (multi-step HTTP checks) |
| `zabbix_api_monitor_setup.py` | Set up API endpoint monitoring with validation |
| `web_scenario_validator.py` | Validate configurations before deployment |
| `api_health_checker.py` | Test API endpoints and generate reports |
| `ssl_cert_monitor.py` | Set up SSL certificate expiration monitoring |
| `synthetic_monitor_builder.py` | Build complex synthetic user journeys |

### Examples

Complete working examples for every scenario:

- **basic_web_check.json** - Simple HTTP/HTTPS availability checks
- **multi_step_scenario.yaml** - Multi-step transactions (login, forms, shopping)
- **api_monitoring.json** - RESTful API monitoring with various auth methods
- **authentication_scenarios.yaml** - 15 authentication flow patterns
- **ssl_monitoring.json** - SSL certificate monitoring configurations
- **json_api_validation.yaml** - JSONPath validation and response parsing
- **graphql_monitoring.json** - GraphQL query monitoring
- **ecommerce_journey.yaml** - Complete e-commerce checkout flow
- **microservices_health.json** - Microservices health check patterns

## Prerequisites

1. **Zabbix Server** (5.0 or later recommended)
2. **Python 3.7+** with pip
3. **Python packages**:
   ```bash
   pip install pyzabbix pyyaml requests jsonschema validators
   ```

## Installation

1. Clone or download this skill directory
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Configure Zabbix connection in scripts or use environment variables:
   ```bash
   export ZABBIX_URL="http://your-zabbix-server/zabbix"
   export ZABBIX_USER="Admin"
   export ZABBIX_PASSWORD="your-password"
   ```

## Common Use Cases

### Monitor a Website

```bash
# Simple check
python scripts/zabbix_web_scenario_manager.py create \
  --name "Website Monitoring" \
  --url "https://example.com" \
  --host-id 10001

# With content validation
python scripts/zabbix_web_scenario_manager.py create \
  --name "Homepage Check" \
  --url "https://example.com" \
  --required-string "Welcome" \
  --host-id 10001
```

### Monitor API with Authentication

```bash
python scripts/zabbix_api_monitor_setup.py \
  --name "Protected API" \
  --url "https://api.example.com/user/profile" \
  --method GET \
  --header "Authorization: Bearer YOUR_TOKEN" \
  --jsonpath "$.status" \
  --expected-value "active" \
  --host-id 10001
```

### Multi-Step User Journey

1. Create configuration file (see `examples/multi_step_scenario.yaml`)
2. Deploy:
   ```bash
   python scripts/zabbix_web_scenario_manager.py create \
     --config examples/multi_step_scenario.yaml \
     --host-id 10001
   ```

### SSL Certificate Monitoring

```bash
# Single domain
python scripts/ssl_cert_monitor.py setup \
  --url "https://example.com" \
  --host-id 10001 \
  --warning 30 \
  --critical 7

# Multiple domains
python scripts/ssl_cert_monitor.py setup \
  --config examples/ssl_monitoring.json \
  --host-id 10001
```

### Complete Synthetic Journey

```bash
# Generate template
python scripts/synthetic_monitor_builder.py template \
  --type ecommerce \
  --output my_journey.yaml

# Edit my_journey.yaml, then deploy
python scripts/synthetic_monitor_builder.py deploy \
  --config my_journey.yaml \
  --host-id 10001 \
  --validate
```

## Testing Before Deployment

### Validate Configuration

```bash
# Validate web scenario
python scripts/web_scenario_validator.py examples/multi_step_scenario.yaml

# Strict mode (warnings as errors)
python scripts/web_scenario_validator.py examples/multi_step_scenario.yaml --strict
```

### Test API Endpoint

```bash
# Test single endpoint
python scripts/api_health_checker.py \
  --url "https://api.example.com/health" \
  --method GET

# Test with authentication
python scripts/api_health_checker.py \
  --url "https://api.example.com/protected" \
  --header "Authorization: Bearer TOKEN"

# Test multiple endpoints and generate report
python scripts/api_health_checker.py \
  --config examples/api_monitoring.json \
  --report report.html \
  --format html
```

### Check SSL Certificate

```bash
python scripts/ssl_cert_monitor.py check \
  --url "https://example.com"
```

## Configuration Examples

### Basic Web Scenario (YAML)

```yaml
name: "Website Check"
update_interval: "60s"
retries: 1

steps:
  - name: "Homepage"
    url: "https://example.com"
    status_codes: "200"
    required_string: "Welcome"
    timeout: "15s"
```

### API Monitoring (JSON)

```json
{
  "name": "API Health Check",
  "url": "https://api.example.com/health",
  "method": "GET",
  "interval": "60s",
  "status_codes": "200",
  "jsonpath": "$.status",
  "expected_value": "ok"
}
```

### Multi-Step Login Flow

```yaml
name: "Login Flow"
update_interval: "5m"

variables:
  - name: "username"
    value: "{$TEST_USER}"
  - name: "password"
    value: "{$TEST_PASS}"

steps:
  - name: "Login Page"
    url: "https://example.com/login"
    status_codes: "200"
    variables:
      - name: "csrf_token"
        regex: 'name="csrf" value="([^"]+)"'

  - name: "Submit Login"
    url: "https://example.com/auth"
    posts: "username={username}&password={password}&csrf={csrf_token}"
    status_codes: "200,302"

  - name: "Dashboard"
    url: "https://example.com/dashboard"
    status_codes: "200"
    required_string: "Welcome"
```

## Authentication Methods

### Bearer Token

```bash
python scripts/zabbix_api_monitor_setup.py \
  --name "API with Token" \
  --url "https://api.example.com/data" \
  --header "Authorization: Bearer {$API_TOKEN}" \
  --host-id 10001
```

### API Key

```bash
python scripts/zabbix_api_monitor_setup.py \
  --name "API with Key" \
  --url "https://api.example.com/data" \
  --header "X-API-Key: {$API_KEY}" \
  --host-id 10001
```

### OAuth 2.0 Flow

See `examples/authentication_scenarios.yaml` for complete OAuth implementation.

## Response Validation

### JSONPath Validation

```bash
python scripts/zabbix_api_monitor_setup.py \
  --name "Status Check" \
  --url "https://api.example.com/status" \
  --jsonpath "$.status" \
  --expected-value "operational" \
  --host-id 10001
```

### Regex Validation

In web scenario YAML:
```yaml
required_regex: '"status":\s*"(ok|healthy|operational)"'
```

### Multiple Field Validation

See `examples/json_api_validation.yaml` for complex validation patterns.

## Performance Monitoring

Response time and performance metrics are automatically tracked for:
- Web scenarios (per step and total)
- HTTP agent items (response time)
- SSL handshake time

Create triggers based on these metrics:
```
last(/Host/web.test.time[scenario,step,resp]) > 2
```

## Best Practices

### Check Intervals

- **Critical services**: 30-60 seconds
- **Standard websites**: 1-5 minutes
- **Third-party APIs**: 5-15 minutes (respect rate limits)
- **SSL certificates**: 1 hour

### Timeout Settings

- **Fast APIs**: 5 seconds
- **Standard pages**: 10-15 seconds
- **Complex transactions**: 30 seconds
- Never exceed check interval

### Security

- Store credentials in Zabbix macros (`{$USERNAME}`, `{$PASSWORD}`)
- Use HTTPS for sensitive data
- Rotate test account credentials regularly
- Monitor SSL certificate validity
- Use dedicated monitoring API keys with limited permissions

### Macro Usage

```yaml
variables:
  - name: "api_key"
    value: "{$API_KEY}"
  - name: "username"
    value: "{$TEST_USER}"
  - name: "password"
    value: "{$TEST_PASS}"
```

### Error Handling

- Set appropriate retry counts (1-3)
- Configure timeout values
- Use proper status code validation
- Add content validation for critical checks
- Monitor both success and failure scenarios

## Troubleshooting

### Web Scenario Fails Immediately

1. Check URL accessibility from Zabbix server:
   ```bash
   curl -I https://example.com
   ```
2. Verify authentication credentials
3. Check firewall rules
4. Review proxy settings if needed

### Variable Extraction Not Working

1. Test regex independently:
   ```bash
   echo 'response content' | grep -oP 'pattern'
   ```
2. Check response content format
3. Verify variable usage syntax: `{variable_name}`
4. Enable debug logging in Zabbix

### SSL Certificate Check Fails

1. Verify port 443 is accessible
2. Check certificate validity manually:
   ```bash
   openssl s_client -connect example.com:443 -servername example.com
   ```
3. Ensure Zabbix has updated CA certificates
4. Review firewall rules

### API Rate Limiting

1. Increase check interval
2. Use dedicated monitoring API keys
3. Monitor rate limit headers
4. Implement exponential backoff

## Advanced Topics

### GraphQL Monitoring

See `examples/graphql_monitoring.json` for GraphQL-specific patterns.

### Microservices Health Checks

See `examples/microservices_health.json` for distributed system monitoring.

### Synthetic User Journeys

Use `synthetic_monitor_builder.py` to create complex multi-step business transactions.

### Custom Preprocessing

Use JavaScript preprocessing for complex validation logic:

```json
{
  "type": "javascript",
  "params": "var data = JSON.parse(value); return data.status === 'ok' ? 1 : 0;"
}
```

## Support and Documentation

- **Skill Documentation**: See `SKILL.md` for complete reference
- **Zabbix Documentation**: https://www.zabbix.com/documentation
- **Example Library**: See `examples/` directory for 50+ working examples

## License

This skill is part of the Zabbix Skills collection.

## Contributing

When adding new examples or improving scripts:
1. Validate configurations before committing
2. Include comprehensive error handling
3. Add usage examples in docstrings
4. Update this README with new features
5. Test with multiple Zabbix versions

## Version History

- **1.0.0** - Initial release
  - Web scenario management
  - API monitoring setup
  - SSL certificate monitoring
  - Synthetic journey builder
  - 50+ working examples
  - Complete validation and testing tools
