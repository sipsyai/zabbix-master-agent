---
name: Web & API Monitoring in Zabbix
description: Automates Zabbix web scenario and API monitoring including HTTP/HTTPS checks, multi-step web transactions, RESTful API monitoring, authentication methods, SSL certificate monitoring, response time tracking, content validation, and synthetic monitoring through the Zabbix API. Use when monitoring websites, APIs, web applications, microservices, third-party integrations, SSL certificates, or creating synthetic user journeys.
version: 1.0.0
category: zabbix-monitoring
tags: [zabbix, monitoring, web-monitoring, api-monitoring, http, https, rest-api, graphql, ssl, synthetic-monitoring, authentication, performance]
degree_of_freedom: high
---

# Web & API Monitoring in Zabbix

## Quick Start

### Basic HTTP/HTTPS Check
To create a simple website availability check:
```python
python scripts/zabbix_web_scenario_manager.py create \
  --name "Website Health Check" \
  --url "https://example.com" \
  --host-id 10001
```

### RESTful API Monitoring
To monitor a REST API endpoint:
```python
python scripts/zabbix_api_monitor_setup.py \
  --name "API Health" \
  --url "https://api.example.com/health" \
  --method GET \
  --expected-status 200
```

### Multi-Step Web Transaction
See `examples/multi_step_scenario.yaml` for complete e-commerce checkout monitoring.

## Core Instructions

### When to Use This Skill
Use this skill for:
- Monitoring website availability and performance
- Tracking API health and response times
- Validating multi-step web transactions (login, checkout, form submissions)
- Monitoring SSL certificate expiration
- Testing authentication flows
- Synthetic user journey monitoring
- Microservices health checks
- Third-party API dependency tracking
- API rate limit monitoring
- SaaS application monitoring

### Available Tools

**Scripts:**
- `zabbix_web_scenario_manager.py` - Create, update, delete, and manage web scenarios
- `zabbix_api_monitor_setup.py` - Configure API endpoint monitoring with validation
- `web_scenario_validator.py` - Validate web scenario configurations before deployment
- `api_health_checker.py` - Test API endpoints and generate health reports
- `ssl_cert_monitor.py` - Set up SSL certificate expiration monitoring
- `synthetic_monitor_builder.py` - Build complex synthetic monitoring workflows

**Examples:**
- `basic_web_check.json` - Simple HTTP/HTTPS availability checks
- `multi_step_scenario.yaml` - Multi-step web transaction monitoring
- `api_monitoring.json` - RESTful API monitoring configurations
- `authentication_scenarios.yaml` - Various authentication flow examples
- `ssl_monitoring.json` - SSL certificate monitoring setup
- `json_api_validation.yaml` - JSON response validation with JSONPath
- `graphql_monitoring.json` - GraphQL query monitoring
- `ecommerce_journey.yaml` - Complete e-commerce user journey
- `microservices_health.json` - Microservices health check patterns

### Decision Framework

**For simple HTTP/HTTPS checks:**
1. Use `zabbix_web_scenario_manager.py` with single-step configuration
2. Configure URL, expected status code, and optional content validation
3. Set appropriate check intervals (60s for critical, 5m for standard)

**For API monitoring:**
1. Use `zabbix_api_monitor_setup.py` for RESTful endpoints
2. Configure HTTP method (GET/POST/PUT/DELETE/PATCH)
3. Add authentication headers (Bearer token, API key)
4. Set up response validation (status code, JSON schema, response time)
5. Configure preprocessing with JSONPath or regex

**For multi-step web scenarios:**
1. Start with `examples/multi_step_scenario.yaml` as template
2. Define each step with URL, method, and validation
3. Extract variables from responses for subsequent steps
4. Handle cookies and session state automatically
5. Deploy using `zabbix_web_scenario_manager.py`

**For SSL certificate monitoring:**
1. Use `ssl_cert_monitor.py` to create certificate checks
2. Set warning threshold (e.g., 30 days before expiration)
3. Configure trigger for expiration alerts
4. Monitor certificate chain and validity

**For authentication flows:**
1. Reference `examples/authentication_scenarios.yaml`
2. Implement login step with credential extraction
3. Use cookies or tokens in subsequent steps
4. Validate successful authentication response
5. Test complete authenticated workflow

**For synthetic monitoring:**
1. Use `synthetic_monitor_builder.py` for complex journeys
2. Define user actions (browse, search, add to cart, checkout)
3. Add validation at each step
4. Extract and correlate transaction IDs
5. Measure end-to-end transaction time

### Web Scenario Configuration

**Basic Structure:**
```yaml
name: "Web Scenario Name"
host_id: 10001
application: "Web Monitoring"
update_interval: 60
agent: "Zabbix"
steps:
  - name: "Step 1"
    url: "https://example.com/page1"
    status_codes: "200"
    timeout: 15
    follow_redirects: true
```

**Key Parameters:**
- `name` - Descriptive scenario name
- `update_interval` - Check frequency in seconds
- `agent` - User agent string (default: "Zabbix")
- `retries` - Number of retry attempts (default: 1)
- `steps` - Array of HTTP requests to execute sequentially

**Step Configuration:**
- `url` - Full URL to check
- `status_codes` - Expected HTTP status codes (comma-separated)
- `required_string` - String that must appear in response
- `required_regex` - Regex pattern to match in response
- `timeout` - Request timeout in seconds
- `headers` - Custom HTTP headers
- `posts` - POST data for form submissions
- `variables` - Extract variables from response using regex

### API Monitoring Configuration

**HTTP Item Type:**
For API endpoints, use HTTP agent item type:
```json
{
  "name": "API Health Check",
  "type": 19,
  "key_": "api.health.check",
  "url": "https://api.example.com/health",
  "request_method": 0,
  "timeout": "10s",
  "status_codes": "200",
  "follow_redirects": 1
}
```

**HTTP Methods:**
- 0 = GET
- 1 = POST
- 2 = PUT
- 3 = HEAD
- 4 = DELETE
- 5 = PATCH

**Authentication:**
Add to headers parameter:
```json
"headers": [
  {
    "name": "Authorization",
    "value": "Bearer {$API_TOKEN}"
  },
  {
    "name": "Content-Type",
    "value": "application/json"
  }
]
```

**Response Validation:**
Use preprocessing steps:
```json
"preprocessing": [
  {
    "type": 12,
    "params": "$.status\nOK",
    "error_handler": 0
  },
  {
    "type": 5,
    "params": "\\d+\\.\\d+",
    "error_handler": 0
  }
]
```

Preprocessing types:
- Type 12 = JSONPath
- Type 5 = Regular expression
- Type 1 = Multiplier (for numeric conversion)
- Type 15 = Check for error using regex

### Authentication Methods

**HTTP Basic Authentication:**
```yaml
headers:
  - name: "Authorization"
    value: "Basic {$ENCODED_CREDENTIALS}"
```

**Bearer Token:**
```yaml
headers:
  - name: "Authorization"
    value: "Bearer {$API_TOKEN}"
```

**API Key:**
```yaml
headers:
  - name: "X-API-Key"
    value: "{$API_KEY}"
```

**OAuth 2.0 Flow:**
```yaml
steps:
  - name: "Get Access Token"
    url: "https://auth.example.com/oauth/token"
    posts: "grant_type=client_credentials&client_id={$CLIENT_ID}&client_secret={$CLIENT_SECRET}"
    variables:
      - name: "access_token"
        regex: '"access_token":"([^"]+)"'
  - name: "API Call"
    url: "https://api.example.com/resource"
    headers:
      - name: "Authorization"
        value: "Bearer {access_token}"
```

**Cookie-Based Session:**
Zabbix automatically handles cookies between steps in web scenarios.
```yaml
steps:
  - name: "Login"
    url: "https://example.com/login"
    posts: "username={$USERNAME}&password={$PASSWORD}"
    status_codes: "200,302"
  - name: "Dashboard"
    url: "https://example.com/dashboard"
    required_string: "Welcome"
```

### Response Validation

**Content Validation:**
- `required_string` - Exact string match (case-sensitive)
- `required_regex` - Regex pattern match
- JSONPath for JSON responses (in preprocessing)
- XPath for XML responses (in preprocessing)

**Status Code Validation:**
```yaml
status_codes: "200"           # Single code
status_codes: "200,201,204"   # Multiple acceptable codes
status_codes: "200-299"       # Range (handled via triggers)
```

**Response Time Validation:**
Create triggers on response time items:
```json
{
  "expression": "last(/Host/web.test.time[Scenario,Step,resp])>2",
  "name": "High response time on Step",
  "priority": 2
}
```

**JSON Schema Validation:**
Use JSONPath preprocessing to validate structure:
```json
"preprocessing": [
  {"type": 12, "params": "$.data.id"},
  {"type": 12, "params": "$.data.status"},
  {"type": 12, "params": "$.meta.timestamp"}
]
```

### SSL Certificate Monitoring

**Setup Certificate Check:**
```python
python scripts/ssl_cert_monitor.py \
  --url "https://example.com" \
  --host-id 10001 \
  --warning-days 30 \
  --critical-days 7
```

**Manual Configuration:**
Use `net.tcp.service.cert` item key:
```json
{
  "name": "SSL Certificate Expiration",
  "type": 3,
  "key_": "net.tcp.service.cert[tcp,example.com,443]",
  "value_type": 3,
  "units": "s",
  "preprocessing": [
    {
      "type": 5,
      "params": "\"Certificate will expire on (.+)\"\n\\1"
    }
  ]
}
```

### Performance Metrics

**Response Time Tracking:**
Web scenario automatically creates items:
- `web.test.time[scenario,step,resp]` - Response time
- `web.test.time[scenario,step,download]` - Download speed
- `web.test.time[scenario,,last]` - Last check time

**Throughput Monitoring:**
For API rate limiting:
```json
{
  "name": "API Requests per Minute",
  "key_": "api.requests.rate",
  "type": 18,
  "params": "return api_call_count()",
  "delay": "1m"
}
```

**SLA Tracking:**
Create calculated items for availability:
```
100*(1-last(//web.test.fail[scenario]))
```

### Error Handling

**Retry Configuration:**
```yaml
retries: 3
timeout: 15
```

**Fallback Monitoring:**
Create dependent items that trigger on primary failure:
```json
{
  "name": "Backup Check",
  "type": 18,
  "master_itemid": 12345,
  "trigger": "last()=0"
}
```

**Alert Configuration:**
```json
{
  "name": "Web Scenario Failure",
  "expression": "last(/Host/web.test.fail[scenario])=1",
  "priority": 4,
  "manual_close": 1
}
```

### Workflow

1. **Planning Phase:**
   - Identify endpoints/pages to monitor
   - Define success criteria (status codes, content, response time)
   - Determine authentication requirements
   - Plan multi-step workflows if needed

2. **Configuration Phase:**
   - Use appropriate example as template
   - Customize URLs, headers, and validation rules
   - Set up authentication (credentials as macros)
   - Configure intervals and timeouts

3. **Validation Phase:**
   - Run `web_scenario_validator.py` on configuration
   - Test with `api_health_checker.py` before deployment
   - Verify all variables and dependencies

4. **Deployment Phase:**
   - Deploy using `zabbix_web_scenario_manager.py` or `zabbix_api_monitor_setup.py`
   - Verify items are created and collecting data
   - Check latest data in Zabbix UI

5. **Monitoring Phase:**
   - Create triggers for failures and performance
   - Set up notifications
   - Monitor trends and adjust thresholds
   - Generate reports with `api_health_checker.py`

### Best Practices

**Interval Configuration:**
- Critical services: 30-60 seconds
- Standard websites: 1-5 minutes
- Third-party APIs: 5-15 minutes (respect rate limits)
- SSL certificates: 1 hour (daily check sufficient)

**Timeout Settings:**
- Fast APIs: 5 seconds
- Standard web pages: 10-15 seconds
- Complex transactions: 30 seconds
- Never exceed check interval

**Variable Extraction:**
Use specific regex patterns:
```yaml
variables:
  - name: "transaction_id"
    regex: '"transactionId":"([a-f0-9-]+)"'
  - name: "session_token"
    regex: 'X-Session-Token: ([A-Za-z0-9]+)'
```

**Header Management:**
Always include:
```yaml
headers:
  - name: "User-Agent"
    value: "Zabbix Monitoring/1.0"
  - name: "Accept"
    value: "application/json"
```

**Macro Usage:**
Store sensitive data in macros:
- `{$API_TOKEN}` - API authentication tokens
- `{$USERNAME}` - Login credentials
- `{$PASSWORD}` - Login credentials
- `{$API_URL}` - Base API URL

**Rate Limiting:**
Respect API limits:
- Add delays between steps if needed
- Use appropriate check intervals
- Monitor rate limit headers
- Implement exponential backoff in custom scripts

## Reference Materials

For detailed configurations, see:
- `examples/` - Complete working examples for all scenarios
- `scripts/README.md` - Script usage and parameters
- Zabbix documentation: Web monitoring and HTTP agent item type

## Common Patterns

**Pattern 1: Simple Health Check**
```bash
python scripts/zabbix_api_monitor_setup.py \
  --name "Service Health" \
  --url "https://api.example.com/health" \
  --expected-status 200 \
  --interval 60
```

**Pattern 2: Authenticated API**
```bash
python scripts/zabbix_api_monitor_setup.py \
  --name "Authenticated API" \
  --url "https://api.example.com/user/profile" \
  --method GET \
  --header "Authorization: Bearer {$TOKEN}" \
  --jsonpath "$.status" \
  --expected-value "active"
```

**Pattern 3: Multi-Step Transaction**
```bash
python scripts/zabbix_web_scenario_manager.py create \
  --config examples/multi_step_scenario.yaml \
  --host-id 10001
```

**Pattern 4: SSL Monitoring**
```bash
python scripts/ssl_cert_monitor.py \
  --url "https://example.com" \
  --warning 30 \
  --critical 7
```

**Pattern 5: Complete Synthetic Journey**
```bash
python scripts/synthetic_monitor_builder.py \
  --config examples/ecommerce_journey.yaml \
  --validate \
  --deploy
```

## Troubleshooting

**Issue: Web scenario fails immediately**
- Check URL accessibility from Zabbix server
- Verify authentication credentials
- Check timeout settings
- Review proxy configuration if needed

**Issue: Variable extraction not working**
- Test regex pattern independently
- Check response content format
- Verify variable usage syntax: `{variable_name}`
- Enable debug logging in Zabbix

**Issue: SSL certificate check fails**
- Verify port 443 accessible
- Check certificate validity manually
- Ensure Zabbix has updated CA certificates
- Review firewall rules

**Issue: API rate limiting errors**
- Increase check interval
- Implement retry with backoff
- Monitor rate limit headers
- Use dedicated monitoring API keys

**Issue: Response validation failures**
- Verify expected content is present
- Check for encoding issues
- Review response format (JSON/XML/HTML)
- Test JSONPath/XPath expressions independently

## Advanced Topics

For advanced configurations including:
- GraphQL query monitoring
- SOAP web service monitoring
- WebSocket connection monitoring
- gRPC health checks
- Custom authentication flows
- Advanced response parsing
- Performance benchmarking
- Distributed synthetic monitoring

Refer to individual example files and script documentation.
