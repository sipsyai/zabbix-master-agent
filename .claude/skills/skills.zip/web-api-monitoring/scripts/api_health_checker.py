#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
API Health Checker

Tests API endpoints and generates health reports. Can be used before setting up
monitoring or for ad-hoc health checks.

Usage:
    python api_health_checker.py --url "https://api.example.com/health"
    python api_health_checker.py --config endpoints.yaml --report report.html
    python api_health_checker.py --url "https://api.example.com/user" --header "Authorization: Bearer token"

Requirements:
    pip install requests pyyaml jinja2
"""

import sys
import json
import yaml
import argparse
import time
from typing import Dict, List, Any, Optional
from datetime import datetime
from urllib.parse import urlparse

try:
    import requests
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry
except ImportError:
    print("Missing requests library. Install with: pip install requests", file=sys.stderr)
    sys.exit(1)


class APIHealthChecker:
    """Check health of API endpoints"""

    def __init__(self, timeout: int = 10, retries: int = 3):
        """
        Initialize health checker

        Args:
            timeout: Request timeout in seconds
            retries: Number of retry attempts
        """
        self.timeout = timeout
        self.session = self._create_session(retries)

    def _create_session(self, retries: int) -> requests.Session:
        """Create requests session with retry logic"""
        session = requests.Session()
        retry = Retry(
            total=retries,
            read=retries,
            connect=retries,
            backoff_factor=0.3,
            status_forcelist=(500, 502, 504)
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        return session

    def check_endpoint(self, url: str, method: str = "GET",
                       headers: Optional[Dict[str, str]] = None,
                       data: Optional[str] = None,
                       expected_status: Optional[int] = None,
                       expected_content: Optional[str] = None,
                       jsonpath: Optional[str] = None) -> Dict[str, Any]:
        """
        Check single API endpoint

        Args:
            url: API endpoint URL
            method: HTTP method
            headers: Optional headers
            data: Optional request body
            expected_status: Expected status code
            expected_content: Expected content in response
            jsonpath: JSONPath expression to validate

        Returns:
            Health check results
        """
        result = {
            "url": url,
            "method": method,
            "timestamp": datetime.utcnow().isoformat(),
            "success": False,
            "status_code": None,
            "response_time": None,
            "content_length": None,
            "checks": {
                "reachable": False,
                "status_code_match": None,
                "content_match": None,
                "jsonpath_match": None,
                "ssl_valid": None
            },
            "error": None
        }

        try:
            # Make request
            start_time = time.time()
            response = self.session.request(
                method=method,
                url=url,
                headers=headers or {},
                data=data,
                timeout=self.timeout,
                verify=True
            )
            elapsed = time.time() - start_time

            # Basic metrics
            result["status_code"] = response.status_code
            result["response_time"] = round(elapsed, 3)
            result["content_length"] = len(response.content)
            result["checks"]["reachable"] = True

            # Check SSL for HTTPS
            if url.startswith("https://"):
                result["checks"]["ssl_valid"] = True

            # Check status code
            if expected_status:
                result["checks"]["status_code_match"] = (response.status_code == expected_status)
            else:
                result["checks"]["status_code_match"] = (200 <= response.status_code < 300)

            # Check content
            if expected_content:
                result["checks"]["content_match"] = (expected_content in response.text)

            # Check JSONPath
            if jsonpath:
                try:
                    data = response.json()
                    value = self._jsonpath_extract(data, jsonpath)
                    result["checks"]["jsonpath_match"] = (value is not None)
                    result["jsonpath_value"] = value
                except Exception as e:
                    result["checks"]["jsonpath_match"] = False
                    result["jsonpath_error"] = str(e)

            # Store response details
            result["headers"] = dict(response.headers)

            # Try to parse JSON
            try:
                result["json"] = response.json()
            except:
                result["text"] = response.text[:500]

            # Overall success
            checks = result["checks"]
            result["success"] = (
                checks["reachable"] and
                checks.get("status_code_match", True) and
                checks.get("content_match", True) and
                checks.get("jsonpath_match", True)
            )

        except requests.exceptions.SSLError as e:
            result["error"] = f"SSL Error: {str(e)}"
            result["checks"]["ssl_valid"] = False
        except requests.exceptions.Timeout:
            result["error"] = f"Timeout after {self.timeout} seconds"
        except requests.exceptions.ConnectionError as e:
            result["error"] = f"Connection Error: {str(e)}"
        except Exception as e:
            result["error"] = f"Unexpected Error: {str(e)}"

        return result

    def check_multiple(self, endpoints: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Check multiple endpoints

        Args:
            endpoints: List of endpoint configurations

        Returns:
            List of health check results
        """
        results = []
        for endpoint in endpoints:
            result = self.check_endpoint(
                url=endpoint["url"],
                method=endpoint.get("method", "GET"),
                headers=endpoint.get("headers"),
                data=endpoint.get("data"),
                expected_status=endpoint.get("expected_status"),
                expected_content=endpoint.get("expected_content"),
                jsonpath=endpoint.get("jsonpath")
            )
            result["name"] = endpoint.get("name", endpoint["url"])
            results.append(result)
        return results

    def _jsonpath_extract(self, data: Any, path: str) -> Any:
        """
        Extract value using JSONPath expression (simplified)

        Args:
            data: JSON data
            path: JSONPath expression (e.g., $.status or $.data.id)

        Returns:
            Extracted value or None
        """
        if not path.startswith("$."):
            return None

        keys = path[2:].split(".")
        current = data

        for key in keys:
            if isinstance(current, dict):
                current = current.get(key)
            elif isinstance(current, list) and key.isdigit():
                idx = int(key)
                current = current[idx] if idx < len(current) else None
            else:
                return None

            if current is None:
                return None

        return current

    def generate_report(self, results: List[Dict[str, Any]], format: str = "text") -> str:
        """
        Generate health check report

        Args:
            results: List of check results
            format: Output format (text, json, html)

        Returns:
            Formatted report
        """
        if format == "json":
            return json.dumps(results, indent=2)

        elif format == "html":
            return self._generate_html_report(results)

        else:  # text
            return self._generate_text_report(results)

    def _generate_text_report(self, results: List[Dict[str, Any]]) -> str:
        """Generate text report"""
        lines = []
        lines.append("\n" + "=" * 80)
        lines.append("API HEALTH CHECK REPORT")
        lines.append("=" * 80)
        lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"Total Endpoints: {len(results)}")

        success_count = sum(1 for r in results if r["success"])
        lines.append(f"Successful: {success_count}")
        lines.append(f"Failed: {len(results) - success_count}")
        lines.append("=" * 80)

        for idx, result in enumerate(results, 1):
            lines.append(f"\n{idx}. {result.get('name', result['url'])}")
            lines.append("-" * 80)
            lines.append(f"   URL: {result['url']}")
            lines.append(f"   Method: {result['method']}")
            lines.append(f"   Status: {'[OK] PASS' if result['success'] else '[ERROR] FAIL'}")

            if result["status_code"]:
                lines.append(f"   Status Code: {result['status_code']}")
            if result["response_time"]:
                lines.append(f"   Response Time: {result['response_time']}s")
            if result["content_length"]:
                lines.append(f"   Content Length: {result['content_length']} bytes")

            # Checks
            lines.append("   Checks:")
            for check_name, check_result in result["checks"].items():
                if check_result is not None:
                    status = "[OK]" if check_result else "[ERROR]"
                    lines.append(f"     {status} {check_name.replace('_', ' ').title()}")

            if result.get("error"):
                lines.append(f"   Error: {result['error']}")

            if result.get("jsonpath_value"):
                lines.append(f"   JSONPath Value: {result['jsonpath_value']}")

        lines.append("\n" + "=" * 80)
        lines.append(f"Overall Status: {'[OK] ALL PASS' if success_count == len(results) else f'[ERROR] {len(results) - success_count} FAILED'}")
        lines.append("=" * 80 + "\n")

        return "\n".join(lines)

    def _generate_html_report(self, results: List[Dict[str, Any]]) -> str:
        """Generate HTML report"""
        success_count = sum(1 for r in results if r["success"])

        html = f"""
<!DOCTYPE html>
<html>
<head>
    <title>API Health Check Report</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }}
        .container {{ max-width: 1200px; margin: 0 auto; background: white; padding: 20px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }}
        h1 {{ color: #333; border-bottom: 3px solid #4CAF50; padding-bottom: 10px; }}
        .summary {{ background: #e8f5e9; padding: 15px; border-radius: 5px; margin: 20px 0; }}
        .summary-stats {{ display: flex; gap: 20px; }}
        .stat {{ flex: 1; text-align: center; }}
        .stat-value {{ font-size: 2em; font-weight: bold; }}
        .stat-label {{ color: #666; }}
        .endpoint {{ background: #fafafa; margin: 20px 0; padding: 15px; border-left: 4px solid #ccc; }}
        .endpoint.success {{ border-left-color: #4CAF50; }}
        .endpoint.failure {{ border-left-color: #f44336; }}
        .endpoint-header {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }}
        .endpoint-title {{ font-size: 1.2em; font-weight: bold; }}
        .status {{ padding: 5px 10px; border-radius: 3px; font-weight: bold; }}
        .status.success {{ background: #4CAF50; color: white; }}
        .status.failure {{ background: #f44336; color: white; }}
        .metrics {{ display: flex; gap: 20px; margin: 10px 0; }}
        .metric {{ padding: 5px 10px; background: #e0e0e0; border-radius: 3px; }}
        .checks {{ margin: 10px 0; }}
        .check {{ padding: 5px; margin: 3px 0; }}
        .check.pass {{ color: #4CAF50; }}
        .check.fail {{ color: #f44336; }}
        .error {{ background: #ffebee; color: #c62828; padding: 10px; border-radius: 3px; margin: 10px 0; }}
        .timestamp {{ color: #666; font-size: 0.9em; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>API Health Check Report</h1>
        <div class="timestamp">Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>

        <div class="summary">
            <div class="summary-stats">
                <div class="stat">
                    <div class="stat-value">{len(results)}</div>
                    <div class="stat-label">Total Endpoints</div>
                </div>
                <div class="stat">
                    <div class="stat-value" style="color: #4CAF50;">{success_count}</div>
                    <div class="stat-label">Successful</div>
                </div>
                <div class="stat">
                    <div class="stat-value" style="color: #f44336;">{len(results) - success_count}</div>
                    <div class="stat-label">Failed</div>
                </div>
            </div>
        </div>
"""

        for result in results:
            success_class = "success" if result["success"] else "failure"
            status_text = "[OK] PASS" if result["success"] else "[ERROR] FAIL"

            html += f"""
        <div class="endpoint {success_class}">
            <div class="endpoint-header">
                <div class="endpoint-title">{result.get('name', result['url'])}</div>
                <div class="status {success_class}">{status_text}</div>
            </div>
            <div style="color: #666; margin-bottom: 10px;">{result['method']} {result['url']}</div>
"""

            if result["status_code"] or result["response_time"]:
                html += '            <div class="metrics">\n'
                if result["status_code"]:
                    html += f'                <div class="metric">Status: {result["status_code"]}</div>\n'
                if result["response_time"]:
                    html += f'                <div class="metric">Time: {result["response_time"]}s</div>\n'
                if result["content_length"]:
                    html += f'                <div class="metric">Size: {result["content_length"]} bytes</div>\n'
                html += '            </div>\n'

            html += '            <div class="checks">\n'
            for check_name, check_result in result["checks"].items():
                if check_result is not None:
                    check_class = "pass" if check_result else "fail"
                    icon = "[OK]" if check_result else "[ERROR]"
                    html += f'                <div class="check {check_class}">{icon} {check_name.replace("_", " ").title()}</div>\n'
            html += '            </div>\n'

            if result.get("error"):
                html += f'            <div class="error">{result["error"]}</div>\n'

            html += '        </div>\n'

        html += """
    </div>
</body>
</html>
"""
        return html


def load_config(config_file: str) -> List[Dict[str, Any]]:
    """Load endpoint configuration from file"""
    with open(config_file, 'r') as f:
        if config_file.endswith('.yaml') or config_file.endswith('.yml'):
            data = yaml.safe_load(f)
        else:
            data = json.load(f)

    # Handle both list and dict formats
    if isinstance(data, dict) and "endpoints" in data:
        return data["endpoints"]
    elif isinstance(data, list):
        return data
    else:
        return [data]


def main():
    parser = argparse.ArgumentParser(
        description="Check API endpoint health",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Single endpoint:
    %(prog)s --url "https://api.example.com/health"

  With authentication:
    %(prog)s --url "https://api.example.com/user" --header "Authorization: Bearer token"

  Multiple endpoints from config:
    %(prog)s --config endpoints.yaml

  Generate HTML report:
    %(prog)s --config endpoints.yaml --report report.html --format html

  JSON output:
    %(prog)s --url "https://api.example.com/health" --format json
        """
    )

    parser.add_argument('--url', help='API endpoint URL')
    parser.add_argument('--method', default='GET', help='HTTP method')
    parser.add_argument('--header', action='append', help='HTTP header (Name: Value)')
    parser.add_argument('--data', help='Request body data')
    parser.add_argument('--expected-status', type=int, help='Expected status code')
    parser.add_argument('--expected-content', help='Expected content in response')
    parser.add_argument('--jsonpath', help='JSONPath expression to validate')
    parser.add_argument('--config', help='Configuration file with multiple endpoints')
    parser.add_argument('--timeout', type=int, default=10, help='Request timeout in seconds')
    parser.add_argument('--retries', type=int, default=3, help='Number of retry attempts')
    parser.add_argument('--format', choices=['text', 'json', 'html'], default='text', help='Output format')
    parser.add_argument('--report', help='Save report to file')

    args = parser.parse_args()

    # Parse headers
    headers = {}
    if args.header:
        for header in args.header:
            parts = header.split(':', 1)
            if len(parts) == 2:
                headers[parts[0].strip()] = parts[1].strip()

    # Initialize checker
    checker = APIHealthChecker(timeout=args.timeout, retries=args.retries)

    # Run checks
    if args.config:
        endpoints = load_config(args.config)
        results = checker.check_multiple(endpoints)
    elif args.url:
        result = checker.check_endpoint(
            url=args.url,
            method=args.method,
            headers=headers or None,
            data=args.data,
            expected_status=args.expected_status,
            expected_content=args.expected_content,
            jsonpath=args.jsonpath
        )
        results = [result]
    else:
        parser.print_help()
        sys.exit(1)

    # Generate report
    report = checker.generate_report(results, format=args.format)

    # Output report
    if args.report:
        with open(args.report, 'w') as f:
            f.write(report)
        print(f"Report saved to: {args.report}")
    else:
        print(report)

    # Exit with appropriate code
    success_count = sum(1 for r in results if r["success"])
    sys.exit(0 if success_count == len(results) else 1)


if __name__ == '__main__':
    main()
