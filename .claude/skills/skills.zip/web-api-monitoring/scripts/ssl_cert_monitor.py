#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
SSL Certificate Monitor Setup

Sets up SSL certificate expiration monitoring in Zabbix with automatic triggers.

Usage:
    python ssl_cert_monitor.py --url "https://example.com" --host-id 10001
    python ssl_cert_monitor.py --url "https://example.com" --warning 30 --critical 7
    python ssl_cert_monitor.py --config domains.yaml --host-id 10001

Requirements:
    pip install pyzabbix ssl
"""

import sys
import json
import yaml
import argparse
import ssl
import socket
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from pyzabbix import ZabbixAPI, ZabbixAPIException
from urllib.parse import urlparse

# Zabbix connection settings
ZABBIX_URL = "http://localhost/zabbix"
ZABBIX_USER = "Admin"
ZABBIX_PASSWORD = "zabbix"


class SSLCertMonitor:
    """Setup SSL certificate monitoring in Zabbix"""

    def __init__(self, url: str, user: str, password: str):
        """Initialize Zabbix API connection"""
        self.zapi = ZabbixAPI(url)
        try:
            self.zapi.login(user, password)
            print(f"Connected to Zabbix API version {self.zapi.api_version()}")
        except ZabbixAPIException as e:
            print(f"Failed to connect to Zabbix: {e}", file=sys.stderr)
            sys.exit(1)

    def setup_cert_monitoring(self, host_id: str, domain: str,
                              port: int = 443,
                              warning_days: int = 30,
                              critical_days: int = 7) -> Dict[str, Any]:
        """
        Setup SSL certificate monitoring for a domain

        Args:
            host_id: Zabbix host ID
            domain: Domain to monitor
            port: SSL port (default 443)
            warning_days: Warning threshold in days
            critical_days: Critical threshold in days

        Returns:
            Setup results with item and trigger IDs
        """
        results = {
            "domain": domain,
            "port": port,
            "items": [],
            "triggers": []
        }

        # Create certificate validity item
        validity_item = self._create_cert_validity_item(host_id, domain, port)
        results["items"].append(validity_item)

        # Create certificate expiration date item
        expiry_item = self._create_cert_expiry_item(host_id, domain, port)
        results["items"].append(expiry_item)

        # Create certificate subject item
        subject_item = self._create_cert_subject_item(host_id, domain, port)
        results["items"].append(subject_item)

        # Create triggers
        warning_trigger = self._create_expiry_trigger(
            host_id, validity_item["itemid"], domain,
            warning_days, severity=2  # Warning
        )
        results["triggers"].append(warning_trigger)

        critical_trigger = self._create_expiry_trigger(
            host_id, validity_item["itemid"], domain,
            critical_days, severity=4  # High
        )
        results["triggers"].append(critical_trigger)

        print(f"[OK] SSL certificate monitoring setup complete for {domain}")
        return results

    def _create_cert_validity_item(self, host_id: str, domain: str, port: int) -> Dict[str, Any]:
        """Create item to check certificate validity (days until expiration)"""
        params = {
            "hostid": host_id,
            "name": f"SSL Certificate Validity - {domain}",
            "key_": f"ssl.cert.validity[{domain},{port}]",
            "type": 3,  # Simple check
            "value_type": 3,  # Numeric unsigned
            "delay": "1h",
            "units": "days",
            "description": f"Days until SSL certificate expires for {domain}:{port}",
            "tags": [
                {"tag": "SSL", "value": "certificate"},
                {"tag": "Domain", "value": domain}
            ]
        }

        try:
            result = self.zapi.item.create(params)
            item_id = result["itemids"][0]
            print(f"[OK] Certificate validity item created (ID: {item_id})")
            return self.zapi.item.get({"itemids": item_id, "output": "extend"})[0]
        except ZabbixAPIException as e:
            print(f"[ERROR] Failed to create validity item: {e}", file=sys.stderr)
            sys.exit(1)

    def _create_cert_expiry_item(self, host_id: str, domain: str, port: int) -> Dict[str, Any]:
        """Create item to store certificate expiration date"""
        params = {
            "hostid": host_id,
            "name": f"SSL Certificate Expiry Date - {domain}",
            "key_": f"ssl.cert.expiry[{domain},{port}]",
            "type": 3,  # Simple check
            "value_type": 1,  # Character
            "delay": "1d",
            "description": f"SSL certificate expiration date for {domain}:{port}",
            "tags": [
                {"tag": "SSL", "value": "certificate"},
                {"tag": "Domain", "value": domain}
            ]
        }

        try:
            result = self.zapi.item.create(params)
            item_id = result["itemids"][0]
            print(f"[OK] Certificate expiry date item created (ID: {item_id})")
            return self.zapi.item.get({"itemids": item_id, "output": "extend"})[0]
        except ZabbixAPIException as e:
            print(f"[WARN] Failed to create expiry date item: {e}", file=sys.stderr)
            return {}

    def _create_cert_subject_item(self, host_id: str, domain: str, port: int) -> Dict[str, Any]:
        """Create item to store certificate subject/issuer info"""
        params = {
            "hostid": host_id,
            "name": f"SSL Certificate Subject - {domain}",
            "key_": f"ssl.cert.subject[{domain},{port}]",
            "type": 3,  # Simple check
            "value_type": 1,  # Character
            "delay": "1d",
            "description": f"SSL certificate subject information for {domain}:{port}",
            "tags": [
                {"tag": "SSL", "value": "certificate"},
                {"tag": "Domain", "value": domain}
            ]
        }

        try:
            result = self.zapi.item.create(params)
            item_id = result["itemids"][0]
            print(f"[OK] Certificate subject item created (ID: {item_id})")
            return self.zapi.item.get({"itemids": item_id, "output": "extend"})[0]
        except ZabbixAPIException as e:
            print(f"[WARN] Failed to create subject item: {e}", file=sys.stderr)
            return {}

    def _create_expiry_trigger(self, host_id: str, item_id: str, domain: str,
                               days: int, severity: int) -> Dict[str, Any]:
        """Create trigger for certificate expiration"""
        severity_names = {1: "Information", 2: "Warning", 3: "Average", 4: "High", 5: "Disaster"}
        severity_name = severity_names.get(severity, "Warning")

        # Get host name for trigger expression
        host = self.zapi.host.get({"hostids": host_id, "output": ["host"]})[0]
        host_name = host["host"]

        # Get item key
        item = self.zapi.item.get({"itemids": item_id, "output": ["key_"]})[0]
        item_key = item["key_"]

        params = {
            "description": f"SSL certificate for {domain} expires in less than {days} days",
            "expression": f"last(/{host_name}/{item_key})<{days}",
            "priority": severity,
            "manual_close": 1,
            "comments": f"SSL certificate for {domain} is expiring soon. Please renew the certificate.",
            "tags": [
                {"tag": "SSL", "value": "expiration"},
                {"tag": "Domain", "value": domain}
            ]
        }

        try:
            result = self.zapi.trigger.create(params)
            trigger_id = result["triggerids"][0]
            print(f"[OK] {severity_name} trigger created for {days} days (ID: {trigger_id})")
            return self.zapi.trigger.get({"triggerids": trigger_id, "output": "extend"})[0]
        except ZabbixAPIException as e:
            print(f"[ERROR] Failed to create trigger: {e}", file=sys.stderr)
            return {}

    def check_certificate(self, domain: str, port: int = 443) -> Dict[str, Any]:
        """
        Check SSL certificate details

        Args:
            domain: Domain to check
            port: SSL port

        Returns:
            Certificate details
        """
        try:
            context = ssl.create_default_context()
            with socket.create_connection((domain, port), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname=domain) as ssock:
                    cert = ssock.getpeercert()

            # Parse expiration date
            not_after = cert.get('notAfter')
            expiry_date = datetime.strptime(not_after, '%b %d %H:%M:%S %Y %Z')
            days_until_expiry = (expiry_date - datetime.now()).days

            # Get subject and issuer
            subject = dict(x[0] for x in cert.get('subject', []))
            issuer = dict(x[0] for x in cert.get('issuer', []))

            return {
                "success": True,
                "domain": domain,
                "port": port,
                "valid": days_until_expiry > 0,
                "days_until_expiry": days_until_expiry,
                "expiry_date": expiry_date.isoformat(),
                "subject": subject,
                "issuer": issuer,
                "serial_number": cert.get('serialNumber'),
                "version": cert.get('version')
            }

        except Exception as e:
            return {
                "success": False,
                "domain": domain,
                "port": port,
                "error": str(e)
            }

    def list_cert_items(self, host_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all SSL certificate monitoring items"""
        params = {
            "output": "extend",
            "search": {"key_": "ssl.cert"},
            "selectTags": "extend"
        }

        if host_id:
            params["hostids"] = host_id

        try:
            items = self.zapi.item.get(params)
            return items
        except ZabbixAPIException as e:
            print(f"[ERROR] Failed to list items: {e}", file=sys.stderr)
            return []


def load_config(config_file: str) -> List[Dict[str, Any]]:
    """Load domain configuration from file"""
    with open(config_file, 'r') as f:
        if config_file.endswith('.yaml') or config_file.endswith('.yml'):
            data = yaml.safe_load(f)
        else:
            data = json.load(f)

    # Handle both list and dict formats
    if isinstance(data, dict) and "domains" in data:
        return data["domains"]
    elif isinstance(data, list):
        return data
    else:
        return [data]


def main():
    parser = argparse.ArgumentParser(
        description="Setup SSL certificate monitoring in Zabbix",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Single domain:
    %(prog)s --url "https://example.com" --host-id 10001

  Custom thresholds:
    %(prog)s --url "https://example.com" --host-id 10001 --warning 30 --critical 7

  Multiple domains from config:
    %(prog)s --config domains.yaml --host-id 10001

  Check certificate (no Zabbix setup):
    %(prog)s check --url "https://example.com"

  List existing monitors:
    %(prog)s list --host-id 10001
        """
    )

    parser.add_argument('--zabbix-url', default=ZABBIX_URL, help='Zabbix URL')
    parser.add_argument('--user', default=ZABBIX_USER, help='Zabbix username')
    parser.add_argument('--password', default=ZABBIX_PASSWORD, help='Zabbix password')

    subparsers = parser.add_subparsers(dest='command', help='Command to execute')

    # Setup command
    setup_parser = subparsers.add_parser('setup', help='Setup certificate monitoring')
    setup_parser.add_argument('--host-id', required=True, help='Host ID')
    setup_parser.add_argument('--url', help='URL to monitor (e.g., https://example.com)')
    setup_parser.add_argument('--domain', help='Domain to monitor')
    setup_parser.add_argument('--port', type=int, default=443, help='SSL port')
    setup_parser.add_argument('--warning', dest='warning_days', type=int, default=30, help='Warning threshold (days)')
    setup_parser.add_argument('--critical', dest='critical_days', type=int, default=7, help='Critical threshold (days)')
    setup_parser.add_argument('--config', help='Configuration file with multiple domains')

    # Check command
    check_parser = subparsers.add_parser('check', help='Check certificate (no setup)')
    check_parser.add_argument('--url', help='URL to check')
    check_parser.add_argument('--domain', help='Domain to check')
    check_parser.add_argument('--port', type=int, default=443, help='SSL port')

    # List command
    list_parser = subparsers.add_parser('list', help='List certificate monitors')
    list_parser.add_argument('--host-id', help='Filter by host ID')
    list_parser.add_argument('--json', action='store_true', help='Output as JSON')

    args = parser.parse_args()

    if not args.command:
        args.command = 'setup'

    # Extract domain from URL if provided
    def extract_domain(url_or_domain: str) -> str:
        if url_or_domain.startswith('http://') or url_or_domain.startswith('https://'):
            parsed = urlparse(url_or_domain)
            return parsed.netloc
        return url_or_domain

    # Handle check command separately (no Zabbix connection needed)
    if args.command == 'check':
        domain = extract_domain(args.url or args.domain)
        monitor = SSLCertMonitor(args.zabbix_url, args.user, args.password)
        result = monitor.check_certificate(domain, args.port)

        print(json.dumps(result, indent=2))

        if result["success"]:
            print(f"\n{'[OK]' if result['valid'] else '[ERROR]'} Certificate {'valid' if result['valid'] else 'expired'}")
            print(f"Days until expiry: {result['days_until_expiry']}")
            print(f"Expiry date: {result['expiry_date']}")
        else:
            print(f"\n[ERROR] Failed to check certificate: {result['error']}")
            sys.exit(1)

        sys.exit(0)

    # Initialize monitor
    monitor = SSLCertMonitor(args.zabbix_url, args.user, args.password)

    # Execute command
    if args.command == 'setup':
        if args.config:
            domains = load_config(args.config)
            results = []
            for domain_config in domains:
                domain = extract_domain(domain_config.get("url") or domain_config.get("domain"))
                port = domain_config.get("port", 443)
                warning = domain_config.get("warning_days", 30)
                critical = domain_config.get("critical_days", 7)

                result = monitor.setup_cert_monitoring(
                    args.host_id, domain, port, warning, critical
                )
                results.append(result)

            print(f"\n[OK] Setup complete for {len(results)} domain(s)")
            print(json.dumps(results, indent=2))

        elif args.url or args.domain:
            domain = extract_domain(args.url or args.domain)
            result = monitor.setup_cert_monitoring(
                args.host_id, domain, args.port,
                args.warning_days, args.critical_days
            )
            print(json.dumps(result, indent=2))

        else:
            print("Error: Either --url/--domain or --config is required", file=sys.stderr)
            sys.exit(1)

    elif args.command == 'list':
        items = monitor.list_cert_items(args.host_id)
        if args.json:
            print(json.dumps(items, indent=2))
        else:
            print(f"\nFound {len(items)} SSL certificate monitoring item(s):\n")
            for item in items:
                print(f"ID: {item['itemid']}")
                print(f"Name: {item['name']}")
                print(f"Key: {item['key_']}")
                print(f"Interval: {item['delay']}")
                print("-" * 50)


if __name__ == '__main__':
    main()
