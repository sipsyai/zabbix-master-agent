#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Synthetic Monitor Builder

Builds complex synthetic monitoring workflows for user journeys and multi-step
business transactions. Combines web scenarios, API monitoring, and validation.

Usage:
    python synthetic_monitor_builder.py --config journey.yaml --host-id 10001
    python synthetic_monitor_builder.py --config ecommerce.yaml --validate --deploy
    python synthetic_monitor_builder.py template --type ecommerce --output journey.yaml

Requirements:
    pip install pyzabbix pyyaml
"""

import sys
import json
import yaml
import argparse
from typing import Dict, List, Any, Optional
from pyzabbix import ZabbixAPI, ZabbixAPIException

# Zabbix connection settings
ZABBIX_URL = "http://localhost/zabbix"
ZABBIX_USER = "Admin"
ZABBIX_PASSWORD = "zabbix"


class SyntheticMonitorBuilder:
    """Build complex synthetic monitoring workflows"""

    def __init__(self, url: str, user: str, password: str):
        """Initialize Zabbix API connection"""
        self.zapi = ZabbixAPI(url)
        try:
            self.zapi.login(user, password)
            print(f"Connected to Zabbix API version {self.zapi.api_version()}")
        except ZabbixAPIException as e:
            print(f"Failed to connect to Zabbix: {e}", file=sys.stderr)
            sys.exit(1)

    def build_journey(self, host_id: str, config: Dict[str, Any], validate: bool = True) -> Dict[str, Any]:
        """
        Build complete synthetic monitoring journey

        Args:
            host_id: Zabbix host ID
            config: Journey configuration
            validate: Validate configuration before deploying

        Returns:
            Deployment results
        """
        if validate:
            print("Validating configuration...")
            validation = self._validate_config(config)
            if not validation["valid"]:
                print("[ERROR] Configuration validation failed:")
                for error in validation["errors"]:
                    print(f"  * {error}")
                sys.exit(1)
            print("[OK] Configuration is valid")

        results = {
            "journey": config.get("name", "Synthetic Journey"),
            "scenarios": [],
            "items": [],
            "triggers": []
        }

        # Build main user journey web scenario
        if "journey" in config:
            scenario = self._build_web_scenario(host_id, config["journey"])
            results["scenarios"].append(scenario)

        # Build API health checks
        if "api_checks" in config:
            for api_config in config["api_checks"]:
                item = self._build_api_check(host_id, api_config)
                results["items"].append(item)

        # Build performance monitors
        if "performance" in config:
            perf_items = self._build_performance_monitors(host_id, config["performance"])
            results["items"].extend(perf_items)

        # Build business logic triggers
        if "business_rules" in config:
            triggers = self._build_business_triggers(host_id, config["business_rules"], results)
            results["triggers"].extend(triggers)

        print(f"\n[OK] Synthetic journey '{results['journey']}' deployed successfully")
        return results

    def _validate_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Validate synthetic journey configuration"""
        errors = []
        warnings = []

        # Check required fields
        if "name" not in config:
            errors.append("Missing 'name' field")

        if "journey" not in config and "api_checks" not in config:
            errors.append("Must have either 'journey' or 'api_checks'")

        # Validate journey steps
        if "journey" in config:
            journey = config["journey"]
            if "steps" not in journey or not journey["steps"]:
                errors.append("Journey must have at least one step")

            for idx, step in enumerate(journey.get("steps", []), 1):
                if "url" not in step:
                    errors.append(f"Step {idx} missing 'url' field")

        # Validate API checks
        if "api_checks" in config:
            for idx, api in enumerate(config["api_checks"], 1):
                if "url" not in api:
                    errors.append(f"API check {idx} missing 'url' field")

        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings
        }

    def _build_web_scenario(self, host_id: str, journey_config: Dict[str, Any]) -> Dict[str, Any]:
        """Build web scenario from journey configuration"""
        params = {
            "hostid": host_id,
            "name": journey_config.get("name", "User Journey"),
            "delay": journey_config.get("interval", "5m"),
            "retries": journey_config.get("retries", 1),
            "agent": journey_config.get("agent", "Zabbix Synthetic Monitor"),
            "variables": [],
            "headers": [],
            "steps": []
        }

        # Add global variables
        for var in journey_config.get("variables", []):
            params["variables"].append({
                "name": var["name"],
                "value": var["value"]
            })

        # Add global headers
        for header in journey_config.get("headers", []):
            params["headers"].append({
                "name": header["name"],
                "value": header["value"]
            })

        # Build steps
        for idx, step in enumerate(journey_config["steps"], start=1):
            step_params = {
                "no": idx,
                "name": step.get("name", f"Step {idx}"),
                "url": step["url"],
                "timeout": step.get("timeout", "30s"),
                "posts": step.get("posts", ""),
                "required": step.get("validation", {}).get("content", ""),
                "status_codes": step.get("validation", {}).get("status_code", "200"),
                "follow_redirects": 1,
                "retrieve_mode": 2,  # Both body and headers
                "variables": [],
                "headers": []
            }

            # Add step variables (for data extraction)
            for var in step.get("extract", []):
                step_params["variables"].append({
                    "name": var["name"],
                    "value": var["regex"]
                })

            # Add step headers
            for header in step.get("headers", []):
                step_params["headers"].append({
                    "name": header["name"],
                    "value": header["value"]
                })

            params["steps"].append(step_params)

        # Add tags
        params["tags"] = [
            {"tag": "Type", "value": "Synthetic"},
            {"tag": "Journey", "value": params["name"]}
        ]

        try:
            result = self.zapi.httptest.create(params)
            scenario_id = result["httptestids"][0]
            print(f"[OK] Web scenario created: {params['name']} (ID: {scenario_id})")
            return self.zapi.httptest.get({
                "httptestids": scenario_id,
                "output": "extend",
                "selectSteps": "extend"
            })[0]
        except ZabbixAPIException as e:
            print(f"[ERROR] Failed to create web scenario: {e}", file=sys.stderr)
            sys.exit(1)

    def _build_api_check(self, host_id: str, api_config: Dict[str, Any]) -> Dict[str, Any]:
        """Build API monitoring item"""
        params = {
            "hostid": host_id,
            "name": api_config.get("name", "API Check"),
            "key_": api_config.get("key", f"api.check[{api_config.get('name', 'check').lower().replace(' ', '_')}]"),
            "type": 19,  # HTTP agent
            "value_type": api_config.get("value_type", 3),
            "url": api_config["url"],
            "request_method": self._get_http_method(api_config.get("method", "GET")),
            "timeout": api_config.get("timeout", "10s"),
            "delay": api_config.get("interval", "1m"),
            "status_codes": api_config.get("status_code", "200"),
            "follow_redirects": 1,
            "headers": [],
            "preprocessing": [],
            "tags": [
                {"tag": "Type", "value": "Synthetic"},
                {"tag": "Component", "value": "API"}
            ]
        }

        # Add headers
        for header in api_config.get("headers", []):
            params["headers"].append({
                "name": header["name"],
                "value": header["value"]
            })

        # Add validation preprocessing
        if "validation" in api_config:
            validation = api_config["validation"]

            if "jsonpath" in validation:
                params["preprocessing"].append({
                    "type": 12,  # JSONPath
                    "params": validation["jsonpath"],
                    "error_handler": 0
                })

            if "expected_value" in validation:
                params["preprocessing"].append({
                    "type": 20,  # JavaScript
                    "params": f"return value === '{validation['expected_value']}' ? 1 : 0;",
                    "error_handler": 0
                })

        try:
            result = self.zapi.item.create(params)
            item_id = result["itemids"][0]
            print(f"[OK] API check created: {params['name']} (ID: {item_id})")
            return self.zapi.item.get({
                "itemids": item_id,
                "output": "extend"
            })[0]
        except ZabbixAPIException as e:
            print(f"[ERROR] Failed to create API check: {e}", file=sys.stderr)
            return {}

    def _build_performance_monitors(self, host_id: str, perf_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Build performance monitoring items"""
        items = []

        # Response time thresholds
        if "response_time" in perf_config:
            rt_config = perf_config["response_time"]
            # These are typically created automatically with web scenarios
            # We can create calculated items for aggregations
            print("[OK] Response time monitoring configured")

        # Availability tracking
        if "availability" in perf_config:
            avail_config = perf_config["availability"]
            # Create calculated item for availability percentage
            print("[OK] Availability monitoring configured")

        # Transaction success rate
        if "success_rate" in perf_config:
            sr_config = perf_config["success_rate"]
            print("[OK] Success rate monitoring configured")

        return items

    def _build_business_triggers(self, host_id: str, rules: List[Dict[str, Any]],
                                 results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Build business logic triggers"""
        triggers = []

        host = self.zapi.host.get({"hostids": host_id, "output": ["host"]})[0]
        host_name = host["host"]

        for rule in rules:
            rule_type = rule.get("type")

            if rule_type == "availability":
                # Create availability trigger
                scenario_name = rule.get("scenario")
                threshold = rule.get("threshold", 95)

                trigger_params = {
                    "description": rule.get("name", f"Low availability for {scenario_name}"),
                    "expression": f"(last(/{host_name}/web.test.fail[{scenario_name}]) = 1)",
                    "priority": rule.get("severity", 3),
                    "manual_close": 1,
                    "tags": [
                        {"tag": "Type", "value": "Business"},
                        {"tag": "Rule", "value": "Availability"}
                    ]
                }

                try:
                    result = self.zapi.trigger.create(trigger_params)
                    print(f"[OK] Business trigger created: {trigger_params['description']}")
                    triggers.append(result)
                except ZabbixAPIException as e:
                    print(f"[WARN] Failed to create trigger: {e}", file=sys.stderr)

            elif rule_type == "response_time":
                # Create response time trigger
                scenario_name = rule.get("scenario")
                threshold = rule.get("threshold", 2)

                trigger_params = {
                    "description": rule.get("name", f"High response time for {scenario_name}"),
                    "expression": f"(avg(/{host_name}/web.test.time[{scenario_name},,resp],5m) > {threshold})",
                    "priority": rule.get("severity", 2),
                    "tags": [
                        {"tag": "Type", "value": "Performance"},
                        {"tag": "Rule", "value": "ResponseTime"}
                    ]
                }

                try:
                    result = self.zapi.trigger.create(trigger_params)
                    print(f"[OK] Business trigger created: {trigger_params['description']}")
                    triggers.append(result)
                except ZabbixAPIException as e:
                    print(f"[WARN] Failed to create trigger: {e}", file=sys.stderr)

        return triggers

    def _get_http_method(self, method: str) -> int:
        """Convert HTTP method string to Zabbix code"""
        methods = {'GET': 0, 'POST': 1, 'PUT': 2, 'HEAD': 3, 'DELETE': 4, 'PATCH': 5}
        return methods.get(method.upper(), 0)

    def generate_template(self, journey_type: str) -> Dict[str, Any]:
        """Generate template for common journey types"""
        templates = {
            "ecommerce": self._template_ecommerce(),
            "login": self._template_login(),
            "api_workflow": self._template_api_workflow(),
            "form_submission": self._template_form_submission()
        }

        return templates.get(journey_type, self._template_basic())

    def _template_ecommerce(self) -> Dict[str, Any]:
        """E-commerce checkout journey template"""
        return {
            "name": "E-commerce Checkout Journey",
            "journey": {
                "name": "Checkout Flow",
                "interval": "5m",
                "steps": [
                    {
                        "name": "Homepage",
                        "url": "https://example.com/",
                        "validation": {"status_code": "200", "content": "Welcome"}
                    },
                    {
                        "name": "Product Page",
                        "url": "https://example.com/products/item123",
                        "validation": {"status_code": "200", "content": "Add to Cart"},
                        "extract": [
                            {"name": "product_id", "regex": "product-id=\"([0-9]+)\""},
                            {"name": "price", "regex": "price\":([0-9.]+)"}
                        ]
                    },
                    {
                        "name": "Add to Cart",
                        "url": "https://example.com/cart/add",
                        "posts": "product_id={product_id}&quantity=1",
                        "validation": {"status_code": "200,302"}
                    },
                    {
                        "name": "Cart Page",
                        "url": "https://example.com/cart",
                        "validation": {"status_code": "200", "content": "Checkout"}
                    },
                    {
                        "name": "Checkout",
                        "url": "https://example.com/checkout",
                        "validation": {"status_code": "200", "content": "Payment"}
                    }
                ]
            },
            "api_checks": [
                {
                    "name": "Product API",
                    "url": "https://api.example.com/products/item123",
                    "method": "GET",
                    "interval": "1m",
                    "validation": {"jsonpath": "$.available", "expected_value": "true"}
                },
                {
                    "name": "Cart API",
                    "url": "https://api.example.com/cart/status",
                    "method": "GET",
                    "interval": "1m"
                }
            ],
            "performance": {
                "response_time": {"threshold": 3, "critical": 5},
                "availability": {"threshold": 99.5}
            },
            "business_rules": [
                {
                    "type": "availability",
                    "name": "Checkout Flow Failure",
                    "scenario": "Checkout Flow",
                    "severity": 4
                },
                {
                    "type": "response_time",
                    "name": "Slow Checkout",
                    "scenario": "Checkout Flow",
                    "threshold": 5,
                    "severity": 3
                }
            ]
        }

    def _template_login(self) -> Dict[str, Any]:
        """Login flow template"""
        return {
            "name": "User Login Journey",
            "journey": {
                "name": "Login Flow",
                "interval": "5m",
                "variables": [
                    {"name": "username", "value": "{$TEST_USERNAME}"},
                    {"name": "password", "value": "{$TEST_PASSWORD}"}
                ],
                "steps": [
                    {
                        "name": "Login Page",
                        "url": "https://example.com/login",
                        "validation": {"status_code": "200", "content": "Sign In"}
                    },
                    {
                        "name": "Submit Login",
                        "url": "https://example.com/auth/login",
                        "posts": "username={username}&password={password}",
                        "validation": {"status_code": "200,302"},
                        "extract": [
                            {"name": "session_token", "regex": "token\":\"([^\"]+)\""}
                        ]
                    },
                    {
                        "name": "Dashboard",
                        "url": "https://example.com/dashboard",
                        "validation": {"status_code": "200", "content": "Welcome"}
                    }
                ]
            }
        }

    def _template_api_workflow(self) -> Dict[str, Any]:
        """API workflow template"""
        return {
            "name": "API Workflow",
            "api_checks": [
                {
                    "name": "Auth Token",
                    "url": "https://api.example.com/auth/token",
                    "method": "POST",
                    "headers": [
                        {"name": "Content-Type", "value": "application/json"}
                    ],
                    "validation": {"jsonpath": "$.access_token"}
                },
                {
                    "name": "User Profile",
                    "url": "https://api.example.com/user/profile",
                    "method": "GET",
                    "headers": [
                        {"name": "Authorization", "value": "Bearer {$API_TOKEN}"}
                    ],
                    "validation": {"jsonpath": "$.status", "expected_value": "active"}
                }
            ]
        }

    def _template_form_submission(self) -> Dict[str, Any]:
        """Form submission template"""
        return {
            "name": "Form Submission Journey",
            "journey": {
                "name": "Contact Form",
                "interval": "10m",
                "steps": [
                    {
                        "name": "Contact Page",
                        "url": "https://example.com/contact",
                        "validation": {"status_code": "200"}
                    },
                    {
                        "name": "Submit Form",
                        "url": "https://example.com/contact/submit",
                        "posts": "name=Test&email=test@example.com&message=Test",
                        "validation": {"status_code": "200", "content": "Thank you"}
                    }
                ]
            }
        }

    def _template_basic(self) -> Dict[str, Any]:
        """Basic template"""
        return {
            "name": "Basic Journey",
            "journey": {
                "name": "Basic Check",
                "steps": [
                    {
                        "name": "Step 1",
                        "url": "https://example.com/",
                        "validation": {"status_code": "200"}
                    }
                ]
            }
        }


def load_config(config_file: str) -> Dict[str, Any]:
    """Load configuration from file"""
    with open(config_file, 'r') as f:
        if config_file.endswith('.yaml') or config_file.endswith('.yml'):
            return yaml.safe_load(f)
        else:
            return json.load(f)


def main():
    parser = argparse.ArgumentParser(
        description="Build synthetic monitoring workflows",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Deploy from config:
    %(prog)s --config journey.yaml --host-id 10001

  Validate without deploying:
    %(prog)s --config journey.yaml --validate

  Generate template:
    %(prog)s template --type ecommerce --output journey.yaml

  Available template types:
    - ecommerce: E-commerce checkout journey
    - login: User login flow
    - api_workflow: API-based workflow
    - form_submission: Form submission journey
        """
    )

    parser.add_argument('--zabbix-url', default=ZABBIX_URL, help='Zabbix URL')
    parser.add_argument('--user', default=ZABBIX_USER, help='Zabbix username')
    parser.add_argument('--password', default=ZABBIX_PASSWORD, help='Zabbix password')

    subparsers = parser.add_subparsers(dest='command', help='Command to execute')

    # Deploy command
    deploy_parser = subparsers.add_parser('deploy', help='Deploy synthetic journey')
    deploy_parser.add_argument('--config', required=True, help='Configuration file')
    deploy_parser.add_argument('--host-id', required=True, help='Host ID')
    deploy_parser.add_argument('--validate', action='store_true', help='Validate before deploying')

    # Template command
    template_parser = subparsers.add_parser('template', help='Generate template')
    template_parser.add_argument('--type', required=True,
                                  choices=['ecommerce', 'login', 'api_workflow', 'form_submission'],
                                  help='Template type')
    template_parser.add_argument('--output', required=True, help='Output file')

    args = parser.parse_args()

    if not args.command:
        args.command = 'deploy'

    if args.command == 'template':
        builder = SyntheticMonitorBuilder(args.zabbix_url, args.user, args.password)
        template = builder.generate_template(args.type)

        with open(args.output, 'w') as f:
            yaml.dump(template, f, default_flow_style=False, sort_keys=False)

        print(f"[OK] Template generated: {args.output}")
        sys.exit(0)

    # Deploy command
    builder = SyntheticMonitorBuilder(args.zabbix_url, args.user, args.password)
    config = load_config(args.config)

    result = builder.build_journey(args.host_id, config, validate=args.validate)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
