#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Web Scenario Configuration Validator

Validates web scenario configurations before deployment to Zabbix.
Checks for common errors, security issues, and best practices.

Usage:
    python web_scenario_validator.py config.yaml
    python web_scenario_validator.py config.json --strict
    python web_scenario_validator.py config.yaml --output report.json

Requirements:
    pip install pyyaml jsonschema validators
"""

import sys
import json
import yaml
import argparse
import re
from typing import Dict, List, Any, Tuple
from urllib.parse import urlparse

try:
    from jsonschema import validate, ValidationError
    import validators
except ImportError:
    print("Missing dependencies. Install with: pip install jsonschema validators", file=sys.stderr)
    sys.exit(1)


class WebScenarioValidator:
    """Validator for web scenario configurations"""

    # Configuration schema
    SCHEMA = {
        "type": "object",
        "required": ["name", "steps"],
        "properties": {
            "name": {"type": "string", "minLength": 1},
            "update_interval": {"type": ["string", "integer"]},
            "retries": {"type": "integer", "minimum": 0, "maximum": 10},
            "agent": {"type": "string"},
            "steps": {
                "type": "array",
                "minItems": 1,
                "items": {
                    "type": "object",
                    "required": ["url"],
                    "properties": {
                        "name": {"type": "string"},
                        "url": {"type": "string", "format": "uri"},
                        "timeout": {"type": ["string", "integer"]},
                        "status_codes": {"type": "string"},
                        "required_string": {"type": "string"},
                        "required_regex": {"type": "string"},
                        "follow_redirects": {"type": "boolean"},
                        "posts": {"type": "string"},
                        "headers": {"type": "array"},
                        "variables": {"type": "array"}
                    }
                }
            }
        }
    }

    def __init__(self, strict: bool = False):
        """
        Initialize validator

        Args:
            strict: Enable strict validation mode
        """
        self.strict = strict
        self.errors = []
        self.warnings = []
        self.info = []

    def validate(self, config: Dict[str, Any]) -> bool:
        """
        Validate web scenario configuration

        Args:
            config: Configuration dictionary

        Returns:
            True if valid, False otherwise
        """
        self.errors = []
        self.warnings = []
        self.info = []

        # Schema validation
        try:
            validate(instance=config, schema=self.SCHEMA)
            self.info.append("[OK] Configuration structure is valid")
        except ValidationError as e:
            self.errors.append(f"Schema validation failed: {e.message}")
            return False

        # Validate scenario-level settings
        self._validate_scenario_settings(config)

        # Validate each step
        for idx, step in enumerate(config.get("steps", []), start=1):
            self._validate_step(step, idx)

        # Check for security issues
        self._check_security(config)

        # Check for best practices
        self._check_best_practices(config)

        # Return validation result
        if self.errors:
            return False
        if self.strict and self.warnings:
            return False
        return True

    def _validate_scenario_settings(self, config: Dict[str, Any]):
        """Validate scenario-level settings"""
        # Check interval
        interval = config.get("update_interval", "60s")
        if isinstance(interval, str):
            if not self._is_valid_time_suffix(interval):
                self.errors.append(f"Invalid update_interval format: {interval}")
            else:
                seconds = self._parse_time_suffix(interval)
                if seconds < 30:
                    self.warnings.append(f"Update interval {interval} is very short, may cause load issues")
                elif seconds > 3600:
                    self.warnings.append(f"Update interval {interval} is very long")

        # Check retries
        retries = config.get("retries", 1)
        if retries > 5:
            self.warnings.append(f"Retry count {retries} is high, may cause delays")

        # Check agent string
        agent = config.get("agent", "")
        if agent and len(agent) > 255:
            self.errors.append("User agent string exceeds 255 characters")

    def _validate_step(self, step: Dict[str, Any], step_num: int):
        """Validate individual step configuration"""
        prefix = f"Step {step_num}"

        # Validate URL
        url = step.get("url", "")
        if not self._is_valid_url(url):
            self.errors.append(f"{prefix}: Invalid URL: {url}")
        else:
            # Check for hardcoded credentials in URL
            parsed = urlparse(url)
            if parsed.username or parsed.password:
                self.warnings.append(f"{prefix}: URL contains credentials, use variables instead")

            # Check protocol
            if parsed.scheme not in ["http", "https"]:
                self.errors.append(f"{prefix}: Invalid protocol: {parsed.scheme}")

        # Validate timeout
        timeout = step.get("timeout", "15s")
        if isinstance(timeout, str):
            if not self._is_valid_time_suffix(timeout):
                self.errors.append(f"{prefix}: Invalid timeout format: {timeout}")
            else:
                seconds = self._parse_time_suffix(timeout)
                if seconds > 300:
                    self.warnings.append(f"{prefix}: Timeout {timeout} is very long")

        # Validate status codes
        status_codes = step.get("status_codes", "200")
        if not self._validate_status_codes(status_codes):
            self.errors.append(f"{prefix}: Invalid status_codes format: {status_codes}")

        # Validate regex if present
        if "required_regex" in step:
            regex = step["required_regex"]
            if not self._is_valid_regex(regex):
                self.errors.append(f"{prefix}: Invalid regex pattern: {regex}")

        # Validate variables
        if "variables" in step:
            for var in step["variables"]:
                if "name" not in var:
                    self.errors.append(f"{prefix}: Variable missing 'name' field")
                    continue

                var_name = var["name"]
                if not self._is_valid_variable_name(var_name):
                    self.errors.append(f"{prefix}: Invalid variable name: {var_name}")

                # Check regex if present
                if "regex" in var:
                    if not self._is_valid_regex(var["regex"]):
                        self.errors.append(f"{prefix}: Invalid variable regex: {var['regex']}")

        # Validate headers
        if "headers" in step:
            for header in step["headers"]:
                if "name" not in header or "value" not in header:
                    self.errors.append(f"{prefix}: Header missing 'name' or 'value' field")
                    continue

                # Check for sensitive data in headers
                header_name = header["name"].lower()
                header_value = header["value"]

                if header_name in ["authorization", "api-key", "x-api-key"] and not self._uses_variable(header_value):
                    self.warnings.append(f"{prefix}: {header['name']} header should use variables for security")

        # Check POST data
        if "posts" in step:
            posts = step["posts"]
            # Check for sensitive data in POST body
            if any(keyword in posts.lower() for keyword in ["password", "secret", "token", "key"]):
                if not self._uses_variable(posts):
                    self.warnings.append(f"{prefix}: POST data may contain sensitive information, use variables")

    def _check_security(self, config: Dict[str, Any]):
        """Check for security issues"""
        # Check for hardcoded credentials
        config_str = json.dumps(config).lower()

        suspicious_patterns = [
            r'password["\s:]+["\'](?!\{\$)[^"\']+["\']',
            r'token["\s:]+["\'](?!\{\$)[^"\']+["\']',
            r'api[_-]?key["\s:]+["\'](?!\{\$)[^"\']+["\']',
        ]

        for pattern in suspicious_patterns:
            if re.search(pattern, config_str):
                self.warnings.append("Potential hardcoded credentials detected, use macros/variables")
                break

        # Check SSL verification
        if "ssl" in config:
            ssl_config = config["ssl"]
            if not ssl_config.get("verify_peer", True):
                self.warnings.append("SSL peer verification is disabled (security risk)")
            if not ssl_config.get("verify_host", True):
                self.warnings.append("SSL host verification is disabled (security risk)")

    def _check_best_practices(self, config: Dict[str, Any]):
        """Check for best practices"""
        # Check step count
        step_count = len(config.get("steps", []))
        if step_count > 10:
            self.info.append(f"Scenario has {step_count} steps, consider splitting into multiple scenarios")

        # Check for step names
        for idx, step in enumerate(config.get("steps", []), start=1):
            if "name" not in step or not step["name"]:
                self.warnings.append(f"Step {idx} missing descriptive name")

        # Check for required string or regex
        for idx, step in enumerate(config.get("steps", []), start=1):
            has_validation = "required_string" in step or "required_regex" in step
            if not has_validation:
                self.info.append(f"Step {idx} has no content validation (required_string/required_regex)")

        # Check variable usage
        defined_vars = set()
        for step in config.get("steps", []):
            if "variables" in step:
                for var in step["variables"]:
                    defined_vars.add(var.get("name", ""))

        # Check if defined variables are used
        config_str = json.dumps(config)
        for var_name in defined_vars:
            if var_name and config_str.count(f"{{{var_name}}}") < 2:  # Less than 2 means only definition
                self.warnings.append(f"Variable '{var_name}' is defined but not used")

    def _is_valid_url(self, url: str) -> bool:
        """Check if URL is valid"""
        if not url:
            return False
        # Allow variable substitution in URLs
        if "{" in url and "}" in url:
            url = re.sub(r'\{[^}]+\}', 'placeholder', url)
        return validators.url(url) or url.startswith("http")

    def _is_valid_time_suffix(self, time_str: str) -> bool:
        """Check if time string has valid format (e.g., '60s', '1m', '1h')"""
        return bool(re.match(r'^\d+[smhd]?$', time_str))

    def _parse_time_suffix(self, time_str: str) -> int:
        """Parse time string to seconds"""
        match = re.match(r'^(\d+)([smhd]?)$', time_str)
        if not match:
            return 0

        value = int(match.group(1))
        unit = match.group(2) or 's'

        multipliers = {'s': 1, 'm': 60, 'h': 3600, 'd': 86400}
        return value * multipliers.get(unit, 1)

    def _validate_status_codes(self, status_codes: str) -> bool:
        """Validate status codes format"""
        # Allow comma-separated codes: "200", "200,201", "200,201,204"
        codes = status_codes.split(",")
        for code in codes:
            code = code.strip()
            if not code.isdigit() or not (100 <= int(code) <= 599):
                return False
        return True

    def _is_valid_regex(self, pattern: str) -> bool:
        """Check if regex pattern is valid"""
        try:
            re.compile(pattern)
            return True
        except re.error:
            return False

    def _is_valid_variable_name(self, name: str) -> bool:
        """Check if variable name is valid"""
        # Variable names should be alphanumeric with underscores
        return bool(re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', name))

    def _uses_variable(self, value: str) -> bool:
        """Check if value uses variable/macro substitution"""
        return bool(re.search(r'\{\$?[A-Z_][A-Z0-9_]*\}', value, re.IGNORECASE))

    def get_report(self) -> Dict[str, Any]:
        """Get validation report"""
        return {
            "valid": len(self.errors) == 0 and (not self.strict or len(self.warnings) == 0),
            "errors": self.errors,
            "warnings": self.warnings,
            "info": self.info
        }

    def print_report(self):
        """Print validation report"""
        print("\n" + "=" * 70)
        print("WEB SCENARIO VALIDATION REPORT")
        print("=" * 70)

        if self.errors:
            print("\n[ERROR] ERRORS:")
            for error in self.errors:
                print(f"  * {error}")

        if self.warnings:
            print("\n[WARN]️  WARNINGS:")
            for warning in self.warnings:
                print(f"  * {warning}")

        if self.info:
            print("\nℹ️  INFORMATION:")
            for info in self.info:
                print(f"  * {info}")

        print("\n" + "=" * 70)
        if not self.errors:
            if not self.warnings:
                print("[OK] Configuration is valid with no issues")
            else:
                print(f"[OK] Configuration is valid with {len(self.warnings)} warning(s)")
        else:
            print(f"[ERROR] Configuration has {len(self.errors)} error(s)")
        print("=" * 70 + "\n")


def load_config(config_file: str) -> Dict[str, Any]:
    """Load configuration from file"""
    try:
        with open(config_file, 'r') as f:
            if config_file.endswith('.yaml') or config_file.endswith('.yml'):
                return yaml.safe_load(f)
            else:
                return json.load(f)
    except Exception as e:
        print(f"Error loading configuration: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(
        description="Validate web scenario configuration",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Basic validation:
    %(prog)s config.yaml

  Strict validation (warnings treated as errors):
    %(prog)s config.yaml --strict

  Save report to file:
    %(prog)s config.yaml --output report.json

  Validate multiple files:
    %(prog)s config1.yaml config2.yaml config3.yaml
        """
    )

    parser.add_argument('config_files', nargs='+', help='Configuration file(s) to validate')
    parser.add_argument('--strict', action='store_true', help='Treat warnings as errors')
    parser.add_argument('--output', help='Output report to file (JSON format)')
    parser.add_argument('--quiet', action='store_true', help='Suppress output, only return exit code')

    args = parser.parse_args()

    all_valid = True
    all_reports = {}

    for config_file in args.config_files:
        if not args.quiet:
            print(f"\nValidating: {config_file}")

        config = load_config(config_file)
        validator = WebScenarioValidator(strict=args.strict)
        is_valid = validator.validate(config)

        if not args.quiet:
            validator.print_report()

        all_reports[config_file] = validator.get_report()
        all_valid = all_valid and is_valid

    # Save report if requested
    if args.output:
        with open(args.output, 'w') as f:
            json.dump(all_reports, f, indent=2)
        if not args.quiet:
            print(f"Report saved to: {args.output}")

    # Exit with appropriate code
    sys.exit(0 if all_valid else 1)


if __name__ == '__main__':
    main()
