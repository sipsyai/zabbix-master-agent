#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix API Monitor Setup

This script sets up API endpoint monitoring in Zabbix using HTTP agent items.
Supports RESTful APIs, GraphQL, JSON/XML validation, authentication, and
response time tracking.

Usage:
    python zabbix_api_monitor_setup.py --name "API Health" --url "https://api.example.com/health" --host-id 10001
    python zabbix_api_monitor_setup.py --config api_config.yaml --host-id 10001
    python zabbix_api_monitor_setup.py --name "Auth API" --url "https://api.example.com/user" --header "Authorization: Bearer token"

Requirements:
    pip install pyzabbix pyyaml
"""

import sys
import json
import yaml
import argparse
from typing import Dict, List, Any, Optional
from pyzabbix import ZabbixAPI, ZabbixAPIException

# Zabbix connection settings
ZABBIX_URL = "http://localhost/zabbix"
ZABBIX_USER = "Admin"
ZABBIX_PASSWORD = "zabbix"

# HTTP methods
HTTP_METHODS = {
    'GET': 0,
    'POST': 1,
    'PUT': 2,
    'HEAD': 3,
    'DELETE': 4,
    'PATCH': 5
}

# Preprocessing types
PREPROCESS_TYPES = {
    'regex': 5,
    'jsonpath': 12,
    'xpath': 13,
    'multiplier': 1,
    'trim': 2,
    'javascript': 20,
    'prometheus': 22,
    'csv': 23,
    'xml_xpath': 13,
    'check_error_regex': 15
}


class ZabbixAPIMonitor:
    """Setup and manage API monitoring in Zabbix"""

    def __init__(self, url: str, user: str, password: str):
        """Initialize Zabbix API connection"""
        self.zapi = ZabbixAPI(url)
        try:
            self.zapi.login(user, password)
            print(f"Connected to Zabbix API version {self.zapi.api_version()}")
        except ZabbixAPIException as e:
            print(f"Failed to connect to Zabbix: {e}", file=sys.stderr)
            sys.exit(1)

    def create_api_item(self, host_id: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create HTTP agent item for API monitoring

        Args:
            host_id: Zabbix host ID
            config: API item configuration

        Returns:
            Created item details
        """
        # Base item parameters
        item_name = config.get("name", "API Check")
        item_key = config.get("key", f"api.check[{item_name.lower().replace(' ', '_')}]")

        params = {
            "hostid": host_id,
            "name": item_name,
            "key_": item_key,
            "type": 19,  # HTTP agent
            "value_type": config.get("value_type", 3),  # 0=float, 1=char, 3=numeric unsigned, 4=text
            "url": config["url"],
            "request_method": HTTP_METHODS.get(config.get("method", "GET"), 0),
            "timeout": config.get("timeout", "10s"),
            "delay": config.get("interval", "60s"),
            "status_codes": config.get("status_codes", "200"),
            "follow_redirects": 1 if config.get("follow_redirects", True) else 0,
            "retrieve_mode": config.get("retrieve_mode", 0),  # 0=body, 1=headers, 2=both
            "output_format": config.get("output_format", 0),  # 0=raw, 1=JSON
            "verify_peer": 1 if config.get("verify_ssl", True) else 0,
            "verify_host": 1 if config.get("verify_host", True) else 0,
            "ssl_cert_file": config.get("ssl_cert_file", ""),
            "ssl_key_file": config.get("ssl_key_file", ""),
            "ssl_key_password": config.get("ssl_key_password", ""),
            "http_proxy": config.get("http_proxy", ""),
            "posts": config.get("posts", ""),
            "headers": [],
            "preprocessing": [],
            "tags": []
        }

        # Add headers
        if "headers" in config:
            for header in config["headers"]:
                if isinstance(header, dict):
                    params["headers"].append({
                        "name": header["name"],
                        "value": header["value"]
                    })
                else:
                    # Parse "Name: Value" format
                    parts = header.split(":", 1)
                    if len(parts) == 2:
                        params["headers"].append({
                            "name": parts[0].strip(),
                            "value": parts[1].strip()
                        })

        # Add authentication header
        if "auth" in config:
            auth = config["auth"]
            if auth.get("type") == "bearer":
                params["headers"].append({
                    "name": "Authorization",
                    "value": f"Bearer {auth['token']}"
                })
            elif auth.get("type") == "basic":
                import base64
                credentials = f"{auth['username']}:{auth['password']}"
                encoded = base64.b64encode(credentials.encode()).decode()
                params["headers"].append({
                    "name": "Authorization",
                    "value": f"Basic {encoded}"
                })
            elif auth.get("type") == "apikey":
                params["headers"].append({
                    "name": auth.get("header", "X-API-Key"),
                    "value": auth["key"]
                })

        # Add preprocessing steps
        if "preprocessing" in config:
            for idx, step in enumerate(config["preprocessing"], start=1):
                preprocess_step = {
                    "type": PREPROCESS_TYPES.get(step["type"], 5),
                    "params": step.get("params", ""),
                    "error_handler": step.get("error_handler", 0),
                    "error_handler_params": step.get("error_handler_params", "")
                }
                params["preprocessing"].append(preprocess_step)

        # Add JSONPath validation if specified
        if "jsonpath" in config:
            params["preprocessing"].append({
                "type": 12,  # JSONPath
                "params": config["jsonpath"],
                "error_handler": 0
            })

        # Add regex validation if specified
        if "regex" in config:
            params["preprocessing"].append({
                "type": 5,  # Regular expression
                "params": config["regex"],
                "error_handler": 0
            })

        # Add expected value check
        if "expected_value" in config:
            params["preprocessing"].append({
                "type": 20,  # JavaScript
                "params": f"return value === '{config['expected_value']}' ? 1 : 0;",
                "error_handler": 0
            })

        # Add tags
        if "tags" in config:
            for tag in config["tags"]:
                params["tags"].append({
                    "tag": tag["name"],
                    "value": tag.get("value", "")
                })
        else:
            params["tags"].append({"tag": "API", "value": "monitoring"})

        # Add description
        if "description" in config:
            params["description"] = config["description"]

        try:
            result = self.zapi.item.create(params)
            item_id = result["itemids"][0]
            print(f"[OK] API monitoring item created successfully (ID: {item_id})")

            # Create response time item
            if config.get("track_response_time", True):
                self._create_response_time_item(host_id, item_name, config["url"])

            return self.get_item(item_id)
        except ZabbixAPIException as e:
            print(f"[ERROR] Failed to create API monitoring item: {e}", file=sys.stderr)
            sys.exit(1)

    def _create_response_time_item(self, host_id: str, api_name: str, url: str):
        """Create companion item for response time tracking"""
        params = {
            "hostid": host_id,
            "name": f"{api_name} - Response Time",
            "key_": f"api.response.time[{api_name.lower().replace(' ', '_')}]",
            "type": 19,  # HTTP agent
            "value_type": 0,  # Numeric float
            "url": url,
            "request_method": 3,  # HEAD for faster checks
            "timeout": "10s",
            "delay": "60s",
            "status_codes": "200",
            "units": "s",
            "tags": [
                {"tag": "API", "value": "monitoring"},
                {"tag": "Metric", "value": "response_time"}
            ],
            "preprocessing": [
                {
                    "type": 20,  # JavaScript
                    "params": "return Date.now() / 1000;",
                    "error_handler": 0
                }
            ]
        }

        try:
            result = self.zapi.item.create(params)
            print(f"[OK] Response time item created (ID: {result['itemids'][0]})")
        except ZabbixAPIException as e:
            print(f"[WARN] Failed to create response time item: {e}", file=sys.stderr)

    def create_simple_api_check(self, host_id: str, name: str, url: str,
                                 method: str = "GET",
                                 expected_status: int = 200,
                                 headers: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Create a simple API health check

        Args:
            host_id: Zabbix host ID
            name: Monitor name
            url: API endpoint URL
            method: HTTP method
            expected_status: Expected status code
            headers: Optional HTTP headers

        Returns:
            Created item details
        """
        config = {
            "name": name,
            "url": url,
            "method": method,
            "status_codes": str(expected_status),
            "value_type": 3,  # Unsigned integer
            "interval": "60s"
        }

        if headers:
            config["headers"] = headers

        # Add preprocessing to return 1 for success, 0 for failure
        config["preprocessing"] = [
            {
                "type": "javascript",
                "params": "return 1;",  # If we got here, request succeeded
                "error_handler": 0
            }
        ]

        return self.create_api_item(host_id, config)

    def create_json_api_monitor(self, host_id: str, name: str, url: str,
                                 jsonpath: str,
                                 expected_value: Optional[str] = None,
                                 headers: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Create API monitor with JSON validation

        Args:
            host_id: Zabbix host ID
            name: Monitor name
            url: API endpoint URL
            jsonpath: JSONPath expression
            expected_value: Expected value (optional)
            headers: Optional HTTP headers

        Returns:
            Created item details
        """
        config = {
            "name": name,
            "url": url,
            "method": "GET",
            "value_type": 4,  # Text
            "jsonpath": jsonpath,
            "interval": "60s"
        }

        if headers:
            config["headers"] = headers

        if expected_value:
            config["expected_value"] = expected_value

        return self.create_api_item(host_id, config)

    def update_item(self, item_id: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update an existing API monitoring item

        Args:
            item_id: Item ID
            config: Updated configuration

        Returns:
            Updated item details
        """
        params = {"itemid": item_id}

        # Update allowed fields
        field_mapping = {
            "name": "name",
            "url": "url",
            "method": "request_method",
            "timeout": "timeout",
            "interval": "delay",
            "status_codes": "status_codes"
        }

        for config_key, api_key in field_mapping.items():
            if config_key in config:
                if config_key == "method":
                    params[api_key] = HTTP_METHODS.get(config[config_key], 0)
                else:
                    params[api_key] = config[config_key]

        # Update headers
        if "headers" in config:
            params["headers"] = []
            for header in config["headers"]:
                if isinstance(header, dict):
                    params["headers"].append({
                        "name": header["name"],
                        "value": header["value"]
                    })

        # Update preprocessing
        if "preprocessing" in config:
            params["preprocessing"] = []
            for step in config["preprocessing"]:
                params["preprocessing"].append({
                    "type": PREPROCESS_TYPES.get(step["type"], 5),
                    "params": step.get("params", ""),
                    "error_handler": step.get("error_handler", 0)
                })

        try:
            result = self.zapi.item.update(params)
            print(f"[OK] API monitoring item updated successfully (ID: {item_id})")
            return self.get_item(item_id)
        except ZabbixAPIException as e:
            print(f"[ERROR] Failed to update item: {e}", file=sys.stderr)
            sys.exit(1)

    def delete_item(self, item_id: str) -> bool:
        """Delete an API monitoring item"""
        try:
            result = self.zapi.item.delete([item_id])
            print(f"[OK] API monitoring item deleted successfully (ID: {item_id})")
            return True
        except ZabbixAPIException as e:
            print(f"[ERROR] Failed to delete item: {e}", file=sys.stderr)
            return False

    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """Get item details"""
        try:
            result = self.zapi.item.get({
                "itemids": item_id,
                "output": "extend",
                "selectPreprocessing": "extend",
                "selectTags": "extend"
            })
            if result:
                return result[0]
            return None
        except ZabbixAPIException as e:
            print(f"[ERROR] Failed to get item: {e}", file=sys.stderr)
            return None

    def list_api_items(self, host_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all API monitoring items"""
        params = {
            "output": "extend",
            "filter": {"type": 19},  # HTTP agent type
            "selectPreprocessing": "extend",
            "selectTags": "extend"
        }

        if host_id:
            params["hostids"] = host_id

        try:
            items = self.zapi.item.get(params)
            return items
        except ZabbixAPIException as e:
            print(f"[ERROR] Failed to list items: {e}", file=sys.stderr)
            return []

    def test_api_endpoint(self, url: str, method: str = "GET",
                          headers: Optional[Dict[str, str]] = None,
                          data: Optional[str] = None) -> Dict[str, Any]:
        """
        Test API endpoint before creating monitor

        Args:
            url: API endpoint URL
            method: HTTP method
            headers: Optional headers
            data: Optional request body

        Returns:
            Test results
        """
        import requests
        import time

        try:
            start_time = time.time()
            response = requests.request(
                method=method,
                url=url,
                headers=headers or {},
                data=data,
                timeout=10
            )
            elapsed = time.time() - start_time

            result = {
                "success": True,
                "status_code": response.status_code,
                "response_time": round(elapsed, 3),
                "content_length": len(response.content),
                "headers": dict(response.headers)
            }

            # Try to parse JSON
            try:
                result["json"] = response.json()
            except:
                result["text"] = response.text[:500]  # First 500 chars

            return result
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }


def load_config(config_file: str) -> Dict[str, Any]:
    """Load configuration from YAML or JSON file"""
    with open(config_file, 'r') as f:
        if config_file.endswith('.yaml') or config_file.endswith('.yml'):
            return yaml.safe_load(f)
        else:
            return json.load(f)


def main():
    parser = argparse.ArgumentParser(
        description="Setup API monitoring in Zabbix",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Simple health check:
    %(prog)s --name "API Health" --url "https://api.example.com/health" --host-id 10001

  With authentication:
    %(prog)s --name "Auth API" --url "https://api.example.com/user" --header "Authorization: Bearer token" --host-id 10001

  JSON validation:
    %(prog)s --name "Status Check" --url "https://api.example.com/status" --jsonpath "$.status" --expected-value "ok" --host-id 10001

  From config file:
    %(prog)s --config api_monitor.yaml --host-id 10001

  Test endpoint:
    %(prog)s test --url "https://api.example.com/health" --method GET
        """
    )

    parser.add_argument('--url', dest='zabbix_url', default=ZABBIX_URL, help='Zabbix URL')
    parser.add_argument('--user', default=ZABBIX_USER, help='Zabbix username')
    parser.add_argument('--password', default=ZABBIX_PASSWORD, help='Zabbix password')

    subparsers = parser.add_subparsers(dest='command', help='Command to execute')

    # Create command
    create_parser = subparsers.add_parser('create', help='Create API monitor')
    create_parser.add_argument('--host-id', required=True, help='Host ID')
    create_parser.add_argument('--config', help='Configuration file (YAML/JSON)')
    create_parser.add_argument('--name', help='Monitor name')
    create_parser.add_argument('--url', dest='api_url', help='API endpoint URL')
    create_parser.add_argument('--method', default='GET', choices=HTTP_METHODS.keys(), help='HTTP method')
    create_parser.add_argument('--expected-status', type=int, default=200, help='Expected status code')
    create_parser.add_argument('--header', action='append', help='HTTP header (Name: Value)')
    create_parser.add_argument('--jsonpath', help='JSONPath expression for validation')
    create_parser.add_argument('--expected-value', help='Expected value from JSONPath')
    create_parser.add_argument('--interval', default='60s', help='Check interval')

    # Update command
    update_parser = subparsers.add_parser('update', help='Update API monitor')
    update_parser.add_argument('--item-id', required=True, help='Item ID')
    update_parser.add_argument('--config', required=True, help='Configuration file')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete API monitor')
    delete_parser.add_argument('--item-id', required=True, help='Item ID')

    # List command
    list_parser = subparsers.add_parser('list', help='List API monitors')
    list_parser.add_argument('--host-id', help='Filter by host ID')
    list_parser.add_argument('--json', action='store_true', help='Output as JSON')

    # Test command
    test_parser = subparsers.add_parser('test', help='Test API endpoint')
    test_parser.add_argument('--url', required=True, help='API endpoint URL')
    test_parser.add_argument('--method', default='GET', help='HTTP method')
    test_parser.add_argument('--header', action='append', help='HTTP header (Name: Value)')
    test_parser.add_argument('--data', help='Request body data')

    args = parser.parse_args()

    if not args.command:
        args.command = 'create'  # Default to create

    # Handle test command separately (no Zabbix connection needed)
    if args.command == 'test':
        monitor = ZabbixAPIMonitor(args.zabbix_url, args.user, args.password)
        headers = {}
        if hasattr(args, 'header') and args.header:
            for header in args.header:
                parts = header.split(':', 1)
                if len(parts) == 2:
                    headers[parts[0].strip()] = parts[1].strip()

        result = monitor.test_api_endpoint(args.url, args.method, headers, args.data)
        print(json.dumps(result, indent=2))
        sys.exit(0 if result.get("success") else 1)

    # Initialize monitor
    monitor = ZabbixAPIMonitor(args.zabbix_url, args.user, args.password)

    # Execute command
    if args.command == 'create':
        if args.config:
            config = load_config(args.config)
            result = monitor.create_api_item(args.host_id, config)
        elif args.name and args.api_url:
            if args.jsonpath:
                result = monitor.create_json_api_monitor(
                    args.host_id, args.name, args.api_url,
                    args.jsonpath, args.expected_value, args.header
                )
            else:
                result = monitor.create_simple_api_check(
                    args.host_id, args.name, args.api_url,
                    args.method, args.expected_status, args.header
                )
        else:
            print("Error: Either --config or --name and --url are required", file=sys.stderr)
            sys.exit(1)
        print(json.dumps(result, indent=2))

    elif args.command == 'update':
        config = load_config(args.config)
        result = monitor.update_item(args.item_id, config)
        print(json.dumps(result, indent=2))

    elif args.command == 'delete':
        monitor.delete_item(args.item_id)

    elif args.command == 'list':
        items = monitor.list_api_items(args.host_id)
        if args.json:
            print(json.dumps(items, indent=2))
        else:
            print(f"\nFound {len(items)} API monitoring item(s):\n")
            for item in items:
                print(f"ID: {item['itemid']}")
                print(f"Name: {item['name']}")
                print(f"URL: {item.get('url', 'N/A')}")
                print(f"Interval: {item['delay']}")
                print("-" * 50)


if __name__ == '__main__':
    main()
