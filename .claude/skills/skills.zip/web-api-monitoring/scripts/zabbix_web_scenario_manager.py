#!/usr/bin/env python3
import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
"""
Zabbix Web Scenario Manager

This script manages Zabbix web scenarios (HTTP tests) for monitoring websites
and web applications. Supports creating, updating, deleting, and listing web
scenarios with full configuration support.

Usage:
    python zabbix_web_scenario_manager.py create --name "Website Check" --url "https://example.com" --host-id 10001
    python zabbix_web_scenario_manager.py update --scenario-id 123 --config config.yaml
    python zabbix_web_scenario_manager.py delete --scenario-id 123
    python zabbix_web_scenario_manager.py list --host-id 10001
    python zabbix_web_scenario_manager.py get --scenario-id 123

Requirements:
    pip install pyzabbix pyyaml
"""

import sys
import json
import yaml
import argparse
from typing import Dict, List, Any, Optional
from pyzabbix import ZabbixAPI, ZabbixAPIException

# Zabbix connection settings (override with environment variables)
ZABBIX_URL = "http://localhost/zabbix"
ZABBIX_USER = "Admin"
ZABBIX_PASSWORD = "zabbix"


class ZabbixWebScenarioManager:
    """Manager for Zabbix web scenarios"""

    def __init__(self, url: str, user: str, password: str):
        """Initialize Zabbix API connection"""
        self.zapi = ZabbixAPI(url)
        try:
            self.zapi.login(user, password)
            print(f"Connected to Zabbix API version {self.zapi.api_version()}")
        except ZabbixAPIException as e:
            print(f"Failed to connect to Zabbix: {e}", file=sys.stderr)
            sys.exit(1)

    def create_scenario(self, host_id: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create a new web scenario

        Args:
            host_id: Zabbix host ID
            config: Web scenario configuration dictionary

        Returns:
            Created scenario details
        """
        # Prepare web scenario parameters
        params = {
            "hostid": host_id,
            "name": config.get("name", "Web Scenario"),
            "delay": config.get("update_interval", "60s"),
            "retries": config.get("retries", 1),
            "agent": config.get("agent", "Zabbix"),
            "http_proxy": config.get("http_proxy", ""),
            "variables": [],
            "headers": [],
            "steps": []
        }

        # Add global variables
        if "variables" in config:
            for var in config["variables"]:
                params["variables"].append({
                    "name": var["name"],
                    "value": var["value"]
                })

        # Add global headers
        if "headers" in config:
            for header in config["headers"]:
                params["headers"].append({
                    "name": header["name"],
                    "value": header["value"]
                })

        # Add steps
        if "steps" in config:
            for idx, step in enumerate(config["steps"], start=1):
                step_params = {
                    "no": idx,
                    "name": step.get("name", f"Step {idx}"),
                    "url": step["url"],
                    "timeout": step.get("timeout", "15s"),
                    "posts": step.get("posts", ""),
                    "required": step.get("required_string", ""),
                    "status_codes": step.get("status_codes", "200"),
                    "follow_redirects": 1 if step.get("follow_redirects", True) else 0,
                    "retrieve_mode": step.get("retrieve_mode", 0),  # 0=body, 1=headers, 2=both
                    "variables": [],
                    "headers": []
                }

                # Add step-specific variables
                if "variables" in step:
                    for var in step["variables"]:
                        step_params["variables"].append({
                            "name": var["name"],
                            "value": var.get("value", var.get("regex", ""))
                        })

                # Add step-specific headers
                if "headers" in step:
                    for header in step["headers"]:
                        step_params["headers"].append({
                            "name": header["name"],
                            "value": header["value"]
                        })

                params["steps"].append(step_params)

        # Add application (if provided)
        if "application" in config:
            # Note: applications are deprecated in Zabbix 5.4+, use tags instead
            params["tags"] = [{"tag": "Application", "value": config["application"]}]

        # Add authentication
        if "authentication" in config:
            auth = config["authentication"]
            params["authentication"] = auth.get("type", 0)  # 0=none, 1=basic, 2=NTLM
            if params["authentication"] > 0:
                params["http_user"] = auth.get("username", "")
                params["http_password"] = auth.get("password", "")

        # Add SSL settings
        if "ssl" in config:
            ssl = config["ssl"]
            params["verify_peer"] = 1 if ssl.get("verify_peer", True) else 0
            params["verify_host"] = 1 if ssl.get("verify_host", True) else 0
            params["ssl_cert_file"] = ssl.get("cert_file", "")
            params["ssl_key_file"] = ssl.get("key_file", "")
            params["ssl_key_password"] = ssl.get("key_password", "")

        try:
            result = self.zapi.httptest.create(params)
            scenario_id = result["httptestids"][0]
            print(f"[OK] Web scenario created successfully (ID: {scenario_id})")
            return self.get_scenario(scenario_id)
        except ZabbixAPIException as e:
            print(f"[ERROR] Failed to create web scenario: {e}", file=sys.stderr)
            sys.exit(1)

    def create_simple_scenario(self, host_id: str, name: str, url: str,
                               status_codes: str = "200",
                               required_string: str = "",
                               interval: int = 60) -> Dict[str, Any]:
        """
        Create a simple single-step web scenario

        Args:
            host_id: Zabbix host ID
            name: Scenario name
            url: URL to check
            status_codes: Expected status codes
            required_string: Required string in response
            interval: Check interval in seconds

        Returns:
            Created scenario details
        """
        config = {
            "name": name,
            "update_interval": f"{interval}s",
            "steps": [{
                "name": "Check",
                "url": url,
                "status_codes": status_codes,
                "required_string": required_string,
                "timeout": "15s"
            }]
        }
        return self.create_scenario(host_id, config)

    def update_scenario(self, scenario_id: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update an existing web scenario

        Args:
            scenario_id: Web scenario ID
            config: Updated configuration

        Returns:
            Updated scenario details
        """
        params = {"httptestid": scenario_id}

        # Update allowed fields
        if "name" in config:
            params["name"] = config["name"]
        if "update_interval" in config:
            params["delay"] = config["update_interval"]
        if "retries" in config:
            params["retries"] = config["retries"]
        if "agent" in config:
            params["agent"] = config["agent"]
        if "http_proxy" in config:
            params["http_proxy"] = config["http_proxy"]

        # Update variables
        if "variables" in config:
            params["variables"] = []
            for var in config["variables"]:
                params["variables"].append({
                    "name": var["name"],
                    "value": var["value"]
                })

        # Update headers
        if "headers" in config:
            params["headers"] = []
            for header in config["headers"]:
                params["headers"].append({
                    "name": header["name"],
                    "value": header["value"]
                })

        # Update steps
        if "steps" in config:
            params["steps"] = []
            for idx, step in enumerate(config["steps"], start=1):
                step_params = {
                    "no": idx,
                    "name": step.get("name", f"Step {idx}"),
                    "url": step["url"],
                    "timeout": step.get("timeout", "15s"),
                    "posts": step.get("posts", ""),
                    "required": step.get("required_string", ""),
                    "status_codes": step.get("status_codes", "200"),
                    "follow_redirects": 1 if step.get("follow_redirects", True) else 0,
                    "retrieve_mode": step.get("retrieve_mode", 0),
                    "variables": [],
                    "headers": []
                }

                if "variables" in step:
                    for var in step["variables"]:
                        step_params["variables"].append({
                            "name": var["name"],
                            "value": var.get("value", var.get("regex", ""))
                        })

                if "headers" in step:
                    for header in step["headers"]:
                        step_params["headers"].append({
                            "name": header["name"],
                            "value": header["value"]
                        })

                params["steps"].append(step_params)

        try:
            result = self.zapi.httptest.update(params)
            print(f"[OK] Web scenario updated successfully (ID: {scenario_id})")
            return self.get_scenario(scenario_id)
        except ZabbixAPIException as e:
            print(f"[ERROR] Failed to update web scenario: {e}", file=sys.stderr)
            sys.exit(1)

    def delete_scenario(self, scenario_id: str) -> bool:
        """
        Delete a web scenario

        Args:
            scenario_id: Web scenario ID

        Returns:
            True if successful
        """
        try:
            result = self.zapi.httptest.delete([scenario_id])
            print(f"[OK] Web scenario deleted successfully (ID: {scenario_id})")
            return True
        except ZabbixAPIException as e:
            print(f"[ERROR] Failed to delete web scenario: {e}", file=sys.stderr)
            return False

    def get_scenario(self, scenario_id: str) -> Optional[Dict[str, Any]]:
        """
        Get web scenario details

        Args:
            scenario_id: Web scenario ID

        Returns:
            Scenario details or None
        """
        try:
            result = self.zapi.httptest.get({
                "httptestids": scenario_id,
                "selectSteps": "extend",
                "selectTags": "extend"
            })
            if result:
                return result[0]
            return None
        except ZabbixAPIException as e:
            print(f"[ERROR] Failed to get web scenario: {e}", file=sys.stderr)
            return None

    def list_scenarios(self, host_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List web scenarios

        Args:
            host_id: Filter by host ID (optional)

        Returns:
            List of scenarios
        """
        params = {
            "output": "extend",
            "selectSteps": "extend",
            "selectTags": "extend"
        }

        if host_id:
            params["hostids"] = host_id

        try:
            scenarios = self.zapi.httptest.get(params)
            return scenarios
        except ZabbixAPIException as e:
            print(f"[ERROR] Failed to list web scenarios: {e}", file=sys.stderr)
            return []

    def export_scenario(self, scenario_id: str, output_file: str, format: str = "yaml"):
        """
        Export web scenario to file

        Args:
            scenario_id: Web scenario ID
            output_file: Output file path
            format: Output format (yaml or json)
        """
        scenario = self.get_scenario(scenario_id)
        if not scenario:
            print(f"[ERROR] Scenario not found: {scenario_id}", file=sys.stderr)
            return

        # Convert to simplified config format
        config = {
            "name": scenario["name"],
            "update_interval": scenario["delay"],
            "retries": int(scenario["retries"]),
            "agent": scenario["agent"],
            "steps": []
        }

        for step in scenario.get("steps", []):
            step_config = {
                "name": step["name"],
                "url": step["url"],
                "timeout": step["timeout"],
                "status_codes": step["status_codes"],
                "required_string": step.get("required", ""),
                "posts": step.get("posts", ""),
                "follow_redirects": bool(int(step.get("follow_redirects", 1)))
            }
            config["steps"].append(step_config)

        with open(output_file, 'w') as f:
            if format == "yaml":
                yaml.dump(config, f, default_flow_style=False, sort_keys=False)
            else:
                json.dump(config, f, indent=2)

        print(f"[OK] Scenario exported to {output_file}")


def load_config(config_file: str) -> Dict[str, Any]:
    """Load configuration from YAML or JSON file"""
    with open(config_file, 'r') as f:
        if config_file.endswith('.yaml') or config_file.endswith('.yml'):
            return yaml.safe_load(f)
        else:
            return json.load(f)


def main():
    parser = argparse.ArgumentParser(
        description="Manage Zabbix web scenarios",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Create simple scenario:
    %(prog)s create --name "Website Check" --url "https://example.com" --host-id 10001

  Create from config:
    %(prog)s create --config scenario.yaml --host-id 10001

  Update scenario:
    %(prog)s update --scenario-id 123 --config updated.yaml

  List scenarios:
    %(prog)s list --host-id 10001

  Delete scenario:
    %(prog)s delete --scenario-id 123

  Export scenario:
    %(prog)s export --scenario-id 123 --output scenario.yaml
        """
    )

    parser.add_argument('--url', default=ZABBIX_URL, help='Zabbix URL')
    parser.add_argument('--user', default=ZABBIX_USER, help='Zabbix username')
    parser.add_argument('--password', default=ZABBIX_PASSWORD, help='Zabbix password')

    subparsers = parser.add_subparsers(dest='command', help='Command to execute')

    # Create command
    create_parser = subparsers.add_parser('create', help='Create web scenario')
    create_parser.add_argument('--host-id', required=True, help='Host ID')
    create_parser.add_argument('--config', help='Configuration file (YAML/JSON)')
    create_parser.add_argument('--name', help='Scenario name')
    create_parser.add_argument('--url', dest='check_url', help='URL to check')
    create_parser.add_argument('--status-codes', default='200', help='Expected status codes')
    create_parser.add_argument('--required-string', default='', help='Required string in response')
    create_parser.add_argument('--interval', type=int, default=60, help='Check interval in seconds')

    # Update command
    update_parser = subparsers.add_parser('update', help='Update web scenario')
    update_parser.add_argument('--scenario-id', required=True, help='Scenario ID')
    update_parser.add_argument('--config', required=True, help='Configuration file (YAML/JSON)')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete web scenario')
    delete_parser.add_argument('--scenario-id', required=True, help='Scenario ID')

    # Get command
    get_parser = subparsers.add_parser('get', help='Get scenario details')
    get_parser.add_argument('--scenario-id', required=True, help='Scenario ID')

    # List command
    list_parser = subparsers.add_parser('list', help='List web scenarios')
    list_parser.add_argument('--host-id', help='Filter by host ID')
    list_parser.add_argument('--json', action='store_true', help='Output as JSON')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export scenario')
    export_parser.add_argument('--scenario-id', required=True, help='Scenario ID')
    export_parser.add_argument('--output', required=True, help='Output file')
    export_parser.add_argument('--format', choices=['yaml', 'json'], default='yaml', help='Output format')

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    # Initialize manager
    manager = ZabbixWebScenarioManager(args.url, args.user, args.password)

    # Execute command
    if args.command == 'create':
        if args.config:
            config = load_config(args.config)
            result = manager.create_scenario(args.host_id, config)
        elif args.name and args.check_url:
            result = manager.create_simple_scenario(
                args.host_id, args.name, args.check_url,
                args.status_codes, args.required_string, args.interval
            )
        else:
            print("Error: Either --config or --name and --url are required", file=sys.stderr)
            sys.exit(1)
        print(json.dumps(result, indent=2))

    elif args.command == 'update':
        config = load_config(args.config)
        result = manager.update_scenario(args.scenario_id, config)
        print(json.dumps(result, indent=2))

    elif args.command == 'delete':
        manager.delete_scenario(args.scenario_id)

    elif args.command == 'get':
        result = manager.get_scenario(args.scenario_id)
        if result:
            print(json.dumps(result, indent=2))

    elif args.command == 'list':
        scenarios = manager.list_scenarios(args.host_id)
        if args.json:
            print(json.dumps(scenarios, indent=2))
        else:
            print(f"\nFound {len(scenarios)} web scenario(s):\n")
            for scenario in scenarios:
                print(f"ID: {scenario['httptestid']}")
                print(f"Name: {scenario['name']}")
                print(f"Host ID: {scenario['hostid']}")
                print(f"Interval: {scenario['delay']}")
                print(f"Steps: {len(scenario.get('steps', []))}")
                print("-" * 50)

    elif args.command == 'export':
        manager.export_scenario(args.scenario_id, args.output, args.format)


if __name__ == '__main__':
    main()
