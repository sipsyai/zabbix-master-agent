# Working with Templates in Zabbix

Complete Agent Skill for managing Zabbix templates through automation and the Zabbix API.

## Quick Start

### Prerequisites

```bash
# Install required Python packages
pip install requests pyyaml
```

### Authentication

Zabbix API supports two authentication methods:

**API Token (Recommended - Zabbix 5.4+):**
```python
from scripts.zabbix_template_manager import ZabbixTemplateManager

manager = ZabbixTemplateManager(
    url="http://zabbix.example.com/api_jsonrpc.php",
    token="your_api_token"
)
```

**Username/Password (Legacy):**
```python
manager = ZabbixTemplateManager(
    url="http://zabbix.example.com/api_jsonrpc.php",
    user="Admin",
    password="zabbix"
)
```

## Common Operations

### Create Template

```python
template_id = manager.create_template(
    name="My Custom Template",
    groups=["Templates/Custom"],
    description="Custom monitoring template",
    macros=[
        {"macro": "{$THRESHOLD}", "value": "90", "description": "Warning threshold"}
    ]
)
```

### Export Template

```bash
# Using CLI
python scripts/template_import_export.py export \
  --url http://zabbix.local/api_jsonrpc.php \
  --token YOUR_TOKEN \
  --template "Linux Server Basic" \
  --output linux_template.yaml \
  --format yaml
```

```python
# Using Python
from scripts.template_import_export import TemplateImportExport

exporter = TemplateImportExport(manager)
exporter.export_template(
    template_names=["Linux Server Basic"],
    output_file="linux_template.yaml",
    format="yaml"
)
```

### Import Template

```bash
# Using CLI
python scripts/template_import_export.py import \
  --url http://zabbix.local/api_jsonrpc.php \
  --token YOUR_TOKEN \
  --file linux_template.yaml \
  --create-missing \
  --update-existing
```

```python
# Using Python
exporter.import_template(
    file_path="linux_template.yaml",
    rules={
        "templates": {
            "createMissing": True,
            "updateExisting": True
        }
    }
)
```

### Validate Template

```bash
python scripts/validate_template_config.py template.yaml
```

### Compare Templates

```bash
python scripts/template_compare.py template_v1.yaml template_v2.yaml
```

## File Structure

```
working-with-templates/
├── SKILL.md                          # Complete skill documentation
├── README.md                         # This file
├── scripts/
│   ├── zabbix_template_manager.py   # Main template management
│   ├── template_import_export.py    # Import/export utilities
│   ├── validate_template_config.py  # Template validation
│   └── template_compare.py          # Template comparison
└── examples/
    ├── linux_server_template.json   # Linux monitoring template
    ├── windows_server_template.json # Windows monitoring template
    ├── network_device_template.yaml # SNMP network device
    ├── database_template.yaml       # MySQL database monitoring
    ├── web_app_template.json        # Web application monitoring
    ├── template_macros.json         # Macro examples
    ├── template_inheritance.yaml    # Inheritance patterns
    └── bulk_templates.yaml          # Bulk operations examples
```

## Example Templates

All example templates are production-ready and can be imported directly:

- **linux_server_template.json** - Comprehensive Linux server monitoring
- **windows_server_template.json** - Windows Server monitoring with services
- **network_device_template.yaml** - SNMP-based network device monitoring
- **database_template.yaml** - MySQL/MariaDB database monitoring
- **web_app_template.json** - Web application with HTTP checks and SSL monitoring

## Key Features

### Template Management
- Create, update, delete templates
- Clone templates with modifications
- Manage template groups
- Template inheritance (parent-child relationships)

### Import/Export
- Multiple formats: YAML, JSON, XML
- Bulk operations
- Dependency resolution
- Format conversion

### Component Management
- Items (all types)
- Triggers with expressions
- Discovery rules (LLD)
- Graphs and dashboards
- Web scenarios
- Macros (text, secret, vault)
- Value maps

### Template Linking
- Link templates to hosts
- Unlink templates (with or without clearing items)
- Bulk linking operations
- Pattern-based linking

### Validation and Testing
- Syntax validation
- Required fields check
- Trigger expression validation
- Naming convention checks
- Circular dependency detection

### Template Comparison
- Identify added/removed/modified components
- Compare items, triggers, macros
- Generate difference reports
- Support for version tracking

## Usage Patterns

### Development Workflow

1. **Create template locally** (edit YAML/JSON file)
2. **Validate** using validation script
3. **Import to dev environment** for testing
4. **Test** with test hosts
5. **Export** from dev
6. **Version control** (commit to Git)
7. **Deploy to production**

### CI/CD Integration

```yaml
# Example GitLab CI pipeline
deploy-templates:
  stage: deploy
  script:
    - python scripts/template_import_export.py bulk-import \
        --url $ZABBIX_URL \
        --token $ZABBIX_TOKEN \
        --directory ./templates \
        --pattern "*.yaml"
  only:
    - main
```

### Bulk Operations

```bash
# Export all Linux templates
python scripts/template_import_export.py bulk-export \
  --pattern "Linux*" \
  --output-dir ./exports \
  --format yaml

# Import all templates from directory
python scripts/template_import_export.py bulk-import \
  --directory ./templates \
  --pattern "*.yaml"
```

## Best Practices

### Template Naming
- Use descriptive names: "Linux Server Monitoring" not "Template1"
- Include technology: "MySQL Database Server"
- Add version if needed: "Apache 2.4"

### Macro Naming
- Format: `{$COMPONENT.METRIC.THRESHOLD}`
- Examples: `{$CPU.UTIL.WARN}`, `{$DISK.USAGE.CRIT}`
- Use uppercase, dots as separators

### Template Organization
```
Templates/
├── Operating systems/
├── Applications/
├── Modules/
├── Network devices/
└── Custom/
```

### Inheritance Structure
- Maximum 3-4 levels deep
- Base → OS → Application → Specific
- Use modules for reusable components

### Version Control
- Export templates as YAML (most readable)
- Commit regularly with descriptive messages
- Use branches for major changes
- Tag releases

## Troubleshooting

### Import Failures

**Missing dependencies:**
```bash
# Export with dependencies
python scripts/template_import_export.py export \
  --template "My Template" \
  --output template.yaml \
  --include-dependencies
```

**Name conflicts:**
```python
# Update existing templates on import
rules = {
    "templates": {
        "createMissing": True,
        "updateExisting": True  # Allow updates
    }
}
```

### Validation Errors

```bash
# Run validation with detailed output
python scripts/validate_template_config.py template.yaml --verbose

# Treat warnings as errors (strict mode)
python scripts/validate_template_config.py template.yaml --warnings-as-errors
```

### Performance Issues

- Use bulk operations for multiple templates
- Export/import during low-usage periods
- Limit template complexity (aim for <300 items per template)
- Use dependent items to reduce direct checks

## API Reference

See `scripts/zabbix_template_manager.py` for complete API documentation.

### Main Methods

- `create_template()` - Create new template
- `update_template()` - Update existing template
- `delete_template()` - Remove template
- `get_template()` - Retrieve template details
- `list_templates()` - List templates with filtering
- `export_template()` - Export to file
- `import_template()` - Import from file
- `link_template_to_hosts()` - Link to hosts
- `unlink_template_from_hosts()` - Unlink from hosts
- `clone_template()` - Duplicate template
- `manage_template_macros()` - Macro management
- `add_items_to_template()` - Add items
- `add_triggers_to_template()` - Add triggers
- `add_discovery_rule()` - Add LLD rules

## Additional Resources

- **Zabbix Documentation:** https://www.zabbix.com/documentation/current/manual/config/templates
- **Template API Reference:** https://www.zabbix.com/documentation/current/manual/api/reference/template
- **Configuration Export/Import:** https://www.zabbix.com/documentation/current/manual/xml_export_import

## Support

For issues or questions:
1. Review SKILL.md for detailed documentation
2. Check example templates for reference implementations
3. Validate templates before import
4. Review Zabbix logs for API errors

## Version Information

- **Skill Version:** 1.0.0
- **Compatible with:** Zabbix 6.0, 6.4, 7.0+
- **Python Requirements:** 3.7+
- **Dependencies:** requests, pyyaml

## License

This skill is provided as-is for use with Zabbix monitoring systems.
