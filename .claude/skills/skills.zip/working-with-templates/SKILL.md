---
name: Working with Templates in Zabbix
description: Automates Zabbix template management including creating, updating, importing, exporting templates, managing template inheritance, linking templates to hosts, and handling template macros, items, triggers, and discovery rules through the Zabbix API. Use when creating reusable monitoring templates, standardizing monitoring across infrastructure, performing template version control and CI/CD, migrating templates between environments, managing template marketplace/libraries, implementing Infrastructure as Code for monitoring, or conducting template testing and validation.
version: 1.0.0
---

# Working with Templates in Zabbix

Automate comprehensive template management operations in Zabbix, from creation and configuration to import/export and inheritance management.

## Quick Start

### Create a Basic Template
```python
from scripts.zabbix_template_manager import ZabbixTemplateManager

manager = ZabbixTemplateManager(
    url="http://zabbix.example.com/api_jsonrpc.php",
    token="your_api_token"
)

# Create simple template
template_id = manager.create_template(
    name="Linux Server Basic",
    groups=["Templates/Operating systems"],
    description="Basic Linux server monitoring template"
)
```

### Export Template
```python
# Export to YAML (recommended)
manager.export_template(
    template_names=["Linux Server Basic"],
    output_file="linux_template.yaml",
    format="yaml"
)
```

### Import Template
```python
# Import from file
result = manager.import_template(
    file_path="linux_template.yaml",
    rules={
        "templates": {
            "createMissing": True,
            "updateExisting": True
        }
    }
)
```

## Core Capabilities

### 1. Template Creation and Configuration

**Create from scratch:**
- Define template metadata (name, description, groups)
- Set up template tags for organization
- Configure vendor information
- Define template macros with defaults

**Create with components:**
- Add items (all types: agent, SNMP, HTTP, calculated, etc.)
- Configure triggers with expressions
- Set up low-level discovery (LLD) rules
- Define graphs and dashboards
- Configure web scenarios

**Example:** See `examples/linux_server_template.json` for complete structure.

### 2. Template Import/Export

**Supported formats:**
- YAML (recommended, default in Zabbix 7.0+)
- JSON (widely compatible)
- XML (legacy format)

**Export options:**
```python
manager.export_template(
    template_names=["Template Name"],
    output_file="output.yaml",
    format="yaml",
    include_dependencies=True  # Export linked templates
)
```

**Import with rules:**
```python
manager.import_template(
    file_path="template.yaml",
    rules={
        "templates": {
            "createMissing": True,
            "updateExisting": True,
            "deleteMissing": False
        },
        "items": {"createMissing": True, "updateExisting": True},
        "triggers": {"createMissing": True, "updateExisting": True},
        "discoveryRules": {"createMissing": True, "updateExisting": True},
        "valueMaps": {"createMissing": True, "updateExisting": True}
    }
)
```

### 3. Template Inheritance and Linking

**Link template to hosts:**
```python
# Link single template
manager.link_template_to_hosts(
    template_name="Linux Server Basic",
    host_names=["web-server-01", "web-server-02"]
)

# Bulk linking
manager.bulk_link_templates(
    template_host_map={
        "Linux Server Basic": ["web-*"],  # Pattern matching
        "Apache": ["web-*"],
        "MySQL": ["db-*"]
    }
)
```

**Template inheritance:**
```python
# Link parent templates (inheritance)
manager.link_parent_templates(
    template_name="Linux Server Extended",
    parent_templates=["Linux Server Basic", "ICMP Ping"]
)
```

### 4. Template Macros Management

**Add/update macros:**
```python
manager.manage_template_macros(
    template_name="Linux Server Basic",
    macros=[
        {
            "macro": "{$CPU.UTIL.CRIT}",
            "value": "90",
            "description": "Critical CPU utilization threshold"
        },
        {
            "macro": "{$MEMORY.UTIL.MAX}",
            "value": "95",
            "description": "Maximum memory utilization"
        }
    ]
)
```

**Macro types:**
- TEXT (default): Plain text macros
- SECRET_TEXT: Encrypted storage
- VAULT: Integration with HashiCorp Vault

### 5. Template Components Management

**Add items to template:**
```python
manager.add_items_to_template(
    template_name="Linux Server Basic",
    items=[
        {
            "name": "CPU utilization",
            "key": "system.cpu.util",
            "type": 0,  # Zabbix agent
            "value_type": 0,  # Float
            "units": "%",
            "delay": "1m",
            "history": "7d",
            "trends": "365d"
        }
    ]
)
```

**Add triggers:**
```python
manager.add_triggers_to_template(
    template_name="Linux Server Basic",
    triggers=[
        {
            "description": "High CPU utilization",
            "expression": "avg(/Linux Server Basic/system.cpu.util,5m)>{$CPU.UTIL.CRIT}",
            "priority": 3,  # Average
            "manual_close": True
        }
    ]
)
```

**Add discovery rules:**
```python
manager.add_discovery_rule(
    template_name="Linux Server Basic",
    discovery_rule={
        "name": "Network interface discovery",
        "key": "net.if.discovery",
        "type": 0,  # Zabbix agent
        "delay": "1h",
        "lifetime": "7d",
        "item_prototypes": [...],
        "trigger_prototypes": [...]
    }
)
```

### 6. Template Operations

**Clone template:**
```python
new_template_id = manager.clone_template(
    source_template="Linux Server Basic",
    new_name="Linux Server Custom",
    modifications={
        "description": "Customized Linux template",
        "groups": ["Templates/Custom"],
        "macros": {
            "{$CPU.UTIL.CRIT}": "85"  # Override macro
        }
    }
)
```

**Update template:**
```python
manager.update_template(
    template_name="Linux Server Basic",
    updates={
        "description": "Updated description",
        "tags": [
            {"tag": "environment", "value": "production"},
            {"tag": "os", "value": "linux"}
        ]
    }
)
```

**Delete template:**
```python
manager.delete_template(
    template_name="Old Template",
    delete_linked_hosts=False  # Keep hosts, just unlink
)
```

### 7. Template Groups Management

**Organize templates:**
```python
manager.manage_template_groups(
    template_name="Linux Server Basic",
    groups=["Templates/Operating systems", "Templates/Production"]
)
```

### 8. Template Validation

**Validate configuration:**
```python
from scripts.validate_template_config import validate_template

validation_result = validate_template("template.yaml")

if validation_result.is_valid:
    print("Template is valid")
else:
    for error in validation_result.errors:
        print(f"Error: {error}")
```

**Validation checks:**
- Syntax validation (YAML/JSON/XML)
- Required fields presence
- Trigger expression syntax
- Item key uniqueness
- Macro naming conventions
- Circular dependency detection

### 9. Template Comparison

**Compare templates:**
```python
from scripts.template_compare import compare_templates

diff = compare_templates("template_v1.yaml", "template_v2.yaml")

print(f"Added items: {diff.added_items}")
print(f"Removed items: {diff.removed_items}")
print(f"Modified items: {diff.modified_items}")
print(f"Macro changes: {diff.macro_changes}")
```

### 10. Bulk Operations

**Process multiple templates:**
```python
# Bulk export
manager.bulk_export_templates(
    template_pattern="Linux*",
    output_dir="./exports",
    format="yaml"
)

# Bulk import
manager.bulk_import_templates(
    directory="./templates",
    file_pattern="*.yaml",
    parallel=True
)
```

## Template Components Reference

### Items
All item types supported:
- Zabbix agent (active/passive)
- SNMP agent
- IPMI
- Simple checks
- VMware monitoring
- JMX monitoring
- ODBC database
- HTTP agent
- External scripts
- Calculated items
- Dependent items
- SSH/Telnet checks
- Trapper items

### Triggers
- Simple expressions
- Complex logic with AND/OR
- Trigger functions (avg, min, max, last, etc.)
- Trigger dependencies
- Event tags
- Manual close options
- Recovery expressions

### Discovery Rules
- Item prototypes
- Trigger prototypes
- Graph prototypes
- Host prototypes
- LLD macros and filters
- Custom LLD keys
- Preprocessing for LLD

### Other Components
- Graphs (simple, stacked, pie)
- Dashboards and widgets
- Web scenarios (HTTP monitoring)
- Value maps
- Template tags

## Best Practices

### Template Design
1. **Use meaningful names**: Template names should clearly indicate purpose
2. **Organize with groups**: Use hierarchical template groups
3. **Document macros**: Always provide descriptions for macros
4. **Tag appropriately**: Use tags for filtering and organization
5. **Version templates**: Include version in vendor information

### Template Structure
```yaml
# Recommended template organization
Templates/
├── Operating systems/      # OS-level templates
├── Applications/          # Application-specific
├── Modules/              # Reusable modules
├── Network devices/      # Network equipment
└── Custom/              # Organization-specific
```

### Macro Conventions
- Use consistent naming: `{$COMPONENT.METRIC.THRESHOLD}`
- Examples:
  - `{$CPU.UTIL.CRIT}` - Critical CPU threshold
  - `{$MEMORY.AVAILABLE.MIN}` - Minimum available memory
  - `{$DISK.USAGE.WARN}` - Disk usage warning
  - `{$SERVICE.RESPONSE.MAX}` - Max response time

### Inheritance Strategy
1. **Base templates**: Core monitoring (ICMP, system metrics)
2. **OS templates**: Operating system-specific items
3. **Application templates**: Application monitoring
4. **Environment templates**: Environment-specific overrides

### Version Control
```python
# Export templates for Git
manager.export_for_version_control(
    templates=["Linux Server Basic"],
    output_dir="./git-repo/templates",
    include_metadata=True,
    format="yaml"
)
```

Commit templates to Git for:
- Change tracking
- Rollback capability
- Peer review process
- CI/CD integration

### Template Testing
```python
# Validate before deployment
from scripts.validate_template_config import validate_template

result = validate_template("new_template.yaml")

if result.is_valid:
    # Deploy to test environment first
    manager.import_template("new_template.yaml")

    # Test with dedicated test hosts
    manager.link_template_to_hosts(
        template_name="New Template",
        host_names=["test-host-01"]
    )

    # Monitor for issues before production rollout
```

## Examples Library

### Complete Template Examples
- `examples/linux_server_template.json` - Comprehensive Linux monitoring
- `examples/windows_server_template.json` - Windows Server monitoring
- `examples/network_device_template.yaml` - SNMP-based network monitoring
- `examples/database_template.yaml` - Database monitoring (MySQL/PostgreSQL)
- `examples/web_app_template.json` - Web application monitoring

### Specialized Examples
- `examples/template_macros.json` - Macro configuration examples
- `examples/template_inheritance.yaml` - Multi-level inheritance
- `examples/bulk_templates.yaml` - Bulk operations configuration

## Common Workflows

### New Application Template
1. Create base template structure
2. Define macros for thresholds
3. Add core items
4. Create triggers with macro references
5. Set up LLD rules if needed
6. Test on dev environment
7. Export and version control
8. Deploy to production

### Template Migration
```python
# Export from source Zabbix
source_manager.export_template(
    template_names=["Production Template"],
    output_file="template.yaml"
)

# Import to target Zabbix
target_manager.import_template(
    file_path="template.yaml",
    rules={"templates": {"createMissing": True}}
)
```

### Template Update Rollout
1. Export current template (backup)
2. Modify template configuration
3. Validate changes
4. Import to test environment
5. Verify on test hosts
6. Compare differences
7. Import to production
8. Monitor affected hosts

## Troubleshooting

### Import Failures
- **Missing dependencies**: Export with `include_dependencies=True`
- **Name conflicts**: Use `updateExisting=True` in import rules
- **Invalid expressions**: Validate trigger expressions before import
- **Circular dependencies**: Check template inheritance chain

### Template Linking Issues
- Verify template exists: `manager.get_template(name)`
- Check host exists and is accessible
- Review host permissions
- Ensure no conflicting templates

### Performance Considerations
- Limit items per template: ~200-300 items optimal
- Use dependent items to reduce checks
- Optimize trigger expressions (avoid complex calculations)
- Set appropriate history/trend retention
- Use LLD for dynamic discovery vs. static items

## API Reference

See `scripts/zabbix_template_manager.py` for complete API documentation.

### Key Methods
- `create_template()` - Create new template
- `update_template()` - Update existing template
- `delete_template()` - Remove template
- `get_template()` - Retrieve template details
- `export_template()` - Export to file
- `import_template()` - Import from file
- `link_template_to_hosts()` - Link to hosts
- `unlink_template_from_hosts()` - Unlink from hosts
- `clone_template()` - Duplicate template
- `add_items_to_template()` - Add items
- `add_triggers_to_template()` - Add triggers
- `manage_template_macros()` - Macro management

## Script Reference

### Main Scripts
- `scripts/zabbix_template_manager.py` - Primary template operations
- `scripts/template_import_export.py` - Import/export utilities
- `scripts/validate_template_config.py` - Template validation
- `scripts/template_compare.py` - Template comparison tool

### Usage Examples

**CLI Export:**
```bash
python scripts/template_import_export.py export \
  --url http://zabbix.example.com/api_jsonrpc.php \
  --token YOUR_TOKEN \
  --template "Linux Server Basic" \
  --output template.yaml \
  --format yaml
```

**CLI Import:**
```bash
python scripts/template_import_export.py import \
  --url http://zabbix.example.com/api_jsonrpc.php \
  --token YOUR_TOKEN \
  --file template.yaml \
  --create-missing \
  --update-existing
```

**Validation:**
```bash
python scripts/validate_template_config.py template.yaml
```

**Comparison:**
```bash
python scripts/template_compare.py template_v1.yaml template_v2.yaml
```

## Additional Resources

- Zabbix Template Documentation: `/zabbix-docs-masters/zabbix-docs/07_Configuration/8_templates.md`
- Import/Export Guide: `/zabbix-docs-masters/zabbix-docs/14_Configuration_Export_Import/3_templates.md`
- Template API Reference: `/zabbix-docs-masters/zabbix-docs/20_API/288_template.md`
- Out-of-the-Box Templates: `/zabbix-docs-masters/zabbix-docs/07_Configuration/9_templates_out_of_the_box.md`

## Notes

- Always test templates in non-production environment first
- Back up templates before major changes (export to file)
- Use version control for template management
- Document custom templates thoroughly
- Review Zabbix version compatibility
- Consider template dependencies when importing
- Monitor host performance after template changes
