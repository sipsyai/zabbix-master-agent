#!/usr/bin/env python3
"""
Zabbix Template Comparison Tool

Compare two template files or versions to identify differences in
items, triggers, macros, and other components.

Author: Generated for Zabbix Skills
Version: 1.0.0
"""

import json
import yaml
import argparse
from pathlib import Path
from typing import Dict, Any, List, Set, Tuple
from dataclasses import dataclass, field
from difflib import unified_diff


import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
@dataclass
class TemplateDiff:
    """Template difference data class"""
    template_name: str = ""

    # Items
    added_items: List[Dict[str, Any]] = field(default_factory=list)
    removed_items: List[Dict[str, Any]] = field(default_factory=list)
    modified_items: List[Tuple[Dict, Dict]] = field(default_factory=list)

    # Triggers
    added_triggers: List[Dict[str, Any]] = field(default_factory=list)
    removed_triggers: List[Dict[str, Any]] = field(default_factory=list)
    modified_triggers: List[Tuple[Dict, Dict]] = field(default_factory=list)

    # Macros
    added_macros: List[Dict[str, Any]] = field(default_factory=list)
    removed_macros: List[Dict[str, Any]] = field(default_factory=list)
    modified_macros: List[Tuple[Dict, Dict]] = field(default_factory=list)

    # Discovery rules
    added_discovery_rules: List[Dict[str, Any]] = field(default_factory=list)
    removed_discovery_rules: List[Dict[str, Any]] = field(default_factory=list)
    modified_discovery_rules: List[Tuple[Dict, Dict]] = field(default_factory=list)

    # Metadata changes
    metadata_changes: Dict[str, Tuple[Any, Any]] = field(default_factory=dict)

    def has_changes(self) -> bool:
        """Check if there are any changes"""
        return bool(
            self.added_items or self.removed_items or self.modified_items or
            self.added_triggers or self.removed_triggers or self.modified_triggers or
            self.added_macros or self.removed_macros or self.modified_macros or
            self.added_discovery_rules or self.removed_discovery_rules or
            self.modified_discovery_rules or self.metadata_changes
        )


class TemplateComparer:
    """
    Compare two Zabbix template configurations.

    Identifies additions, removals, and modifications across all
    template components.
    """

    def __init__(self):
        """Initialize comparer"""
        pass

    def compare_files(self, file1: str, file2: str) -> TemplateDiff:
        """
        Compare two template files.

        Args:
            file1: First template file path
            file2: Second template file path

        Returns:
            TemplateDiff object with differences
        """
        # Load both files
        template1 = self._load_template(file1)
        template2 = self._load_template(file2)

        return self.compare_templates(template1, template2)

    def compare_templates(self, template1: Dict[str, Any],
                         template2: Dict[str, Any]) -> TemplateDiff:
        """
        Compare two template dictionaries.

        Args:
            template1: First template data
            template2: Second template data

        Returns:
            TemplateDiff object with differences
        """
        diff = TemplateDiff()

        # Get template name
        if 'template' in template1:
            diff.template_name = template1.get('template', 'Unknown')
        elif 'name' in template1:
            diff.template_name = template1.get('name', 'Unknown')

        # Compare metadata
        self._compare_metadata(template1, template2, diff)

        # Compare macros
        self._compare_macros(
            template1.get('macros', []),
            template2.get('macros', []),
            diff
        )

        # Compare items
        self._compare_items(
            template1.get('items', []),
            template2.get('items', []),
            diff
        )

        # Compare triggers
        self._compare_triggers(
            template1.get('triggers', []),
            template2.get('triggers', []),
            diff
        )

        # Compare discovery rules
        self._compare_discovery_rules(
            template1.get('discovery_rules', []),
            template2.get('discovery_rules', []),
            diff
        )

        return diff

    def _load_template(self, file_path: str) -> Dict[str, Any]:
        """Load template from file"""
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        ext = path.suffix.lower()

        if ext in ['.yaml', '.yml']:
            data = yaml.safe_load(content)
        elif ext == '.json':
            data = json.loads(content)
        else:
            raise ValueError(f"Unsupported file format: {ext}")

        # Extract template from zabbix_export structure
        if 'zabbix_export' in data:
            templates = data['zabbix_export'].get('templates', [])
            if templates:
                return templates[0]  # Return first template
            else:
                raise ValueError("No templates found in export")

        return data

    def _compare_metadata(self, template1: Dict[str, Any],
                         template2: Dict[str, Any],
                         diff: TemplateDiff):
        """Compare template metadata"""
        metadata_fields = ['name', 'description', 'vendor', 'groups', 'tags']

        for field in metadata_fields:
            val1 = template1.get(field)
            val2 = template2.get(field)

            if val1 != val2:
                diff.metadata_changes[field] = (val1, val2)

    def _compare_macros(self, macros1: List[Dict[str, Any]],
                       macros2: List[Dict[str, Any]],
                       diff: TemplateDiff):
        """Compare template macros"""
        # Create lookup by macro name
        macros1_dict = {m['macro']: m for m in macros1 if 'macro' in m}
        macros2_dict = {m['macro']: m for m in macros2 if 'macro' in m}

        # Find added macros
        for macro_name in macros2_dict:
            if macro_name not in macros1_dict:
                diff.added_macros.append(macros2_dict[macro_name])

        # Find removed macros
        for macro_name in macros1_dict:
            if macro_name not in macros2_dict:
                diff.removed_macros.append(macros1_dict[macro_name])

        # Find modified macros
        for macro_name in macros1_dict:
            if macro_name in macros2_dict:
                macro1 = macros1_dict[macro_name]
                macro2 = macros2_dict[macro_name]

                if self._macro_differs(macro1, macro2):
                    diff.modified_macros.append((macro1, macro2))

    def _macro_differs(self, macro1: Dict[str, Any],
                      macro2: Dict[str, Any]) -> bool:
        """Check if two macros differ"""
        # Compare value and description
        return (
            macro1.get('value') != macro2.get('value') or
            macro1.get('description') != macro2.get('description') or
            macro1.get('type') != macro2.get('type')
        )

    def _compare_items(self, items1: List[Dict[str, Any]],
                      items2: List[Dict[str, Any]],
                      diff: TemplateDiff):
        """Compare template items"""
        # Create lookup by item key
        items1_dict = {i['key']: i for i in items1 if 'key' in i}
        items2_dict = {i['key']: i for i in items2 if 'key' in i}

        # Find added items
        for key in items2_dict:
            if key not in items1_dict:
                diff.added_items.append(items2_dict[key])

        # Find removed items
        for key in items1_dict:
            if key not in items2_dict:
                diff.removed_items.append(items1_dict[key])

        # Find modified items
        for key in items1_dict:
            if key in items2_dict:
                item1 = items1_dict[key]
                item2 = items2_dict[key]

                if self._item_differs(item1, item2):
                    diff.modified_items.append((item1, item2))

    def _item_differs(self, item1: Dict[str, Any],
                     item2: Dict[str, Any]) -> bool:
        """Check if two items differ"""
        # Compare key fields
        compare_fields = [
            'name', 'type', 'value_type', 'delay', 'history', 'trends',
            'units', 'description', 'preprocessing'
        ]

        for field in compare_fields:
            if item1.get(field) != item2.get(field):
                return True

        return False

    def _compare_triggers(self, triggers1: List[Dict[str, Any]],
                         triggers2: List[Dict[str, Any]],
                         diff: TemplateDiff):
        """Compare template triggers"""
        # Create lookup by trigger name and expression
        triggers1_dict = {
            (t.get('name', ''), t.get('expression', '')): t
            for t in triggers1
        }
        triggers2_dict = {
            (t.get('name', ''), t.get('expression', '')): t
            for t in triggers2
        }

        # Find added triggers
        for key in triggers2_dict:
            if key not in triggers1_dict:
                diff.added_triggers.append(triggers2_dict[key])

        # Find removed triggers
        for key in triggers1_dict:
            if key not in triggers2_dict:
                diff.removed_triggers.append(triggers1_dict[key])

        # Find modified triggers (by name only, check if expression changed)
        triggers1_by_name = {t.get('name', ''): t for t in triggers1}
        triggers2_by_name = {t.get('name', ''): t for t in triggers2}

        for name in triggers1_by_name:
            if name in triggers2_by_name:
                trigger1 = triggers1_by_name[name]
                trigger2 = triggers2_by_name[name]

                if self._trigger_differs(trigger1, trigger2):
                    # Only add if not already in added/removed
                    key1 = (name, trigger1.get('expression', ''))
                    key2 = (name, trigger2.get('expression', ''))

                    if key1 in triggers1_dict and key2 in triggers2_dict:
                        diff.modified_triggers.append((trigger1, trigger2))

    def _trigger_differs(self, trigger1: Dict[str, Any],
                        trigger2: Dict[str, Any]) -> bool:
        """Check if two triggers differ"""
        compare_fields = [
            'expression', 'priority', 'description', 'manual_close',
            'recovery_expression', 'tags'
        ]

        for field in compare_fields:
            if trigger1.get(field) != trigger2.get(field):
                return True

        return False

    def _compare_discovery_rules(self, rules1: List[Dict[str, Any]],
                                rules2: List[Dict[str, Any]],
                                diff: TemplateDiff):
        """Compare discovery rules"""
        # Create lookup by key
        rules1_dict = {r['key']: r for r in rules1 if 'key' in r}
        rules2_dict = {r['key']: r for r in rules2 if 'key' in r}

        # Find added rules
        for key in rules2_dict:
            if key not in rules1_dict:
                diff.added_discovery_rules.append(rules2_dict[key])

        # Find removed rules
        for key in rules1_dict:
            if key not in rules2_dict:
                diff.removed_discovery_rules.append(rules1_dict[key])

        # Find modified rules
        for key in rules1_dict:
            if key in rules2_dict:
                rule1 = rules1_dict[key]
                rule2 = rules2_dict[key]

                if self._discovery_rule_differs(rule1, rule2):
                    diff.modified_discovery_rules.append((rule1, rule2))

    def _discovery_rule_differs(self, rule1: Dict[str, Any],
                               rule2: Dict[str, Any]) -> bool:
        """Check if two discovery rules differ"""
        compare_fields = ['name', 'type', 'delay', 'filter', 'lifetime']

        for field in compare_fields:
            if rule1.get(field) != rule2.get(field):
                return True

        # Check prototypes
        if len(rule1.get('item_prototypes', [])) != len(rule2.get('item_prototypes', [])):
            return True

        if len(rule1.get('trigger_prototypes', [])) != len(rule2.get('trigger_prototypes', [])):
            return True

        return False


def format_diff_report(diff: TemplateDiff, detailed: bool = False) -> str:
    """
    Format difference report as string.

    Args:
        diff: TemplateDiff object
        detailed: Include detailed field-by-field differences

    Returns:
        Formatted report string
    """
    lines = []
    lines.append(f"\n{'='*70}")
    lines.append(f"Template Comparison Report: {diff.template_name}")
    lines.append(f"{'='*70}\n")

    if not diff.has_changes():
        lines.append("[OK] No differences found - templates are identical\n")
        return '\n'.join(lines)

    # Metadata changes
    if diff.metadata_changes:
        lines.append("📋 METADATA CHANGES:")
        for field, (old, new) in diff.metadata_changes.items():
            lines.append(f"  {field}:")
            lines.append(f"    Old: {old}")
            lines.append(f"    New: {new}")
        lines.append("")

    # Macros
    if diff.added_macros or diff.removed_macros or diff.modified_macros:
        lines.append(f"🔧 MACROS:")
        if diff.added_macros:
            lines.append(f"  Added ({len(diff.added_macros)}):")
            for macro in diff.added_macros:
                lines.append(f"    + {macro['macro']}: {macro.get('value', '')}")

        if diff.removed_macros:
            lines.append(f"  Removed ({len(diff.removed_macros)}):")
            for macro in diff.removed_macros:
                lines.append(f"    - {macro['macro']}: {macro.get('value', '')}")

        if diff.modified_macros:
            lines.append(f"  Modified ({len(diff.modified_macros)}):")
            for old, new in diff.modified_macros:
                lines.append(f"    ~ {old['macro']}:")
                if old.get('value') != new.get('value'):
                    lines.append(f"      Value: {old.get('value')} -> {new.get('value')}")
                if old.get('description') != new.get('description'):
                    lines.append(f"      Description changed")
        lines.append("")

    # Items
    if diff.added_items or diff.removed_items or diff.modified_items:
        lines.append(f"📊 ITEMS:")
        if diff.added_items:
            lines.append(f"  Added ({len(diff.added_items)}):")
            for item in diff.added_items:
                lines.append(f"    + {item.get('name', 'Unnamed')} [{item.get('key', '')}]")

        if diff.removed_items:
            lines.append(f"  Removed ({len(diff.removed_items)}):")
            for item in diff.removed_items:
                lines.append(f"    - {item.get('name', 'Unnamed')} [{item.get('key', '')}]")

        if diff.modified_items:
            lines.append(f"  Modified ({len(diff.modified_items)}):")
            for old, new in diff.modified_items:
                lines.append(f"    ~ {old.get('name', 'Unnamed')} [{old.get('key', '')}]")
                if detailed:
                    if old.get('delay') != new.get('delay'):
                        lines.append(f"      Delay: {old.get('delay')} -> {new.get('delay')}")
                    if old.get('history') != new.get('history'):
                        lines.append(f"      History: {old.get('history')} -> {new.get('history')}")
        lines.append("")

    # Triggers
    if diff.added_triggers or diff.removed_triggers or diff.modified_triggers:
        lines.append(f"[WARN]️  TRIGGERS:")
        if diff.added_triggers:
            lines.append(f"  Added ({len(diff.added_triggers)}):")
            for trigger in diff.added_triggers:
                lines.append(f"    + {trigger.get('name', 'Unnamed')}")

        if diff.removed_triggers:
            lines.append(f"  Removed ({len(diff.removed_triggers)}):")
            for trigger in diff.removed_triggers:
                lines.append(f"    - {trigger.get('name', 'Unnamed')}")

        if diff.modified_triggers:
            lines.append(f"  Modified ({len(diff.modified_triggers)}):")
            for old, new in diff.modified_triggers:
                lines.append(f"    ~ {old.get('name', 'Unnamed')}")
                if detailed and old.get('expression') != new.get('expression'):
                    lines.append(f"      Expression changed")
                    lines.append(f"      Old: {old.get('expression', '')[:60]}...")
                    lines.append(f"      New: {new.get('expression', '')[:60]}...")
        lines.append("")

    # Discovery rules
    if diff.added_discovery_rules or diff.removed_discovery_rules or diff.modified_discovery_rules:
        lines.append(f"🔍 DISCOVERY RULES:")
        if diff.added_discovery_rules:
            lines.append(f"  Added ({len(diff.added_discovery_rules)}):")
            for rule in diff.added_discovery_rules:
                lines.append(f"    + {rule.get('name', 'Unnamed')} [{rule.get('key', '')}]")

        if diff.removed_discovery_rules:
            lines.append(f"  Removed ({len(diff.removed_discovery_rules)}):")
            for rule in diff.removed_discovery_rules:
                lines.append(f"    - {rule.get('name', 'Unnamed')} [{rule.get('key', '')}]")

        if diff.modified_discovery_rules:
            lines.append(f"  Modified ({len(diff.modified_discovery_rules)}):")
            for old, new in diff.modified_discovery_rules:
                lines.append(f"    ~ {old.get('name', 'Unnamed')} [{old.get('key', '')}]")
        lines.append("")

    # Summary
    lines.append(f"{'='*70}")
    lines.append("SUMMARY:")
    total_changes = (
        len(diff.added_items) + len(diff.removed_items) + len(diff.modified_items) +
        len(diff.added_triggers) + len(diff.removed_triggers) + len(diff.modified_triggers) +
        len(diff.added_macros) + len(diff.removed_macros) + len(diff.modified_macros) +
        len(diff.added_discovery_rules) + len(diff.removed_discovery_rules) +
        len(diff.modified_discovery_rules) + len(diff.metadata_changes)
    )
    lines.append(f"  Total changes: {total_changes}")
    lines.append(f"{'='*70}\n")

    return '\n'.join(lines)


def compare_templates(file1: str, file2: str) -> TemplateDiff:
    """
    Compare two template files.

    Args:
        file1: First template file
        file2: Second template file

    Returns:
        TemplateDiff object
    """
    comparer = TemplateComparer()
    return comparer.compare_files(file1, file2)


def main():
    """CLI interface"""
    parser = argparse.ArgumentParser(
        description='Compare two Zabbix template files'
    )
    parser.add_argument('file1', help='First template file')
    parser.add_argument('file2', help='Second template file')
    parser.add_argument('--detailed', '-d', action='store_true',
                       help='Show detailed field-by-field differences')
    parser.add_argument('--json', action='store_true',
                       help='Output in JSON format')

    args = parser.parse_args()

    try:
        diff = compare_templates(args.file1, args.file2)

        if args.json:
            # Output as JSON (for programmatic use)
            import json
            from dataclasses import asdict
            print(json.dumps(asdict(diff), indent=2))
        else:
            # Human-readable output
            report = format_diff_report(diff, detailed=args.detailed)
            print(report)

        # Exit code: 0 if no differences, 1 if differences found
        return 0 if not diff.has_changes() else 1

    except Exception as e:
        print(f"Error: {e}")
        return 2


if __name__ == '__main__':
    exit(main())
