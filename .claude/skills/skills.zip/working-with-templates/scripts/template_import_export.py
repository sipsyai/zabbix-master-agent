#!/usr/bin/env python3
"""
Zabbix Template Import/Export Utility

Handles template import and export operations with support for multiple formats
(YAML, JSON, XML) and comprehensive error handling.

Author: Generated for Zabbix Skills
Version: 1.0.0
"""

import json
import yaml
import xml.etree.ElementTree as ET
import argparse
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional
from zabbix_template_manager import ZabbixTemplateManager, ZabbixAPIError

import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class TemplateImportExport:
    """
    Handles template import and export operations.

    Supports:
    - Multiple formats: YAML, JSON, XML
    - Batch operations
    - Dependency resolution
    - Format conversion
    """

    def __init__(self, manager: ZabbixTemplateManager):
        """
        Initialize import/export handler.

        Args:
            manager: ZabbixTemplateManager instance
        """
        self.manager = manager

    def export_template(self, template_names: List[str],
                       output_file: str,
                       format: str = 'yaml',
                       include_dependencies: bool = False) -> bool:
        """
        Export templates to file.

        Args:
            template_names: List of template names to export
            output_file: Output file path
            format: Export format (yaml, json, xml)
            include_dependencies: Include linked templates

        Returns:
            True if successful
        """
        logger.info(f"Exporting {len(template_names)} template(s) to {output_file}")

        # Get template IDs
        template_ids = []
        for name in template_names:
            template = self.manager.get_template(name)
            if template:
                template_ids.append(template['templateid'])
            else:
                logger.warning(f"Template not found: {name}")

        if not template_ids:
            raise ValueError("No valid templates found to export")

        # Build export options
        options = {
            'templates': template_ids
        }

        # Export using configuration.export API
        export_data = self.manager._call_api('configuration.export', {
            'options': options,
            'format': format
        })

        # Save to file
        output_path = Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        if format == 'yaml':
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(export_data)
        elif format == 'json':
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(export_data)
        elif format == 'xml':
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(export_data)
        else:
            raise ValueError(f"Unsupported format: {format}")

        logger.info(f"Export completed successfully: {output_file}")
        return True

    def import_template(self, file_path: str,
                       rules: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Import templates from file.

        Args:
            file_path: Path to template file
            rules: Import rules dictionary

        Returns:
            Import result dictionary
        """
        logger.info(f"Importing template from: {file_path}")

        # Read file content
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # Detect format
        format = self._detect_format(file_path, content)
        logger.info(f"Detected format: {format}")

        # Default import rules
        if rules is None:
            rules = {
                'templates': {
                    'createMissing': True,
                    'updateExisting': True
                },
                'items': {
                    'createMissing': True,
                    'updateExisting': True
                },
                'triggers': {
                    'createMissing': True,
                    'updateExisting': True
                },
                'graphs': {
                    'createMissing': True,
                    'updateExisting': True
                },
                'discoveryRules': {
                    'createMissing': True,
                    'updateExisting': True
                },
                'httptests': {
                    'createMissing': True,
                    'updateExisting': True
                },
                'templateDashboards': {
                    'createMissing': True,
                    'updateExisting': True
                },
                'valueMaps': {
                    'createMissing': True,
                    'updateExisting': True
                }
            }

        # Import using configuration.import API
        result = self.manager._call_api('configuration.import', {
            'format': format,
            'rules': rules,
            'source': content
        })

        logger.info("Import completed successfully")
        return result

    def bulk_export_templates(self, template_pattern: str,
                             output_dir: str,
                             format: str = 'yaml',
                             one_file_per_template: bool = True) -> int:
        """
        Export multiple templates matching pattern.

        Args:
            template_pattern: Template name pattern (SQL LIKE style)
            output_dir: Output directory
            format: Export format
            one_file_per_template: Create separate file for each template

        Returns:
            Number of templates exported
        """
        logger.info(f"Bulk exporting templates matching: {template_pattern}")

        # List matching templates
        templates = self.manager.list_templates(pattern=template_pattern)

        if not templates:
            logger.warning(f"No templates found matching: {template_pattern}")
            return 0

        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        exported_count = 0

        if one_file_per_template:
            # Export each template to separate file
            for template in templates:
                template_name = template['host']
                safe_name = template_name.replace('/', '_').replace(' ', '_')
                output_file = output_path / f"{safe_name}.{format}"

                try:
                    self.export_template(
                        template_names=[template_name],
                        output_file=str(output_file),
                        format=format
                    )
                    exported_count += 1
                except Exception as e:
                    logger.error(f"Failed to export {template_name}: {e}")
        else:
            # Export all to single file
            template_names = [t['host'] for t in templates]
            output_file = output_path / f"templates_bulk.{format}"
            self.export_template(
                template_names=template_names,
                output_file=str(output_file),
                format=format
            )
            exported_count = len(templates)

        logger.info(f"Exported {exported_count} templates to {output_dir}")
        return exported_count

    def bulk_import_templates(self, directory: str,
                             file_pattern: str = '*.yaml',
                             rules: Optional[Dict[str, Any]] = None,
                             stop_on_error: bool = False) -> Dict[str, Any]:
        """
        Import multiple template files from directory.

        Args:
            directory: Directory containing template files
            file_pattern: File pattern to match (e.g., '*.yaml')
            rules: Import rules
            stop_on_error: Stop on first error

        Returns:
            Import results dictionary
        """
        logger.info(f"Bulk importing templates from: {directory}")

        path = Path(directory)
        if not path.exists():
            raise FileNotFoundError(f"Directory not found: {directory}")

        # Find matching files
        files = list(path.glob(file_pattern))

        if not files:
            logger.warning(f"No files found matching: {file_pattern}")
            return {'success': 0, 'failed': 0, 'errors': []}

        results = {
            'success': 0,
            'failed': 0,
            'errors': []
        }

        for file_path in files:
            try:
                logger.info(f"Importing: {file_path.name}")
                self.import_template(str(file_path), rules)
                results['success'] += 1
            except Exception as e:
                logger.error(f"Failed to import {file_path.name}: {e}")
                results['failed'] += 1
                results['errors'].append({
                    'file': file_path.name,
                    'error': str(e)
                })

                if stop_on_error:
                    logger.error("Stopping due to error")
                    break

        logger.info(f"Bulk import completed. Success: {results['success']}, Failed: {results['failed']}")
        return results

    def convert_format(self, input_file: str, output_file: str,
                      output_format: str) -> bool:
        """
        Convert template file between formats.

        Args:
            input_file: Input file path
            output_file: Output file path
            output_format: Target format (yaml, json, xml)

        Returns:
            True if successful
        """
        logger.info(f"Converting {input_file} to {output_format}")

        # Read input file
        with open(input_file, 'r', encoding='utf-8') as f:
            content = f.read()

        input_format = self._detect_format(input_file, content)

        # Parse input
        if input_format == 'yaml':
            data = yaml.safe_load(content)
        elif input_format == 'json':
            data = json.loads(content)
        elif input_format == 'xml':
            # XML is more complex, use string directly
            data = content
        else:
            raise ValueError(f"Unsupported input format: {input_format}")

        # Write output
        with open(output_file, 'w', encoding='utf-8') as f:
            if output_format == 'yaml':
                yaml.dump(data, f, default_flow_style=False, allow_unicode=True)
            elif output_format == 'json':
                json.dump(data, f, indent=2, ensure_ascii=False)
            elif output_format == 'xml':
                if isinstance(data, str):
                    f.write(data)
                else:
                    raise ValueError("Cannot convert to XML from parsed data")
            else:
                raise ValueError(f"Unsupported output format: {output_format}")

        logger.info(f"Conversion completed: {output_file}")
        return True

    def _detect_format(self, file_path: str, content: str) -> str:
        """
        Detect file format from extension and content.

        Args:
            file_path: File path
            content: File content

        Returns:
            Format string (yaml, json, xml)
        """
        path = Path(file_path)
        ext = path.suffix.lower()

        # Check extension first
        if ext in ['.yaml', '.yml']:
            return 'yaml'
        elif ext == '.json':
            return 'json'
        elif ext == '.xml':
            return 'xml'

        # Try to detect from content
        content_stripped = content.strip()

        if content_stripped.startswith('<?xml') or content_stripped.startswith('<zabbix_export'):
            return 'xml'
        elif content_stripped.startswith('{'):
            return 'json'
        else:
            # Default to YAML
            return 'yaml'

    def export_for_version_control(self, template_names: List[str],
                                   output_dir: str,
                                   include_metadata: bool = True) -> bool:
        """
        Export templates optimized for version control.

        Args:
            template_names: List of template names
            output_dir: Output directory
            include_metadata: Include metadata file

        Returns:
            True if successful
        """
        logger.info("Exporting templates for version control")

        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        # Export each template
        for template_name in template_names:
            safe_name = template_name.replace('/', '_').replace(' ', '_')
            output_file = output_path / f"{safe_name}.yaml"

            self.export_template(
                template_names=[template_name],
                output_file=str(output_file),
                format='yaml'
            )

        # Create metadata file
        if include_metadata:
            metadata = {
                'templates': template_names,
                'exported_count': len(template_names),
                'format': 'yaml',
                'purpose': 'version_control'
            }

            metadata_file = output_path / 'metadata.json'
            with open(metadata_file, 'w') as f:
                json.dump(metadata, f, indent=2)

        logger.info(f"Version control export completed: {output_dir}")
        return True


def main():
    """CLI interface for template import/export"""
    parser = argparse.ArgumentParser(
        description='Zabbix Template Import/Export Utility'
    )

    parser.add_argument('--url', required=True,
                       help='Zabbix API URL')
    parser.add_argument('--token', required=True,
                       help='Zabbix API token')

    subparsers = parser.add_subparsers(dest='command', help='Command')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export templates')
    export_parser.add_argument('--template', required=True, action='append',
                              help='Template name (can be specified multiple times)')
    export_parser.add_argument('--output', required=True,
                              help='Output file path')
    export_parser.add_argument('--format', choices=['yaml', 'json', 'xml'],
                              default='yaml', help='Export format')
    export_parser.add_argument('--include-dependencies', action='store_true',
                              help='Include linked templates')

    # Import command
    import_parser = subparsers.add_parser('import', help='Import templates')
    import_parser.add_argument('--file', required=True,
                              help='Template file path')
    import_parser.add_argument('--create-missing', action='store_true',
                              help='Create missing entities')
    import_parser.add_argument('--update-existing', action='store_true',
                              help='Update existing entities')

    # Bulk export command
    bulk_export_parser = subparsers.add_parser('bulk-export',
                                              help='Bulk export templates')
    bulk_export_parser.add_argument('--pattern', required=True,
                                   help='Template name pattern')
    bulk_export_parser.add_argument('--output-dir', required=True,
                                   help='Output directory')
    bulk_export_parser.add_argument('--format', choices=['yaml', 'json', 'xml'],
                                   default='yaml', help='Export format')

    # Bulk import command
    bulk_import_parser = subparsers.add_parser('bulk-import',
                                              help='Bulk import templates')
    bulk_import_parser.add_argument('--directory', required=True,
                                   help='Input directory')
    bulk_import_parser.add_argument('--pattern', default='*.yaml',
                                   help='File pattern')

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    try:
        # Initialize manager
        manager = ZabbixTemplateManager(url=args.url, token=args.token)
        importer_exporter = TemplateImportExport(manager)

        if args.command == 'export':
            importer_exporter.export_template(
                template_names=args.template,
                output_file=args.output,
                format=args.format,
                include_dependencies=args.include_dependencies
            )
            print(f"Export successful: {args.output}")

        elif args.command == 'import':
            rules = None
            if args.create_missing or args.update_existing:
                rules = {
                    'templates': {
                        'createMissing': args.create_missing,
                        'updateExisting': args.update_existing
                    }
                }

            result = importer_exporter.import_template(args.file, rules)
            print(f"Import successful")

        elif args.command == 'bulk-export':
            count = importer_exporter.bulk_export_templates(
                template_pattern=args.pattern,
                output_dir=args.output_dir,
                format=args.format
            )
            print(f"Exported {count} templates to {args.output_dir}")

        elif args.command == 'bulk-import':
            results = importer_exporter.bulk_import_templates(
                directory=args.directory,
                file_pattern=args.pattern
            )
            print(f"Success: {results['success']}, Failed: {results['failed']}")
            if results['errors']:
                print("\nErrors:")
                for error in results['errors']:
                    print(f"  {error['file']}: {error['error']}")

    except Exception as e:
        print(f"Error: {e}")
        return 1

    return 0


if __name__ == '__main__':
    exit(main())
