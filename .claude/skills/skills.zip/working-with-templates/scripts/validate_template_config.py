#!/usr/bin/env python3
"""
Zabbix Template Configuration Validator

Validates template configuration files for syntax, required fields,
naming conventions, and logical consistency.

Author: Generated for Zabbix Skills
Version: 1.0.0
"""

import json
import yaml
import re
import argparse
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field


import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
@dataclass
class ValidationResult:
    """Validation result data class"""
    is_valid: bool = True
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    info: List[str] = field(default_factory=list)


class TemplateValidator:
    """
    Validates Zabbix template configuration files.

    Checks:
    - Syntax (YAML/JSON/XML)
    - Required fields
    - Naming conventions
    - Trigger expressions
    - Item keys
    - Macro format
    - Circular dependencies
    - Best practices
    """

    # Macro pattern
    MACRO_PATTERN = re.compile(r'^\{\$[A-Z0-9._]+\}$')

    # Item key pattern (basic)
    ITEM_KEY_PATTERN = re.compile(r'^[a-zA-Z0-9_.]+(\[.*\])?$')

    # Trigger expression patterns (basic validation)
    TRIGGER_FUNCTION_PATTERN = re.compile(
        r'(avg|min|max|sum|last|count|nodata|change|diff|fuzzytime|'
        r'logeventid|logseverity|logsource|now|time|dayofweek|dayofmonth|'
        r'date|iregexp|regexp|strlen|band|forecast|timeleft)\('
    )

    def __init__(self):
        """Initialize validator"""
        self.result = ValidationResult()

    def validate_file(self, file_path: str) -> ValidationResult:
        """
        Validate template file.

        Args:
            file_path: Path to template file

        Returns:
            ValidationResult object
        """
        self.result = ValidationResult()

        path = Path(file_path)
        if not path.exists():
            self.result.is_valid = False
            self.result.errors.append(f"File not found: {file_path}")
            return self.result

        # Read file
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            self.result.is_valid = False
            self.result.errors.append(f"Failed to read file: {e}")
            return self.result

        # Detect format and parse
        try:
            data = self._parse_content(file_path, content)
        except Exception as e:
            self.result.is_valid = False
            self.result.errors.append(f"Failed to parse file: {e}")
            return self.result

        # Validate structure
        self._validate_structure(data)

        # Validate templates
        if 'zabbix_export' in data:
            export_data = data['zabbix_export']

            # Validate version
            self._validate_version(export_data.get('version'))

            # Validate templates
            if 'templates' in export_data:
                for template in export_data['templates']:
                    self._validate_template(template)

        return self.result

    def _parse_content(self, file_path: str, content: str) -> Dict[str, Any]:
        """Parse file content based on format"""
        path = Path(file_path)
        ext = path.suffix.lower()

        if ext in ['.yaml', '.yml']:
            return yaml.safe_load(content)
        elif ext == '.json':
            return json.loads(content)
        elif ext == '.xml':
            # Basic XML validation - just check if it parses
            import xml.etree.ElementTree as ET
            ET.fromstring(content)
            # For full validation, would need to convert XML to dict
            return {'zabbix_export': {}}
        else:
            raise ValueError(f"Unsupported file format: {ext}")

    def _validate_structure(self, data: Dict[str, Any]):
        """Validate basic structure"""
        if 'zabbix_export' not in data:
            self.result.errors.append("Missing 'zabbix_export' root element")
            self.result.is_valid = False
            return

        export_data = data['zabbix_export']

        if 'version' not in export_data:
            self.result.warnings.append("Missing 'version' field")

        if 'templates' not in export_data:
            self.result.errors.append("No templates found in export")
            self.result.is_valid = False

    def _validate_version(self, version: Optional[str]):
        """Validate Zabbix version"""
        if not version:
            return

        # Version should be in format X.Y or X.Y.Z
        if not re.match(r'^\d+\.\d+(\.\d+)?$', version):
            self.result.warnings.append(f"Invalid version format: {version}")

    def _validate_template(self, template: Dict[str, Any]):
        """Validate template object"""
        # Required fields
        required_fields = ['template', 'name', 'groups']
        for field in required_fields:
            if field not in template:
                self.result.errors.append(
                    f"Template missing required field: {field}"
                )
                self.result.is_valid = False

        # Validate template name (host)
        if 'template' in template:
            self._validate_template_name(template['template'])

        # Validate groups
        if 'groups' in template:
            self._validate_groups(template['groups'])

        # Validate tags
        if 'tags' in template:
            self._validate_tags(template['tags'])

        # Validate macros
        if 'macros' in template:
            self._validate_macros(template['macros'])

        # Validate items
        if 'items' in template:
            self._validate_items(template['items'])

        # Validate triggers
        if 'triggers' in template:
            self._validate_triggers(template['triggers'], template.get('template', ''))

        # Validate discovery rules
        if 'discovery_rules' in template:
            self._validate_discovery_rules(template['discovery_rules'])

        # Check for circular dependencies in parent templates
        if 'templates' in template:
            self._check_circular_dependencies(
                template.get('template', ''),
                template['templates']
            )

    def _validate_template_name(self, name: str):
        """Validate template name"""
        if not name:
            self.result.errors.append("Template name cannot be empty")
            self.result.is_valid = False
            return

        # Template names should not contain special characters
        if not re.match(r'^[a-zA-Z0-9\s_\-./()]+$', name):
            self.result.warnings.append(
                f"Template name contains special characters: {name}"
            )

        # Best practice: meaningful name
        if len(name) < 5:
            self.result.warnings.append(
                f"Template name is very short: {name}"
            )

    def _validate_groups(self, groups: List[Dict[str, str]]):
        """Validate template groups"""
        if not groups:
            self.result.warnings.append("Template has no groups assigned")
            return

        for group in groups:
            if 'name' not in group:
                self.result.errors.append("Group missing 'name' field")
                self.result.is_valid = False

    def _validate_tags(self, tags: List[Dict[str, str]]):
        """Validate template tags"""
        if not tags:
            return

        seen_tags = set()
        for tag in tags:
            if 'tag' not in tag:
                self.result.errors.append("Tag missing 'tag' field")
                self.result.is_valid = False
                continue

            tag_name = tag['tag']

            # Check for duplicates
            if tag_name in seen_tags:
                self.result.warnings.append(f"Duplicate tag: {tag_name}")

            seen_tags.add(tag_name)

    def _validate_macros(self, macros: List[Dict[str, Any]]):
        """Validate template macros"""
        if not macros:
            return

        seen_macros = set()

        for macro in macros:
            if 'macro' not in macro:
                self.result.errors.append("Macro missing 'macro' field")
                self.result.is_valid = False
                continue

            macro_name = macro['macro']

            # Validate macro format
            if not self.MACRO_PATTERN.match(macro_name):
                self.result.errors.append(
                    f"Invalid macro format: {macro_name}. "
                    "Should be {{$NAME}} with uppercase letters, numbers, dots, underscores"
                )
                self.result.is_valid = False

            # Check for duplicates
            if macro_name in seen_macros:
                self.result.errors.append(f"Duplicate macro: {macro_name}")
                self.result.is_valid = False

            seen_macros.add(macro_name)

            # Check if value is provided
            if 'value' not in macro:
                self.result.warnings.append(
                    f"Macro {macro_name} has no default value"
                )

            # Best practice: include description
            if 'description' not in macro or not macro['description']:
                self.result.warnings.append(
                    f"Macro {macro_name} has no description"
                )

    def _validate_items(self, items: List[Dict[str, Any]]):
        """Validate template items"""
        if not items:
            return

        seen_keys = set()

        for item in items:
            # Required fields
            if 'name' not in item:
                self.result.errors.append("Item missing 'name' field")
                self.result.is_valid = False

            if 'key' not in item:
                self.result.errors.append("Item missing 'key' field")
                self.result.is_valid = False
                continue

            key = item['key']

            # Validate key format (basic)
            if not self.ITEM_KEY_PATTERN.match(key):
                self.result.warnings.append(
                    f"Item key may have invalid format: {key}"
                )

            # Check for duplicate keys
            if key in seen_keys:
                self.result.errors.append(f"Duplicate item key: {key}")
                self.result.is_valid = False

            seen_keys.add(key)

            # Validate type
            if 'type' in item:
                item_type = item['type']
                # Type should be integer or valid string constant
                valid_types = [
                    'ZABBIX_PASSIVE', 'TRAP', 'SIMPLE', 'INTERNAL',
                    'ZABBIX_ACTIVE', 'EXTERNAL', 'ODBC', 'IPMI', 'SSH',
                    'TELNET', 'CALCULATED', 'JMX', 'SNMP_TRAP', 'DEPENDENT',
                    'HTTP_AGENT', 'SNMP_AGENT', 'ITEM_TYPE_SCRIPT', 'ITEM_TYPE_BROWSER'
                ]
                if isinstance(item_type, str) and item_type not in valid_types:
                    self.result.warnings.append(
                        f"Unknown item type: {item_type} for key {key}"
                    )

            # Validate dependent items have master_item
            if item.get('type') == 'DEPENDENT' or item.get('type') == 18:
                if 'master_item' not in item:
                    self.result.errors.append(
                        f"Dependent item {key} missing master_item"
                    )
                    self.result.is_valid = False

            # Validate preprocessing steps
            if 'preprocessing' in item:
                self._validate_preprocessing(item['preprocessing'], key)

    def _validate_preprocessing(self, preprocessing: List[Dict[str, Any]],
                               item_key: str):
        """Validate item preprocessing steps"""
        for i, step in enumerate(preprocessing):
            if 'type' not in step:
                self.result.errors.append(
                    f"Preprocessing step {i+1} for {item_key} missing 'type'"
                )
                self.result.is_valid = False

            # Some preprocessing types require parameters
            step_type = step.get('type', '')
            requires_params = [
                'MULTIPLIER', 'RTRIM', 'LTRIM', 'TRIM', 'REGEX',
                'XMLPATH', 'JSONPATH', 'IN_RANGE', 'MATCHES_REGEX',
                'NOT_MATCHES_REGEX', 'JAVASCRIPT', 'PROMETHEUS_PATTERN',
                'CSV_TO_JSON', 'STR_REPLACE'
            ]

            if step_type in requires_params:
                if 'parameters' not in step or not step['parameters']:
                    self.result.warnings.append(
                        f"Preprocessing step {step_type} for {item_key} "
                        "may require parameters"
                    )

    def _validate_triggers(self, triggers: List[Dict[str, Any]],
                          template_name: str):
        """Validate template triggers"""
        if not triggers:
            return

        for trigger in triggers:
            # Required fields
            if 'name' not in trigger or 'description' not in trigger:
                self.result.errors.append("Trigger missing 'name' or 'description'")
                self.result.is_valid = False

            if 'expression' not in trigger:
                self.result.errors.append("Trigger missing 'expression'")
                self.result.is_valid = False
                continue

            expression = trigger['expression']

            # Basic expression validation
            self._validate_trigger_expression(expression, template_name)

            # Validate priority
            if 'priority' in trigger:
                priority = trigger['priority']
                valid_priorities = [
                    'NOT_CLASSIFIED', 'INFO', 'WARNING', 'AVERAGE', 'HIGH', 'DISASTER',
                    0, 1, 2, 3, 4, 5
                ]
                if priority not in valid_priorities:
                    self.result.warnings.append(
                        f"Invalid trigger priority: {priority}"
                    )

    def _validate_trigger_expression(self, expression: str, template_name: str):
        """Validate trigger expression (basic checks)"""
        if not expression:
            return

        # Check for balanced parentheses
        if expression.count('(') != expression.count(')'):
            self.result.errors.append(
                f"Unbalanced parentheses in trigger expression: {expression[:50]}..."
            )
            self.result.is_valid = False

        # Check for valid trigger functions
        if not self.TRIGGER_FUNCTION_PATTERN.search(expression):
            self.result.warnings.append(
                f"No recognized trigger functions in expression: {expression[:50]}..."
            )

        # Check if template name is referenced (if provided)
        if template_name and template_name not in expression:
            self.result.warnings.append(
                f"Trigger expression may not reference template items: {expression[:50]}..."
            )

    def _validate_discovery_rules(self, rules: List[Dict[str, Any]]):
        """Validate low-level discovery rules"""
        if not rules:
            return

        seen_keys = set()

        for rule in rules:
            # Required fields
            if 'name' not in rule:
                self.result.errors.append("Discovery rule missing 'name'")
                self.result.is_valid = False

            if 'key' not in rule:
                self.result.errors.append("Discovery rule missing 'key'")
                self.result.is_valid = False
                continue

            key = rule['key']

            # Check for duplicates
            if key in seen_keys:
                self.result.errors.append(f"Duplicate discovery rule key: {key}")
                self.result.is_valid = False

            seen_keys.add(key)

            # Validate item prototypes
            if 'item_prototypes' in rule:
                self._validate_item_prototypes(rule['item_prototypes'], key)

            # Validate trigger prototypes
            if 'trigger_prototypes' in rule:
                self._validate_trigger_prototypes(rule['trigger_prototypes'])

    def _validate_item_prototypes(self, prototypes: List[Dict[str, Any]],
                                  rule_key: str):
        """Validate item prototypes"""
        for prototype in prototypes:
            if 'key' not in prototype:
                self.result.errors.append(
                    f"Item prototype in rule {rule_key} missing 'key'"
                )
                self.result.is_valid = False
                continue

            # Item prototypes should contain LLD macros
            key = prototype['key']
            if not re.search(r'\{#[A-Z0-9._]+\}', key):
                self.result.warnings.append(
                    f"Item prototype key may be missing LLD macro: {key}"
                )

    def _validate_trigger_prototypes(self, prototypes: List[Dict[str, Any]]):
        """Validate trigger prototypes"""
        for prototype in prototypes:
            if 'expression' not in prototype:
                self.result.errors.append("Trigger prototype missing 'expression'")
                self.result.is_valid = False
                continue

            # Trigger prototypes should contain LLD macros
            expression = prototype['expression']
            if not re.search(r'\{#[A-Z0-9._]+\}', expression):
                self.result.warnings.append(
                    "Trigger prototype may be missing LLD macro in expression"
                )

    def _check_circular_dependencies(self, template_name: str,
                                    parent_templates: List[Dict[str, str]]):
        """Check for circular dependencies in template inheritance"""
        if not parent_templates:
            return

        for parent in parent_templates:
            if 'name' in parent:
                parent_name = parent['name']
                # Simple check: template links to itself
                if parent_name == template_name:
                    self.result.errors.append(
                        f"Circular dependency: template links to itself ({template_name})"
                    )
                    self.result.is_valid = False


def validate_template(file_path: str) -> ValidationResult:
    """
    Validate template file.

    Args:
        file_path: Path to template file

    Returns:
        ValidationResult object
    """
    validator = TemplateValidator()
    return validator.validate_file(file_path)


def main():
    """CLI interface"""
    parser = argparse.ArgumentParser(
        description='Validate Zabbix template configuration files'
    )
    parser.add_argument('file', help='Template file to validate')
    parser.add_argument('--verbose', '-v', action='store_true',
                       help='Show detailed output')
    parser.add_argument('--warnings-as-errors', action='store_true',
                       help='Treat warnings as errors')

    args = parser.parse_args()

    result = validate_template(args.file)

    # Print results
    print(f"\nValidation Results for: {args.file}")
    print("=" * 60)

    if result.errors:
        print(f"\n[ERROR] ERRORS ({len(result.errors)}):")
        for error in result.errors:
            print(f"  - {error}")

    if result.warnings:
        print(f"\n[WARN]️  WARNINGS ({len(result.warnings)}):")
        for warning in result.warnings:
            print(f"  - {warning}")

    if args.verbose and result.info:
        print(f"\nℹ️  INFO ({len(result.info)}):")
        for info in result.info:
            print(f"  - {info}")

    # Determine exit code
    if not result.is_valid:
        print("\n[ERROR] Validation FAILED")
        return 1
    elif args.warnings_as_errors and result.warnings:
        print("\n[ERROR] Validation FAILED (warnings treated as errors)")
        return 1
    else:
        print("\n[OK] Validation PASSED")
        if result.warnings:
            print(f"   ({len(result.warnings)} warnings)")
        return 0


if __name__ == '__main__':
    exit(main())
