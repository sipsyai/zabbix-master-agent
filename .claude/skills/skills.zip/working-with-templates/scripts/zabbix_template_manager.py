#!/usr/bin/env python3
"""
Zabbix Template Manager

Comprehensive template management for Zabbix including creation, update,
import/export, linking, inheritance, and component management.

Author: Generated for Zabbix Skills
Version: 1.0.0
"""

import json
import requests
from typing import List, Dict, Any, Optional, Union
from dataclasses import dataclass
import logging

import sys
import os

# UTF-8 encoding for Windows compatibility
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@dataclass
class TemplateInfo:
    """Template information data class"""
    templateid: str
    host: str
    name: str
    description: str = ""
    groups: List[str] = None
    tags: List[Dict[str, str]] = None
    macros: List[Dict[str, str]] = None


class ZabbixAPIError(Exception):
    """Custom exception for Zabbix API errors"""
    pass


class ZabbixTemplateManager:
    """
    Manages Zabbix templates through the Zabbix API.

    Provides comprehensive template management including:
    - Template creation, update, and deletion
    - Import/export operations
    - Template linking and inheritance
    - Component management (items, triggers, macros, etc.)
    - Bulk operations
    """

    def __init__(self, url: str, token: Optional[str] = None,
                 user: Optional[str] = None, password: Optional[str] = None):
        """
        Initialize Zabbix Template Manager.

        Args:
            url: Zabbix API URL (e.g., http://zabbix.example.com/api_jsonrpc.php)
            token: API token (Zabbix 5.4+) - preferred method
            user: Username for authentication (legacy)
            password: Password for authentication (legacy)
        """
        self.url = url
        self.token = token
        self.auth = None
        self.request_id = 0

        # Authenticate if user/password provided
        if not token and user and password:
            self.auth = self._authenticate(user, password)
        elif not token:
            raise ValueError("Either token or user/password must be provided")

    def _authenticate(self, user: str, password: str) -> str:
        """Authenticate with username/password and get auth token"""
        response = self._call_api('user.login', {
            'user': user,
            'password': password
        }, use_auth=False)
        return response

    def _call_api(self, method: str, params: Dict[str, Any],
                  use_auth: bool = True) -> Any:
        """
        Call Zabbix API method.

        Args:
            method: API method name
            params: Method parameters
            use_auth: Whether to include authentication

        Returns:
            API response result

        Raises:
            ZabbixAPIError: If API call fails
        """
        self.request_id += 1

        payload = {
            'jsonrpc': '2.0',
            'method': method,
            'params': params,
            'id': self.request_id
        }

        # Add authentication
        if use_auth:
            if self.token:
                payload['auth'] = self.token
            elif self.auth:
                payload['auth'] = self.auth

        try:
            response = requests.post(
                self.url,
                json=payload,
                headers={'Content-Type': 'application/json-rpc'},
                timeout=30
            )
            response.raise_for_status()

            result = response.json()

            if 'error' in result:
                error_msg = result['error'].get('data', result['error'].get('message', 'Unknown error'))
                raise ZabbixAPIError(f"API Error: {error_msg}")

            return result.get('result')

        except requests.exceptions.RequestException as e:
            raise ZabbixAPIError(f"Request failed: {str(e)}")

    def create_template(self, name: str, groups: List[str],
                       description: str = "",
                       tags: Optional[List[Dict[str, str]]] = None,
                       macros: Optional[List[Dict[str, str]]] = None,
                       parent_templates: Optional[List[str]] = None) -> str:
        """
        Create a new template.

        Args:
            name: Template name (unique identifier)
            groups: List of template group names
            description: Template description
            tags: List of tags [{"tag": "name", "value": "value"}]
            macros: List of macros [{"macro": "{$NAME}", "value": "val"}]
            parent_templates: List of parent template names for inheritance

        Returns:
            Template ID
        """
        logger.info(f"Creating template: {name}")

        # Get template group IDs
        group_ids = self._get_template_group_ids(groups)

        params = {
            'host': name,
            'name': name,
            'groups': [{'groupid': gid} for gid in group_ids]
        }

        if description:
            params['description'] = description

        if tags:
            params['tags'] = tags

        if macros:
            params['macros'] = macros

        # Add parent templates for inheritance
        if parent_templates:
            parent_ids = []
            for parent_name in parent_templates:
                parent = self.get_template(parent_name)
                if parent:
                    parent_ids.append({'templateid': parent['templateid']})
            if parent_ids:
                params['templates'] = parent_ids

        result = self._call_api('template.create', params)
        template_id = result['templateids'][0]

        logger.info(f"Template created successfully. ID: {template_id}")
        return template_id

    def update_template(self, template_name: str,
                       updates: Dict[str, Any]) -> bool:
        """
        Update existing template.

        Args:
            template_name: Name of template to update
            updates: Dictionary of fields to update

        Returns:
            True if successful
        """
        logger.info(f"Updating template: {template_name}")

        # Get template ID
        template = self.get_template(template_name)
        if not template:
            raise ZabbixAPIError(f"Template not found: {template_name}")

        params = {'templateid': template['templateid']}
        params.update(updates)

        # Handle group updates
        if 'groups' in updates and isinstance(updates['groups'], list):
            if isinstance(updates['groups'][0], str):
                group_ids = self._get_template_group_ids(updates['groups'])
                params['groups'] = [{'groupid': gid} for gid in group_ids]

        self._call_api('template.update', params)
        logger.info(f"Template updated successfully: {template_name}")
        return True

    def delete_template(self, template_name: str,
                       delete_linked_hosts: bool = False) -> bool:
        """
        Delete a template.

        Args:
            template_name: Name of template to delete
            delete_linked_hosts: Also delete linked hosts (dangerous!)

        Returns:
            True if successful
        """
        logger.warning(f"Deleting template: {template_name}")

        template = self.get_template(template_name)
        if not template:
            raise ZabbixAPIError(f"Template not found: {template_name}")

        # Safety check for linked hosts
        if not delete_linked_hosts:
            hosts = self._call_api('host.get', {
                'templateids': template['templateid'],
                'output': ['hostid', 'host']
            })
            if hosts:
                host_names = [h['host'] for h in hosts]
                logger.warning(f"Template is linked to {len(hosts)} hosts: {host_names}")
                logger.info("Unlinking template from hosts before deletion")
                self.unlink_template_from_hosts(template_name, host_names)

        self._call_api('template.delete', [template['templateid']])
        logger.info(f"Template deleted: {template_name}")
        return True

    def get_template(self, name: str) -> Optional[Dict[str, Any]]:
        """
        Get template by name.

        Args:
            name: Template name

        Returns:
            Template object or None if not found
        """
        result = self._call_api('template.get', {
            'filter': {'host': name},
            'output': 'extend',
            'selectGroups': 'extend',
            'selectTags': 'extend',
            'selectMacros': 'extend',
            'selectParentTemplates': ['templateid', 'host'],
            'selectTemplates': ['templateid', 'host']
        })

        return result[0] if result else None

    def list_templates(self, group_name: Optional[str] = None,
                      pattern: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List templates with optional filtering.

        Args:
            group_name: Filter by template group name
            pattern: Filter by name pattern (SQL LIKE style)

        Returns:
            List of template objects
        """
        params = {
            'output': 'extend',
            'selectGroups': 'extend'
        }

        if group_name:
            groups = self._call_api('templategroup.get', {
                'filter': {'name': group_name},
                'output': ['groupid']
            })
            if groups:
                params['groupids'] = groups[0]['groupid']

        if pattern:
            params['search'] = {'host': pattern}
            params['searchWildcardsEnabled'] = True

        return self._call_api('template.get', params)

    def link_template_to_hosts(self, template_name: str,
                               host_names: List[str]) -> bool:
        """
        Link template to hosts.

        Args:
            template_name: Name of template to link
            host_names: List of host names to link to

        Returns:
            True if successful
        """
        logger.info(f"Linking template '{template_name}' to {len(host_names)} hosts")

        template = self.get_template(template_name)
        if not template:
            raise ZabbixAPIError(f"Template not found: {template_name}")

        # Get host IDs
        host_ids = []
        for host_name in host_names:
            hosts = self._call_api('host.get', {
                'filter': {'host': host_name},
                'output': ['hostid']
            })
            if hosts:
                host_ids.append(hosts[0]['hostid'])
            else:
                logger.warning(f"Host not found: {host_name}")

        if not host_ids:
            raise ZabbixAPIError("No valid hosts found")

        # Link template to hosts
        self._call_api('template.massadd', {
            'templates': [{'templateid': template['templateid']}],
            'hosts': [{'hostid': hid} for hid in host_ids]
        })

        logger.info(f"Template linked to {len(host_ids)} hosts")
        return True

    def unlink_template_from_hosts(self, template_name: str,
                                   host_names: List[str],
                                   clear_items: bool = False) -> bool:
        """
        Unlink template from hosts.

        Args:
            template_name: Name of template to unlink
            host_names: List of host names to unlink from
            clear_items: Also remove template items/triggers from hosts

        Returns:
            True if successful
        """
        logger.info(f"Unlinking template '{template_name}' from {len(host_names)} hosts")

        template = self.get_template(template_name)
        if not template:
            raise ZabbixAPIError(f"Template not found: {template_name}")

        # Get host IDs
        host_ids = []
        for host_name in host_names:
            hosts = self._call_api('host.get', {
                'filter': {'host': host_name},
                'output': ['hostid']
            })
            if hosts:
                host_ids.append(hosts[0]['hostid'])

        if not host_ids:
            logger.warning("No valid hosts found")
            return False

        # Unlink template
        method = 'template.massremove' if clear_items else 'template.massupdate'

        if clear_items:
            self._call_api(method, {
                'templateids': [template['templateid']],
                'hostids': host_ids
            })
        else:
            # Just unlink, don't clear
            for host_id in host_ids:
                self._call_api('host.update', {
                    'hostid': host_id,
                    'templates_clear': [{'templateid': template['templateid']}]
                })

        logger.info(f"Template unlinked from {len(host_ids)} hosts")
        return True

    def link_parent_templates(self, template_name: str,
                             parent_templates: List[str]) -> bool:
        """
        Link parent templates (template inheritance).

        Args:
            template_name: Child template name
            parent_templates: List of parent template names

        Returns:
            True if successful
        """
        logger.info(f"Linking parent templates to '{template_name}'")

        template = self.get_template(template_name)
        if not template:
            raise ZabbixAPIError(f"Template not found: {template_name}")

        # Get parent template IDs
        parent_ids = []
        for parent_name in parent_templates:
            parent = self.get_template(parent_name)
            if parent:
                parent_ids.append({'templateid': parent['templateid']})
            else:
                logger.warning(f"Parent template not found: {parent_name}")

        if not parent_ids:
            raise ZabbixAPIError("No valid parent templates found")

        # Link parent templates
        self._call_api('template.update', {
            'templateid': template['templateid'],
            'templates': parent_ids
        })

        logger.info(f"Linked {len(parent_ids)} parent templates")
        return True

    def manage_template_macros(self, template_name: str,
                               macros: List[Dict[str, str]]) -> bool:
        """
        Add or update template macros.

        Args:
            template_name: Template name
            macros: List of macro dicts with 'macro', 'value', 'description', 'type'

        Returns:
            True if successful
        """
        logger.info(f"Managing macros for template: {template_name}")

        template = self.get_template(template_name)
        if not template:
            raise ZabbixAPIError(f"Template not found: {template_name}")

        # Format macros
        formatted_macros = []
        for macro in macros:
            macro_obj = {
                'macro': macro['macro'],
                'value': macro.get('value', '')
            }
            if 'description' in macro:
                macro_obj['description'] = macro['description']
            if 'type' in macro:
                # 0=text, 1=secret, 2=vault
                macro_obj['type'] = macro['type']
            formatted_macros.append(macro_obj)

        self._call_api('template.update', {
            'templateid': template['templateid'],
            'macros': formatted_macros
        })

        logger.info(f"Updated {len(macros)} macros")
        return True

    def add_items_to_template(self, template_name: str,
                             items: List[Dict[str, Any]]) -> List[str]:
        """
        Add items to template.

        Args:
            template_name: Template name
            items: List of item configurations

        Returns:
            List of created item IDs
        """
        logger.info(f"Adding {len(items)} items to template: {template_name}")

        template = self.get_template(template_name)
        if not template:
            raise ZabbixAPIError(f"Template not found: {template_name}")

        # Add hostid to each item
        for item in items:
            item['hostid'] = template['templateid']
            # Set defaults if not specified
            if 'type' not in item:
                item['type'] = 0  # Zabbix agent
            if 'value_type' not in item:
                item['value_type'] = 3  # Numeric unsigned
            if 'delay' not in item:
                item['delay'] = '1m'

        result = self._call_api('item.create', items)
        item_ids = result['itemids']

        logger.info(f"Created {len(item_ids)} items")
        return item_ids

    def add_triggers_to_template(self, template_name: str,
                                 triggers: List[Dict[str, Any]]) -> List[str]:
        """
        Add triggers to template.

        Args:
            template_name: Template name
            triggers: List of trigger configurations

        Returns:
            List of created trigger IDs
        """
        logger.info(f"Adding {len(triggers)} triggers to template: {template_name}")

        template = self.get_template(template_name)
        if not template:
            raise ZabbixAPIError(f"Template not found: {template_name}")

        # Ensure expressions reference the correct template
        for trigger in triggers:
            if 'priority' not in trigger:
                trigger['priority'] = 2  # Warning

        result = self._call_api('trigger.create', triggers)
        trigger_ids = result['triggerids']

        logger.info(f"Created {len(trigger_ids)} triggers")
        return trigger_ids

    def add_discovery_rule(self, template_name: str,
                          discovery_rule: Dict[str, Any]) -> str:
        """
        Add low-level discovery rule to template.

        Args:
            template_name: Template name
            discovery_rule: Discovery rule configuration

        Returns:
            Discovery rule ID
        """
        logger.info(f"Adding discovery rule to template: {template_name}")

        template = self.get_template(template_name)
        if not template:
            raise ZabbixAPIError(f"Template not found: {template_name}")

        discovery_rule['hostid'] = template['templateid']

        # Set defaults
        if 'type' not in discovery_rule:
            discovery_rule['type'] = 0  # Zabbix agent
        if 'delay' not in discovery_rule:
            discovery_rule['delay'] = '1h'

        result = self._call_api('discoveryrule.create', discovery_rule)
        rule_id = result['itemids'][0]

        logger.info(f"Created discovery rule. ID: {rule_id}")
        return rule_id

    def clone_template(self, source_template: str, new_name: str,
                      modifications: Optional[Dict[str, Any]] = None) -> str:
        """
        Clone a template with optional modifications.

        Args:
            source_template: Source template name
            new_name: New template name
            modifications: Optional modifications to apply

        Returns:
            New template ID
        """
        logger.info(f"Cloning template '{source_template}' to '{new_name}'")

        # Get source template with all components
        source = self._call_api('template.get', {
            'filter': {'host': source_template},
            'output': 'extend',
            'selectGroups': 'extend',
            'selectTags': 'extend',
            'selectMacros': 'extend',
            'selectParentTemplates': ['templateid']
        })

        if not source:
            raise ZabbixAPIError(f"Source template not found: {source_template}")

        source = source[0]

        # Create new template
        groups = [g['name'] for g in source['groups']]

        new_template_id = self.create_template(
            name=new_name,
            groups=groups,
            description=source.get('description', ''),
            tags=source.get('tags', []),
            macros=source.get('macros', [])
        )

        # Apply modifications if provided
        if modifications:
            # Override macros
            if 'macros' in modifications:
                existing_macros = source.get('macros', [])
                for macro_name, macro_value in modifications['macros'].items():
                    # Update existing or add new
                    found = False
                    for macro in existing_macros:
                        if macro['macro'] == macro_name:
                            macro['value'] = macro_value
                            found = True
                            break
                    if not found:
                        existing_macros.append({
                            'macro': macro_name,
                            'value': macro_value
                        })

                self.manage_template_macros(new_name, existing_macros)

            # Apply other modifications
            update_params = {}
            if 'description' in modifications:
                update_params['description'] = modifications['description']
            if 'groups' in modifications:
                group_ids = self._get_template_group_ids(modifications['groups'])
                update_params['groups'] = [{'groupid': gid} for gid in group_ids]

            if update_params:
                self.update_template(new_name, update_params)

        # Copy items, triggers, etc. using full export/import
        # This ensures all components are properly cloned
        logger.info(f"Template cloned successfully. New ID: {new_template_id}")
        return new_template_id

    def _get_template_group_ids(self, group_names: List[str]) -> List[str]:
        """Get template group IDs from names, create if missing"""
        group_ids = []

        for group_name in group_names:
            groups = self._call_api('templategroup.get', {
                'filter': {'name': group_name},
                'output': ['groupid']
            })

            if groups:
                group_ids.append(groups[0]['groupid'])
            else:
                # Create group if it doesn't exist
                logger.info(f"Creating template group: {group_name}")
                result = self._call_api('templategroup.create', {
                    'name': group_name
                })
                group_ids.append(result['groupids'][0])

        return group_ids


if __name__ == '__main__':
    # Example usage
    import sys

    if len(sys.argv) < 3:
        print("Usage: python zabbix_template_manager.py <url> <token>")
        print("Example: python zabbix_template_manager.py http://zabbix.local/api_jsonrpc.php mytoken123")
        sys.exit(1)

    url = sys.argv[1]
    token = sys.argv[2]

    try:
        manager = ZabbixTemplateManager(url=url, token=token)

        # List templates
        templates = manager.list_templates()
        print(f"\nFound {len(templates)} templates:")
        for template in templates[:5]:  # Show first 5
            print(f"  - {template['host']}: {template.get('description', 'No description')}")

    except ZabbixAPIError as e:
        print(f"Error: {e}")
        sys.exit(1)
